#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# SimpleSSHTest.py - 交互式测试工具 (优化版)

import sys
import signal
import shlex
import time
import platform
from SimpleSSHWrapper import SimpleSSHWrapper
from SimpleSSHDef import get_status_desc

class SimpleSSHTest:
    def __init__(self):
        self.api = None
        self.running = True
        self.active_ids = set()
        try:
            self.api = SimpleSSHWrapper()
        except Exception as e:
            print(f"[致命错误] 初始化失败: {e}")
            self.api = None

    def cleanup(self):
        if not self.api: return
        if self.active_ids:
            print("\n[清理] 关闭所有活跃连接...")
            for id_ in list(self.active_ids):
                self.api.close(id_)
        self.api.close_log()

    def run(self):
        print("=" * 70)
        print(f"SimpleSSH 交互式测试工具 v1.3.1 {platform.architecture()[0]}")
        print("=" * 70)
        
        if not self.api: return

        print("提示: 输入 --help 查看常用命令示例")
        print("提示: 输入 --exit 退出程序")

        while self.running:
            try:
                # 捕获 Ctrl+C 导致的输入中断
                try:
                    raw = input("\nSimpleSSH >>> ").strip()
                except EOFError:
                    break
                
                if not raw: continue
                
                # 使用 shlex 处理引号包含空格的情况 (例如 -cmd "ls -l")
                args = shlex.split(raw)
                if not args: continue
                
                # 统一转换为小写命令，方便匹配
                cmd = args[0].lower()

                if cmd == "--exit": break
                elif cmd == "--help": self.print_help()
                elif cmd == "--log": self.do_log(args)
                elif cmd == "--connect": self.do_connect(args)
                elif cmd == "--close": self.do_close(args)
                elif cmd == "--exec": self.do_exec(args)
                elif cmd == "--start": self.do_start(args)
                elif cmd == "--read": self.do_read(args)
                elif cmd == "--stop": self.do_stop(args)
                elif cmd == "--upload": self.do_upload(args)
                elif cmd == "--download": self.do_download(args)
                else: print(f"[错误] 未知命令: {cmd} (输入 --help 查看列表)")

            except KeyboardInterrupt:
                print("\n[提示] 输入 --exit 退出，或继续输入命令")
            except Exception as e:
                print(f"[异常] {e}")

        self.cleanup()

    def print_help(self):
        print("\n" + "-" * 70)
        print(" 命令使用示例 (可以直接复制修改)")
        print("-" * 70)
        
        print("\n[1. 基础控制]")
        print("  开启日志:   --log on")
        print("  关闭日志:   --log off")
        print("  退出程序:   --exit")

        print("\n[2. 连接管理]")
        print("  连接服务器 (注意参数前是双杠 --):")
        print("    --connect --host 192.168.1.120 --user root --pass 123456")
        print("  断开连接:")
        print("    --close -id 1")

        print("\n[3. 命令执行]")
        print("  同步执行 (等待结果):")
        print("    --exec -id 1 -cmd \"ls -l /tmp\"")
        print("  异步执行 (配合 --read 使用):")
        print("    --start -id 1 -cmd \"ping 8.8.8.8\"")
        print("    --read -id 1 -timeout 100")
        print("    --stop -id 1")

        print("\n[4. 文件传输 (SFTP)]")
        print("  上传文件 (注意: 远程路径建议包含文件名):")
        print("    --upload -id 1 -local D:\\test.txt -remote /tmp/test.txt")
        print("  下载文件:")
        print("    --download -id 1 -remote /var/log/syslog -local D:\\syslog.txt")
        print("-" * 70)

    def extract_arg(self, args, key, default=None):
        """从参数列表中提取值，例如 extract_arg(['-id', '1'], '-id') -> '1'"""
        try:
            if key in args:
                return args[args.index(key) + 1]
        except IndexError: pass
        return default

    # --- Command Handlers ---

    def do_log(self, args):
        if "on" in args:
            ret = self.api.open_log()
            print(f"[log] 开启: {get_status_desc(ret)}")
        elif "off" in args:
            ret = self.api.close_log()
            print(f"[log] 关闭: {get_status_desc(ret)}")

    def do_connect(self, args):
        cmd_str = " ".join(args[1:])
        if not cmd_str:
            print("[错误] 请提供连接参数")
            print("示例: --connect --host 192.168.1.1 --user root --pass 123")
            return

        print(f"[connect] 连接请求: {cmd_str}")
        ret = self.api.connect(cmd_str)
        if ret > 0:
            print(f"[connect] 连接成功! 会话ID: {ret}")
            self.active_ids.add(ret)
        else:
            print(f"[connect] 连接失败: {get_status_desc(ret)} (Code: {ret})")

    def do_close(self, args):
        id_str = self.extract_arg(args, '-id')
        if not id_str: print("[错误] 缺少 -id 参数"); return
        
        id_ = int(id_str)
        self.api.close(id_)
        if id_ in self.active_ids: self.active_ids.remove(id_)
        print(f"[close] ID {id_} 已断开")

    def do_exec(self, args):
        id_str = self.extract_arg(args, '-id')
        cmd = self.extract_arg(args, '-cmd')
        timeout = int(self.extract_arg(args, '-timeout', 3000))
        
        if not id_str or not cmd: print("[错误] 缺少 -id 或 -cmd 参数"); return
        
        id_ = int(id_str)
        print(f"[exec] ID {id_}: {cmd}")
        ret, output, exit_code = self.api.execute_cmd(id_, cmd, timeout_ms=timeout)
        
        status_color = "SUCCESS" if ret == 0 else "FAILED"
        print(f"[exec] 结果: {get_status_desc(ret)}, 退出码: {exit_code}")
        if output:
            print(f"------ 输出开始 ------\n{output}\n------ 输出结束 ------")

    def do_start(self, args):
        id_str = self.extract_arg(args, '-id')
        cmd = self.extract_arg(args, '-cmd')
        if not id_str or not cmd: print("[错误] 缺少参数"); return
        
        ret = self.api.start_cmd_async(int(id_str), cmd)
        print(f"[start] 异步命令启动: {get_status_desc(ret)}")

    def do_read(self, args):
        id_str = self.extract_arg(args, '-id')
        timeout = int(self.extract_arg(args, '-timeout', 100))
        if not id_str: print("[错误] 缺少 -id"); return
        
        ret, data = self.api.read_cmd_async(int(id_str), timeout_ms=timeout)
        if ret == 0:
            if data: print(data, end='') # 实时输出不换行
        elif ret == -100: # READ_EMPTY
            pass
        else:
            print(f"\n[read] 读取错误: {get_status_desc(ret)}")

    def do_stop(self, args):
        id_str = self.extract_arg(args, '-id')
        if not id_str: print("[错误] 缺少 -id"); return
        self.api.stop_cmd_async(int(id_str))
        print(f"[stop] 已发送停止信号")

    def do_upload(self, args):
        id_str = self.extract_arg(args, '-id')
        local = self.extract_arg(args, '-local')
        remote = self.extract_arg(args, '-remote')
        
        if not all([id_str, local, remote]):
            print("[错误] 缺少参数: -id, -local 或 -remote")
            print("示例: --upload -id 1 -local D:\\file.txt -remote /tmp/file.txt")
            return
        
        print(f"[upload] {local} -> {remote}")
        ret = self.api.upload_file(int(id_str), local, remote)
        print(f"[upload] 结果: {get_status_desc(ret)}")

    def do_download(self, args):
        id_str = self.extract_arg(args, '-id')
        local = self.extract_arg(args, '-local')
        remote = self.extract_arg(args, '-remote')
        
        if not all([id_str, local, remote]):
            print("[错误] 缺少参数: -id, -local 或 -remote")
            return
        
        print(f"[download] {remote} -> {local}")
        ret = self.api.download_file(int(id_str), remote, local)
        print(f"[download] 结果: {get_status_desc(ret)}")

if __name__ == "__main__":
    test = SimpleSSHTest()
    # 允许 Ctrl+C 优雅退出
    signal.signal(signal.SIGINT, lambda s, f: setattr(test, 'running', False))
    test.run()
