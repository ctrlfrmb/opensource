#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# SimpleSSHTest.py - 交互式测试工具
# Version: v2.1.0 (支持 execMode 参数)

import sys
import signal
import shlex
import time
import platform
from SimpleSSHWrapper import SimpleSSHWrapper
from SimpleSSHDef import get_status_desc

class SimpleSSHTest:
    def __init__(self):
        self.api = None
        self.running = True
        self.active_ids = set()
        try:
            self.api = SimpleSSHWrapper()
        except Exception as e:
            print(f"[致命错误] 初始化失败: {e}")
            self.api = None

    def cleanup(self):
        """清理资源"""
        if not self.api: 
            return
        if self.active_ids:
            print("\n[清理] 关闭所有活跃连接...")
            for id_ in list(self.active_ids):
                self.api.close(id_)
        self.api.close_log()

    def run(self):
        """主循环"""
        print("=" * 70)
        print(f"SimpleSSH 交互式测试工具 v2.1.0 {platform.architecture()[0]}")
        print("=" * 70)
        
        if not self.api: 
            return

        print("提示: 输入 --help 查看常用命令示例")
        print("提示: 输入 --exit 退出程序")

        while self.running:
            try:
                try:
                    raw = input("\nSimpleSSH >>> ").strip()
                except EOFError:
                    break
                
                if not raw: 
                    continue
                
                try:
                    args = shlex.split(raw)
                except ValueError as e:
                    print(f"[错误] 参数解析失败: {e}")
                    continue

                if not args: 
                    continue
                
                cmd = args[0].lower()

                # 命令分发
                if cmd == "--exit": 
                    break
                elif cmd == "--help": 
                    self.print_help()
                elif cmd == "--log": 
                    self.do_log(args)
                elif cmd == "--connect": 
                    self.do_connect(args)
                elif cmd == "--close": 
                    self.do_close(args)
                elif cmd == "--exec": 
                    self.do_exec(args)
                elif cmd == "--start": 
                    self.do_start(args)
                elif cmd == "--read": 
                    self.do_read(args)
                elif cmd == "--stop": 
                    self.do_stop(args)
                elif cmd == "--upload": 
                    self.do_upload(args)
                elif cmd == "--download": 
                    self.do_download(args)
                else: 
                    print(f"[错误] 未知命令: {cmd} (输入 --help 查看列表)")

            except KeyboardInterrupt:
                print("\n[提示] 输入 --exit 退出，或继续输入命令")
            except Exception as e:
                print(f"[异常] {e}")

        self.cleanup()

    def print_help(self):
        """打印帮助信息"""
        print("\n" + "-" * 70)
        print(" 命令使用示例")
        print("-" * 70)
        
        print("\n[1. 基础控制]")
        print("  开启日志:   --log on")
        print("  关闭日志:   --log off")
        print("  退出程序:   --exit")

        print("\n[2. 连接管理]")
        print("  连接: --connect --host 192.168.1.120 --user root --pass 123456")
        print("  断开: --close -id 1")

        print("\n[3. 命令执行模式说明]")
        print("  -mode 0: Exec 模式（默认）- 单次执行，上下文无关联")
        print("  -mode 1: Shell 模式 - 持久会话，保持上下文（如 cd、export）")
        
        print("\n[4. 同步执行示例]")
        print("  [Exec 模式] 独立命令，每次都是新的 channel")
        print("    --exec -id 1 -cmd \"ls -l\" -mode 0")
        print("    --exec -id 1 -cmd \"pwd\" -mode 0  # 仍在 ~ 目录")
        
        print("\n  [Shell 模式] 保持上下文")
        print("    --exec -id 1 -cmd \"cd /tmp\" -mode 1")
        print("    --exec -id 1 -cmd \"pwd\" -mode 1  # 输出 /tmp")
        
        print("\n[5. 异步执行示例]")
        print("  [Shell 模式 - 短命令（自动结束）]")
        print("    --start -id 1 -cmd \"cd /tmp\" -timeout 5000 -mode 1")
        print("    --read -id 1 -timeout 100")
        print("    --start -id 1 -cmd \"ls -l\" -timeout 5000 -mode 1")
        print("    --read -id 1 -timeout 100  # 看到 /tmp 的内容")
        
        print("\n  [Shell 模式 - 长命令（手动停止）]")
        print("    --start -id 1 -cmd \"ping 8.8.8.8\" -timeout 0 -mode 1")
        print("    --read -id 1 -timeout 100  # 循环读取")
        print("    --stop -id 1 -mode 1  # Ctrl+C 模拟")
        
        print("\n  [Exec 模式 - 快速独立命令]")
        print("    --start -id 1 -cmd \"uptime\" -timeout 3000 -mode 0")
        print("    --read -id 1 -timeout 100")

        print("\n[6. 文件传输]")
        print("  上传: --upload -id 1 -local D:\\test.txt -remote /tmp/test.txt")
        print("  下载: --download -id 1 -remote /var/log/syslog -local D:\\syslog.txt")
        
        print("\n[7. 参数说明]")
        print("  -timeout 5000  : 5 秒内无新输出自动结束（适合短命令）")
        print("  -timeout 0     : 无限等待，需手动 --stop（适合 ping 等持续输出）")
        print("  -mode 0        : Exec 模式（默认），每次独立执行")
        print("  -mode 1        : Shell 模式，保持会话上下文")
        print("-" * 70)

    def extract_arg(self, args, key, default=None):
        """提取命令行参数"""
        try:
            if key in args:
                return args[args.index(key) + 1]
        except IndexError: 
            pass
        return default

    # ==================== 命令处理器 ====================

    def do_log(self, args):
        """日志控制"""
        if "on" in args:
            ret = self.api.open_log()
            print(f"[log] 开启: {get_status_desc(ret)}")
        elif "off" in args:
            ret = self.api.close_log()
            print(f"[log] 关闭: {get_status_desc(ret)}")

    def do_connect(self, args):
        """连接到服务器"""
        cmd_str = " ".join(args[1:])
        if not cmd_str:
            print("[错误] 请提供连接参数")
            return
        print(f"[connect] 连接请求: {cmd_str}")
        ret = self.api.connect(cmd_str)
        if ret > 0:
            print(f"[connect] 连接成功! 会话ID: {ret}")
            self.active_ids.add(ret)
        else:
            print(f"[connect] 连接失败: {get_status_desc(ret)} (Code: {ret})")

    def do_close(self, args):
        """断开连接"""
        id_str = self.extract_arg(args, '-id')
        if not id_str: 
            print("[错误] 缺少 -id 参数")
            return
        id_ = int(id_str)
        self.api.close(id_)
        if id_ in self.active_ids: 
            self.active_ids.remove(id_)
        print(f"[close] ID {id_} 已断开")

    def do_exec(self, args):
        """同步执行命令"""
        id_str = self.extract_arg(args, '-id')
        cmd = self.extract_arg(args, '-cmd')
        timeout = int(self.extract_arg(args, '-timeout', 3000))
        mode = int(self.extract_arg(args, '-mode', 0))  # 默认 Exec 模式
        
        if not id_str or not cmd: 
            print("[错误] 缺少 -id 或 -cmd 参数")
            return
        
        cmd = cmd.replace(r'\n', '\n')
        id_ = int(id_str)
        
        mode_name = "Shell" if mode == 1 else "Exec"
        print(f"[exec] ID {id_}, Mode: {mode_name}, Cmd: {cmd.strip()}")
        
        ret, output, exit_code = self.api.execute_cmd(id_, cmd, timeout_ms=timeout, exec_mode=mode)
        
        print(f"[exec] 结果: {get_status_desc(ret)}, 退出码: {exit_code}")
        if output:
            print(f"------ 输出开始 ------\n{output}\n------ 输出结束 ------")

    def do_start(self, args):
        """启动异步命令"""
        id_str = self.extract_arg(args, '-id')
        cmd = self.extract_arg(args, '-cmd')
        timeout = int(self.extract_arg(args, '-timeout', 5000))
        mode = int(self.extract_arg(args, '-mode', 0))  # 默认 Exec 模式

        if not id_str or not cmd: 
            print("[错误] 缺少参数")
            return
        
        cmd = cmd.replace(r'\n', '\n')
        mode_name = "Shell" if mode == 1 else "Exec"
        
        print(f"[start] ID {id_str}, Mode: {mode_name}, Cmd Length: {len(cmd)}, Timeout: {timeout}ms")
        
        ret = self.api.start_cmd_async(int(id_str), cmd, timeout_ms=timeout, exec_mode=mode)
        print(f"[start] 启动结果: {get_status_desc(ret)}")

    def do_read(self, args):
        """读取异步命令输出"""
        id_str = self.extract_arg(args, '-id')
        timeout = int(self.extract_arg(args, '-timeout', 100))
        if not id_str: 
            print("[错误] 缺少 -id")
            return
        
        ret, data = self.api.read_cmd_async(int(id_str), timeout_ms=timeout)
        if ret == 0:
            if data: 
                print(data, end='') 
        elif ret == -100: 
            pass  # 无数据，静默
        else:
            print(f"\n[read] 读取错误: {get_status_desc(ret)}")

    def do_stop(self, args):
        """停止异步命令"""
        id_str = self.extract_arg(args, '-id')
        mode = int(self.extract_arg(args, '-mode', 0))  # 默认 Exec 模式
        
        if not id_str: 
            print("[错误] 缺少 -id")
            return
        
        self.api.stop_cmd_async(int(id_str), exec_mode=mode)
        mode_name = "Shell" if mode == 1 else "Exec"
        print(f"[stop] 已发送停止信号 (Mode: {mode_name})")

    def do_upload(self, args):
        """上传文件"""
        id_str = self.extract_arg(args, '-id')
        local = self.extract_arg(args, '-local')
        remote = self.extract_arg(args, '-remote')
        if not all([id_str, local, remote]):
            print("[错误] 缺少参数")
            return
        print(f"[upload] {local} -> {remote}")
        ret = self.api.upload_file(int(id_str), local, remote)
        print(f"[upload] 结果: {get_status_desc(ret)}")

    def do_download(self, args):
        """下载文件"""
        id_str = self.extract_arg(args, '-id')
        local = self.extract_arg(args, '-local')
        remote = self.extract_arg(args, '-remote')
        if not all([id_str, local, remote]):
            print("[错误] 缺少参数")
            return
        print(f"[download] {remote} -> {local}")
        ret = self.api.download_file(int(id_str), remote, local)
        print(f"[download] 结果: {get_status_desc(ret)}")

if __name__ == "__main__":
    test = SimpleSSHTest()
    signal.signal(signal.SIGINT, lambda s, f: setattr(test, 'running', False))
    test.run()
