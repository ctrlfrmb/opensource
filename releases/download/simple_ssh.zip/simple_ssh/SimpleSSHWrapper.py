#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# SimpleSSHWrapper.py - 封装 simple_ssh.dll/libsimple_ssh.so

import os
import platform
import ctypes
from ctypes import *

class SimpleSSHWrapper:
    def __init__(self):
        self.lib = None
        try:
            self._load_dll()
            self._define_api()
        except Exception as e:
            print(f"[DEBUG] Python Arch: {platform.architecture()[0]}")
            raise RuntimeError(f"SimpleSSH 库加载失败: {e}")

    def _load_dll(self):
        arch = platform.architecture()[0]
        if platform.system() == "Windows":
            # 1. 确定目录
            lib_dir = os.path.abspath("./lib/Winx64" if arch == "64bit" else "./lib/Winx86")
            dll_name = "simple_ssh.dll"
            
            # 2. 设置环境变量 (兼容旧版 Python)
            os.environ['PATH'] = lib_dir + os.pathsep + os.environ.get('PATH', '')
            
            # 3. [关键修复] Python 3.8+ 必须显式添加 DLL 目录，否则找不到 Qt5Core.dll 等依赖
            if hasattr(os, 'add_dll_directory'):
                os.add_dll_directory(lib_dir)
                
        else:
            # Linux 假设在 lib 目录下，或者根据你的实际情况调整
            lib_dir = os.path.abspath("./lib") 
            dll_name = "libsimple_ssh.so"
        
        lib_path = os.path.join(lib_dir, dll_name)
        
        if not os.path.exists(lib_path):
            raise FileNotFoundError(f"无法找到库文件: {lib_path}")
            
        self.lib = ctypes.CDLL(lib_path)

    def _define_api(self):
        """定义 C 函数原型"""
        
        # Log
        self.lib.SimpleSSHOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
        self.lib.SimpleSSHOpenLog.restype = c_int
        self.lib.SimpleSSHCloseLog.argtypes = []
        self.lib.SimpleSSHCloseLog.restype = c_int

        # Connection
        self.lib.SimpleSSHConnect.argtypes = [c_char_p]
        self.lib.SimpleSSHConnect.restype = c_int
        
        self.lib.SimpleSSHClose.argtypes = [c_int]
        self.lib.SimpleSSHClose.restype = None
        
        self.lib.SimpleSSHIsConnected.argtypes = [c_int]
        self.lib.SimpleSSHIsConnected.restype = c_int

        # Sync Command
        self.lib.SimpleSSHExecuteCmd.argtypes = [c_int, c_char_p, c_char_p, c_int, POINTER(c_int), c_int]
        self.lib.SimpleSSHExecuteCmd.restype = c_int

        # Async Command
        self.lib.SimpleSSHStartCmdAsync.argtypes = [c_int, c_char_p]
        self.lib.SimpleSSHStartCmdAsync.restype = c_int
        
        self.lib.SimpleSSHReadCmdOutputAsync.argtypes = [c_int, c_char_p, c_int, POINTER(c_int), c_int]
        self.lib.SimpleSSHReadCmdOutputAsync.restype = c_int
        
        self.lib.SimpleSSHStopCmdAsync.argtypes = [c_int]
        self.lib.SimpleSSHStopCmdAsync.restype = None

        # SFTP
        self.lib.SimpleSSHUploadFile.argtypes = [c_int, c_char_p, c_char_p]
        self.lib.SimpleSSHUploadFile.restype = c_int
        
        self.lib.SimpleSSHDownloadFile.argtypes = [c_int, c_char_p, c_char_p]
        self.lib.SimpleSSHDownloadFile.restype = c_int

    # --- Python Methods ---

    def open_log(self, path="simple_ssh.log", level=0, max_size=5, max_files=5):
        return self.lib.SimpleSSHOpenLog(path.encode('utf-8'), level, max_size, max_files)

    def close_log(self):
        return self.lib.SimpleSSHCloseLog()

    def connect(self, cmd_str):
        return self.lib.SimpleSSHConnect(cmd_str.encode('utf-8'))

    def close(self, instance_id):
        self.lib.SimpleSSHClose(instance_id)

    def is_connected(self, instance_id):
        return self.lib.SimpleSSHIsConnected(instance_id) == 1

    def execute_cmd(self, instance_id, cmd, buffer_size=1024*1024, timeout_ms=3000):
        buf = create_string_buffer(buffer_size)
        exit_code = c_int(0)
        ret = self.lib.SimpleSSHExecuteCmd(instance_id, cmd.encode('utf-8'), buf, buffer_size, byref(exit_code), timeout_ms)
        output = buf.value.decode('utf-8', errors='replace')
        return ret, output, exit_code.value

    def start_cmd_async(self, instance_id, cmd):
        return self.lib.SimpleSSHStartCmdAsync(instance_id, cmd.encode('utf-8'))

    def read_cmd_async(self, instance_id, buffer_size=4096, timeout_ms=0):
        buf = create_string_buffer(buffer_size)
        bytes_read = c_int(0)
        ret = self.lib.SimpleSSHReadCmdOutputAsync(instance_id, buf, buffer_size, byref(bytes_read), timeout_ms)
        data = ""
        if bytes_read.value > 0:
            data = buf.value.decode('utf-8', errors='replace')
        return ret, data

    def stop_cmd_async(self, instance_id):
        self.lib.SimpleSSHStopCmdAsync(instance_id)

    def upload_file(self, instance_id, local, remote):
        return self.lib.SimpleSSHUploadFile(instance_id, local.encode('utf-8'), remote.encode('utf-8'))

    def download_file(self, instance_id, remote, local):
        return self.lib.SimpleSSHDownloadFile(instance_id, remote.encode('utf-8'), local.encode('utf-8'))
