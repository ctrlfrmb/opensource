#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# SimpleSSHWrapper.py - 封装 simple_ssh.dll/libsimple_ssh.so
# Version: v2.1.0 (支持 execMode 参数)

import os
import platform
import ctypes
from ctypes import *

class SimpleSSHWrapper:
    def __init__(self):
        self.lib = None
        try:
            self._load_dll()
            self._define_api()
        except Exception as e:
            print(f"[DEBUG] Python Arch: {platform.architecture()[0]}")
            raise RuntimeError(f"SimpleSSH 库加载失败: {e}")

    def _load_dll(self):
        """加载 DLL/SO 库"""
        arch = platform.architecture()[0]
        if platform.system() == "Windows":
            lib_dir = os.path.abspath("./lib/Winx64" if arch == "64bit" else "./lib/Winx86")
            dll_name = "simple_ssh.dll"
            os.environ['PATH'] = lib_dir + os.pathsep + os.environ.get('PATH', '')
            if hasattr(os, 'add_dll_directory'):
                os.add_dll_directory(lib_dir)
        else:
            lib_dir = os.path.abspath("./lib") 
            dll_name = "libsimple_ssh.so"
        
        lib_path = os.path.join(lib_dir, dll_name)
        if not os.path.exists(lib_path):
            raise FileNotFoundError(f"无法找到库文件: {lib_path}")
        self.lib = ctypes.CDLL(lib_path)

    def _define_api(self):
        """定义 C 函数原型"""
        
        # ==================== 日志管理 ====================
        self.lib.SimpleSSHOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
        self.lib.SimpleSSHOpenLog.restype = c_int
        
        self.lib.SimpleSSHCloseLog.argtypes = []
        self.lib.SimpleSSHCloseLog.restype = c_int

        # ==================== 连接管理 ====================
        self.lib.SimpleSSHConnect.argtypes = [c_char_p]
        self.lib.SimpleSSHConnect.restype = c_int
        
        self.lib.SimpleSSHClose.argtypes = [c_int]
        self.lib.SimpleSSHClose.restype = None
        
        self.lib.SimpleSSHIsConnected.argtypes = [c_int]
        self.lib.SimpleSSHIsConnected.restype = c_int

        # ==================== 命令执行（同步）====================
        self.lib.SimpleSSHExecuteCmd.argtypes = [c_int, c_char_p, c_char_p, c_int, POINTER(c_int), c_int, c_int]
        self.lib.SimpleSSHExecuteCmd.restype = c_int

        # ==================== 命令执行（异步）====================
        self.lib.SimpleSSHStartCmdAsync.argtypes = [c_int, c_char_p, c_int, c_int]
        self.lib.SimpleSSHStartCmdAsync.restype = c_int
        
        self.lib.SimpleSSHReadCmdOutputAsync.argtypes = [c_int, c_char_p, c_int, POINTER(c_int), c_int]
        self.lib.SimpleSSHReadCmdOutputAsync.restype = c_int
        
        self.lib.SimpleSSHStopCmdAsync.argtypes = [c_int, c_int]
        self.lib.SimpleSSHStopCmdAsync.restype = None

        # ==================== 文件传输（SFTP）====================
        self.lib.SimpleSSHUploadFile.argtypes = [c_int, c_char_p, c_char_p]
        self.lib.SimpleSSHUploadFile.restype = c_int
        
        self.lib.SimpleSSHDownloadFile.argtypes = [c_int, c_char_p, c_char_p]
        self.lib.SimpleSSHDownloadFile.restype = c_int

    # ==================== Python 方法封装 ====================

    def open_log(self, path="simple_ssh.log", level=-200, max_size=5, max_files=5):
        """开启日志记录"""
        return self.lib.SimpleSSHOpenLog(path.encode('utf-8'), level, max_size, max_files)

    def close_log(self):
        """关闭日志记录"""
        return self.lib.SimpleSSHCloseLog()

    def connect(self, cmd_str):
        """连接到 SSH 服务器"""
        return self.lib.SimpleSSHConnect(cmd_str.encode('utf-8'))

    def close(self, instance_id):
        """断开连接"""
        self.lib.SimpleSSHClose(instance_id)

    def is_connected(self, instance_id):
        """检查连接状态"""
        return self.lib.SimpleSSHIsConnected(instance_id) == 1

    def execute_cmd(self, instance_id, cmd, buffer_size=1024*1024, timeout_ms=3000, exec_mode=0):
        """
        同步执行命令
        
        Args:
            instance_id: 实例ID
            cmd: 要执行的命令
            buffer_size: 输出缓冲区大小
            timeout_ms: 超时时间（毫秒）
            exec_mode: 执行模式 (0=exec单次, 1=shell持久)
        
        Returns:
            (ret, output, exit_code) 元组
        """
        buf = create_string_buffer(buffer_size)
        exit_code = c_int(0)
        ret = self.lib.SimpleSSHExecuteCmd(
            instance_id, 
            cmd.encode('utf-8'), 
            buf, 
            buffer_size, 
            byref(exit_code), 
            timeout_ms,
            exec_mode
        )
        output = buf.value.decode('utf-8', errors='replace')
        return ret, output, exit_code.value

    def start_cmd_async(self, instance_id, cmd, timeout_ms=5000, exec_mode=0):
        """
        启动异步命令执行
        
        Args:
            instance_id: 实例ID
            cmd: 要执行的命令
            timeout_ms: 空闲超时（毫秒），0 表示无限等待
            exec_mode: 执行模式 (0=exec单次, 1=shell持久)
        
        Returns:
            0: 成功, <0: 错误码
        """
        return self.lib.SimpleSSHStartCmdAsync(
            instance_id, 
            cmd.encode('utf-8'), 
            timeout_ms,
            exec_mode
        )

    def read_cmd_async(self, instance_id, buffer_size=4096, timeout_ms=0):
        """读取异步命令的输出"""
        buf = create_string_buffer(buffer_size)
        bytes_read = c_int(0)
        ret = self.lib.SimpleSSHReadCmdOutputAsync(
            instance_id, 
            buf, 
            buffer_size, 
            byref(bytes_read), 
            timeout_ms
        )
        data = ""
        if bytes_read.value > 0:
            data = buf.value.decode('utf-8', errors='replace')
        return ret, data

    def stop_cmd_async(self, instance_id, exec_mode=0):
        """
        停止当前异步命令
        
        Args:
            instance_id: 实例ID
            exec_mode: 执行模式 (0=exec单次, 1=shell持久)
        """
        self.lib.SimpleSSHStopCmdAsync(instance_id, exec_mode)

    def upload_file(self, instance_id, local, remote):
        """上传文件到远程主机"""
        return self.lib.SimpleSSHUploadFile(
            instance_id, 
            local.encode('utf-8'), 
            remote.encode('utf-8')
        )

    def download_file(self, instance_id, remote, local):
        """从远程主机下载文件"""
        return self.lib.SimpleSSHDownloadFile(
            instance_id, 
            remote.encode('utf-8'), 
            local.encode('utf-8')
        )
