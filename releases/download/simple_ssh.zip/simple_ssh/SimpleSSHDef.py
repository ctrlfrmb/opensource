#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# SimpleSSHDef.py - 定义 SimpleSSH 的常量和错误码

status_map = {
    0: "操作成功 (SUCCESS)",
    
    # --- 通用错误 ---
    -1: "无效参数 (INVALID_PARAMETER)",
    -2: "内部错误 (INTERNAL)",
    -3: "执行失败 (EXECUTE_FAILED)",
    -4: "操作超时 (TIMEOUT)",
    -5: "无效状态 (INVALID_STATE)",

    # --- 连接错误 ---
    -10: "连接失败 (CONNECTION_FAILED)",
    -11: "认证失败 (AUTHENTICATION_FAILED)",
    -12: "算法协商失败 (ALGORITHM_ERROR)",
    -13: "网络错误 (NETWORK_ERROR)",

    # --- 通道与命令错误 ---
    -20: "通道打开失败 (CHANNEL_FAILURE)",
    -21: "请求失败 (CHANNEL_REQUEST_FAILED)",
    -22: "通道IO错误 (CHANNEL_IO_ERROR)",

    # --- SFTP 错误 ---
    -30: "SFTP 初始化失败 (SFTP_FAILURE)",
    -31: "打开远程文件失败 (SFTP_OPEN_FAILED)",
    -32: "读取远程文件失败 (SFTP_READ_FAILED)",
    -33: "写入远程文件失败 (SFTP_WRITE_FAILED)",
    -34: "创建目录失败 (SFTP_MKDIR_FAILED)",
    -35: "获取状态失败 (SFTP_STAT_FAILED)",
    -36: "本地文件错误 (SFTP_LOCAL_FILE_ERROR)",
    -37: "不是目录 (SFTP_NOT_A_DIRECTORY)",
    -38: "权限不足 (SFTP_PERMISSION_DENIED)",
    -39: "远程文件不存在 (SFTP_NO_SUCH_FILE)",

    # --- 管理器错误 ---
    -51: "无效ID (INVALID_ID)",
    -52: "实例不存在 (INSTANCE_NOT_FOUND)",
    -53: "达到连接上限 (MAX_CLIENTS_REACHED)",
    -54: "缓冲区太小 (BUFFER_TOO_SMALL)",

    # --- 状态 ---
    -100: "读取为空 (READ_EMPTY)"
}

def get_status_desc(code):
    """获取状态码的描述信息"""
    return status_map.get(code, f"未知错误码 ({code})")
