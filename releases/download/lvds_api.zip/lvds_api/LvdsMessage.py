﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: leiwei
LvdsMessage.py - LVDS API 消息类型定义和常量

版本: v2.7.0 (与 lvds_api 库版本对齐)
"""

import ctypes

# =============================================================================
# LVDS API 结果状态码 (与 lvds_message.h 完全对应)
# =============================================================================

# === 成功状态 ===
LVDS_RESULT_OK = 0

# === 参数和配置错误 (-1 ~ -10) ===
LVDS_RESULT_INVALID_PARAM = -1
LVDS_RESULT_INTERNAL_ERROR = -2
LVDS_RESULT_BUFFER_TOO_SMALL = -3
LVDS_RESULT_INVALID_STATE = -4

# === 连接相关错误 (-11 ~ -20) ===
LVDS_RESULT_CONNECTION_FAILED = -11
LVDS_RESULT_TOO_MANY_INSTANCES = -12
LVDS_RESULT_INVALID_INSTANCE_ID = -13
LVDS_RESULT_NOT_CONNECTED = -14

# === 业务逻辑错误 (-21 ~ -30) ===
LVDS_RESULT_SEND_FAILED = -21
LVDS_RESULT_TIMEOUT = -22
LVDS_RESULT_NO_RESPONSE = -23
LVDS_RESULT_NO_DATA = -24

# === 运行状态错误 (-31 ~ -40) ===
LVDS_RESULT_ALREADY_RUNNING = -31
LVDS_RESULT_NOT_RUNNING = -32
LVDS_RESULT_MODE_CONFLICT = -33
LVDS_RESULT_REF_CAPTURE_FAILED = -34
LVDS_RESULT_REF_CAPTURE_TIMEOUT = -35
LVDS_RESULT_IMAGE_COUNT_EXCEEDED = -36
LVDS_RESULT_NO_IMAGE_SOURCE = -37
LVDS_RESULT_DEVICE_REJECTED = -38


STATUS_DESCRIPTIONS = {
    LVDS_RESULT_OK: "操作成功",
    LVDS_RESULT_INVALID_PARAM: "无效的参数",
    LVDS_RESULT_INTERNAL_ERROR: "内部错误",
    LVDS_RESULT_BUFFER_TOO_SMALL: "缓冲区太小",
    LVDS_RESULT_INVALID_STATE: "无效的状态",
    LVDS_RESULT_CONNECTION_FAILED: "连接失败",
    LVDS_RESULT_TOO_MANY_INSTANCES: "实例过多",
    LVDS_RESULT_INVALID_INSTANCE_ID: "无效的实例ID",
    LVDS_RESULT_NOT_CONNECTED: "设备未连接",
    LVDS_RESULT_SEND_FAILED: "发送失败",
    LVDS_RESULT_TIMEOUT: "操作超时",
    LVDS_RESULT_NO_RESPONSE: "设备无响应",
    LVDS_RESULT_NO_DATA: "无可用数据",
    LVDS_RESULT_ALREADY_RUNNING: "已在运行",
    LVDS_RESULT_NOT_RUNNING: "未在运行",
    LVDS_RESULT_MODE_CONFLICT: "模式冲突",
    LVDS_RESULT_REF_CAPTURE_FAILED: "标定帧获取失败",
    LVDS_RESULT_REF_CAPTURE_TIMEOUT: "标定帧获取超时",
    LVDS_RESULT_IMAGE_COUNT_EXCEEDED: "图像数量超限，通道比对已自动停止",
    LVDS_RESULT_NO_IMAGE_SOURCE: "无图像源（图像分辨率 0×0）",
    LVDS_RESULT_DEVICE_REJECTED: "设备拒绝命令（响应 FF FF）",
}


def get_status_description(status_code):
    """获取状态码的中文描述"""
    return STATUS_DESCRIPTIONS.get(status_code, f"未知错误码: {status_code}")


# =============================================================================
# C 结构体定义 (与 lvds_message.h 对齐，4字节对齐)
# =============================================================================

class LvdsImageCompareStatus(ctypes.Structure):
    """
    图像比对状态及统计信息 (56 字节)

    对应 C 结构体 LvdsImageCompareStatus (lvds_message.h)

    status_code 位定义:
      - Bit0: 比对开关状态 (1=开启, 0=关闭)
      - Bit1: 错误标志 (1=当前帧有错误, 0=正常)
      - Bit2: 图像源状态 (1=有图像源, 0=无图像源)
    """
    _pack_ = 4
    _fields_ = [
        ("channel", ctypes.c_uint),
        ("status_code", ctypes.c_uint),
        ("width", ctypes.c_uint),
        ("height", ctypes.c_uint),
        ("fps", ctypes.c_uint),
        ("total_frames", ctypes.c_uint),
        ("err_pixel", ctypes.c_uint),
        ("input_pixel", ctypes.c_uint),
        ("threshold", ctypes.c_uint),
        ("error_col", ctypes.c_uint),
        ("error_line", ctypes.c_uint),
        ("rgb_cnt_pixel", ctypes.c_uint),
        ("rgb_pixel_total", ctypes.c_uint),
        ("rgb_not_pixel", ctypes.c_uint),
        ("compare_start_x", ctypes.c_uint),
        ("compare_end_x", ctypes.c_uint),
        ("compare_start_y", ctypes.c_uint),
        ("compare_end_y", ctypes.c_uint),
        ("point_x", ctypes.c_uint),
        ("point_y", ctypes.c_uint),
        ("point_pixel", ctypes.c_uint),
    ]

    def __repr__(self):
        switch_on = (self.status_code & 0x01) != 0
        has_error = (self.status_code & 0x02) != 0
        has_source = (self.status_code & 0x04) != 0
        return (
            f"状态[Ch:{self.channel}, 分辨率:{self.width}x{self.height}, "
            f"帧率:{self.fps}, 开关:{'ON' if switch_on else 'OFF'}, "
            f"异常:{'YES' if has_error else 'NO'}, "
            f"图源:{'YES' if has_source else 'NO'}, "
            f"错误像素:0x{self.err_pixel:06X}, "
            f"输入像素:0x{self.input_pixel:06X}, 阈值:{self.threshold}, "
            f"统计像素:0x{self.rgb_cnt_pixel:06X}, 统计总数:{self.rgb_pixel_total}, "
            f"不比较像素:0x{self.rgb_not_pixel:06X}, "
            f"对比区域:X({self.compare_start_x}~{self.compare_end_x}) "
            f"Y({self.compare_start_y}~{self.compare_end_y}), "
            f"InputPoint:({self.point_x},{self.point_y})=0x{self.point_pixel:06X}]"
        )


class LvdsErrorRecord(ctypes.Structure):
    """
    单条错误记录 (108 字节)

    对应 C 结构体 LvdsErrorRecord (lvds_message.h)

    图像文件名格式: ERR_YYYYMMDDHHmmsszzz.png
    """
    _pack_ = 4
    _fields_ = [
        ("image_name", ctypes.c_char * 64),
        ("status", LvdsImageCompareStatus),
    ]

    def __repr__(self):
        try:
            name = self.image_name.decode('utf-8').strip('\x00')
        except Exception:
            name = str(self.image_name)
        return (
            f"LvdsErrorRecord(Ch:{self.status.channel}, 图像:{name}, "
            f"错误像素:0x{self.status.err_pixel:06X}, "
            f"输入像素:0x{self.status.input_pixel:06X})"
        )

    def to_dict(self):
        """转换为字典格式"""
        try:
            name = self.image_name.decode('utf-8').strip('\x00')
        except Exception:
            name = str(self.image_name)
        return {
            "image_name": name,
            "channel": self.status.channel,
            "width": self.status.width,
            "height": self.status.height,
            "fps": self.status.fps,
            "status_code": self.status.status_code,
            "total_frames": self.status.total_frames,
            "err_pixel": self.status.err_pixel,
            "input_pixel": self.status.input_pixel,
            "threshold": self.status.threshold,
            "rgb_cnt_pixel": self.status.rgb_cnt_pixel,
            "rgb_pixel_total": self.status.rgb_pixel_total,
            "rgb_not_pixel": self.status.rgb_not_pixel,
        }



