﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: leiwei
LvdsTest.py - LVDS 多客户端测试命令行工具

版本: v2.7.0

支持功能:
- 多设备同时连接和管理
- 单客户端命令: connect 1 --serverIp ...
- 批量命令: connectbatch, startall, stopall, disconnectall
- 全局状态监控: status, list
- 路径自动按 IP 最后一段分目录
"""

from LvdsClient import LvdsClient
from LvdsMessage import LVDS_RESULT_OK
import signal
import sys
import os
import re

# =============================================================================
# 全局客户端管理
# =============================================================================

clients = {}       # idx(int) -> LvdsClient
next_idx = 1       # 下一个自动分配的索引


def get_client(idx):
    """获取指定索引的客户端"""
    c = clients.get(idx)
    if c is None:
        print(f"  错误: 客户端 {idx} 不存在。使用 'list' 查看所有客户端。")
    return c


def _auto_resolve_client(idx_str=None):
    """
    自动解析客户端索引（兼容旧脚本体验）：

    - 如果提供了 idx_str，直接使用
    - 如果未提供且仅有1个已连接客户端，自动选择
    - 否则提示用户指定 IDX

    Returns:
        (idx, client) 或 (None, None)
    """
    if idx_str is not None:
        idx = int(idx_str)
        c = clients.get(idx)
        if c is None:
            print(f"  错误: 客户端 {idx} 不存在。使用 'list' 查看所有客户端。")
            return None, None
        return idx, c

    connected = {k: v for k, v in clients.items() if v.is_connected()}
    if len(connected) == 1:
        idx, c = next(iter(connected.items()))
        return idx, c
    elif len(connected) == 0:
        print("  错误: 当前无已连接的客户端。请先执行 connect。")
        return None, None
    else:
        print(f"  错误: 当前有 {len(connected)} 个已连接客户端，请指定 IDX。使用 'list' 查看。")
        return None, None


def get_connected_clients():
    """获取所有已连接的客户端"""
    return {k: v for k, v in clients.items() if v.is_connected()}


def add_client():
    """创建并注册一个新客户端，返回 (idx, client)"""
    global next_idx
    c = LvdsClient()
    idx = next_idx
    clients[idx] = c
    next_idx += 1
    return idx, c


def remove_client(idx):
    """移除客户端"""
    if idx in clients:
        c = clients[idx]
        c.stop_auto_poll()
        if c.is_connected():
            c.disconnect()
        del clients[idx]


# =============================================================================
# 信号处理
# =============================================================================

def signal_handler(sig, frame):
    print("\n接收到中断信号，正在清理...")
    for c in clients.values():
        c.stop_auto_poll()
    LvdsClient.cleanup_library()
    sys.exit(0)


# =============================================================================
# 辅助函数
# =============================================================================

def _get_ip_suffix(client):
    """
    从客户端 IP 中提取最后一段作为目录后缀
    例: 192.168.245.101 -> 101
    """
    if client.server_ip:
        parts = client.server_ip.split('.')
        if len(parts) == 4:
            return parts[-1]
    return str(client.instance_id or 0)


def _append_ip_suffix(params_str, client):
    """
    为 --imagePath 或 --imageRootPath 追加 /{ip_suffix} 后缀
    
    例: --imageRootPath E:\\TestData  + IP 192.168.245.101
      → --imageRootPath E:\\TestData\\101
    """
    suffix = _get_ip_suffix(client)

    def replace_path(match):
        key = match.group(1)
        path = match.group(2).rstrip('/\\')
        return f"--{key} {path}/{suffix}"

    result = re.sub(r'--(imagePath|imageRootPath)\s+(\S+)', replace_path, params_str)
    return result


def _show_ref_images(client, params_str):
    """显示标定图信息"""
    m = re.search(r'--channels\s+([0-9,]+)', params_str)
    if m:
        chs = [int(ch.strip()) for ch in m.group(1).split(',')]
    else:
        m2 = re.search(r'--channel\s+(\d+)', params_str)
        chs = [int(m2.group(1))] if m2 else [1]

    for ch in chs:
        name = client.get_reference_image_name(ch)
        if name:
            print(f"    Ch{ch} 标定图: {name}")


# =============================================================================
# 状态显示
# =============================================================================

def show_status():
    """显示所有客户端状态"""
    connected = get_connected_clients()
    if not connected:
        print("  当前无已连接的客户端。")
        return

    print(f"\n  {'IDX':<5} {'设备地址':<24} {'实例ID':<8} {'Ch1错误':<10} {'Ch2错误':<10} {'Ch3错误':<10}")
    print("  " + "-" * 75)
    for idx, c in sorted(connected.items()):
        e1 = c.get_channel_error_record_count(1)
        e2 = c.get_channel_error_record_count(2)
        e3 = c.get_channel_error_record_count(3)
        e1s = str(e1) if e1 >= 0 else "-"
        e2s = str(e2) if e2 >= 0 else "-"
        e3s = str(e3) if e3 >= 0 else "-"
        print(f"  {idx:<5} {c.display_name:<24} {c.instance_id:<8} {e1s:<10} {e2s:<10} {e3s:<10}")
    print()


def show_list():
    """列出所有客户端"""
    if not clients:
        print("  无客户端。")
        return
    print(f"\n  {'IDX':<5} {'状态':<8} {'设备地址':<24} {'实例ID':<8}")
    print("  " + "-" * 50)
    for idx, c in sorted(clients.items()):
        state = "已连接" if c.is_connected() else "未连接"
        iid = str(c.instance_id) if c.instance_id else "-"
        print(f"  {idx:<5} {state:<8} {c.display_name:<24} {iid:<8}")
    print()


# =============================================================================
# 帮助信息
# =============================================================================

def print_help():
    print("""
================================================================================
              LVDS 多客户端命令行测试工具 v2.7.0
================================================================================

─────────────────── 单客户端操作（IDX 可省略自动推断） ─────────────────────────
  connect [IDX] [params]              连接设备
                                      默认: --serverIp 192.168.1.10 --serverPort 5555
  disconnect [IDX]                    断开指定客户端
  patternmove [IDX] <0|1>            方块移动 (0=静态, 1=动态)
  reboot [IDX]                        继电器重启板卡
  isconnected [IDX]                  检查 DLL 侧连接状态
  statpixel [IDX] <channel> <RRGGBB> 设置统计像素 (Cmd 0x30 / 0x07)
  ignorepixel [IDX] <channel> <RRGGBB>
                                      设置不进行比较的像素 (Cmd 0x30 / 0x08)
  setarea [IDX] <channel> <startX> <endX> <startY> <endY>
                                      设置图像对比限定区域 (Cmd 0x30 / 0x09)
  start [IDX] [params]               启动比对 (单通道或多通道)
  stopch [IDX] <channel>             停止指定通道
  stop [IDX]                         停止所有通道
  capture [IDX] <path> [ch] [timeout] 截图
  switch [IDX] <channel>             切换视频源通道
  errcount [IDX] [channel]           查看错误计数
  errrecords [IDX] [channel] [count] 拉取错误记录
  clearerr [IDX] [channel]           清空错误记录
  refname [IDX] <channel>            查看标定图名
  imagestatus [IDX] [channel]        获取图像比较状态信息
  autopoll [IDX] [interval] [chs]    开启后台轮询 (chs: 1,2,3)
  stoppoll [IDX]                     停止后台轮询

─────────────────── 批量操作（对所有已连接客户端） ────────────────────────────
  connectbatch <ip1,ip2,...> [port]   批量连接多个设备
  disconnectall                       断开所有客户端
  patternmoveall <0|1>               所有客户端设置方块移动
  startall [params]                   所有客户端启动比对
                                      ★ 路径自动追加 /{IP最后一段}
                                      例: --imageRootPath E:\\TestData
                                      → 101设备: E:\\TestData\\101
                                      → 103设备: E:\\TestData\\103
  stopall                             所有客户端停止比对
  captureall <dir> [ch] [timeout]    所有客户端截图 (保存到 dir/{IP最后一段}/)
  autopollon [interval] [chs]        所有客户端开启轮询
  autopolloff                         所有客户端停止轮询

─────────────────── 全局命令 ──────────────────────────────────────────────────
  status                              显示所有客户端状态及错误计数
  list                                列出所有客户端
  clearall                            清理所有实例
  help                                显示帮助
  exit                                退出程序

================================================================================
                              使用示例
================================================================================
【多设备测试流程】:
  LVDS> connectbatch 192.168.245.101,192.168.245.103,192.168.245.105
  LVDS> patternmoveall 1
  LVDS> startall --channels 1,2,3 --threshold 5 --interval 5000 --imageRootPath E:\\TestData
        → 101 设备保存到 E:\\TestData\\101\\{1,2,3}\\
        → 121 设备保存到 E:\\TestData\\121\\{1,2,3}\\
        → 123 设备保存到 E:\\TestData\\123\\{1,2,3}\\
  LVDS> status
  LVDS> autopollon 2000 1,2,3
  LVDS> autopolloff
  LVDS> stopall
  LVDS> disconnectall

【单设备测试】:
  LVDS> connect 1 --serverIp 192.168.245.101
  LVDS> patternmove 1 0
  LVDS> start 1 --channel 1 --threshold 5 --imagePath ./images/ch1
  LVDS> autopoll 1 1000 1
  LVDS> stoppoll 1
  LVDS> stop 1
  LVDS> disconnect 1

【截图】:
  LVDS> capture 1 ./test.png 1 5000
  LVDS> captureall E:\\TestData\\Capture
        → 101 设备: E:\\TestData\\Capture\\101\\
        → 103 设备: E:\\TestData\\Capture\\103\\
================================================================================
""")


# =============================================================================
# 命令处理：单客户端
# =============================================================================

def cmd_connect(parts):
    """connect [IDX] [params]"""
    if len(parts) < 2:
        params = "--serverIp 192.168.1.10 --serverPort 5555"
        idx, c = add_client()
        c.connect(params)
        return

    # connect --serverIp ...  (省略 IDX，自动分配)
    if parts[1].startswith("--"):
        params = " ".join(parts[1:]) if len(parts) > 1 else "--serverIp 192.168.1.10 --serverPort 5555"
        idx, c = add_client()
        c.connect(params)
        return

    idx = int(parts[1])
    params = " ".join(parts[2:]) if len(parts) > 2 else "--serverIp 192.168.1.10 --serverPort 5555"

    if idx in clients and clients[idx].is_connected():
        print(f"  客户端 {idx} 已连接到 {clients[idx].display_name}，先断开。")
        clients[idx].disconnect()

    if idx not in clients:
        global next_idx
        clients[idx] = LvdsClient()
        next_idx = max(next_idx, idx + 1)

    clients[idx].connect(params)


def cmd_disconnect(parts):
    """disconnect [IDX]"""
    idx, c = _auto_resolve_client(parts[1] if len(parts) > 1 else None)
    if c:
        c.disconnect()


def cmd_patternmove(parts):
    """patternmove [IDX] <0|1>"""
    if len(parts) < 2:
        print("  用法: patternmove [IDX] <0|1>")
        return

    if len(parts) == 2:
        idx, c = _auto_resolve_client(None)
        enable = parts[1] not in ('0', 'false', 'off')
    else:
        if parts[1].isdigit():
            idx, c = _auto_resolve_client(parts[1])
            enable = parts[2] not in ('0', 'false', 'off')
        else:
            idx, c = _auto_resolve_client(None)
            enable = parts[1] not in ('0', 'false', 'off')

    if c:
        ok = c.set_pattern_move(enable)
        if ok:
            print(f"  [{c.display_name}] 方块移动: {'开启' if enable else '关闭'}")


def cmd_reboot(parts):
    """reboot [IDX]"""
    idx, c = _auto_resolve_client(parts[1] if len(parts) > 1 else None)
    if c:
        ok = c.reboot_board()
        if ok:
            print(f"  [{c.display_name}] 继电器重启命令已发送")


def _parse_rgb_value(text):
    text = text.strip()
    if text.lower().startswith("0x"):
        text = text[2:]
    if not re.fullmatch(r"[0-9a-fA-F]{1,6}", text):
        raise ValueError("RGB 必须是 1-6 位十六进制，例如 FF00FF")
    return int(text, 16) & 0xFFFFFF


def cmd_isconnected(parts):
    """isconnected [IDX]"""
    idx, c = _auto_resolve_client(parts[1] if len(parts) > 1 else None)
    if c:
        print(f"  [{c.display_name}] DLL连接状态: {'CONNECTED' if c.is_connected() else 'DISCONNECTED'}")


def cmd_statpixel(parts):
    """statpixel [IDX] <channel> <RRGGBB>"""
    if len(parts) < 3:
        print("  用法: statpixel [IDX] <channel> <RRGGBB>")
        return

    if len(parts) == 3:
        idx, c = _auto_resolve_client(None)
        ch = int(parts[1])
        rgb = _parse_rgb_value(parts[2])
    else:
        if parts[1].isdigit():
            idx, c = _auto_resolve_client(parts[1])
            ch = int(parts[2])
            rgb = _parse_rgb_value(parts[3])
        else:
            idx, c = _auto_resolve_client(None)
            ch = int(parts[1])
            rgb = _parse_rgb_value(parts[2])

    if c:
        ok = c.set_statistics_pixel(ch, rgb)
        print(f"  [{c.display_name}] 设置 Ch{ch} 统计像素 0x{rgb:06X}: {'OK' if ok else 'FAIL'}")


def cmd_ignorepixel(parts):
    """ignorepixel [IDX] <channel> <RRGGBB>"""
    if len(parts) < 3:
        print("  用法: ignorepixel [IDX] <channel> <RRGGBB>")
        return

    if len(parts) == 3:
        idx, c = _auto_resolve_client(None)
        ch = int(parts[1])
        rgb = _parse_rgb_value(parts[2])
    else:
        if parts[1].isdigit():
            idx, c = _auto_resolve_client(parts[1])
            ch = int(parts[2])
            rgb = _parse_rgb_value(parts[3])
        else:
            idx, c = _auto_resolve_client(None)
            ch = int(parts[1])
            rgb = _parse_rgb_value(parts[2])

    if c:
        ok = c.set_ignored_pixel(ch, rgb)
        print(f"  [{c.display_name}] 设置 Ch{ch} 不比较像素 0x{rgb:06X}: {'OK' if ok else 'FAIL'}")


def cmd_setarea(parts):
    """setarea [IDX] <channel> <startX> <endX> <startY> <endY>"""
    if len(parts) < 6:
        print("  用法: setarea [IDX] <channel> <startX> <endX> <startY> <endY>")
        return

    if len(parts) == 6:
        idx, c = _auto_resolve_client(None)
        ch = int(parts[1])
        sx = int(parts[2])
        ex = int(parts[3])
        sy = int(parts[4])
        ey = int(parts[5])
    else:
        if parts[1].isdigit():
            idx, c = _auto_resolve_client(parts[1])
            ch = int(parts[2])
            sx = int(parts[3])
            ex = int(parts[4])
            sy = int(parts[5])
            ey = int(parts[6])
        else:
            idx, c = _auto_resolve_client(None)
            ch = int(parts[1])
            sx = int(parts[2])
            ex = int(parts[3])
            sy = int(parts[4])
            ey = int(parts[5])

    if c:
        ok = c.set_compare_area(ch, sx, ex, sy, ey)
        print(f"  [{c.display_name}] 设置 Ch{ch} 对比区域 startX={sx} endX={ex} startY={sy} endY={ey}: {'OK' if ok else 'FAIL'}")


## NOTE: removed duplicated statpixel/ignorepixel implementations (kept the first pair).


def cmd_start(parts):
    """start [IDX] [params]"""
    if len(parts) < 2:
        idx, c = _auto_resolve_client(None)
        params = "--channel 1 --threshold 5 --interval 1000 --imagePath ./images"
    else:
        if parts[1].isdigit():
            idx, c = _auto_resolve_client(parts[1])
            params = " ".join(parts[2:]) if len(parts) > 2 else "--channel 1 --threshold 5 --interval 1000 --imagePath ./images"
        else:
            idx, c = _auto_resolve_client(None)
            params = " ".join(parts[1:]) if len(parts) > 1 else "--channel 1 --threshold 5 --interval 1000 --imagePath ./images"

    if c:
        ok = c.start_comparison(params)
        if ok:
            print(f"  [{c.display_name}] 比对启动成功")
            _show_ref_images(c, params)


def cmd_stopch(parts):
    """stopch [IDX] <channel>"""
    if len(parts) < 2:
        print("  用法: stopch [IDX] <channel>")
        return
    if len(parts) == 2:
        idx, c = _auto_resolve_client(None)
        ch = int(parts[1])
    else:
        if parts[1].isdigit():
            idx, c = _auto_resolve_client(parts[1])
            ch = int(parts[2])
        else:
            idx, c = _auto_resolve_client(None)
            ch = int(parts[1])
    if c:
        ok = c.stop_channel_comparison(ch)
        print(f"  [{c.display_name}] 停止通道 {ch}: {'OK' if ok else 'FAIL'}")


def cmd_stop(parts):
    """stop [IDX]"""
    idx, c = _auto_resolve_client(parts[1] if len(parts) > 1 else None)
    if c:
        ok = c.stop_comparison()
        print(f"  [{c.display_name}] 停止比对: {'OK' if ok else 'FAIL'}")


def cmd_capture(parts):
    """capture <IDX> <path> [channel] [timeout]"""
    if len(parts) < 3:
        print("  用法: capture <IDX> <path> [channel] [timeout]")
        return
    idx = int(parts[1])
    path = parts[2]
    ch = int(parts[3]) if len(parts) > 3 else 1
    timeout = int(parts[4]) if len(parts) > 4 else 5000
    c = get_client(idx)
    if c:
        ok = c.capture_image(path, ch, timeout)
        if ok:
            print(f"  [{c.display_name}] 截图成功: {path}")


def cmd_switch(parts):
    """switch <IDX> <channel>"""
    if len(parts) < 3:
        print("  用法: switch <IDX> <channel>")
        return
    idx, ch = int(parts[1]), int(parts[2])
    c = get_client(idx)
    if c:
        ok = c.switch_video_source(ch)
        print(f"  [{c.display_name}] 切换视频源到 Ch{ch}: {'OK' if ok else 'FAIL'}")


def cmd_errcount(parts):
    """errcount <IDX> [channel]"""
    if len(parts) < 2:
        print("  用法: errcount <IDX> [channel]")
        return
    idx = int(parts[1])
    c = get_client(idx)
    if not c:
        return
    if len(parts) > 2:
        ch = int(parts[2])
        count = c.get_channel_error_record_count(ch)
        print(f"  [{c.display_name}] 通道 {ch} 错误: {count}")
    else:
        count = c.get_channel_error_record_count(-1)
        print(f"  [{c.display_name}] 总错误: {count}")
        for ch in range(1, 4):
            cnt = c.get_channel_error_record_count(ch)
            if cnt >= 0:
                print(f"    Ch{ch}: {cnt}")


def cmd_errrecords(parts):
    """errrecords <IDX> [channel] [count]"""
    if len(parts) < 2:
        print("  用法: errrecords <IDX> [channel] [count]")
        return
    idx = int(parts[1])
    c = get_client(idx)
    if not c:
        return

    if len(parts) > 2 and parts[2].isdigit():
        ch = int(parts[2])
        max_count = int(parts[3]) if len(parts) > 3 else 100
        records = c.get_channel_error_records(ch, max_count)
        print(f"  [{c.display_name}] 通道 {ch}: {len(records)} 条记录")
        for r in records:
            print(f"    {r}")
    else:
        max_count = int(parts[2]) if len(parts) > 2 else 100
        records = c.get_channel_error_records(-1, max_count)
        print(f"  [{c.display_name}] 全部: {len(records)} 条记录")
        for r in records:
            print(f"    {r}")


def cmd_clearerr(parts):
    """clearerr <IDX> [channel]"""
    if len(parts) < 2:
        print("  用法: clearerr <IDX> [channel]")
        return
    idx = int(parts[1])
    c = get_client(idx)
    if not c:
        return
    if len(parts) > 2:
        ch = int(parts[2])
        c.clear_channel_error_records(ch)
        print(f"  [{c.display_name}] 通道 {ch} 记录已清空。")
    else:
        c.clear_channel_error_records(-1)
        print(f"  [{c.display_name}] 所有记录已清空。")


def cmd_refname(parts):
    """refname <IDX> <channel>"""
    if len(parts) < 3:
        print("  用法: refname <IDX> <channel>")
        return
    idx, ch = int(parts[1]), int(parts[2])
    c = get_client(idx)
    if c:
        name = c.get_reference_image_name(ch)
        if name:
            print(f"  [{c.display_name}] Ch{ch} 标定图: {name}")
        else:
            print(f"  [{c.display_name}] Ch{ch} 无标定图")


def cmd_imagestatus(parts):
    """imagestatus [IDX] [channel]"""
    if len(parts) == 1:
        idx, c = _auto_resolve_client(None)
        ch = 1
    elif len(parts) == 2:
        if parts[1].isdigit() and int(parts[1]) in clients:
            idx, c = _auto_resolve_client(parts[1])
            ch = 1
        else:
            idx, c = _auto_resolve_client(None)
            ch = int(parts[1])
    else:
        idx, c = _auto_resolve_client(parts[1])
        ch = int(parts[2])

    if c:
        status = c.get_image_compare_status(ch)
        if status is not None:
            print(f"  [{c.display_name}] Ch{ch} 状态: {status}")


def cmd_autopoll(parts):
    """autopoll <IDX> [interval] [channels]"""
    if len(parts) < 2:
        print("  用法: autopoll <IDX> [interval_ms] [channels]  (channels: 1,2,3)")
        return
    idx = int(parts[1])
    interval = int(parts[2]) if len(parts) > 2 else 1000
    channels = None
    if len(parts) > 3:
        channels = [int(ch.strip()) for ch in parts[3].split(',')]
    c = get_client(idx)
    if c:
        c.start_auto_poll(interval, channels)
        print(f"  [{c.display_name}] 后台轮询已启动 (间隔: {interval}ms)")


def cmd_stoppoll(parts):
    """stoppoll <IDX>"""
    if len(parts) < 2:
        print("  用法: stoppoll <IDX>")
        return
    idx = int(parts[1])
    c = get_client(idx)
    if c:
        c.stop_auto_poll()
        print(f"  [{c.display_name}] 后台轮询已停止")


# =============================================================================
# 命令处理：批量操作
# =============================================================================

def cmd_connectbatch(parts):
    """connectbatch <ip1,ip2,...> [port]"""
    if len(parts) < 2:
        print("  用法: connectbatch <ip1,ip2,...> [port]")
        print("  示例: connectbatch 192.168.245.101,192.168.245.103,192.168.245.105")
        return
    ips = [ip.strip() for ip in parts[1].split(',') if ip.strip()]
    port = int(parts[2]) if len(parts) > 2 else 5555

    print(f"  批量连接 {len(ips)} 个设备 (端口: {port})...")
    global next_idx
    success = 0
    for ip in ips:
        idx = next_idx
        c = LvdsClient()
        clients[idx] = c
        next_idx += 1
        params = f"--serverIp {ip} --serverPort {port}"
        if c.connect(params):
            success += 1
    print(f"  批量连接完成: {success}/{len(ips)} 成功")


def cmd_disconnectall():
    """断开所有"""
    connected = get_connected_clients()
    if not connected:
        print("  无已连接的客户端。")
        return
    print(f"  断开 {len(connected)} 个客户端...")
    for idx, c in sorted(connected.items()):
        c.stop_auto_poll()
        c.disconnect()
    print("  全部已断开。")


def cmd_patternmoveall(parts):
    """patternmoveall <0|1>"""
    if len(parts) < 2:
        print("  用法: patternmoveall <0|1>")
        return
    enable = parts[1] not in ('0', 'false', 'off')
    desc = "开启" if enable else "关闭"
    connected = get_connected_clients()
    if not connected:
        print("  无已连接的客户端。")
        return
    for idx, c in sorted(connected.items()):
        ok = c.set_pattern_move(enable)
        print(f"  [{idx}] {c.display_name}: 方块移动{desc} {'OK' if ok else 'FAIL'}")


def cmd_startall(parts):
    """
    startall [params]
    
    自动为每个客户端的 --imagePath/--imageRootPath 追加 /{IP最后一段}
    
    例: connectbatch 192.168.245.101,192.168.245.103,192.168.245.105
        startall --channels 1,2,3 --threshold 5 --interval 2000 --imageRootPath E:\\TestData
    实际执行:
        实例1: --imageRootPath E:\\TestData\\101
        实例2: --imageRootPath E:\\TestData\\103
        实例3: --imageRootPath E:\\TestData\\105
    """
    base_params = " ".join(parts[1:]) if len(parts) > 1 else \
        "--channels 1,2,3 --threshold 5 --interval 2000 --imageRootPath ./images"

    connected = get_connected_clients()
    if not connected:
        print("  无已连接的客户端。")
        return

    print(f"  为 {len(connected)} 个客户端启动比对...")
    success = 0
    for idx, c in sorted(connected.items()):
        # 用 IP 最后一段作为子目录
        params = _append_ip_suffix(base_params, c)
        ok = c.start_comparison(params)
        status_str = '✓ 成功' if ok else '✗ 失败'
        suffix = _get_ip_suffix(c)
        print(f"  [{idx}] {c.display_name}: {status_str}  (路径后缀: /{suffix})")
        if ok:
            success += 1
            _show_ref_images(c, params)
    print(f"  启动完成: {success}/{len(connected)} 成功")


def cmd_stopall():
    """停止所有比对"""
    connected = get_connected_clients()
    if not connected:
        print("  无已连接的客户端。")
        return
    for idx, c in sorted(connected.items()):
        ok = c.stop_comparison()
        print(f"  [{idx}] {c.display_name}: 停止比对 {'OK' if ok else 'FAIL'}")


def cmd_captureall(parts):
    """
    captureall <dir> [channel] [timeout]
    
    保存到 dir/{IP最后一段}/
    """
    if len(parts) < 2:
        print("  用法: captureall <dir> [channel] [timeout]")
        return
    base_dir = parts[1]
    ch = int(parts[2]) if len(parts) > 2 else 1
    timeout = int(parts[3]) if len(parts) > 3 else 5000

    connected = get_connected_clients()
    if not connected:
        print("  无已连接的客户端。")
        return

    success = 0
    for idx, c in sorted(connected.items()):
        suffix = _get_ip_suffix(c)
        path = os.path.join(base_dir, suffix)
        ok = c.capture_image(path, ch, timeout)
        print(f"  [{idx}] {c.display_name}: 截图 {'OK' if ok else 'FAIL'} -> {path}")
        if ok:
            success += 1
    print(f"  截图完成: {success}/{len(connected)} 成功")


def cmd_autopollon(parts):
    """autopollon [interval] [channels]"""
    interval = int(parts[1]) if len(parts) > 1 else 1000
    channels = None
    if len(parts) > 2:
        channels = [int(ch.strip()) for ch in parts[2].split(',')]
    connected = get_connected_clients()
    if not connected:
        print("  无已连接的客户端。")
        return
    for idx, c in sorted(connected.items()):
        c.start_auto_poll(interval, channels)
    ch_desc = f"通道 {channels}" if channels else "所有通道"
    print(f"  {len(connected)} 个客户端后台轮询已启动 (间隔: {interval}ms, {ch_desc})")


def cmd_autopolloff():
    """停止所有轮询"""
    count = 0
    for c in clients.values():
        if c._auto_poll_thread and c._auto_poll_thread.is_alive():
            c.stop_auto_poll()
            count += 1
    print(f"  {count} 个客户端后台轮询已停止。")


def cmd_clearall():
    """清理所有"""
    cmd_autopolloff()
    for c in clients.values():
        if c.is_connected():
            c.disconnect()
    clients.clear()
    global next_idx
    next_idx = 1
    LvdsClient._dll.LvdsClearAll()
    print("  所有实例已清理。")


# =============================================================================
# 主函数
# =============================================================================

def main():
    signal.signal(signal.SIGINT, signal_handler)

    print("=" * 70)
    print("  LVDS 多客户端测试工具 v2.7.0")
    print("=" * 70)
    print("  输入 'help' 获取帮助, 'exit' 退出。\n")

    try:
        LvdsClient.init_library()
    except Exception as e:
        print(f"初始化 DLL 失败: {e}")
        return

    while True:
        try:
            cmd_line = input("LVDS> ").strip()
            if not cmd_line:
                continue

            parts = cmd_line.split()
            command = parts[0].lower()

            # ─────────── 全局命令 ───────────
            if command == "help":
                print_help()
            elif command == "exit":
                break
            elif command == "status":
                show_status()
            elif command == "list":
                show_list()
            elif command == "clearall":
                cmd_clearall()

            # ─────────── 批量命令 ───────────
            elif command == "connectbatch":
                cmd_connectbatch(parts)
            elif command == "disconnectall":
                cmd_disconnectall()
            elif command == "patternmoveall":
                cmd_patternmoveall(parts)
            elif command == "startall":
                cmd_startall(parts)
            elif command == "stopall":
                cmd_stopall()
            elif command == "captureall":
                cmd_captureall(parts)
            elif command == "autopollon":
                cmd_autopollon(parts)
            elif command == "autopolloff":
                cmd_autopolloff()

            # ─────────── 单客户端命令 ───────────
            elif command == "connect":
                cmd_connect(parts)
            elif command == "disconnect":
                cmd_disconnect(parts)
            elif command == "patternmove":
                cmd_patternmove(parts)
            elif command == "reboot":
                cmd_reboot(parts)
            elif command == "isconnected":
                cmd_isconnected(parts)
            elif command == "statpixel":
                cmd_statpixel(parts)
            elif command == "ignorepixel":
                cmd_ignorepixel(parts)
            elif command == "setarea":
                cmd_setarea(parts)
            elif command == "start":
                cmd_start(parts)
            elif command == "startmulti":
                # 兼容旧命令，等同于 start
                cmd_start(parts)
            elif command == "stopch":
                cmd_stopch(parts)
            elif command == "stop":
                cmd_stop(parts)
            elif command == "capture":
                cmd_capture(parts)
            elif command == "switch":
                cmd_switch(parts)
            elif command == "errcount":
                cmd_errcount(parts)
            elif command == "errrecords":
                cmd_errrecords(parts)
            elif command == "clearerr":
                cmd_clearerr(parts)
            elif command == "refname":
                cmd_refname(parts)
            elif command == "imagestatus":
                cmd_imagestatus(parts)
            elif command == "autopoll":
                cmd_autopoll(parts)
            elif command == "stoppoll":
                cmd_stoppoll(parts)

            else:
                print(f"  未知命令: '{command}'。输入 'help' 查看帮助。")

        except ValueError as e:
            print(f"  参数格式错误: {e}")
        except Exception as e:
            print(f"  异常: {e}")
            import traceback
            traceback.print_exc()

    # ─────────── 退出清理 ───────────
    print("\n正在清理资源...")
    cmd_autopolloff()
    for idx, c in sorted(clients.items()):
        if c.is_connected():
            c.disconnect()
    LvdsClient.cleanup_library()
    print("程序已退出。")


if __name__ == "__main__":
    main()

