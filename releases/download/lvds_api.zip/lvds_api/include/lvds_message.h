/*----------------------------------------------------------------------------
*               LVDS 通信协议消息定义
*-----------------------------------------------------------------------------
*
* 该文件定义了与 LVDS 设备通信所使用的核心数据结构和错误码。
* 此文件对外暴露，供用户应用程序（如 LabVIEW、C#）使用。
*
* 作者: leiwei
* 版本: v1.0.0
*----------------------------------------------------------------------------*/

#ifndef LVDS_MESSAGE_H
#define LVDS_MESSAGE_H

/* 确保结构体按 4 字节对齐 */
#ifdef _MSC_VER
#pragma pack(push, 4)
#else
#pragma pack(4)
#endif

// =============================================================================
//                              操作结果枚举
// =============================================================================

/**
 * @brief 操作结果码
 *
 * 所有 API 函数的返回值均使用此枚举定义的错误码。
 * 0 表示成功，负值表示各种错误类型。
 */
typedef enum {
    // === 成功状态 ===
    LVDS_RESULT_OK = 0,                     ///< 操作成功

    // === 参数和配置错误 (-1 ~ -10) ===
    LVDS_RESULT_INVALID_PARAM = -1,         ///< 无效的参数
    LVDS_RESULT_INTERNAL_ERROR = -2,        ///< 内部错误
    LVDS_RESULT_BUFFER_TOO_SMALL = -3,      ///< 缓冲区太小
    LVDS_RESULT_INVALID_STATE = -4,         ///< 无效的状态

    // === 连接相关错误 (-11 ~ -20) ===
    LVDS_RESULT_CONNECTION_FAILED = -11,    ///< 连接失败
    LVDS_RESULT_TOO_MANY_INSTANCES = -12,   ///< 实例过多
    LVDS_RESULT_INVALID_INSTANCE_ID = -13,  ///< 无效的实例 ID
    LVDS_RESULT_NOT_CONNECTED = -14,        ///< 设备未连接

    // === 业务逻辑错误 (-21 ~ -30) ===
    LVDS_RESULT_SEND_FAILED = -21,          ///< 发送失败
    LVDS_RESULT_TIMEOUT = -22,              ///< 操作超时
    LVDS_RESULT_NO_RESPONSE = -23,          ///< 设备无响应
    LVDS_RESULT_NO_DATA = -24,              ///< 无可用数据

    // === 运行状态错误 (-31 ~ -40) ===
    LVDS_RESULT_ALREADY_RUNNING = -31,      ///< 已在运行
    LVDS_RESULT_NOT_RUNNING = -32,          ///< 未在运行
    LVDS_RESULT_MODE_CONFLICT = -33,        ///< 模式冲突
    LVDS_RESULT_REF_CAPTURE_FAILED = -34,   ///< 标定帧获取失败
    LVDS_RESULT_REF_CAPTURE_TIMEOUT = -35,  ///< 标定帧获取超时
    LVDS_RESULT_IMAGE_COUNT_EXCEEDED = -36, ///< 图像数量超限，通道比对已自动停止
    LVDS_RESULT_NO_IMAGE_SOURCE = -37,      ///< 无图像源（图像分辨率 0×0）
    LVDS_RESULT_DEVICE_REJECTED = -38,      ///< 设备拒绝命令（响应 FF FF）
} LvdsResultCode;

// =============================================================================
//                              图像比对状态结构
// =============================================================================

/**
 * @brief 图像比对状态及统计信息
 *
 * 对应协议 Cmd 0x30 Sub 0x04 (主动查询) 或 0x05 (自动上报) 的响应数据。
 *
 * status_code 位定义:
 *   - Bit0: 比对开关状态 (1=开启, 0=关闭)
 *   - Bit1: 错误标志 (1=当前帧有错误, 0=正常)
 *   - Bit2: 图像源状态 (1=有图像源, 0=无图像源)
 */
typedef struct LvdsImageStatus_ {
    unsigned int channel;           ///< [7-10] 通道号
    unsigned int status_code;       ///< [11-14] 状态码 (Bit0:开关, Bit1:错误标志, Bit2:图像源)
    unsigned int width;             ///< [15-18] 视频宽度 (像素)
    unsigned int height;            ///< [19-22] 视频高度 (像素)
    unsigned int fps;               ///< [23-26] 当前帧率
    unsigned int total_frames;      ///< [27-30] 累计帧总数 (对应板卡 fps_total_cnt)
    unsigned int err_pixel;         ///< [31-34] 错误时的像素点，即上一帧的像素点
    unsigned int input_pixel;       ///< [35-38] 错误时输入的像素点
    unsigned int threshold;         ///< [39-42] 像素比对阈值
    unsigned int error_col;         ///< [43-46] 一张图片发送的帧序号，当前图片的第n帧
    unsigned int error_line;        ///< [47-50] 当前包图片数据大小，例如1200
    unsigned int rgb_cnt_pixel;     ///< [51-54] 需要进行统计的像素值 rgb24位
    unsigned int rgb_pixel_total;   ///< [55-58] 统计后的像素值个数
    unsigned int rgb_not_pixel;     ///< [59-62] 不进行比较像素值
    unsigned int compare_start_x;     ///< [63-66] 对比区域起始X坐标
    unsigned int compare_end_x;       ///< [67-70] 对比区域结束X坐标
    unsigned int compare_start_y;     ///< [71-74] 对比区域起始Y坐标
    unsigned int compare_end_y;       ///< [75-78] 对比区域结束Y坐标
    unsigned int point_x;             ///< 输入坐标 X
    unsigned int point_y;             ///< 输入坐标 Y
    unsigned int point_pixel;         ///< 输入坐标对应像素值，RGB888
} LvdsImageCompareStatus;

// =============================================================================
//                              错误记录结构
// =============================================================================

/**
 * @brief 单条错误记录
 *
 * 当图像比对检测到错误时，会生成一条错误记录。
 * 包含错误发生时的图像文件名（含时间戳）和详细状态信息。
 *
 * 图像文件名格式: ERR_YYYYMMDDHHmmsszzz.png
 * 例如: ERR_20250211103418123.png
 */
typedef struct LvdsErrorRecord_ {
    char image_name[64];            ///< 错误图像文件名 (如 "ERR_20250211103418123.png")
    LvdsImageCompareStatus status;  ///< 错误发生时的状态信息
} LvdsErrorRecord;

#ifdef _MSC_VER
#pragma pack(pop)
#else
#pragma pack()
#endif

#endif // LVDS_MESSAGE_H
