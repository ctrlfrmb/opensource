﻿/*----------------------------------------------------------------------------
* LVDS 图像比对卡 C-API 接口
*
* 提供 LVDS 图像采集与比对功能的 C-API 接口，支持设备连接、图像比对控制。
* 该 API 旨在为上层应用（如 LabVIEW、C#）提供一个简单、稳定的硬件控制层，
* 并已封装为跨平台的动态链接库（DLL/SO）。
*
* 主要特点：
* - 建立与 LVDS 设备的 UDP 连接
* - 支持单通道和多通道图像比对
* - 使用板卡自动上报模式，无需上位机轮询
* - 自动获取标定图像和错误帧并保存到文件
* - 支持截图功能，保存当前帧到文件
* - 支持视频源通道切换
* - 支持方块移动控制（用于测试场景）
* - 使用实例 ID 进行多设备并行管理
* - 完善的日志功能，便于调试和问题追溯
* - 线程安全设计
*
* 错误码说明：
* - 0: 成功
* - -1 ~ -10: 参数错误 (无效参数、内部错误、缓冲区太小等)
* - -11 ~ -20: 连接错误 (连接失败、实例超限、未连接等)
* - -21 ~ -30: 业务错误 (发送失败、超时、无数据等)
* - -31 ~ -40: 状态错误 (已运行、未运行、模式冲突、标定帧超时等)
*
* 使用示例 (单通道):
*   // 1. 可选：开启日志
*   LvdsOpenLog("logs/lvds.log", 1, 10, 5);
*
*   // 2. 连接设备
*   int id = LvdsConnect("--serverIp 192.168.1.10 --serverPort 5555");
*   if (id <= 0) {
*       printf("连接失败: %d\n", id);
*       return;
*   }
*
*   // 3. 关闭方块移动（可选，板卡默认开启方块移动）
*   LvdsSetPatternMove(id, 0);
*
*   // 4. 启动单通道图像比对
*   int ret = LvdsStartComparison(id, "--channel 1 --threshold 5 --interval 1000 --imagePath C:/lvds/ch1");
*   if (ret != 0) {
*       printf("启动比对失败: %d\n", ret);
*       LvdsDisconnect(id);
*       return;
*   }
*
*   // 5. 循环获取错误记录
*   while (running) {
*       int errCount = LvdsGetChannelErrorRecordCount(id, 1);  // 通道1
*       if (errCount > 0) {
*           LvdsErrorRecord records[100];
*           int got = LvdsGetChannelErrorRecords(id, 1, records, 100);
*           for (int i = 0; i < got; i++) {
*               printf("错误图像: %s, 错误像素: %u\n",
*                      records[i].image_name, records[i].status.err_pixel);
*           }
*       }
*       Sleep(1000);
*   }
*
*   // 6. 停止并断开
*   LvdsStopComparison(id, 1);  // 停止通道1
*   LvdsDisconnect(id);
*
* 使用示例 (多通道):
*   // 启动三通道同时比对
*   int ret = LvdsStartComparison(id, "--channels 1,2,3 --threshold 5 --interval 1000 --imageRootPath C:/lvds");
*   // 图像将保存到: C:/lvds/1/, C:/lvds/2/, C:/lvds/3/
*
*   // 获取所有通道的错误记录数量
*   int total = LvdsGetChannelErrorRecordCount(id, -1);
*
*   // 清空所有通道错误记录
*   LvdsClearChannelErrorRecords(id, -1);
*
*   // 停止所有通道
*   LvdsStopAllComparison(id);
*
*-----------------------------------------------------------------------------
* 作者: leiwei
* 版本: v2.7.0
* 日期: 2026-05-14
*----------------------------------------------------------------------------*/

#ifndef LVDS_API_H
#define LVDS_API_H

#include "lvds_message.h"

#ifdef _WIN32
#ifdef BUILD_LVDS_API
#define LVDS_API extern "C" __declspec(dllexport)
#else
#define LVDS_API extern "C" __declspec(dllimport)
#endif
#else
#define LVDS_API extern "C"
#endif


/*******************************************************************************
 * 日志管理
 *******************************************************************************/

/**
 * @brief 打开日志，用于调试和故障诊断
 *
 * 建议调试时使用，通常不调用此接口，会占用 CPU 和硬盘资源
 *
 * @param logFile 日志文件路径，形如: logs/lvds.log
 * @param level 日志等级 0:DEBUG 1:INFO 2:WARN 3:ERROR
 * @param maxSize 文件大小，单位 MB，推荐 10
 * @param maxFiles 文件个数，推荐 5
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsOpenLog(const char* logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志
 *
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsCloseLog();


/*******************************************************************************
 * 连接管理
 *******************************************************************************/

/**
 * @brief 连接到 LVDS 设备
 *
 * @param params 参数字符串，格式为 "--key value" 对
 *               必填: --serverIp <string> 设备 IP 地址
 *               可选: --serverPort <int> 端口号 (默认: 5555)
 *                     --localIp <string> 本地网卡 IP (多网卡环境)
 *                     --localPort <int> 本地端口 (默认: 0，自动分配)
 *                     --sendBufferSize <int> UDP 发送缓冲区大小(字节), < 0: 系统默认值 0: 程序自动调整  > 0: 指定大小
 *                     --recvBufferSize <int> UDP 接收缓冲区大小(字节), < 0: 系统默认值 0: 程序自动调整  > 0: 指定大小
 * @return >0:成功，返回实例 ID  <=0:失败错误码
 *
 * @code
 *   int id = LvdsConnect("--serverIp 192.168.1.10 --serverPort 5555 --recvBufferSize 8388608");
 * @endcode
 */
LVDS_API int LvdsConnect(const char* params);

/**
 * @brief 断开设备连接
 *
 * @param instanceId 实例 ID
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsDisconnect(int instanceId);

/**
 * @brief 检查设备是否已连接
 *
 * @param instanceId 实例 ID
 * @return 1:已连接 0:未连接 <0:失败错误码
 */
LVDS_API int LvdsIsConnected(int instanceId);

/**
 * @brief 断开所有连接并清理资源
 *
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsClearAll();


/*******************************************************************************
 * 图像比对控制
 *******************************************************************************/

/**
 * @brief 设置模拟图案方块移动
 *
 * 用于测试场景，控制视频流中的方块图案是否移动。
 * - 关闭时：视频流为静态图，图像比对正常
 * - 开启时：视频流为动态图（方块移动），图像比对会报错
 *
 * 板卡默认开启方块移动。建议在启动比对前调用此接口关闭方块移动，
 * 以确保比对结果正常。
 *
 * @param instanceId 实例 ID
 * @param enable 0=关闭方块移动(静态图), 非0=开启方块移动(动态图)
 * @return 0:成功 -13:无效实例ID -14:未连接 其它:失败错误码
 */
LVDS_API int LvdsSetPatternMove(int instanceId, int enable);

/**
 * @brief 继电器重启板卡
 *
 * 通过控制继电器断电再上电，实现板卡硬重启。
 * 对应协议命令: 08 00 00 00 40 0B 00 xx
 *
 * @param instanceId 实例 ID
 * @return 0:成功 -13:无效实例ID -14:未连接 其它:失败错误码
 */
LVDS_API int LvdsRebootBoard(int instanceId);

/**
 * @brief 设置图像比较统计像素值
 *
 * 对应协议 Cmd 0x30 / cmd_index 0x07。
 * rgb 使用上位机统一的 0xRRGGBB 格式，发送时在协议边界转换为板端 GBR 三字节。
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)
 * @param rgb RGB888 颜色值，格式 0xRRGGBB
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsSetStatisticsPixel(int instanceId, int channel, unsigned int rgb);

/**
 * @brief 设置不进行比较的像素值
 *
 * 对应协议 Cmd 0x30 / cmd_index 0x08。
 * rgb 使用上位机统一的 0xRRGGBB 格式，发送时在协议边界转换为板端 GBR 三字节。
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)
 * @param rgb RGB888 颜色值，格式 0xRRGGBB
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsSetIgnoredPixel(int instanceId, int channel, unsigned int rgb);

/**
 * @brief 设置图像对比限定区域
 *
 * 对应协议 Cmd 0x30 / cmd_index 0x09。
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)
 * @param startX 区域起始X坐标（用户输入从 1 开始，板卡内部会自行减 1）
 * @param endX 区域结束X坐标（用户输入从 1 开始）
 * @param startY 区域起始Y坐标（用户输入从 1 开始，板卡内部会自行减 1）
 * @param endY 区域结束Y坐标（用户输入从 1 开始）
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsSetCompareArea(int instanceId, int channel, unsigned int startX, unsigned int endX, unsigned int startY, unsigned int endY);

/**
 * @brief 设置输入坐标，用于查询该坐标的像素值
 *
 * 对应协议 Cmd 0x30 / cmd_index 0x0A。
 * 设置成功后，调用 `LvdsGetImageCompareStatus` 可从 `LvdsImageCompareStatus`
 * 的 `point_x`、`point_y`、`point_pixel` 读取板卡返回的坐标及像素值。
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)
 * @param x 输入坐标 X
 * @param y 输入坐标 Y
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsSetInputPoint(int instanceId, int channel, unsigned int x, unsigned int y);

/**
 * @brief 启动图像比对 (支持单通道和多通道)
 *
 * 此函数会同步阻塞直到所有通道的标定帧获取成功或超时。
 * 使用板卡自动上报模式，检测到错误时自动保存错误帧。
 *
 * 单通道参数格式:
 *   必填: --channel <int> 通道号 (1-3)
 *         --imagePath <string> 图像保存目录
 *   可选: --threshold <int> 像素阈值 0-255 (默认: 5)
 *         --interval <int> 截图间隔 ms (默认: 1000)
 *         --maxImages <int> 最大图像数量 (默认: 10000)
 *         --maxRecords <int> 最大错误记录数 (默认: 10000)
 *         --refTimeout <int> 标定帧获取超时 ms (默认: 2000)
 *         --imageFormat <string> 保存格式 (默认: png)
 *
 * 多通道参数格式:
 *   必填: --channels <string> 通道列表，逗号分隔 (如 "1,2,3")
 *         --imageRootPath <string> 图像保存根目录 (会自动创建 1/, 2/, 3/ 子目录)
 *   可选: --threshold <int> 所有通道的像素阈值 (默认: 5)
 *         --interval <int> 所有通道的截图间隔 ms (默认: 1000)
 *         --maxImages <int> 每个通道的最大图像数量 (默认: 10000)
 *         --maxRecords <int> 每个通道的最大错误记录数 (默认: 10000)
 *         --refTimeout <int> 标定帧获取超时 ms (默认: 2000)
 *         --imageFormat <string> 保存格式 (默认: png)
 *
 * @param instanceId 实例 ID
 * @param params 参数字符串
 * @return 0:成功 -35:标定帧获取超时 其它:失败错误码
 *
 * @code
 *   // 单通道比对
 *   LvdsSetPatternMove(id, 0);
 *   int ret = LvdsStartComparison(id, "--channel 1 --threshold 5 --imagePath C:/lvds/ch1");
 *
 *   // 多通道比对
 *   int ret = LvdsStartComparison(id, "--channels 1,2,3 --threshold 5 --imageRootPath C:/lvds");
 * @endcode
 */
LVDS_API int LvdsStartComparison(int instanceId, const char* params);

/**
 * @brief 停止指定通道的图像比对
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsStopChannelComparison(int instanceId, int channel);

/**
 * @brief 停止所有通道的图像比对
 *
 * @param instanceId 实例 ID
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsStopComparison(int instanceId);


/*******************************************************************************
 * 截图与通道切换
 *******************************************************************************/

/**
 * @brief 捕获当前图像并保存
 *
 * 同步阻塞获取一帧图像并保存到指定路径。
 *
 * 路径规则：
 *   - 如果 path 以 .png/.jpg/.bmp 等扩展名结尾，视为完整文件路径，直接保存
 *   - 否则视为目录路径，自动生成文件名 IMG_YYYYMMDDHHmmsszzz.png
 *
 * @param instanceId 实例 ID
 * @param path 保存路径 (可以是目录或完整文件路径)
 * @param channel 通道号 (默认: 1)
 * @param timeoutMs 超时时间毫秒 (默认: 5000)
 * @return 0:成功 -13:无效实例ID -14:未连接 -1:路径无效 -22:超时 -2:保存失败
 *
 * @code
 *   // 保存到指定文件
 *   int ret = LvdsCaptureImage(id, "C:/images/test.png", 1, 5000);
 *
 *   // 保存到目录 (自动生成文件名)
 *   int ret = LvdsCaptureImage(id, "C:/images", 1, 5000);
 * @endcode
 */
LVDS_API int LvdsCaptureImage(int instanceId, const char* path, int channel, int timeoutMs);

/**
 * @brief 切换视频源通道
 *
 * 仅在板卡内部多通道图像源时生效。
 *
 * @param instanceId 实例 ID
 * @param targetChannel 目标通道号 (1-3)
 * @return 0:成功 -13:无效实例ID -14:未连接 -1:无效通道号 其它:失败错误码
 */
LVDS_API int LvdsSwitchVideoSource(int instanceId, int targetChannel);

/**
 * @brief 获取图像比较状态信息
 *
 * 通过 Cmd 0x30 / Sub 0x04 主动查询板卡当前图像比较状态，
 * 成功时返回 `LvdsImageCompareStatus`（分辨率、帧率、阈值、像素统计等）。
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)
 * @param outStatus [out] 图像比较状态输出结构体
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsGetImageCompareStatus(int instanceId, int channel, LvdsImageCompareStatus* outStatus);


/*******************************************************************************
 * 错误记录管理
 *******************************************************************************/

/**
 * @brief 获取指定通道的错误记录并清空缓存
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)
 * @param outRecords [out] 输出错误记录数组 (调用者分配内存)
 * @param maxCount [in] 最大获取数量
 * @return >=0:实际获取的错误记录数量 <0:失败错误码
 */
LVDS_API int LvdsGetChannelErrorRecords(int instanceId, int channel, LvdsErrorRecord* outRecords, int maxCount);

/**
 * @brief 获取指定通道的错误记录数量
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)，-1 表示所有通道
 * @return >=0: 错误记录数量
 *         LVDS_RESULT_IMAGE_COUNT_EXCEEDED(-36): 该通道图像数量已超限，比对已自动停止
 *         其他负值: 失败错误码 (如 LVDS_RESULT_INVALID_INSTANCE_ID)
 */
LVDS_API int LvdsGetChannelErrorRecordCount(int instanceId, int channel);

/**
 * @brief 清空指定通道的错误记录缓存
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)，-1 表示所有通道
 * @return 0:成功 其它:失败错误码
 */
LVDS_API int LvdsClearChannelErrorRecords(int instanceId, int channel);

/**
 * @brief 获取指定通道的标定图文件名
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-3)
 * @param buffer [out] 输出缓冲区
 * @param bufferSize [in] 缓冲区大小 (建议至少 64 字节)
 * @return 0:成功 -24:无标定图 -13:无效实例ID 其它:失败错误码
 */
LVDS_API int LvdsGetReferenceImageName(int instanceId, int channel, char* buffer, int bufferSize);

#endif // LVDS_API_H

