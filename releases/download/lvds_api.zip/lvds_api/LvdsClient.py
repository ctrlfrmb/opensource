﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: leiwei
LvdsClient.py - LVDS 客户端 Python 封装实现（多实例版）

版本: v2.7.0

核心变更:
- DLL 在类级别加载一次，所有实例共享
- 每个 LvdsClient 实例封装一个设备连接（一个 instance_id）
- 支持同时创建多个实例连接不同设备
"""

from LvdsMessage import *
import ctypes
import platform
import os
import threading
import time
import re


class LvdsClient:
    """
    LVDS 客户端 Python 封装（多实例版）

    使用方法:
        # 1. 初始化库（整个进程只需一次）
        LvdsClient.init_library("./lib/Winx64")

        # 2. 创建多个客户端实例
        c1 = LvdsClient()
        c1.connect("--serverIp 192.168.245.101 --serverPort 5555")

        c2 = LvdsClient()
        c2.connect("--serverIp 192.168.245.121 --serverPort 5555")

        # 3. 各自独立操作
        c1.start_comparison("--channel 1 --threshold 5 --imagePath ./images/dev1/ch1")
        c2.start_comparison("--channel 1 --threshold 5 --imagePath ./images/dev2/ch1")

        # 4. 清理
        c1.disconnect()
        c2.disconnect()
        LvdsClient.cleanup_library()
    """

    # =========================================================================
    # 类级别：DLL 单例管理
    # =========================================================================

    _dll = None
    _dll_lock = threading.Lock()
    _initialized = False
    _lib_path = None

    @classmethod
    def init_library(cls, lib_path=None):
        """
        初始化 LVDS 库（加载 DLL + 开启日志）

        整个进程只需调用一次。后续创建的所有 LvdsClient 实例共享同一个 DLL。

        Args:
            lib_path: DLL 所在目录路径，None 则自动检测
        """
        with cls._dll_lock:
            if cls._initialized:
                return

            cls._load_dll(lib_path)
            cls._define_api_prototypes()

            # 开启日志
            log_path = b"logs/lvds_client_test.log"
            cls._dll.LvdsOpenLog(log_path, 1, 10, 5)

            cls._initialized = True
            print("LVDS API 库加载成功 (v2.7.0)，日志保存在 logs/ 目录。")

    @classmethod
    def cleanup_library(cls):
        """清理库资源（关闭日志、释放所有实例），程序退出时调用"""
        with cls._dll_lock:
            if not cls._initialized:
                return
            try:
                cls._dll.LvdsClearAll()
                cls._dll.LvdsCloseLog()
            except Exception as e:
                print(f"清理库资源异常: {e}")
            cls._initialized = False
            print("LVDS API 库资源已清理。")

    @classmethod
    def is_library_ready(cls):
        """检查库是否已初始化"""
        return cls._initialized

    @classmethod
    def _load_dll(cls, lib_path):
        """加载 DLL"""
        if lib_path is None:
            arch = platform.architecture()[0]
            lib_path = os.path.abspath("./lib/Winx64" if arch == "64bit" else "./lib/Winx86")

        if not os.path.isdir(lib_path):
            lib_path = os.path.abspath(".")

        cls._lib_path = lib_path

        # 设置环境变量
        os.environ['QT_PLUGIN_PATH'] = lib_path
        os.environ['PATH'] = lib_path + os.pathsep + os.environ.get('PATH', '')
        if hasattr(os, 'add_dll_directory'):
            os.add_dll_directory(lib_path)

        # 加载 DLL
        try:
            if platform.system() == "Windows":
                # lvds_api.h 未声明 __stdcall，Windows 侧按 cdecl 导出；必须使用 CDLL。
                cls._dll = ctypes.CDLL(os.path.join(lib_path, "lvds_api.dll"))
            else:
                cls._dll = ctypes.CDLL(os.path.join(lib_path, "liblvds_api.so"))
        except OSError as e:
            print(f"加载 DLL 失败: {e}")
            raise

    @classmethod
    def _define_api_prototypes(cls):
        """定义 DLL 函数原型"""
        dll = cls._dll

        # 日志
        dll.LvdsOpenLog.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
        dll.LvdsOpenLog.restype = ctypes.c_int
        dll.LvdsCloseLog.restype = ctypes.c_int

        # 连接
        dll.LvdsConnect.argtypes = [ctypes.c_char_p]
        dll.LvdsConnect.restype = ctypes.c_int
        dll.LvdsDisconnect.argtypes = [ctypes.c_int]
        dll.LvdsDisconnect.restype = ctypes.c_int
        dll.LvdsClearAll.restype = ctypes.c_int

        # 比对控制
        dll.LvdsSetPatternMove.argtypes = [ctypes.c_int, ctypes.c_int]
        dll.LvdsSetPatternMove.restype = ctypes.c_int
        dll.LvdsSetStatisticsPixel.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        dll.LvdsSetStatisticsPixel.restype = ctypes.c_int
        dll.LvdsSetIgnoredPixel.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        dll.LvdsSetIgnoredPixel.restype = ctypes.c_int
        dll.LvdsSetCompareArea.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint]
        dll.LvdsSetCompareArea.restype = ctypes.c_int
        dll.LvdsSetInputPoint.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint, ctypes.c_uint]
        dll.LvdsSetInputPoint.restype = ctypes.c_int
        dll.LvdsStartComparison.argtypes = [ctypes.c_int, ctypes.c_char_p]
        dll.LvdsStartComparison.restype = ctypes.c_int
        dll.LvdsStopChannelComparison.argtypes = [ctypes.c_int, ctypes.c_int]
        dll.LvdsStopChannelComparison.restype = ctypes.c_int
        dll.LvdsStopComparison.argtypes = [ctypes.c_int]
        dll.LvdsStopComparison.restype = ctypes.c_int

        # 截图
        dll.LvdsCaptureImage.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
        dll.LvdsCaptureImage.restype = ctypes.c_int
        dll.LvdsSwitchVideoSource.argtypes = [ctypes.c_int, ctypes.c_int]
        dll.LvdsSwitchVideoSource.restype = ctypes.c_int
        dll.LvdsGetImageCompareStatus.argtypes = [
            ctypes.c_int, ctypes.c_int, ctypes.POINTER(LvdsImageCompareStatus)
        ]
        dll.LvdsGetImageCompareStatus.restype = ctypes.c_int

        # 错误记录
        dll.LvdsGetChannelErrorRecords.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.POINTER(LvdsErrorRecord), ctypes.c_int]
        dll.LvdsGetChannelErrorRecords.restype = ctypes.c_int
        dll.LvdsGetChannelErrorRecordCount.argtypes = [ctypes.c_int, ctypes.c_int]
        dll.LvdsGetChannelErrorRecordCount.restype = ctypes.c_int
        dll.LvdsClearChannelErrorRecords.argtypes = [ctypes.c_int, ctypes.c_int]
        dll.LvdsClearChannelErrorRecords.restype = ctypes.c_int
        dll.LvdsGetReferenceImageName.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
        dll.LvdsGetReferenceImageName.restype = ctypes.c_int
        dll.LvdsIsConnected.argtypes = [ctypes.c_int]
        dll.LvdsIsConnected.restype = ctypes.c_int

    # =========================================================================
    # 实例级别：单设备连接管理
    # =========================================================================

    def __init__(self):
        """
        创建客户端实例

        注意: 使用前必须先调用 LvdsClient.init_library()
        """
        if not LvdsClient._initialized:
            raise RuntimeError("请先调用 LvdsClient.init_library() 初始化库")

        self.instance_id = None
        self.server_ip = ""
        self.server_port = 5555
        self._auto_poll_thread = None
        self._auto_poll_stop_event = None

    @property
    def dll(self):
        return LvdsClient._dll

    @property
    def display_name(self):
        """显示名称（IP:Port）"""
        if self.server_ip:
            return f"{self.server_ip}:{self.server_port}"
        return "未连接"

    def is_connected(self):
        """检查是否已连接"""
        if self.instance_id is None:
            return False
        return self.dll.LvdsIsConnected(self.instance_id) == 1

    # =========================================================================
    # 连接管理
    # =========================================================================

    def connect_ex(self, params_str):
        """连接到 LVDS 设备，返回 LVDS_RESULT_* 错误码。"""
        if self.is_connected():
            print(f"  警告: 已连接到 {self.display_name}，请先断开。")
            return LVDS_RESULT_INVALID_STATE

        self._parse_connect_info(params_str)

        result = self.dll.LvdsConnect(params_str.encode('utf-8'))
        if result > 0:
            self.instance_id = result
            print(f"  连接成功: {self.display_name} (实例ID: {self.instance_id})")
            return LVDS_RESULT_OK

        print(f"  连接失败 [{self.server_ip}]: {get_status_description(result)} ({result})")
        self.server_ip = ""
        return result

    def connect(self, params_str):
        """连接到 LVDS 设备，兼容旧脚本，成功返回 True。"""
        return self.connect_ex(params_str) == LVDS_RESULT_OK

    def disconnect_ex(self):
        """断开连接，返回 LVDS_RESULT_* 错误码。"""
        if not self.is_connected():
            return LVDS_RESULT_NOT_CONNECTED
        self.stop_auto_poll()
        name = self.display_name
        status = self.dll.LvdsDisconnect(self.instance_id)
        if status == LVDS_RESULT_OK:
            self.instance_id = None
            print(f"  已断开: {name}")
            return LVDS_RESULT_OK
        print(f"  断开失败 [{name}]: {get_status_description(status)} ({status})")
        return status

    def disconnect(self):
        """断开连接，兼容旧脚本，成功返回 True。"""
        return self.disconnect_ex() == LVDS_RESULT_OK

    # =========================================================================
    # 方块移动控制
    # =========================================================================

    def set_pattern_move(self, enable):
        """设置方块移动 (True=动态图, False=静态图)"""
        if not self.is_connected():
            return False
        status = self.dll.LvdsSetPatternMove(self.instance_id, 1 if enable else 0)
        if status == LVDS_RESULT_OK:
            return True
        print(f"  [{self.display_name}] 设置方块移动失败: {get_status_description(status)}")
        return False

    def reboot_board(self):
        """继电器重启板卡（断电再上电）"""
        if not self.is_connected():
            return False
        status = self.dll.LvdsRebootBoard(self.instance_id)
        if status == LVDS_RESULT_OK:
            return True
        print(f"  [{self.display_name}] 重启板卡失败: {get_status_description(status)}")
        return False

    def set_statistics_pixel(self, channel, rgb):
        """设置统计像素值，rgb 为 0xRRGGBB。"""
        if not self.is_connected():
            return False
        status = self.dll.LvdsSetStatisticsPixel(self.instance_id, int(channel), int(rgb) & 0xFFFFFF)
        if status == LVDS_RESULT_OK:
            return True
        print(f"  [{self.display_name}] 设置统计像素失败: {get_status_description(status)} ({status})")
        return False

    def set_ignored_pixel(self, channel, rgb):
        """设置不进行比较的像素值，rgb 为 0xRRGGBB。"""
        if not self.is_connected():
            return False
        status = self.dll.LvdsSetIgnoredPixel(self.instance_id, int(channel), int(rgb) & 0xFFFFFF)
        if status == LVDS_RESULT_OK:
            return True
        print(f"  [{self.display_name}] 设置不比较像素失败: {get_status_description(status)} ({status})")
        return False

    def set_compare_area(self, channel, start_x, end_x, start_y, end_y):
        """设置图像对比限定区域。"""
        if not self.is_connected():
            return False
        status = self.dll.LvdsSetCompareArea(self.instance_id, int(channel), int(start_x), int(end_x), int(start_y), int(end_y))
        if status == LVDS_RESULT_OK:
            return True
        print(f"  [{self.display_name}] 设置对比区域失败: {get_status_description(status)} ({status})")
        return False
    def set_input_point(self, channel, x, y):
        """设置输入坐标，并在状态查询中读取该点像素值。"""
        if not self.is_connected():
            return False
        status = self.dll.LvdsSetInputPoint(self.instance_id, int(channel), int(x), int(y))
        if status == LVDS_RESULT_OK:
            return True
        print(f"  [{self.display_name}] 设置输入坐标失败: {get_status_description(status)} ({status})")
        return False

    # =========================================================================
    # 图像比对控制
    # =========================================================================

    def start_comparison_ex(self, params_str):
        """启动图像比对，返回 LVDS_RESULT_* 错误码。"""
        if not self.is_connected():
            return LVDS_RESULT_NOT_CONNECTED
        status = self.dll.LvdsStartComparison(self.instance_id, params_str.encode('utf-8'))
        if status != LVDS_RESULT_OK:
            print(f"  [{self.display_name}] 启动比对失败: {get_status_description(status)} ({status})")
        return status

    def start_comparison(self, params_str):
        """启动图像比对，兼容旧脚本，成功返回 True。"""
        return self.start_comparison_ex(params_str) == LVDS_RESULT_OK

    def stop_channel_comparison_ex(self, channel):
        """停止指定通道比对，返回 LVDS_RESULT_* 错误码。"""
        if not self.is_connected():
            return LVDS_RESULT_NOT_CONNECTED
        return self.dll.LvdsStopChannelComparison(self.instance_id, channel)

    def stop_channel_comparison(self, channel):
        """停止指定通道比对，兼容旧脚本，成功返回 True。"""
        return self.stop_channel_comparison_ex(channel) == LVDS_RESULT_OK

    def stop_comparison_ex(self):
        """停止所有通道比对，返回 LVDS_RESULT_* 错误码。"""
        if not self.is_connected():
            return LVDS_RESULT_NOT_CONNECTED
        return self.dll.LvdsStopComparison(self.instance_id)

    def stop_comparison(self):
        """停止所有通道比对，兼容旧脚本，成功返回 True。"""
        return self.stop_comparison_ex() == LVDS_RESULT_OK

    # =========================================================================
    # 截图
    # =========================================================================

    def capture_image_ex(self, path, channel=1, timeout_ms=5000):
        """捕获图像并保存，返回 LVDS_RESULT_* 错误码。"""
        if not self.is_connected():
            return LVDS_RESULT_NOT_CONNECTED
        target_dir = os.path.dirname(path) if path.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')) else path
        if target_dir and not os.path.exists(target_dir):
            os.makedirs(target_dir, exist_ok=True)
        status = self.dll.LvdsCaptureImage(self.instance_id, path.encode('utf-8'), channel, timeout_ms)
        if status != LVDS_RESULT_OK:
            print(f"  [{self.display_name}] 截图失败: {get_status_description(status)} ({status})")
        return status

    def capture_image(self, path, channel=1, timeout_ms=5000):
        """捕获图像并保存，兼容旧脚本，成功返回 True。"""
        return self.capture_image_ex(path, channel, timeout_ms) == LVDS_RESULT_OK

    def switch_video_source_ex(self, channel):
        """切换视频源通道，返回 LVDS_RESULT_* 错误码。"""
        if not self.is_connected():
            return LVDS_RESULT_NOT_CONNECTED
        return self.dll.LvdsSwitchVideoSource(self.instance_id, channel)

    def switch_video_source(self, channel):
        """切换视频源通道，兼容旧脚本，成功返回 True。"""
        return self.switch_video_source_ex(channel) == LVDS_RESULT_OK

    def get_image_compare_status(self, channel=1):
        """获取图像比较状态信息（Cmd 0x30 Sub 0x04）。"""
        if not self.is_connected():
            return None

        status = LvdsImageCompareStatus()
        ret = self.dll.LvdsGetImageCompareStatus(self.instance_id, int(channel), ctypes.byref(status))
        if ret == LVDS_RESULT_OK:
            return status
        print(f"  [{self.display_name}] 获取图像比较状态失败: {get_status_description(ret)} ({ret})")
        return None

    # =========================================================================
    # 错误记录
    # =========================================================================

    def get_channel_error_record_count(self, channel):
        if not self.is_connected():
            return -1
        return self.dll.LvdsGetChannelErrorRecordCount(self.instance_id, channel)

    def get_channel_error_records(self, channel, max_count=100):
        if not self.is_connected():
            return []
        arr = (LvdsErrorRecord * max_count)()
        got = self.dll.LvdsGetChannelErrorRecords(self.instance_id, channel, arr, max_count)
        return [arr[i] for i in range(got)] if got > 0 else []

    def clear_channel_error_records(self, channel):
        if self.is_connected():
            self.dll.LvdsClearChannelErrorRecords(self.instance_id, channel)

    def get_reference_image_name(self, channel=1):
        if not self.is_connected():
            return None
        buf = ctypes.create_string_buffer(128)
        status = self.dll.LvdsGetReferenceImageName(self.instance_id, channel, buf, ctypes.sizeof(buf))
        if status == LVDS_RESULT_OK:
            return buf.value.decode('utf-8')
        return None

    # =========================================================================
    # 后台自动轮询
    # =========================================================================

    def _poll_worker(self, interval_ms, channels):
        tag = f"[{self.display_name}]"
        while not self._auto_poll_stop_event.is_set():
            if not self.is_connected():
                break
            if channels:
                for ch in channels:
                    count = self.get_channel_error_record_count(ch)
                    if count > 0:
                        records = self.get_channel_error_records(ch, 100)
                        if records:
                            print(f"\n{tag} Ch{ch} 新增 {len(records)} 条错误:")
                            for r in records:
                                print(f"  -> {r}")
            else:
                count = self.get_error_record_count()
                if count > 0:
                    records = self.get_error_records(100)
                    if records:
                        print(f"\n{tag} 新增 {len(records)} 条错误:")
                        for r in records:
                            print(f"  -> {r}")
            time.sleep(interval_ms / 1000.0)

    def start_auto_poll(self, interval_ms=1000, channels=None):
        """开启后台轮询"""
        if not self.is_connected():
            return
        if self._auto_poll_thread and self._auto_poll_thread.is_alive():
            return
        self._auto_poll_stop_event = threading.Event()
        self._auto_poll_thread = threading.Thread(
            target=self._poll_worker, args=(interval_ms, channels), daemon=True)
        self._auto_poll_thread.start()

    def stop_auto_poll(self):
        """停止后台轮询"""
        if self._auto_poll_thread and self._auto_poll_thread.is_alive():
            self._auto_poll_stop_event.set()
            self._auto_poll_thread.join(timeout=2.0)
            self._auto_poll_thread = None

    # =========================================================================
    # 内部辅助
    # =========================================================================

    def _parse_connect_info(self, params_str):
        """从连接参数中提取 IP 和端口"""
        m = re.search(r'--serverIp\s+(\S+)', params_str)
        if m:
            self.server_ip = m.group(1)
        m = re.search(r'--serverPort\s+(\d+)', params_str)
        if m:
            self.server_port = int(m.group(1))
        else:
            self.server_port = 5555




