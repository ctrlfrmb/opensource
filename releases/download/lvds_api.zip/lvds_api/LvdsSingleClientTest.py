﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: leiwei
LvdsSingleClientTest.py - LVDS 单客户端测试工具

版本: v2.7.0

用途：
- 简化的单客户端测试工具
- 适合快速测试单个 LVDS 设备
- 自动管理单个连接，无需指定客户端索引

注：如需同时管理多个设备，请使用 LvdsTest.py
"""

from LvdsClient import LvdsClient
from LvdsMessage import LVDS_RESULT_OK
import signal
import sys
import os
import re

VERSION = "2.5.0"

# 全局单客户端实例
client = None


def signal_handler(sig, frame):
    """信号处理"""
    print("\n接收到中断信号，正在清理...")
    if client:
        client.stop_auto_poll()
        if client.is_connected():
            client.disconnect()
    LvdsClient.cleanup_library()
    sys.exit(0)


def print_help():
    print(f"""
================================================================================
                    LVDS 单客户端测试工具 v{VERSION}
================================================================================

命令列表:
  help                                  显示帮助

  connect <serverIp> [port]             连接设备
    示例: connect 192.168.245.101 8080

  disconnect                            断开连接

  start [params]                        启动比对
    示例: start --channels 1,2,3 --threshold 5 --interval 5000
                --imageRootPath E:\\TestData

  stop                                  停止比对

  status                                查看状态
  info                                  获取设备信息

  autopoll on|off [interval_ms]         启动/停止自动轮询
    示例: autopoll on 500

  refimages                             显示标定图信息

  exit                                  退出

参数说明:
  --channels <ch1,ch2,...>              比对通道列表（逗号分隔）
  --threshold <value>                   差异阈值（0-255）
  --interval <ms>                       比对间隔（毫秒）
  --imageRootPath <path>                标定图根目录
  --imagePath <path>                    标定图完整路径
  --mode <single|continuous>            比对模式

示例流程:
  connect 192.168.245.101 8080
  start --channels 1,2,3 --threshold 5 --interval 5000 --imageRootPath E:\\TestData
  autopoll on 500
  status
  stop
  disconnect
================================================================================
""")


def cmd_connect(parts):
    """连接设备"""
    global client

    if len(parts) < 2:
        print("  用法: connect <serverIp> [port]")
        print("  示例: connect 192.168.245.101 8080")
        return

    if client and client.is_connected():
        print("  警告: 已有连接，将先断开")
        client.disconnect()

    if not client:
        client = LvdsClient()

    server_ip = parts[1]
    port = int(parts[2]) if len(parts) >= 3 else 5555

    result = client.connect_ex(f"--serverIp {server_ip} --serverPort {port}")
    if result == LVDS_RESULT_OK:
        print(f"  连接成功: {server_ip}:{port}")
        print(f"  实例 ID: {client.instance_id}")
    else:
        print(f"  连接失败: 错误码 {result}")


def cmd_disconnect():
    """断开连接"""
    global client

    if not client or not client.is_connected():
        print("  当前未连接")
        return

    client.stop_auto_poll()
    result = client.disconnect_ex()
    if result == LVDS_RESULT_OK:
        print("  已断开连接")
    else:
        print(f"  断开连接失败: 错误码 {result}")


def cmd_start(parts, line):
    """启动比对"""
    if not client or not client.is_connected():
        print("  错误: 未连接设备，请先执行 connect")
        return

    # 提取参数部分
    params_str = line.split(None, 1)[1] if len(line.split(None, 1)) >= 2 else ""

    # 自动为 imagePath/imageRootPath 追加 IP 后缀
    params_str = _append_ip_suffix(params_str, client)

    result = client.start_comparison_ex(params_str)
    if result == LVDS_RESULT_OK:
        print("  启动比对成功")
        _show_ref_images(client, params_str)
    else:
        print(f"  启动比对失败: 错误码 {result}")


def cmd_stop():
    """停止比对"""
    if not client or not client.is_connected():
        print("  错误: 未连接设备")
        return

    result = client.stop_comparison_ex()
    if result == LVDS_RESULT_OK:
        print("  停止比对成功")
    else:
        print(f"  停止比对失败: 错误码 {result}")


def cmd_status():
    """查看状态"""
    if not client:
        print("  客户端未创建")
        return

    print(f"\n客户端状态:")
    print(f"  连接状态: {'已连接' if client.is_connected() else '未连接'}")
    if client.is_connected():
        print(f"  服务器: {client.server_ip}:{client.server_port}")
        print(f"  实例 ID: {client.instance_id}")
        print(f"  自动轮询: {'开启' if client._auto_poll_thread else '关闭'}")


def cmd_info():
    """获取设备信息"""
    if not client or not client.is_connected():
        print("  错误: 未连接设备")
        return

    info = client.get_device_info()
    if info:
        print(f"\n设备信息:")
        print(f"  {info}")
    else:
        print("  获取设备信息失败")


def cmd_autopoll(parts):
    """启动/停止自动轮询"""
    if not client or not client.is_connected():
        print("  错误: 未连接设备")
        return

    if len(parts) < 2:
        print("  用法: autopoll on|off [interval_ms]")
        return

    if parts[1].lower() == "on":
        interval = int(parts[2]) if len(parts) >= 3 else 500
        client.start_auto_poll(interval)
        print(f"  自动轮询已启动 (间隔 {interval}ms)")
    else:
        client.stop_auto_poll()
        print("  自动轮询已停止")


def cmd_refimages():
    """显示标定图信息"""
    if not client or not client.is_connected():
        print("  错误: 未连接设备")
        return

    # 这里可以添加显示标定图信息的逻辑
    print("  标定图信息功能待实现")


def _get_ip_suffix(client):
    """从客户端 IP 中提取最后一段作为目录后缀"""
    if client.server_ip:
        parts = client.server_ip.split('.')
        if len(parts) == 4:
            return parts[-1]
    return str(client.instance_id or 0)


def _append_ip_suffix(params_str, client):
    """为 --imagePath 或 --imageRootPath 追加 /{ip_suffix} 后缀"""
    suffix = _get_ip_suffix(client)

    def replace_path(match):
        key = match.group(1)
        path = match.group(2).rstrip('/\\')
        return f"--{key} {path}/{suffix}"

    result = re.sub(r'--(imagePath|imageRootPath)\s+(\S+)', replace_path, params_str)
    return result


def _show_ref_images(client, params_str):
    """显示标定图信息"""
    m = re.search(r'--channels\s+([0-9,]+)', params_str)
    if m:
        chs = [int(ch.strip()) for ch in m.group(1).split(',')]
    else:
        m2 = re.search(r'--channel\s+(\d+)', params_str)
        chs = [int(m2.group(1))] if m2 else [1]

    # 提取 imagePath 或 imageRootPath
    m_path = re.search(r'--(imagePath|imageRootPath)\s+(\S+)', params_str)
    if not m_path:
        return

    path_type = m_path.group(1)
    base_path = m_path.group(2).rstrip('/\\')

    print(f"\n  标定图路径 ({path_type}):")
    for ch in chs:
        if path_type == "imageRootPath":
            img_path = f"{base_path}/ch{ch}.bmp"
        else:
            img_path = base_path

        exists = "✓" if os.path.exists(img_path) else "✗"
        print(f"    通道 {ch}: {img_path} {exists}")


def main():
    """主循环"""
    signal.signal(signal.SIGINT, signal_handler)
    LvdsClient.init_library()

    print(f"""
================================================================================
                    LVDS 单客户端测试工具 v{VERSION}
================================================================================
输入 'help' 查看命令列表, 输入 'exit' 退出
""")

    while True:
        try:
            line = input("LVDS> ").strip()
            if not line:
                continue

            parts = line.split()
            command = parts[0].lstrip('﻿').lower()

            if command == "help":
                print_help()
            elif command == "connect":
                cmd_connect(parts)
            elif command == "disconnect":
                cmd_disconnect()
            elif command == "start":
                cmd_start(parts, line)
            elif command == "stop":
                cmd_stop()
            elif command == "status":
                cmd_status()
            elif command == "info":
                cmd_info()
            elif command == "autopoll":
                cmd_autopoll(parts)
            elif command == "refimages":
                cmd_refimages()
            elif command == "exit":
                break
            else:
                print(f"  未知命令: {command}, 输入 'help' 查看帮助")

        except KeyboardInterrupt:
            print("\n使用 'exit' 命令退出")
            continue
        except Exception as e:
            print(f"  执行命令时出错: {e}")
            import traceback
            traceback.print_exc()

    # 清理资源
    print("\n正在清理资源...")
    if client:
        client.stop_auto_poll()
        if client.is_connected():
            client.disconnect()
    LvdsClient.cleanup_library()
    print("退出")


if __name__ == "__main__":
    main()

