#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# QVXLTest.py - QVXL API 测试和命令行界面

from QVXLClient import QVXLClient, QVXL_OK, QVXL_FLAG_FD, QVXL_FLAG_BRS, QVXL_FLAG_IDE, QVXL_ERR_RX_EMPTY
from QVXLMessage import * 
import signal
import sys
import platform
import traceback 

client = None

def signal_handler(sig, frame):
    print("\n[Ctrl+C] 正在清理退出...")
    if client: client.cleanup()
    sys.exit(0)

def print_help():
    print("""
============================== QVXL Test Console ==============================
核心命令:
  scan                            扫描当前连接的 Vector 硬件
  connect <params>                连接设备 (支持 AppConfig 或 HwParam 模式)
  disconnect                      断开当前连接
  start / stop                    启动/停止测量 (Go On Bus / Off Bus)
  
数据交互:
  transmit <ID> <Data...> [flags] 发送报文 (例: transmit 123 AA BB)
  read                            手动读取一条报文
  auto_read / stop_read           启动/停止后台自动接收打印
  
状态查询:
  status                          查看收发统计信息
  info                            查看当前连接的硬件详情
  
其他:
  clear_all                       强制复位 API 库
  exit                            退出程序
==============================================================================
""")

def handle_scan():
    if not client.vxl_dll:
        print("错误: DLL 未正确加载，无法扫描。")
        return

    print("正在扫描硬件...")
    try:
        devices = client.scan_hardware()
    except Exception as e:
        print(f"扫描失败: {e}")
        return

    if not devices:
        print("未发现 Vector 硬件。请检查 USB 连接或驱动。")
        return

    print("-" * 85)
    print(f"{'No.':<4} {'Device Name':<30} {'HwType':<8} {'HwIndex':<8} {'HwCh':<6}")
    print("-" * 85)
    for i, dev in enumerate(devices):
        name = dev.name.decode('utf-8', errors='ignore')
        print(f"{i+1:<4} {name:<30} {dev.hwType:<8} {dev.hwIndex:<8} {dev.hwChannel:<6}")
    print("-" * 85)
    
    print("\n[快速连接提示] 复制以下命令即可连接:")
    for i, dev in enumerate(devices):
        print(f"  connect --hwType {dev.hwType} --hwIndex {dev.hwIndex} --hwChannel {dev.hwChannel} --baud 500000 --isFd 1")
    print()

def parse_transmit(parts):
    if len(parts) < 2: return None, None, None
    try:
        can_id = int(parts[1], 16)
        data = []
        flags = QVXL_FLAG_FD # 默认FD
        
        for p in parts[2:]:
            if p.upper().startswith("FLAGS="):
                f_str = p.split('=')[1].upper()
                flags = 0
                if "FD" in f_str: flags |= QVXL_FLAG_FD
                if "BRS" in f_str: flags |= QVXL_FLAG_BRS
                if "IDE" in f_str: flags |= QVXL_FLAG_IDE
            else:
                data.append(int(p, 16))
        return can_id, data, flags
    except:
        return None, None, None

def main():
    global client
    signal.signal(signal.SIGINT, signal_handler)
    
    print(f"QVXL CLI Tool v1.4.1 ({platform.architecture()[0]})")
    
    try:
        client = QVXLClient()
    except Exception as e:
        print("\n!!! 初始化严重错误 !!!")
        print(f"无法加载 QVXLClient: {e}")
        print("请检查 qvxl_api.dll 是否存在且版本正确。")
        traceback.print_exc()
        return

    while True:
        try:
            try:
                cmd_str = input("QVXL> ").strip()
            except EOFError:
                break 

            if not cmd_str: continue
            parts = cmd_str.split()
            cmd = parts[0].lower()

            if cmd == "exit": break
            elif cmd == "help": print_help()
            
            elif cmd == "scan":
                handle_scan()
                
            elif cmd == "connect":
                params = " ".join(parts[1:])
                if not params: print("参数缺失。请先使用 'scan' 获取建议命令。")
                else: client.connect(params)
                
            elif cmd == "disconnect": client.disconnect()
            elif cmd == "start": client.start_measurement()
            elif cmd == "stop": client.stop_measurement()
            elif cmd == "clear_all": client.clear_all()
            
            elif cmd == "status":
                stats = client.get_stats()
                if stats: print(f"统计: {stats}")
                
            elif cmd == "info":
                info = client.get_channel_info()
                if info: print(f"硬件详情: {info}")
                else: print("未连接或查询失败。")
                
            elif cmd == "transmit":
                cid, data, flg = parse_transmit(parts)
                if cid is not None:
                    print(f"Tx -> ID:{cid:X} Data:{len(data)}B")
                    client.transmit(cid, data, flg)
                else:
                    print("格式错误。例: transmit 100 AA BB")
                    
            elif cmd == "read":
                msgs, st = client.receive()
                if msgs:
                    for m in msgs: print(f"  {m}")
                elif st == QVXL_ERR_RX_EMPTY:
                    print("无数据。")
                    
            elif cmd == "auto_read": client.start_auto_read()
            elif cmd == "stop_read": client.stop_auto_read()
            
            else: print("未知命令，输入 'help' 查看帮助。")
            
        except KeyboardInterrupt:
            print("\n(Interrupted)")
            break
        except Exception as e:
            print(f"执行命令时出错: {e}")
            traceback.print_exc()

    if client:
        client.cleanup()
    print("程序已退出。")

if __name__ == "__main__":
    main()
