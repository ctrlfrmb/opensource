/*-----------------------------------------------------------------------------
*               Vector XL Driver API - C Wrapper Interface
*-----------------------------------------------------------------------------
*
* 提供用于 Vector CAN/CAN-FD 硬件 (如 VN16xx 系列) 的 C 语言接口封装。
* 本 API 旨在简化与 Vector XL Driver 的交互，屏蔽底层复杂性，提供一组
* 稳定、易于集成的函数，特别适合用于 LabVIEW, Python, C# 等环境的调用。
*
* 主要特点:
* - 支持 CAN 2.0 和 CAN FD 协议
* - 支持多通道、多实例并发操作
* - 灵活的连接模式：支持应用映射(App Config)和硬件直连(Hw Param)
* - 硬件发现与扫描：无需打开设备即可查询系统中的 Vector 硬件
* - 高效的异步批量报文收发
* - 集成总线负载与错误统计功能
* - 线程安全的日志记录系统
*
* 使用示例 (Usage Example):
*
*   // 1. (可选) 初始化日志系统
*   QVxlOpenLog("vxl_driver.log", 1, 5, 2);
*
*   // 2. (可选) 扫描硬件获取连接参数
*   QVxlScanInfo scanList[16];
*   int count = 16;
*   QVxlScanHardware(scanList, &count);
*
*   // 3. 连接设备 (这里演示硬件直连模式，配置为 CAN FD, 500k/2M)
*   // 实际使用时，参数可来自扫描结果
*   const char* params = "connect --hwType 57 --hwIndex 0 --hwChannel 0 "
*                        "--baud 500000 --dataBaud 2000000 --isFd 1";
*   int handle = -1;
*   int ret = QVxlConnect(params, &handle);
*
*   if (ret == VXL_OK) {
*       // 4. 启动测量 (Go On Bus)
*       QVxlStartMeasurement(handle);
*
*       // 5. 发送 CAN FD 报文
*       QVxlCanMsg txMsg = {0};
*       txMsg.canId = 0x123;
*       txMsg.msgFlags = VXL_FLAG_FD | VXL_FLAG_BRS; // FD + BitRateSwitch
*       txMsg.dlc = 15;    // DLC 15 对应 64 字节
*       txMsg.dataLen = 64;
*       for(int i=0; i<64; i++) txMsg.data[i] = (unsigned char)i;
*
*       QVxlTransmit(handle, &txMsg);
*
*       // 6. 接收报文 (阻塞等待 100ms)
*       QVxlCanMsg rxMsgs[10];
*       int rxCount = 10; // 输入缓冲容量
*       QVxlReceive(handle, rxMsgs, &rxCount, 100);
*
*       if (rxCount > 0) {
*           // 处理接收到的数据...
*       }
*
*       // 7. 获取统计信息
*       QVxlChannelStat stats;
*       QVxlGetStatistics(handle, &stats);
*
*       // 8. 停止测量并断开
*       VxlStopMeasurement(handle);
*       QVxlDisconnect(handle);
*   }
*
*   // 9. 关闭日志
*   QVxlCloseLog();
*
*-----------------------------------------------------------------------------
*               Copyright Notice & License
*-----------------------------------------------------------------------------
* Copyright (c) 2022 leiwei. All rights reserved.
*
* This software is released under the MIT License.
* You may obtain a copy of the License at:
* https://opensource.org/licenses/MIT
*
* Author: leiwei E-mail: ctrlfrmb@gmail.com
* Version: 1.4.1
* Date: 2025-11-14
*----------------------------------------------------------------------------*/

#ifndef QVXL_API_H
#define QVXL_API_H

/**
 * @file qvxl_api.h
 * @brief Exported C API functions for the Vector XL Driver Wrapper.
 *
 * This interface provides high-level control over Vector hardware.
 * It supports multi-channel management, CAN/CAN-FD communication,
 * hardware discovery, and statistical monitoring.
 */

// Define DLL export/import macro for Windows
#ifdef _WIN32
#ifdef BUILD_QVXL_API
#define QVXL_API extern "C" __declspec(dllexport)
#else
#define QVXL_API extern "C" __declspec(dllimport)
#endif
#else
#define QVXL_API extern "C"
#endif

#include "qvxl_def.h"

// ============================================================================
// Initialization & Logging
// ============================================================================

/**
 * @brief Initialize the internal logging system.
 *
 * @param logFile  Full path to the log file (e.g., "C:/logs/vxl.log").
 * @param level    Log level (0:Debug, 1:Info, 2:Warn, 3:Error).
 * @param maxSize  Max size per log file in MB.
 * @param maxFiles Max number of rolling log files.
 * @return VXL_OK on success, or a negative error code.
 */
QVXL_API int QVxlOpenLog(const char* logFile, int level, int maxSize, int maxFiles);

/**
 * @brief Close the logging system and flush buffers.
 * @return VXL_OK on success.
 */
QVXL_API int QVxlCloseLog();

// ============================================================================
// Hardware Discovery
// ============================================================================

/**
 * @brief Scans the system for available Vector hardware channels.
 *
 * This function allows clients to discover devices without establishing a connection.
 * The returned information can be used to construct the connection string for `QVxlConnect`.
 *
 * @param list  [OUT] Pointer to an array of QVxlScanInfo structures. Can be NULL if only querying count.
 * @param count [IN/OUT]
 *              IN: Capacity of the `list` array.
 *              OUT: Actual number of devices found.
 * @return VXL_OK on success.
 */
QVXL_API int QVxlScanHardware(QVxlScanInfo* list, int* count);

// ============================================================================
// Channel Management
// ============================================================================

/**
 * @brief Connects to a Vector CAN channel and creates a new instance.
 *
 * @param params Configuration string containing key-value pairs (space-separated).
 *
 * ### Connection Modes
 *
 * **Mode A: Application Mapping (Recommended)**
 * Requires configuring the "Application" in Vector Hardware Config tool.
 * - `--appName <str>` : Application name (Default: "TestApp").
 * - `--channel <int>` : Application channel index (1-based, Default: 1).
 *
 * **Mode B: Direct Hardware Access**
 * Bypasses application mapping, directly targets physical hardware.
 * Use `QVxlScanHardware` to obtain valid values.
 * - `--hwType <int>`    : Hardware Type ID (e.g., 57 for VN1630).
 * - `--hwIndex <int>`   : Device Index (0-based).
 * - `--hwChannel <int>` : Channel Index (0-based).
 *
 * ### Common Parameters
 * - `--baud <int>`      : Arbitration baud rate (Default: 500000).
 * - `--dataBaud <int>`  : Data baud rate for CAN FD (Default: 2000000).
 * - `--isFd <0|1>`      : Enable CAN FD mode (Default: 1).
 * - `--queueSize <int>` : Software receive queue depth (Default: 10000).
 *
 * @param instanceId [OUT] Receives the unique handle ID for the new instance.
 * @return VXL_OK on success, or VXL_ERR_ALREADY_EXISTS if hardware is busy.
 */
QVXL_API int QVxlConnect(const char* params, int* instanceId);

/**
 * @brief Disconnects a channel instance and releases hardware resources.
 * @param instanceId The handle ID returned by QVxlConnect.
 * @return VXL_OK on success.
 */
QVXL_API int QVxlDisconnect(int instanceId);

/**
 * @brief Disconnects and cleans up all active channel instances.
 * Recommended to call this during application shutdown.
 * @return VXL_OK on success.
 */
QVXL_API int VxlClearAll();


// ============================================================================
// Measurement Control
// ============================================================================

/**
 * @brief Starts measurement on the specified channel (Go On Bus).
 * @param instanceId The handle ID.
 * @return VXL_OK on success.
 */
QVXL_API int QVxlStartMeasurement(int instanceId);

/**
 * @brief Stops measurement on the specified channel (Go Off Bus).
 * @param instanceId The handle ID.
 * @return VXL_OK on success.
 */
QVXL_API int VxlStopMeasurement(int instanceId);


// ============================================================================
// Data Transmission
// ============================================================================

/**
 * @brief Transmits a single CAN/CAN-FD message.
 *
 * @param instanceId The handle ID.
 * @param msg Pointer to the message structure.
 * @return VXL_OK on success.
 * @return VXL_ERR_TX_QUEUE_FULL if the hardware queue is full.
 */
QVXL_API int QVxlTransmit(int instanceId, QVxlCanMsg* msg);

/**
 * @brief Batched receive function for CAN messages.
 *
 * @param instanceId The handle ID.
 * @param msgs [OUT] Buffer to store received messages.
 * @param count [IN/OUT]
 *        IN: Capacity of the `msgs` buffer.
 *        OUT: Number of messages actually read.
 * @param timeoutMs Timeout in milliseconds.
 *        0 = Non-blocking (returns immediately).
 *        -1 = Blocking (waits indefinitely).
 *        >0 = Waits up to specified ms.
 *
 * @return VXL_OK (0) if messages were read.
 * @return VXL_ERR_RX_EMPTY (-6) if queue is empty (non-blocking).
 * @return VXL_ERR_RX_TIMEOUT (-7) if timeout occurred (blocking).
 */
QVXL_API int QVxlReceive(int instanceId, QVxlCanMsg* msgs, int* count, int timeoutMs);


// ============================================================================
// Status & Statistics
// ============================================================================

/**
 * @brief Retrieves the current statistics for a channel.
 * @param instanceId The handle ID.
 * @param stat [OUT] Pointer to the statistics structure.
 * @return VXL_OK on success.
 */
QVXL_API int QVxlGetStatistics(int instanceId, QVxlChannelStat* stat);

/**
 * @brief Retrieves detailed hardware and connection information.
 *
 * Use this to verify which physical device an active instance is bound to,
 * and whether it is currently on-bus.
 *
 * @param instanceId The handle ID.
 * @param info [OUT] Pointer to the channel info structure.
 * @return VXL_OK on success.
 */
QVXL_API int QVxlGetChannelInfo(int instanceId, QVxlChannelInfo* info);

/**
 * @brief Resets the internal statistics counters for a channel.
 * @param instanceId The handle ID.
 * @return VXL_OK on success.
 */
QVXL_API int QVxlResetStatistics(int instanceId);

#endif // QVXL_API_H
