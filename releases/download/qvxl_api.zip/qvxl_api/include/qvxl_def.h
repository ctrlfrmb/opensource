/*-----------------------------------------------------------------------------
*               Copyright Notice & License
*-----------------------------------------------------------------------------
* Copyright (c) 2022 leiwei. All rights reserved.
*
* This software is released under the MIT License.
* You may obtain a copy of the License at:
* https://opensource.org/licenses/MIT
*
* This software is provided "as is", without warranty of any kind, express or
* implied, including but not limited to the warranties of merchantability,
* fitness for a particular purpose and noninfringement. In no event shall the
* authors or copyright holders be liable for any claim, damages or other
* liability, whether in an action of contract, tort or otherwise, arising from,
* out of or in connection with the software or the use or other dealings in the
* software.
*
* Author: leiwei E-mail: ctrlfrmb@gmail.com
* Version: 1.4.1
* Date: 2025-11-14
*----------------------------------------------------------------------------*/

#ifndef QVXL_DEF_H
#define QVXL_DEF_H

/**
 * @file qvxl_def.h
 * @brief Public data types, constants, and error codes for the Vector XL Driver Wrapper.
 *
 * This header serves as the common data definition layer for the library.
 * It is designed to be self-contained and free of external dependencies (except standard types),
 * ensuring easy integration with C, C++, Python (ctypes), C# (P/Invoke), and LabVIEW.
 */

// Set structure packing to 4 bytes.
// Critical for binary compatibility between the DLL and client applications.
#ifdef _MSC_VER
#pragma pack(push, 4)
#else
#pragma pack(4)
#endif

// Maximum data payload length for a CAN FD message in bytes.
#define QVXL_MAX_DATA_LEN 64

/**
 * @brief API Execution Result Codes.
 *
 * 0 indicates success (QVXL_OK). Negative values indicate errors.
 */
enum QVxlResultCode {
    QVXL_OK                  = 0,     ///< Success.
    QVXL_ERR_INIT_FAILED     = -1,    ///< Library or driver initialization failed.
    QVXL_ERR_INVALID_HANDLE  = -2,    ///< Instance ID is invalid or not found.
    QVXL_ERR_INVALID_PARAM   = -3,    ///< Invalid parameter provided (e.g. null pointer).
    QVXL_ERR_CHANNEL_OFFLINE = -4,    ///< Operation failed because channel is not active (Off Bus).
    QVXL_ERR_TX_QUEUE_FULL   = -5,    ///< Transmit queue is full.
    QVXL_ERR_RX_EMPTY        = -6,    ///< No messages available (non-blocking read).
    QVXL_ERR_RX_TIMEOUT      = -7,    ///< Operation timed out.

    // Hardware Conflict Errors
    QVXL_ERR_ALREADY_EXISTS  = -20,   ///< The specified physical hardware is already in use by another instance.

    // System Errors
    QVXL_ERR_DRIVER_ERROR    = -100,  ///< Internal Vector XL driver error.
    QVXL_ERR_NOT_IMPLEMENTED = -404   ///< Functionality not implemented.
};

/**
 * @brief CAN Message Flags.
 * Used in QVxlCanMsg.msgFlags.
 */
#define QVXL_FLAG_IDE        0x01    ///< Extended Frame (29-bit ID).
#define QVXL_FLAG_RTR        0x02    ///< Remote Transmission Request.
#define QVXL_FLAG_FD         0x10    ///< CAN FD Format.
#define QVXL_FLAG_BRS        0x20    ///< Bit Rate Switch (CAN FD only).
#define QVXL_FLAG_ESI        0x40    ///< Error State Indicator.

/**
 * @brief CAN / CAN FD Message Structure.
 *
 * Binary layout is fixed (pack=4) for safe interop.
 */
typedef struct _QVxlCanMsg {
    unsigned int   canId;           ///< Message ID (11-bit or 29-bit).
    unsigned int   msgFlags;        ///< Combination of VXL_FLAG_* flags.
    unsigned char  dlc;             ///< Data Length Code (0-15).
    unsigned char  padding[3];      ///< Reserved alignment padding.
    unsigned char  data[64];        ///< Payload data.QVXL_MAX_DATA_LEN
    unsigned int   dataLen;         ///< Valid data length in bytes (0-64).
    unsigned long long timeStamp;   ///< Hardware timestamp (nanoseconds).
} QVxlCanMsg;

/**
 * @brief Channel Runtime Statistics.
 */
typedef struct _QVxlChannelStat {
    unsigned long long txCount;     ///< Successfully transmitted frames.
    unsigned long long rxCount;     ///< Successfully received frames.
    unsigned long long errCount;    ///< Bus error events.
    unsigned int       busLoad;     ///< Bus load in 0.01% units (e.g. 5000 = 50.00%).
    unsigned int       chipState;   ///< CAN Controller state (Active/Passive/BusOff).
} QVxlChannelStat;

/**
 * @brief Active Channel Information.
 * Used with QVxlGetChannelInfo to query an active instance's hardware binding.
 */
typedef struct _QVxlChannelInfo {
    unsigned int hwType;      ///< Vector Hardware Type ID (e.g. 57 for VN1630).
    unsigned int hwIndex;     ///< Device Index (0-based).
    unsigned int hwChannel;   ///< Channel Index on device (0-based).
    unsigned int isOnBus;     ///< 1 = On Bus, 0 = Off Bus.
} QVxlChannelInfo;

/**
 * @brief Hardware Discovery Information.
 * Used with QVxlScanHardware to list available devices.
 */
typedef struct _QVxlScanInfo {
    char name[64];          ///< Friendly name (e.g. "VN1630 Channel 1").
    unsigned int hwType;    ///< Hardware Type ID.
    unsigned int hwIndex;   ///< Device Index.
    unsigned int hwChannel; ///< Channel Index.
    unsigned int busType;   ///< Bus Capabilities (Usually CAN).
} QVxlScanInfo;

// Restore structure packing.
#ifdef _MSC_VER
#pragma pack(pop)
#else
#pragma pack()
#endif

#endif // QVXL_DEF_H
