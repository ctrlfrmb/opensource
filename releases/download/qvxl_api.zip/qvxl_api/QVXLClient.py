#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# QVXLClient.py - QVXL 客户端 Python 封装实现

from QVXLMessage import *
import ctypes
import platform
import os
import threading
import sys

class QVXLClient:
    def __init__(self, lib_path=None):
        self.vxl_dll = None
        self.instance_id = None
        self._load_dll(lib_path)
        
        self._auto_read_thread = None
        self._auto_read_stop_event = threading.Event()

    def _load_dll(self, lib_path):
        if lib_path is None:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            arch = platform.architecture()[0]
            # 尝试常见路径
            possible_paths = [
                os.path.join(base_dir, "lib", "Winx64" if arch == "64bit" else "Winx86"),
                os.path.join(base_dir, "build", "Release"),
                base_dir 
            ]
            for path in possible_paths:
                if os.path.exists(os.path.join(path, "qvxl_api.dll")):
                    lib_path = path
                    break
        
        if lib_path:
            os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
            dll_file = os.path.join(lib_path, "qvxl_api.dll")
        else:
            dll_file = "qvxl_api.dll"

        try:
            self.vxl_dll = ctypes.WinDLL(dll_file)
        except OSError as e:
            print(f"致命错误: 加载 {dll_file} 失败。\n详情: {e}")
            raise

        self._define_api_prototypes()
        
        try:
            # [修改] API 名称变为 QVxlOpenLog
            self.vxl_dll.QVxlOpenLog(b"qvxl_client_test.log", 1, 5, 2)
            print("QVXL API 库加载成功，日志已启用。")
        except AttributeError:
            print("警告: 无法找到 QVxlOpenLog，请检查 DLL 版本。")
        except Exception as e:
            print(f"警告: 日志初始化失败: {e}")

    def _define_api_prototypes(self):
        """定义 C 函数原型，确保参数类型匹配"""
        try:
            # [修改] 所有函数名增加 Q 前缀
            
            # QVxlScanHardware
            self.vxl_dll.QVxlScanHardware.argtypes = [ctypes.POINTER(QVxlScanInfo), ctypes.POINTER(ctypes.c_int)]
            self.vxl_dll.QVxlScanHardware.restype = ctypes.c_int

            # QVxlConnect
            self.vxl_dll.QVxlConnect.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_int)]
            self.vxl_dll.QVxlConnect.restype = ctypes.c_int
            
            # QVxlTransmit
            self.vxl_dll.QVxlTransmit.argtypes = [ctypes.c_int, ctypes.POINTER(QVxlCanMsg)]
            self.vxl_dll.QVxlTransmit.restype = ctypes.c_int

            # QVxlReceive
            self.vxl_dll.QVxlReceive.argtypes = [ctypes.c_int, ctypes.POINTER(QVxlCanMsg), ctypes.POINTER(ctypes.c_int), ctypes.c_int]
            self.vxl_dll.QVxlReceive.restype = ctypes.c_int
            
            # QVxlGetStatistics
            self.vxl_dll.QVxlGetStatistics.argtypes = [ctypes.c_int, ctypes.POINTER(QVxlChannelStat)]
            self.vxl_dll.QVxlGetStatistics.restype = ctypes.c_int
            
            # QVxlGetChannelInfo
            self.vxl_dll.QVxlGetChannelInfo.argtypes = [ctypes.c_int, ctypes.POINTER(QVxlChannelInfo)]
            self.vxl_dll.QVxlGetChannelInfo.restype = ctypes.c_int

            # QVxlDisconnect, QVxlStartMeasurement, QVxlStopMeasurement, QVxlClearAll, QVxlCloseLog
            # 这些函数参数简单，ctypes 通常能自动推断，但为了严谨可以全部定义
            self.vxl_dll.QVxlDisconnect.argtypes = [ctypes.c_int]
            self.vxl_dll.QVxlStartMeasurement.argtypes = [ctypes.c_int]
            self.vxl_dll.QVxlStopMeasurement.argtypes = [ctypes.c_int]
            
        except AttributeError as e:
            print(f"API 定义错误: DLL 中找不到函数 {e}。请确认 DLL 是否已更新为带 'Q' 前缀的版本。")

    def scan_hardware(self):
        """扫描并返回可用硬件列表"""
        count = ctypes.c_int(0)
        # [修改] QVxlScanHardware
        self.vxl_dll.QVxlScanHardware(None, ctypes.byref(count))
        
        if count.value == 0:
            return []

        max_count = count.value
        info_array = (QVxlScanInfo * max_count)()
        
        status = self.vxl_dll.QVxlScanHardware(info_array, ctypes.byref(count))
        if status == QVXL_OK:
            return [info_array[i] for i in range(count.value)]
        return []

    def connect(self, params_str):
        if self.is_connected():
            print(f"错误: 已连接 (ID: {self.instance_id})")
            return False
        
        c_id = ctypes.c_int(-1)
        # [修改] QVxlConnect
        status = self.vxl_dll.QVxlConnect(params_str.encode('utf-8'), ctypes.byref(c_id))
        
        if status == QVXL_OK:
            self.instance_id = c_id.value
            print(f"连接成功，句柄 ID: {self.instance_id}")
            return True
        else:
            print(f"连接失败: {get_status_description(status)}")
            return False

    def disconnect(self):
        if not self.is_connected(): return True
        self.stop_auto_read()
        # [修改] QVxlDisconnect
        status = self.vxl_dll.QVxlDisconnect(self.instance_id)
        if status == QVXL_OK:
            self.instance_id = None
            print("已断开连接。")
            return True
        return False

    def start_measurement(self):
        if not self.is_connected(): return False
        # [修改] QVxlStartMeasurement
        status = self.vxl_dll.QVxlStartMeasurement(self.instance_id)
        if status == QVXL_OK:
            print("测量已启动。")
            return True
        print(f"启动失败: {get_status_description(status)}")
        return False

    def stop_measurement(self):
        if not self.is_connected(): return False
        self.stop_auto_read()
        # [修改] QVxlStopMeasurement
        self.vxl_dll.QVxlStopMeasurement(self.instance_id)
        print("测量已停止。")
        return True

    def transmit(self, can_id, data_bytes, flags=QVXL_FLAG_FD):
        if not self.is_connected(): return False
        
        msg = QVxlCanMsg()
        msg.canId = can_id
        msg.msgFlags = flags
        msg.dataLen = len(data_bytes)
        
        # 简易 DLC 映射逻辑
        if msg.dataLen <= 8: msg.dlc = msg.dataLen
        elif msg.dataLen <= 12: msg.dlc = 9
        elif msg.dataLen <= 16: msg.dlc = 10
        elif msg.dataLen <= 20: msg.dlc = 11
        elif msg.dataLen <= 24: msg.dlc = 12
        elif msg.dataLen <= 32: msg.dlc = 13
        elif msg.dataLen <= 48: msg.dlc = 14
        else: msg.dlc = 15

        # 填充数据
        for i, val in enumerate(data_bytes[:64]):
            msg.data[i] = val

        # [修改] QVxlTransmit
        status = self.vxl_dll.QVxlTransmit(self.instance_id, ctypes.byref(msg))
        if status != QVXL_OK:
            print(f"发送失败: {get_status_description(status)}")
        return status == QVXL_OK

    def receive(self, max_count=100, timeout_ms=0):
        if not self.is_connected(): return [], QVXL_ERR_CHANNEL_OFFLINE
        
        buffer = (QVxlCanMsg * max_count)()
        count = ctypes.c_int(max_count)
        
        # [修改] QVxlReceive
        status = self.vxl_dll.QVxlReceive(self.instance_id, buffer, ctypes.byref(count), timeout_ms)
        
        if status == QVXL_OK:
            return [buffer[i] for i in range(count.value)], status
        return [], status
            
    def get_stats(self):
        if not self.is_connected(): return None
        stats = QVxlChannelStat()
        # [修改] QVxlGetStatistics
        self.vxl_dll.QVxlGetStatistics(self.instance_id, ctypes.byref(stats))
        return stats

    def get_channel_info(self):
        if not self.is_connected(): return None
        info = QVxlChannelInfo()
        # [修改] QVxlGetChannelInfo
        if self.vxl_dll.QVxlGetChannelInfo(self.instance_id, ctypes.byref(info)) == QVXL_OK:
            return info
        return None

    def _auto_read_worker(self):
        print("\n[AutoRead] 接收线程已启动...")
        while not self._auto_read_stop_event.is_set():
            msgs, status = self.receive(max_count=20, timeout_ms=100)
            if status == QVXL_OK and msgs:
                sys.stdout.write("\r\033[K")
                for msg in msgs: print(f"[Rx] {msg}")
                sys.stdout.write("QVXL> ")
                sys.stdout.flush()

    def start_auto_read(self):
        if not self.is_connected() or (self._auto_read_thread and self._auto_read_thread.is_alive()):
            return
        self._auto_read_stop_event.clear()
        self._auto_read_thread = threading.Thread(target=self._auto_read_worker, daemon=True)
        self._auto_read_thread.start()

    def stop_auto_read(self):
        if self._auto_read_thread and self._auto_read_thread.is_alive():
            self._auto_read_stop_event.set()
            self._auto_read_thread.join(0.5)

    def clear_all(self):
        self.stop_auto_read()
        # [修改] QVxlClearAll
        self.vxl_dll.QVxlClearAll()
        self.instance_id = None
        print("所有实例已清理。")

    def is_connected(self):
        return self.instance_id is not None

    def cleanup(self):
        self.stop_auto_read()
        if self.is_connected():
            self.vxl_dll.QVxlStopMeasurement(self.instance_id)
            self.vxl_dll.QVxlDisconnect(self.instance_id)
        if self.vxl_dll:
            try: 
                # [修改] QVxlCloseLog
                self.vxl_dll.QVxlCloseLog()
            except: pass
