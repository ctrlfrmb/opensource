#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# QVXLMessage.py - QVXL API 消息类型定义和常量

import ctypes

# --- QVXL API 结果状态码 (必须与 qvxl_def.h 严格对应) ---
QVXL_OK                  = 0
QVXL_ERR_INIT_FAILED     = -1
QVXL_ERR_INVALID_HANDLE  = -2
QVXL_ERR_INVALID_PARAM   = -3
QVXL_ERR_CHANNEL_OFFLINE = -4
QVXL_ERR_TX_QUEUE_FULL   = -5
QVXL_ERR_RX_EMPTY        = -6
QVXL_ERR_RX_TIMEOUT      = -7
QVXL_ERR_ALREADY_EXISTS  = -20
QVXL_ERR_DRIVER_ERROR    = -100
QVXL_ERR_NOT_IMPLEMENTED = -404

STATUS_DESCRIPTIONS = {
    QVXL_OK: "操作成功",
    QVXL_ERR_INIT_FAILED: "初始化失败 (驱动未加载?)",
    QVXL_ERR_INVALID_HANDLE: "无效的实例句柄 (ID)",
    QVXL_ERR_INVALID_PARAM: "无效参数",
    QVXL_ERR_CHANNEL_OFFLINE: "通道离线或未启动",
    QVXL_ERR_TX_QUEUE_FULL: "发送队列已满",
    QVXL_ERR_RX_EMPTY: "接收队列为空 (非阻塞模式)",
    QVXL_ERR_RX_TIMEOUT: "接收超时 (阻塞模式)",
    QVXL_ERR_ALREADY_EXISTS: "连接失败: 该物理硬件通道已被其他实例占用",
    QVXL_ERR_DRIVER_ERROR: "驱动内部错误",
    QVXL_ERR_NOT_IMPLEMENTED: "功能未实现"
}

# --- CAN 报文标志位 ---
QVXL_FLAG_IDE = 0x01
QVXL_FLAG_RTR = 0x02
QVXL_FLAG_FD  = 0x10
QVXL_FLAG_BRS = 0x20
QVXL_FLAG_ESI = 0x40

# --- C 结构体定义 ---

class QVxlCanMsg(ctypes.Structure):
    # [修改] 必须与 C++ 的 #pragma pack(4) 一致
    _pack_ = 4 
    _fields_ = [
        ("canId", ctypes.c_uint),             
        ("msgFlags", ctypes.c_uint),          
        ("dlc", ctypes.c_ubyte),              
        ("padding", ctypes.c_ubyte * 3),      
        # [修改] C头文件中定义为 unsigned char data[64]
        ("data", ctypes.c_ubyte * 64),        
        ("dataLen", ctypes.c_uint),           
        ("timeStamp", ctypes.c_ulonglong)     
    ]

    def __repr__(self):
        flags_str = []
        if self.msgFlags & QVXL_FLAG_IDE: flags_str.append("EXT")
        if self.msgFlags & QVXL_FLAG_RTR: flags_str.append("RTR")
        if self.msgFlags & QVXL_FLAG_FD: flags_str.append("FD")
        if self.msgFlags & QVXL_FLAG_BRS: flags_str.append("BRS")
        if self.msgFlags & QVXL_FLAG_ESI: flags_str.append("ESI")
        
        flags_repr = f"({','.join(flags_str)})" if flags_str else ""
        
        # 打印时只显示有效长度的数据
        real_len = min(self.dataLen, 64)
        data_repr = ' '.join(f'{b:02X}' for b in self.data[:real_len])

        return (f"TS:{self.timeStamp:<12} ID:{self.canId:08X} {flags_repr:<10} "
                f"DLC:{self.dlc:<2} Len:{real_len:<2} Data:[{data_repr}]")


class QVxlChannelStat(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("txCount", ctypes.c_ulonglong),
        ("rxCount", ctypes.c_ulonglong),
        ("errCount", ctypes.c_ulonglong),
        ("busLoad", ctypes.c_uint),
        ("chipState", ctypes.c_uint)
    ]
    
    def __repr__(self):
        return (f"Tx:{self.txCount} Rx:{self.rxCount} Err:{self.errCount} "
                f"State:{self.chipState} Load:{self.busLoad / 100.0:.2f}%")


class QVxlChannelInfo(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("hwType", ctypes.c_uint),
        ("hwIndex", ctypes.c_uint),
        ("hwChannel", ctypes.c_uint),
        ("isOnBus", ctypes.c_uint)
    ]
    
    def __repr__(self):
        status = "OnBus" if self.isOnBus else "OffBus"
        return f"Type:{self.hwType} Idx:{self.hwIndex} Ch:{self.hwChannel} [{status}]"


class QVxlScanInfo(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("name", ctypes.c_char * 64),
        ("hwType", ctypes.c_uint),
        ("hwIndex", ctypes.c_uint),
        ("hwChannel", ctypes.c_uint),
        ("busType", ctypes.c_uint)
    ]
    
    def __repr__(self):
        name_str = self.name.decode('utf-8', errors='ignore')
        return (f"[{name_str}] Type:{self.hwType} Index:{self.hwIndex} Ch:{self.hwChannel}")


def get_status_description(status_code):
    return STATUS_DESCRIPTIONS.get(status_code, f"未知错误码: {status_code}")
