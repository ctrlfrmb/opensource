﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# DoIPServerTest.py - DoIP服务器测试和命令行界面

import argparse
import logging
import signal
import sys
import time
import threading
from DoIPServer import DoIPServer

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('DoIPServerTest')

def signal_handler(sig, frame):
    """处理信号（如Ctrl+C）"""
    global server
    logger.info("接收到中断信号，正在关闭服务器...")
    
    if server:
        server.stop()
    
    logger.info("程序已终止")
    sys.exit(0)

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='DoIP服务器模拟程序')
    parser.add_argument('--host', type=str, default='0.0.0.0', help='监听的IP地址')
    parser.add_argument('--port', type=int, default=13400, help='监听的端口号')
    parser.add_argument('--server-address', type=lambda x: int(x, 0), default=0x0E01, 
                      help='服务器逻辑地址 (十六进制格式，如0x0E01)')
    parser.add_argument('--log-level', type=str, choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'], 
                      default='INFO', help='日志级别')
    
    return parser.parse_args()

def print_help():
    """打印帮助信息"""
    print("\n可用命令:")
    print("  help                                     显示此帮助信息")
    print("  status                                   显示服务器状态")
    print("  clients                                  显示已连接的客户端")
    print("  setdid <DID> <数据>                      设置DID数据 (十六进制格式)")
    print("  adddid <DID>                             添加可写入的DID")
    print("  exit                                     退出程序")
    print("\n示例:")
    print("  setdid 0xF190 0102030405060708")
    print("  adddid 0xF195")

def main():
    """主函数"""
    global server
    
    # 注册信号处理器
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    args = parse_arguments()
    
    # 设置日志级别
    logging.getLogger().setLevel(getattr(logging, args.log_level))
    
    # 创建并启动DoIP服务器
    server = DoIPServer(
        host=args.host,
        port=args.port,
        logical_address=args.server_address
    )
    
    # 添加一些示例DID数据
    server.set_did_data(0xF180, "01020304")
    server.set_did_data(0xF181, "AABBCCDD")
    server.set_did_data(0xF190, "0102030405060708")
    server.add_writable_did(0xF190)
    
    # 启动服务器
    if not server.start():
        logger.error("启动服务器失败")
        return
    
    logger.info(f"DoIP服务器已启动，监听于 {args.host}:{args.port}")
    logger.info(f"服务器逻辑地址: 0x{args.server_address:04X}")
    
    print_help()
    
    # 命令行交互
    try:
        while True:
            try:
                cmd = input("\n>>> ").strip()
                
                if not cmd:
                    continue
                
                cmd_parts = cmd.split()
                cmd_name = cmd_parts[0].lower()
                
                if cmd_name == "help":
                    print_help()
                
                elif cmd_name == "status":
                    print(f"服务器状态: {'运行中' if server.running else '已停止'}")
                    print(f"监听地址: {args.host}:{args.port}")
                    print(f"逻辑地址: 0x{args.server_address:04X}")
                
                elif cmd_name == "clients":
                    if not server.clients:
                        print("无已连接的客户端")
                    else:
                        print("已连接的客户端:")
                        for sock, client in server.clients.items():
                            addr = client['addr']
                            tester_address = client['tester_address']
                            activated = client['activated']
                            print(f"  {addr[0]}:{addr[1]} - 测试设备地址: {tester_address if tester_address else 'N/A'}, 激活状态: {'已激活' if activated else '未激活'}")
                
                elif cmd_name == "setdid":
                    if len(cmd_parts) < 3:
                        print("错误: 设置DID的格式为 setdid <DID> <数据>")
                        continue
                    
                    try:
                        did = int(cmd_parts[1], 0)
                        data = cmd_parts[2]
                        server.set_did_data(did, data)
                        print(f"已设置DID 0x{did:04X}的数据: {data}")
                    except ValueError:
                        print("错误: DID必须是十六进制格式")
                
                elif cmd_name == "adddid":
                    if len(cmd_parts) < 2:
                        print("错误: 添加可写入DID的格式为 adddid <DID>")
                        continue
                    
                    try:
                        did = int(cmd_parts[1], 0)
                        server.add_writable_did(did)
                        print(f"已添加可写入DID: 0x{did:04X}")
                    except ValueError:
                        print("错误: DID必须是十六进制格式")
                
                elif cmd_name == "exit":
                    break
                
                else:
                    print(f"未知命令: {cmd_name}，输入 help 获取帮助")
            
            except KeyboardInterrupt:
                print("\n接收到中断，输入 exit 退出程序")
            
            except Exception as e:
                print(f"错误: {e}")
    
    finally:
        # 确保在退出时停止服务器
        logger.info("正在关闭服务器...")
        server.stop()
        logger.info("服务器已关闭")

# 全局变量
server = None

if __name__ == "__main__":
    main()
