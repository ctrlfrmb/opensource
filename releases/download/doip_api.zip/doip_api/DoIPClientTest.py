#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# DoIPClientTest.py - DoIP客户端测试和命令行界面

from DoIPClientMessage import *
from DoIPClient import DoIPClient
import sys
import signal
import platform
import threading
import os
import time
import re

def signal_handler(sig, frame):
    """处理信号（如Ctrl+C）"""
    global client
    print("\n接收到中断信号，正在清理资源...")
    
    try:
        if client:
            # 设置一个超时，避免清理过程无限阻塞
            cleanup_thread = threading.Thread(target=client.cleanup)
            cleanup_thread.daemon = True  # 设置为守护线程
            cleanup_thread.start()
            
            # 等待清理完成，但最多等待3秒
            cleanup_thread.join(timeout=3.0)
            
            if cleanup_thread.is_alive():
                print("警告: 清理过程超时，强制退出")
            else:
                print("清理完成")
    except Exception as e:
        print(f"清理过程中出错: {e}")
    
    print("程序已终止")
    # 强制终止程序，不等待其他线程
    os._exit(0)

def print_help():
    """打印帮助信息"""
    print("\n可用命令:")
    print("  --help                                      显示此帮助信息")
    print("  --connect -serverIP <IP> -serverTcpPort <端口> -source <源地址> -target <目标地址> [-localIP <本地IP>]")
    print("                                              连接到 DoIP 服务器")
    print("  --disconnect                                断开与 DoIP 服务器的连接")
    print("  --send -msg <诊断消息>                      发送诊断消息（十六进制格式，如 '10 01'）")
    print("  --send -first <消息1> -second <消息2>       连续发送两条诊断消息")
    print("  --setReconnect [on|off]                     设置重连功能（on: 启用，off: 禁用）")
    print("  --setReadUDS [on|off]                       设置 UDS 读取模式（on: 仅返回 UDS 数据，off: 返回完整 DoIP 负载）")
    print("  --uds27                                     发送标准 UDS 27 安全解锁序列（默认 450 字节全 0 解锁）")
    print("  --uds27 -first <模式> -second <模式> <密钥>  发送自定义 UDS 27 安全解锁序列")
    print("  --read                                      读取接收到的消息")
    print("  --clear                                     清空消息缓存")
    print("  --addPeriod -time <周期ms> -msg <诊断消息>  添加周期性诊断消息")
    print("  --delPeriod -id <周期ID>                    删除周期性诊断消息")
    print("  --stopAllPeriods                            停止所有周期性诊断消息")
    print("  --listPeriod                                列出所有周期性诊断消息")
    print("  --autoRead [on|off]                         开启/关闭自动读取消息（默认: on）")
    print("  --exit                                      退出程序")
    print("\n示例:")
    print("  --connect -serverIP 192.168.146.1 -source 0x0E80 -target 0x0E01")
    print("  --send -msg 10 01")
    print("  --send -first 27 01 -second 27 02 AA BB CC DD")
    print("  --uds27")
    print("  --uds27 -first 01 -second 02 11 22 33 44 55 66 77 88")
    print("  --setReconnect on")
    print("  --autoRead on")
    print("  --addPeriod -time 5000 -msg 3e 80")
    print("  --addPeriod -time 2000 -msg 22 f1 81")
    print("  --delPeriod -id 1")
    print("  --stopAllPeriods")

def parse_hex_address(address_str):
    """解析十六进制地址"""
    if not address_str:
        return None
    
    try:
        # 支持0x前缀的十六进制和纯十六进制
        if address_str.lower().startswith('0x'):
            return int(address_str, 16)
        else:
            return int(address_str, 16)
    except ValueError:
        print(f"错误: 无效的十六进制地址: {address_str}")
        return None

def handle_connect_command(cmd_parts):
    """处理连接命令"""
    # 解析命令行参数
    server_ip = None
    server_port = 13400  # 默认端口
    source_address = 0x0E80  # 默认源地址
    target_address = 0x0E01  # 默认目标地址
    local_ip = None
    
    i = 1  # 跳过命令名
    while i < len(cmd_parts):
        if cmd_parts[i] == "-serverIP" and i + 1 < len(cmd_parts):
            server_ip = cmd_parts[i + 1]
            i += 2
        elif cmd_parts[i] == "-serverTcpPort" and i + 1 < len(cmd_parts):
            try:
                # 确保端口是整数类型
                server_port = int(cmd_parts[i + 1])
                i += 2
            except ValueError:
                print("错误: serverTcpPort 必须是整数")
                return False
        elif cmd_parts[i] == "-source" and i + 1 < len(cmd_parts):
            source_address = parse_hex_address(cmd_parts[i + 1])
            if source_address is None:
                return False
            i += 2
        elif cmd_parts[i] == "-target" and i + 1 < len(cmd_parts):
            target_address = parse_hex_address(cmd_parts[i + 1])
            if target_address is None:
                return False
            i += 2
        elif cmd_parts[i] == "-localIP" and i + 1 < len(cmd_parts):
            local_ip = cmd_parts[i + 1]
            i += 2
        else:
            i += 1
    
    if server_ip is None:
        print("错误: 缺少参数 serverIP")
        return False
    
    return client.connect(server_ip, server_port, source_address, target_address, local_ip)

def handle_uds27_command(cmd_parts):
    """处理 UDS 27 服务安全访问命令"""
    
    # 如果没有额外参数，使用默认的安全解锁序列
    if len(cmd_parts) == 1:
        print("执行标准 UDS 27 安全解锁序列...")
        
        # 第一条消息：请求种子
        first_message = "27 01"
        print(f"[1/2] 发送请求种子: {first_message}")
        if not client.send_diagnostic(first_message):
            return False
        
        # 等待种子响应
        time.sleep(0.1)
        client.read_messages()
        
        # 第二条消息：发送密钥（450字节全0）
        second_message = "27 02" + " 00" * 450
        print(f"[2/2] 发送密钥: 27 02 00 00 ... (450字节全0)")
        return client.send_diagnostic(second_message)
    
    # 解析自定义27服务序列
    first_msg = None
    second_msg = None
    
    i = 1
    while i < len(cmd_parts):
        if cmd_parts[i] == "-first" and i + 1 < len(cmd_parts):
            # 获取第一条消息
            first_mode = cmd_parts[i + 1]
            if len(first_mode) == 1:
                first_mode = "0" + first_mode
            
            # 验证模式是否有效
            if not re.match(r'^[0-9a-fA-F]{2}$', first_mode):
                print("错误: 无效的模式格式，请使用十六进制格式（例如: 01）")
                return False
            
            first_msg = "27 " + first_mode
            i += 2
        elif cmd_parts[i] == "-second" and i + 1 < len(cmd_parts):
            # 获取第二条消息的基本部分
            second_mode = cmd_parts[i + 1]
            if len(second_mode) == 1:
                second_mode = "0" + second_mode
            
            # 验证模式是否有效
            if not re.match(r'^[0-9a-fA-F]{2}$', second_mode):
                print("错误: 无效的模式格式，请使用十六进制格式（例如: 02）")
                return False
            
            # 获取密钥部分(如果有)
            second_msg = "27 " + second_mode
            
            # 处理密钥部分
            if i + 2 < len(cmd_parts):
                key_parts = []
                j = i + 2
                while j < len(cmd_parts) and not cmd_parts[j].startswith('-'):
                    key_parts.append(cmd_parts[j])
                    j += 1
                
                if key_parts:
                    key_str = " ".join(key_parts)
                    
                    # 验证密钥格式
                    clean_key = key_str.replace(" ", "")
                    if not re.match(r'^[0-9a-fA-F]+$', clean_key):
                        print("错误: 无效的密钥格式，请使用十六进制格式")
                        return False
                    
                    # 如果密钥不是偶数个十六进制字符，则无效
                    if len(clean_key) % 2 != 0:
                        print("错误: 密钥必须由完整的字节组成（每字节两个十六进制字符）")
                        return False
                    
                    second_msg += " " + key_str
            
            i = j  # 更新索引到下一个参数
        else:
            i += 1
    
    # 检查是否提供了两条消息
    if not first_msg or not second_msg:
        print("错误: 需要同时指定 -first 和 -second 参数")
        return False
    
    # 执行27服务序列
    print(f"[1/2] 发送请求种子: {first_msg}")
    if not client.send_diagnostic(first_msg):
        return False
    
    # 等待种子响应
    time.sleep(0.1)
    client.read_messages()
    
    print(f"[2/2] 发送密钥: {second_msg}")
    return client.send_diagnostic(second_msg)

def handle_send_command(cmd_parts, cmd_line):
    """处理发送诊断消息命令"""
    # 检查是否是连续发送两条消息
    if len(cmd_parts) >= 5 and cmd_parts[1] == "-first" and "-second" in cmd_parts:
        first_idx = cmd_line.find("-first") + 7
        second_idx = cmd_line.find("-second")
        
        if first_idx < 0 or second_idx < 0 or second_idx <= first_idx:
            print("错误: 发送连续消息的格式为 --send -first <消息1> -second <消息2>")
            return False
        
        # 提取第一条消息
        first_msg = cmd_line[first_idx:second_idx].strip()
        if not first_msg:
            print("错误: 第一条消息不能为空")
            return False
        
        # 提取第二条消息
        second_msg = cmd_line[second_idx + 8:].strip()
        if not second_msg:
            print("错误: 第二条消息不能为空")
            return False
        
        # 发送第一条消息
        print(f"[1/2] 发送消息: {first_msg}")
        if not client.send_diagnostic(first_msg):
            return False
        
        # 给服务器一点时间处理第一条消息
        time.sleep(0.1)
        client.read_messages()
        
        # 发送第二条消息
        print(f"[2/2] 发送消息: {second_msg}")
        return client.send_diagnostic(second_msg)
    
    # 处理单条消息发送
    elif len(cmd_parts) >= 3 and cmd_parts[1] == "-msg":
        # 获取-msg后的所有内容作为完整的诊断消息
        msg = ' '.join(cmd_parts[2:])
        return client.send_diagnostic(msg)
    else:
        print("错误: 发送诊断消息的格式为 --send -msg <诊断消息> 或 --send -first <消息1> -second <消息2>")
        return False

def main():
    global client
    
    # 注册信号处理器
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("=" * 60)
    print(f"DoIP 客户端命令行工具 v2.2.0 (Python {platform.architecture()[0]})")
    print("=" * 60)
    print("输入 --help 获取帮助，输入 --exit 退出程序")
    
    # 创建DoIP客户端
    client = DoIPClient()
    
    # 主循环
    try:
        while client.running:
            try:
                # 提示符
                print(">>> ", end="", flush=True)
                cmd_line = input().strip()
                
                if not cmd_line:
                    continue
                
                # 分割命令行，得到命令和参数部分
                cmd_parts = cmd_line.split()
                cmd_name = cmd_parts[0].lower() if cmd_parts else ""
                
                # 执行相应的命令
                if cmd_name == "--help":
                    print_help()
                
                elif cmd_name == "--exit":
                    print("正在退出程序...")
                    # 使用与信号处理器相同的方法处理退出
                    signal_handler(signal.SIGINT, None)
                    break
                
                elif cmd_name == "--connect":
                    handle_connect_command(cmd_parts)
                
                elif cmd_name == "--disconnect":
                    client.disconnect()
                
                elif cmd_name == "--setreconnect":
                    if len(cmd_parts) >= 2:
                        flag = 1 if cmd_parts[1].lower() == "on" else 0
                        client.set_reconnect(flag)
                    else:
                        print("错误: 缺少参数，请指定 on 或 off")
                
                elif cmd_name == "--setreaduds":
                    if len(cmd_parts) >= 2:
                        flag = 1 if cmd_parts[1].lower() == "on" else 0
                        client.set_read_uds(flag)
                    else:
                        print("错误: 缺少参数，请指定 on 或 off")
                
                elif cmd_name == "--send":
                    handle_send_command(cmd_parts, cmd_line)
                
                elif cmd_name == "--uds27":
                    # 处理 UDS 27 服务安全访问命令
                    handle_uds27_command(cmd_parts)
                
                elif cmd_name == "--read":
                    client.read_messages()
                
                elif cmd_name == "--clear":
                    client.clear_messages()
                
                elif cmd_name == "--addperiod":
                    # 特殊处理添加周期性诊断消息命令
                    time_ms = 1000  # 默认周期为1000ms
                    msg = None
                    
                    # 查找-time和-msg参数
                    for i in range(1, len(cmd_parts)):
                        if cmd_parts[i] == "-time" and i + 1 < len(cmd_parts):
                            try:
                                time_ms = int(cmd_parts[i + 1])
                            except ValueError:
                                print("错误: time 参数必须是整数")
                                break
                        elif cmd_parts[i] == "-msg":
                            # 提取-msg后的所有内容作为完整的诊断消息
                            msg_index = cmd_line.find("-msg") + len("-msg ")
                            msg = cmd_line[msg_index:].strip()
                            break
                    
                    if msg:
                        client.add_periodic_diagnostic(msg, time_ms)
                    else:
                        print("错误: 添加周期诊断消息的格式为 --addPeriod -time <周期ms> -msg <诊断消息>")
                
                elif cmd_name == "--delperiod":
                    # 解析周期ID
                    period_id = -1
                    for i in range(1, len(cmd_parts)):
                        if cmd_parts[i] == "-id" and i + 1 < len(cmd_parts):
                            try:
                                period_id = int(cmd_parts[i + 1])
                            except ValueError:
                                print("错误: id 参数必须是整数")
                                break
                    
                    if period_id >= 0:
                        client.delete_periodic_diagnostic(period_id)
                    else:
                        print("错误: 删除周期诊断消息的格式为 --delPeriod -id <周期ID>")
                        
                elif cmd_name == "--stopallperiods":
                    client.stop_all_periodic_tasks()
                
                elif cmd_name == "--listperiod":
                    if not client.periodic_ids:
                        print("无活动的周期性诊断消息")
                    else:
                        print("\n当前活动的周期性诊断消息:")
                        for period_id, msg in client.periodic_ids.items():
                            print(f"  ID: {period_id}, 消息: {msg}")
                
                elif cmd_name == "--autoread":
                    # 处理自动读取命令
                    if len(cmd_parts) > 1:
                        state = cmd_parts[1].lower()
                        if state == "on":
                            client.start_auto_read()
                        elif state == "off":
                            client.stop_auto_read()
                        else:
                            print("错误: autoRead 参数必须是 on 或 off")
                    else:
                        # 默认开启
                        client.start_auto_read()
                
                else:
                    print(f"未知命令: {cmd_name}，输入 --help 获取帮助")
            
            except KeyboardInterrupt:
                print("\n接收到中断，输入 --exit 退出程序或再次按 Ctrl+C 强制退出")
            
            except Exception as e:
                print(f"错误: {e}")
                import traceback
                traceback.print_exc()
    finally:
        # 确保在任何情况下都会清理资源
        print("程序结束，正在清理资源...")
        try:
            if client:
                # 设置超时清理
                cleanup_thread = threading.Thread(target=client.cleanup)
                cleanup_thread.daemon = True
                cleanup_thread.start()
                cleanup_thread.join(timeout=3.0)
                
                if cleanup_thread.is_alive():
                    print("警告: 清理过程超时")
                else:
                    print("清理完成")
        except Exception as e:
            print(f"最终清理时出错: {e}")

# 全局变量
client = None

# 入口函数
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"主程序异常: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("程序退出")
        # 强制退出，确保不会被阻塞的线程卡住
        os._exit(0)
