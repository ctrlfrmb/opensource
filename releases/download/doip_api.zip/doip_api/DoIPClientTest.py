#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# DoIPClientTest.py - DoIP客户端测试和命令行界面 (v3.2.0)
# 适配新API：移除 --setReconnect / --setReadUDS 命令，
# reconnectFlag/readUDS 改为连接参数，新增 --isConnected 命令

from DoIPClientMessage import *
from DoIPClient import DoIPClient
import sys
import signal
import platform
import threading
import os
import time
import re

def signal_handler(sig, frame):
    """处理信号（如Ctrl+C）"""
    global client
    print("\n接收到中断信号，正在清理资源...")
    
    try:
        if client:
            cleanup_thread = threading.Thread(target=client.cleanup)
            cleanup_thread.daemon = True
            cleanup_thread.start()
            cleanup_thread.join(timeout=3.0)
            
            if cleanup_thread.is_alive():
                print("警告: 清理过程超时，强制退出")
            else:
                print("清理完成")
    except Exception as e:
        print(f"清理过程中出错: {e}")
    
    print("程序已终止")
    os._exit(0)

def print_help():
    """打印帮助信息"""
    print("\n可用命令:")
    print("  --help                                      显示此帮助信息")
    print("  --connect -serverIP <IP> -serverTcpPort <端口> -source <源地址> -target <目标地址>")
    print("            [-localIP <本地IP>] [-reconnect on|off] [-readUDS on|off]")
    print("            [-autoSecurity27 on|off] [-algoName DH_27] [-algoType dh27] [-dllPath <路径>] ...")
    print("                                              连接到 DoIP 服务器")
    print("  --setSecAlgo \"--algoName ... --dllPath ...\"   连接后配置 27 算法(C API 同格式)")
    print("  --sec27api -level <0x09> [-timeout 3000]      连接后显式调用 DoIPClientSecurityAccess")
    print("  --disconnect                                断开与 DoIP 服务器的连接")
    print("  --isConnected                               查询当前实际连接状态")
    print("  --send -msg <诊断消息>                      发送诊断消息（十六进制格式，如 '10 01'）")
    print("  --send -first <消息1> -second <消息2>       连续发送两条诊断消息")
    print("  --uds27                                     发送标准 UDS 27 安全解锁序列（默认 450 字节全 0 解锁）")
    print("  --uds27 -first <模式> -second <模式> <密钥>  发送自定义 UDS 27 安全解锁序列")
    print("  --read                                      读取接收到的消息")
    print("  --clear                                     清空消息缓存")
    print("  --addPeriod -time <周期ms> -msg <诊断消息> [-target <目标地址>]  添加周期性诊断消息")
    print("  --delPeriod -id <周期ID>                    删除周期性诊断消息")
    print("  --stopAllPeriods                            停止所有周期性诊断消息")
    print("  --listPeriod                                列出所有周期性诊断消息")
    print("  --autoRead [on|off]                         开启/关闭自动读取消息（默认: on）")
    print("  --exit                                      退出程序")
    print("\n示例:")
    print("  --connect -serverIP 192.168.146.1 -source 0x0E80 -target 0x0E01")
    print("  --connect -serverIP 192.168.146.1 -source 0x0E80 -target 0x0E01 -reconnect on -readUDS off")
    print("  --connect -serverIP 192.168.146.1 -source 0x0E80 -target 0x0E01 -autoSecurity27 on -algoName DH_27")
    print("  --isConnected")
    print("  --send -msg 10 01")
    print("  --send -first 27 01 -second 27 02 AA BB CC DD")
    print("  --uds27")
    print("  --uds27 -first 01 -second 02 11 22 33 44 55 66 77 88")
    print("  --autoRead on")
    print("  --addPeriod -time 5000 -msg 3e 80")
    print("  --addPeriod -time 2000 -msg 3e 80 -target 0x0E3E")
    print("  --addPeriod -time 2000 -msg 22 f1 81")
    print("  --delPeriod -id 1")
    print("  --stopAllPeriods")

def parse_hex_address(address_str):
    """解析十六进制地址"""
    if not address_str:
        return None
    try:
        if address_str.lower().startswith('0x'):
            return int(address_str, 16)
        else:
            return int(address_str, 16)
    except ValueError:
        print(f"错误: 无效的十六进制地址: {address_str}")
        return None

def handle_connect_command(cmd_parts):
    """处理连接命令"""
    server_ip = None
    server_port = 13400
    source_address = 0x0E80
    target_address = 0x0E01
    local_ip = None
    reconnect_flag = True
    read_uds = True
    auto_security_27 = False
    algo_name = None
    algo_type = None
    dll_path = None
    
    i = 1
    while i < len(cmd_parts):
        if cmd_parts[i] == "-serverIP" and i + 1 < len(cmd_parts):
            server_ip = cmd_parts[i + 1]
            i += 2
        elif cmd_parts[i] == "-serverTcpPort" and i + 1 < len(cmd_parts):
            try:
                server_port = int(cmd_parts[i + 1])
                i += 2
            except ValueError:
                print("错误: serverTcpPort 必须是整数")
                return False
        elif cmd_parts[i] == "-source" and i + 1 < len(cmd_parts):
            source_address = parse_hex_address(cmd_parts[i + 1])
            if source_address is None:
                return False
            i += 2
        elif cmd_parts[i] == "-target" and i + 1 < len(cmd_parts):
            target_address = parse_hex_address(cmd_parts[i + 1])
            if target_address is None:
                return False
            i += 2
        elif cmd_parts[i] == "-localIP" and i + 1 < len(cmd_parts):
            local_ip = cmd_parts[i + 1]
            i += 2
        elif cmd_parts[i] == "-reconnect" and i + 1 < len(cmd_parts):
            reconnect_flag = cmd_parts[i + 1].lower() in ("on", "true", "1")
            i += 2
        elif cmd_parts[i] == "-readUDS" and i + 1 < len(cmd_parts):
            read_uds = cmd_parts[i + 1].lower() in ("on", "true", "1")
            i += 2
        elif cmd_parts[i] == "-autoSecurity27" and i + 1 < len(cmd_parts):
            auto_security_27 = cmd_parts[i + 1].lower() in ("on", "true", "1")
            i += 2
        elif cmd_parts[i] == "-algoName" and i + 1 < len(cmd_parts):
            algo_name = cmd_parts[i + 1]
            i += 2
        elif cmd_parts[i] == "-algoType" and i + 1 < len(cmd_parts):
            algo_type = cmd_parts[i + 1]
            i += 2
        elif cmd_parts[i] == "-dllPath" and i + 1 < len(cmd_parts):
            dll_path = cmd_parts[i + 1]
            i += 2
        else:
            i += 1
    
    if server_ip is None:
        print("错误: 缺少参数 serverIP")
        return False
    
    return client.connect(server_ip, server_port, source_address, target_address,
                          local_ip, reconnect_flag, read_uds,
                          auto_security_27=auto_security_27,
                          algo_name=algo_name, algo_type=algo_type, dll_path=dll_path)

def handle_uds27_command(cmd_parts):
    """处理 UDS 27 服务安全访问命令"""
    if len(cmd_parts) == 1:
        print("执行标准 UDS 27 安全解锁序列...")
        
        first_message = "27 01"
        print(f"[1/2] 发送请求种子: {first_message}")
        if not client.send_diagnostic(first_message):
            return False
        
        time.sleep(0.1)
        client.read_messages()
        
        second_message = "27 02" + " 00" * 450
        print(f"[2/2] 发送密钥: 27 02 00 00 ... (450字节全0)")
        return client.send_diagnostic(second_message)
    
    first_msg = None
    second_msg = None
    
    i = 1
    while i < len(cmd_parts):
        if cmd_parts[i] == "-first" and i + 1 < len(cmd_parts):
            first_mode = cmd_parts[i + 1]
            if len(first_mode) == 1:
                first_mode = "0" + first_mode
            if not re.match(r'^[0-9a-fA-F]{2}$', first_mode):
                print("错误: 无效的模式格式，请使用十六进制格式（例如: 01）")
                return False
            first_msg = "27 " + first_mode
            i += 2
        elif cmd_parts[i] == "-second" and i + 1 < len(cmd_parts):
            second_mode = cmd_parts[i + 1]
            if len(second_mode) == 1:
                second_mode = "0" + second_mode
            if not re.match(r'^[0-9a-fA-F]{2}$', second_mode):
                print("错误: 无效的模式格式，请使用十六进制格式（例如: 02）")
                return False
            second_msg = "27 " + second_mode
            
            if i + 2 < len(cmd_parts):
                key_parts = []
                j = i + 2
                while j < len(cmd_parts) and not cmd_parts[j].startswith('-'):
                    key_parts.append(cmd_parts[j])
                    j += 1
                
                if key_parts:
                    key_str = " ".join(key_parts)
                    clean_key = key_str.replace(" ", "")
                    if not re.match(r'^[0-9a-fA-F]+$', clean_key):
                        print("错误: 无效的密钥格式，请使用十六进制格式")
                        return False
                    if len(clean_key) % 2 != 0:
                        print("错误: 密钥必须由完整的字节组成（每字节两个十六进制字符）")
                        return False
                    second_msg += " " + key_str
            
            i = j
        else:
            i += 1
    
    if not first_msg or not second_msg:
        print("错误: 需要同时指定 -first 和 -second 参数")
        return False
    
    print(f"[1/2] 发送请求种子: {first_msg}")
    if not client.send_diagnostic(first_msg):
        return False
    
    time.sleep(0.1)
    client.read_messages()
    
    print(f"[2/2] 发送密钥: {second_msg}")
    return client.send_diagnostic(second_msg)

def handle_send_command(cmd_parts, cmd_line):
    """处理发送诊断消息命令"""
    if len(cmd_parts) >= 5 and cmd_parts[1] == "-first" and "-second" in cmd_parts:
        first_idx = cmd_line.find("-first") + 7
        second_idx = cmd_line.find("-second")
        
        if first_idx < 0 or second_idx < 0 or second_idx <= first_idx:
            print("错误: 发送连续消息的格式为 --send -first <消息1> -second <消息2>")
            return False
        
        first_msg = cmd_line[first_idx:second_idx].strip()
        if not first_msg:
            print("错误: 第一条消息不能为空")
            return False
        
        second_msg = cmd_line[second_idx + 8:].strip()
        if not second_msg:
            print("错误: 第二条消息不能为空")
            return False
        
        print(f"[1/2] 发送消息: {first_msg}")
        if not client.send_diagnostic(first_msg):
            return False
        
        time.sleep(0.1)
        client.read_messages()
        
        print(f"[2/2] 发送消息: {second_msg}")
        return client.send_diagnostic(second_msg)
    
    elif len(cmd_parts) >= 3 and cmd_parts[1] == "-msg":
        msg = ' '.join(cmd_parts[2:])
        return client.send_diagnostic(msg)
    else:
        print("错误: 发送诊断消息的格式为 --send -msg <诊断消息> 或 --send -first <消息1> -second <消息2>")
        return False

def main():
    global client
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("=" * 60)
    print(f"DoIP 客户端命令行工具 v3.0.0 (Python {platform.architecture()[0]})")
    print("=" * 60)
    print("输入 --help 获取帮助，输入 --exit 退出程序")
    
    client = DoIPClient()
    
    try:
        while client.running:
            try:
                print(">>> ", end="", flush=True)
                cmd_line = input().strip()
                
                if not cmd_line:
                    continue
                
                cmd_parts = cmd_line.split()
                cmd_name = cmd_parts[0].lower() if cmd_parts else ""
                
                if cmd_name == "--help":
                    print_help()
                
                elif cmd_name == "--exit":
                    print("正在退出程序...")
                    signal_handler(signal.SIGINT, None)
                    break
                
                elif cmd_name == "--connect":
                    handle_connect_command(cmd_parts)

                elif cmd_name == "--setsecalgo":
                    parts = cmd_line.split(None, 1)
                    if len(parts) < 2:
                        print('用法: --setSecAlgo "--algoName DH_27 --algoType canoe --dllPath D:/x.dll ..."')
                    else:
                        rest = parts[1].strip()
                        if (rest.startswith('"') and rest.endswith('"')) or (
                            rest.startswith("'") and rest.endswith("'")
                        ):
                            rest = rest[1:-1]
                        client.set_security_algorithm(rest)

                elif cmd_name == "--sec27api":
                    level = None
                    timeout_ms = 0
                    j = 1
                    while j < len(cmd_parts):
                        if cmd_parts[j] == "-level" and j + 1 < len(cmd_parts):
                            level = parse_hex_address(cmd_parts[j + 1])
                            j += 2
                        elif cmd_parts[j] == "-timeout" and j + 1 < len(cmd_parts):
                            timeout_ms = int(cmd_parts[j + 1])
                            j += 2
                        else:
                            j += 1
                    if level is None:
                        print("用法: --sec27api -level 0x09 [-timeout 3000]")
                    else:
                        client.security_access(level, timeout_ms)
                
                elif cmd_name == "--disconnect":
                    client.disconnect()
                
                elif cmd_name == "--isconnected":
                    if client.instance_id is None:
                        print("当前无实例，未连接")
                    else:
                        connected = client.check_connection()
                        status_str = "已连接" if connected else "未连接（连接已断开）"
                        print(f"实例 ID {client.instance_id}: {status_str}")
                
                elif cmd_name == "--send":
                    handle_send_command(cmd_parts, cmd_line)
                
                elif cmd_name == "--uds27":
                    handle_uds27_command(cmd_parts)
                
                elif cmd_name == "--read":
                    client.read_messages()
                
                elif cmd_name == "--clear":
                    client.clear_messages()
                
                elif cmd_name == "--addperiod":
                    time_ms = 1000
                    msg = None
                    target_address = None

                    for i in range(1, len(cmd_parts)):
                        if cmd_parts[i] == "-time" and i + 1 < len(cmd_parts):
                            try:
                                time_ms = int(cmd_parts[i + 1])
                            except ValueError:
                                print("错误: time 参数必须是整数")
                                break
                        elif cmd_parts[i] == "-target" and i + 1 < len(cmd_parts):
                            target_address = parse_hex_address(cmd_parts[i + 1])
                            if target_address is None:
                                break
                        elif cmd_parts[i] == "-msg":
                            msg_index = cmd_line.find("-msg") + len("-msg ")
                            msg = cmd_line[msg_index:].strip()
                            if " -target " in msg:
                                msg = msg[:msg.rfind(" -target ")].strip()
                            break

                    if msg:
                        client.add_periodic_diagnostic(msg, time_ms, target_address=target_address)
                    else:
                        print("错误: 添加周期诊断消息的格式为 --addPeriod -time <周期ms> -msg <诊断消息> [-target <目标地址>]")
                
                elif cmd_name == "--delperiod":
                    period_id = -1
                    for i in range(1, len(cmd_parts)):
                        if cmd_parts[i] == "-id" and i + 1 < len(cmd_parts):
                            try:
                                period_id = int(cmd_parts[i + 1])
                            except ValueError:
                                print("错误: id 参数必须是整数")
                                break
                    
                    if period_id >= 0:
                        client.delete_periodic_diagnostic(period_id)
                    else:
                        print("错误: 删除周期诊断消息的格式为 --delPeriod -id <周期ID>")
                        
                elif cmd_name == "--stopallperiods":
                    client.stop_all_periodic_tasks()
                
                elif cmd_name == "--listperiod":
                    if not client.periodic_ids:
                        print("无活动的周期性诊断消息")
                    else:
                        print("\n当前活动的周期性诊断消息:")
                        for period_id, msg in client.periodic_ids.items():
                            print(f"  ID: {period_id}, 消息: {msg}")
                
                elif cmd_name == "--autoread":
                    if len(cmd_parts) > 1:
                        state = cmd_parts[1].lower()
                        if state == "on":
                            client.start_auto_read()
                        elif state == "off":
                            client.stop_auto_read()
                        else:
                            print("错误: autoRead 参数必须是 on 或 off")
                    else:
                        client.start_auto_read()
                
                else:
                    print(f"未知命令: {cmd_name}，输入 --help 获取帮助")
            
            except KeyboardInterrupt:
                print("\n接收到中断，输入 --exit 退出程序或再次按 Ctrl+C 强制退出")
            
            except Exception as e:
                print(f"错误: {e}")
                import traceback
                traceback.print_exc()
    finally:
        print("程序结束，正在清理资源...")
        try:
            if client:
                cleanup_thread = threading.Thread(target=client.cleanup)
                cleanup_thread.daemon = True
                cleanup_thread.start()
                cleanup_thread.join(timeout=3.0)
                
                if cleanup_thread.is_alive():
                    print("警告: 清理过程超时")
                else:
                    print("清理完成")
        except Exception as e:
            print(f"最终清理时出错: {e}")

# 全局变量
client = None

# 入口函数
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"主程序异常: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("程序退出")
        os._exit(0)
