#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# DoIPClient.py - DoIP客户端实现

from DoIPClientMessage import *
import time
import sys
import os
import platform
import threading
import ctypes
from ctypes import *

class DoIPClient:
    def __init__(self):
        self.doip_dll = None
        self.instance_id = None
        self.source_address = 0
        self.target_address = 0
        self.periodic_ids = {}
        self.running = True
        self.auto_read_thread = None
        self.auto_read_enabled = False
        
        # 用于缓存未完成的多包消息
        # 结构: {(timestamp, payload_type): {'total': count, 'fragments': {1: data, 2: data...}, 'received_time': time.time()}}
        self.reassembly_buffer = {}
        self.reassembly_lock = threading.Lock() # 保护缓存区
        
        self.load_dll()
        
    def load_dll(self):
        """加载DoIP DLL库并初始化函数原型"""
        try:
            current_arch = platform.architecture()[0]
            if current_arch == "64bit":
                lib_path = os.path.abspath("./lib/Winx64")
            else:
                lib_path = os.path.abspath("./lib/Winx86")
                
            os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
            print(f"加载库路径: {lib_path}")
            
            if platform.system() == "Windows":
                self.doip_dll = ctypes.WinDLL(os.path.join(lib_path, "doip_api.dll"))
            else:
                self.doip_dll = ctypes.CDLL(os.path.join(lib_path, "libdoip_api.so"))
            
            # --- 更新所有函数原型 ---
            self.doip_dll.DoIPOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
            self.doip_dll.DoIPOpenLog.restype = c_int
            self.doip_dll.DoIPCloseLog.argtypes = []
            self.doip_dll.DoIPCloseLog.restype = c_int
            
            self.doip_dll.DoIPClientGetSize.argtypes = []
            self.doip_dll.DoIPClientGetSize.restype = c_int

            self.doip_dll.DoIPClientConnect.argtypes = [c_char_p, POINTER(c_int)]
            self.doip_dll.DoIPClientConnect.restype = c_int
            self.doip_dll.DoIPClientConnectWithId.argtypes = [c_int, c_char_p]
            self.doip_dll.DoIPClientConnectWithId.restype = c_int

            self.doip_dll.DoIPClientSetReconnect.argtypes = [c_int, c_int]
            self.doip_dll.DoIPClientSetReconnect.restype = c_int
            self.doip_dll.DoIPClientSetReadUDS.argtypes = [c_int, c_int]
            self.doip_dll.DoIPClientSetReadUDS.restype = c_int
            self.doip_dll.DoIPClientDisconnect.argtypes = [c_int]
            self.doip_dll.DoIPClientDisconnect.restype = c_int
            self.doip_dll.DoIPClientSend.argtypes = [c_int, POINTER(c_ubyte), c_uint]
            self.doip_dll.DoIPClientSend.restype = c_int
            self.doip_dll.DoIPClientPeriodSend.argtypes = [c_int, POINTER(c_ubyte), c_uint, c_uint, POINTER(c_int)]
            self.doip_dll.DoIPClientPeriodSend.restype = c_int
            self.doip_dll.DoIPClientPeriodStop.argtypes = [c_int, c_int]
            self.doip_dll.DoIPClientPeriodStop.restype = c_int
            self.doip_dll.DoIPClientRead.argtypes = [c_int, POINTER(DoIPOutputMessage), c_int, POINTER(c_int)]
            self.doip_dll.DoIPClientRead.restype = c_int
            self.doip_dll.DoIPClientClearMessages.argtypes = [c_int]
            self.doip_dll.DoIPClientClearMessages.restype = c_int
            
            self.doip_dll.DoIPOpenLog(b"doip_client.log", 0, -1, -1)
            print("DoIP API 库加载成功，日志已打开")
            return True
            
        except Exception as e:
            print(f"加载 DoIP API 库失败: {e}")
            import traceback
            traceback.print_exc()
            return False

    def connect(self, server_ip, port, source_address, target_address, local_ip=None):
        """连接到DoIP服务器"""
        if self.instance_id is not None:
            print("错误: 已连接到 DoIP 服务器，请先断开连接")
            return False
        
        self.source_address = source_address
        self.target_address = target_address
        
        print(f"正在准备连接到 DoIP 服务器: {server_ip}:{port}")
        cmd_parts = [
            f"--serverIp {server_ip}",
            f"--serverTcpPort {port}",
            f"--sourceAddress 0x{source_address:04X}",
            f"--targetAddress 0x{target_address:04X}",
            "--version 0x02",
            "--activationType 0x00",
            "--routingActivation true",
            "--aliveCheckResponse true",
            "--useOEMSpecific false",
            "--oemSpecific 0x00,0x00,0x00,0x00",
            "--futureStandardization 0x00,0x00,0x00,0x00",
            "--routingActivationWaitTime 2000",
            "--diagnoseResponseWaitTime 2000",
            "--timeout 2000"
        ]
        
        if local_ip:
            cmd_parts.append(f"--bindLocalIp {local_ip}")
            print(f"绑定本地 IP: {local_ip}")
        
        commands = " ".join(cmd_parts)
        
        instance_id = c_int(0)
        print("正在连接到 DoIP 服务器...")
        status = self.doip_dll.DoIPClientConnect(commands.encode('utf-8'), byref(instance_id))
        
        if status != DOIP_RESULT_OK:
            print(f"连接失败: {get_status_description(status)} (错误代码: {status})")
            return False
        
        self.instance_id = instance_id.value
        print(f"连接成功，实例 ID: {self.instance_id}")
        return True

    def disconnect(self):
        """断开与DoIP服务器的连接"""
        if self.instance_id is None:
            print("错误: 未连接到 DoIP 服务器")
            return False
        
        self.stop_auto_read()
        self.stop_all_periodic_tasks()
        
        print("正在从 DoIP 服务器断开连接...")
        status = self.doip_dll.DoIPClientDisconnect(self.instance_id)
        
        if status != DOIP_RESULT_OK:
            print(f"断开连接失败: {get_status_description(status)}")
            return False
        
        self.instance_id = None
        print("成功断开连接")
        return True
    
    def _process_and_reassemble(self, raw_messages, count):
        """处理原始消息并重组分包"""
        completed_messages = []
        with self.reassembly_lock:
            # 1. 清理超时的不完整消息
            current_time = time.time()
            timeout = 10.0 # 10秒超时
            stale_keys = [
                key for key, data in self.reassembly_buffer.items()
                if current_time - data['received_time'] > timeout
            ]
            for key in stale_keys:
                print(f"警告: 消息 {key} 重组超时，已丢弃。")
                del self.reassembly_buffer[key]

            # 2. 处理新收到的消息
            for i in range(count):
                msg = raw_messages[i]
                
                if msg.package_count <= 1: # 0或1都表示单包
                    # 单包消息，直接添加到完成列表
                    completed_messages.append(msg)
                else:
                    # 分包消息，存入缓冲区
                    key = (msg.timestamp, msg.payload_type)
                    
                    if key not in self.reassembly_buffer:
                        self.reassembly_buffer[key] = {
                            'total': msg.package_count,
                            'fragments': {},
                            'received_time': current_time
                        }
                    
                    # 存储分包数据
                    buffer_entry = self.reassembly_buffer[key]
                    if msg.package_number not in buffer_entry['fragments']:
                        fragment_data = bytes(msg.payload[:msg.payload_length])
                        buffer_entry['fragments'][msg.package_number] = fragment_data
                    
                    # 检查是否已收齐所有分包
                    if len(buffer_entry['fragments']) == buffer_entry['total']:
                        # 重组消息
                        full_payload = bytearray()
                        for num in sorted(buffer_entry['fragments'].keys()):
                            full_payload.extend(buffer_entry['fragments'][num])
                        
                        # 创建一个代表完整消息的结构体
                        reassembled_msg = DoIPOutputMessage()
                        reassembled_msg.timestamp = msg.timestamp
                        reassembled_msg.payload_type = msg.payload_type
                        reassembled_msg.payload_length = len(full_payload)
                        reassembled_msg.package_count = msg.package_count # 保留原始信息
                        reassembled_msg.package_number = 0 # 0表示已重组
                        
                        # 将数据复制到payload
                        ctypes.memmove(reassembled_msg.payload, bytes(full_payload), len(full_payload))
                        
                        completed_messages.append(reassembled_msg)
                        
                        # 从缓冲区删除已完成的消息
                        del self.reassembly_buffer[key]
                        
        return completed_messages

    def read_messages(self):
        """读取并重组接收到的DoIP消息"""
        if not self.is_connected():
            print("错误: 未连接到 DoIP 服务器")
            return False
        
        messages_buffer = (DoIPOutputMessage * 10)()
        actual_count = c_int(0)
        
        status = self.doip_dll.DoIPClientRead(self.instance_id, messages_buffer, 10, byref(actual_count))
        
        if status != DOIP_RESULT_OK and status != DOIP_RESULT_NO_READ_DATA:
            print(f"读取消息失败: {get_status_description(status)}")
            return False
        
        if status == DOIP_RESULT_NO_READ_DATA or actual_count.value == 0:
            print("无可读取的消息")
            return True
        
        completed_messages = self._process_and_reassemble(messages_buffer, actual_count.value)
        
        if completed_messages:
            print_doip_messages(completed_messages, len(completed_messages))
        else:
            print("收到分包数据，等待后续包...")
            
        return True

    def _auto_read_worker(self, interval):
        """自动读取工作线程"""
        while self.auto_read_enabled and self.running:
            try:
                if self.instance_id is not None:
                    messages_buffer = (DoIPOutputMessage * 10)()
                    actual_count = c_int(0)
                    
                    status = self.doip_dll.DoIPClientRead(self.instance_id, messages_buffer, 10, byref(actual_count))
                    
                    if status == DOIP_RESULT_OK and actual_count.value > 0:
                        completed_messages = self._process_and_reassemble(messages_buffer, actual_count.value)
                        
                        if completed_messages:
                            print("\n--- [自动读取] ---")
                            print_doip_messages(completed_messages, len(completed_messages))
                            print(">>> ", end="", flush=True) # 重新打印提示符
                
                for _ in range(int(interval * 10)):
                    if not self.auto_read_enabled or not self.running:
                        break
                    time.sleep(0.1)
            except Exception as e:
                print(f"\n自动读取线程出错: {e}")
                time.sleep(0.5)

    def cleanup(self):
        """清理资源"""
        print("开始清理资源...")
        self.running = False
        
        if self.auto_read_thread is not None:
            self.stop_auto_read()
        
        if self.periodic_ids:
            self.stop_all_periodic_tasks()
        
        if self.instance_id is not None:
            try:
                self.doip_dll.DoIPClientDisconnect(self.instance_id)
                self.instance_id = None
                time.sleep(1.0)
                print("DoIP 连接已断开")
            except Exception as e:
                print(f"断开连接时出错: {e}")
        
        with self.reassembly_lock:
            self.reassembly_buffer.clear()
            
        if self.doip_dll is not None:
            try:
                self.doip_dll.DoIPCloseLog()
                time.sleep(1.2)
            except Exception as e:
                print(f"关闭日志时出错: {e}")
        
        print("资源清理完成")

    def set_reconnect(self, flag):
        if self.instance_id is None: return False
        status = self.doip_dll.DoIPClientSetReconnect(self.instance_id, flag)
        if status != DOIP_RESULT_OK: print(f"设置重连功能失败: {get_status_description(status)}"); return False
        print(f"已{'启用' if flag else '禁用'}重连功能"); return True

    def set_read_uds(self, flag):
        if self.instance_id is None: return False
        status = self.doip_dll.DoIPClientSetReadUDS(self.instance_id, flag)
        if status != DOIP_RESULT_OK: print(f"设置 UDS 读取模式失败: {get_status_description(status)}"); return False
        print(f"已{'启用' if flag else '禁用'} UDS 读取模式"); return True

    def is_connected(self):
        return self.instance_id is not None

    def send_diagnostic(self, payload_str):
        if not self.is_connected(): print("错误: 未连接到服务器"); return False
        try:
            clean_str = payload_str.replace(" ", "")
            if not all(c in '0123456789ABCDEFabcdef' for c in clean_str) or len(clean_str) % 2 != 0:
                print("错误: 诊断消息必须为偶数长度的十六进制格式"); return False
            data = bytes.fromhex(clean_str)
            formatted_str = ' '.join([f"{b:02X}" for b in data])
            print(f"发送诊断请求: {formatted_str}")
            return self._send_diagnostic_message(data)
        except Exception as e: print(f"发送诊断请求失败: {e}"); return False

    def _send_diagnostic_message(self, data_bytes):
        if self.instance_id is None: return False
        try:
            data_array = (c_ubyte * len(data_bytes))(*data_bytes)
            status = self.doip_dll.DoIPClientSend(self.instance_id, data_array, len(data_bytes))
            if status != DOIP_RESULT_OK: print(f"发送诊断消息失败: {get_status_description(status)}"); return False
            print("诊断消息发送成功"); return True
        except Exception as e: print(f"发送诊断消息失败: {e}"); return False

    def add_periodic_diagnostic(self, message_hex, period_ms):
        if not self.is_connected(): return False
        try:
            clean_str = message_hex.replace(" ", "")
            if not all(c in '0123456789ABCDEFabcdef' for c in clean_str) or len(clean_str) % 2 != 0:
                print("错误: 诊断消息必须为偶数长度的十六进制格式"); return False
            data = bytes.fromhex(clean_str)
            formatted_str = ' '.join([f"{b:02X}" for b in data])
            print(f"添加周期诊断请求: {formatted_str}, 周期: {period_ms}ms")
            data_array = (c_ubyte * len(data))(*data)
            period_id = c_int(0)
            status = self.doip_dll.DoIPClientPeriodSend(self.instance_id, data_array, len(data), period_ms, byref(period_id))
            if status != DOIP_RESULT_OK: print(f"添加周期诊断消息失败: {get_status_description(status)}"); return False
            period_id_value = period_id.value
            self.periodic_ids[period_id_value] = message_hex
            print(f"周期诊断消息添加成功，周期 ID: {period_id_value}")
            return period_id_value
        except Exception as e: print(f"添加周期诊断消息失败: {e}"); return False

    def delete_periodic_diagnostic(self, period_id):
        if not self.is_connected() or period_id not in self.periodic_ids: return False
        try:
            print(f"删除周期诊断消息，周期 ID: {period_id}")
            status = self.doip_dll.DoIPClientPeriodStop(self.instance_id, period_id)
            if status != DOIP_RESULT_OK: print(f"删除周期诊断消息失败: {get_status_description(status)}"); return False
            del self.periodic_ids[period_id]
            print(f"周期诊断消息删除成功，周期 ID: {period_id}")
            return True
        except Exception as e: print(f"删除周期诊断消息时出错: {e}"); return False

    def stop_all_periodic_tasks(self):
        if self.instance_id is None or not self.periodic_ids: return
        try:
            print("正在停止所有周期诊断消息...")
            status = self.doip_dll.DoIPClientPeriodStop(self.instance_id, -1)
            if status != DOIP_RESULT_OK: print(f"停止所有周期诊断消息失败: {get_status_description(status)}"); return False
            self.periodic_ids.clear()
            print("所有周期诊断消息已停止"); return True
        except Exception as e: print(f"停止所有周期诊断消息时出错: {e}"); return False

    def clear_messages(self):
        if not self.is_connected(): return False
        status = self.doip_dll.DoIPClientClearMessages(self.instance_id)
        if status != DOIP_RESULT_OK: print(f"清空消息缓存失败: {get_status_description(status)}"); return False
        print("消息缓存已清空"); return True

    def start_auto_read(self, interval=1.0):
        if not self.is_connected(): print("错误: 未连接到服务器"); return
        if self.auto_read_thread is not None: print("自动读取已启动"); return
        self.auto_read_enabled = True
        self.auto_read_thread = threading.Thread(target=self._auto_read_worker, args=(interval,), daemon=True)
        self.auto_read_thread.start()
        print(f"自动读取已启动，间隔: {interval}秒")

    def stop_auto_read(self):
        if self.auto_read_thread is None: return
        print("正在停止自动读取线程...")
        self.auto_read_enabled = False
        try:
            self.auto_read_thread.join(timeout=0.5)
            if self.auto_read_thread.is_alive(): print("警告: 自动读取线程未能在超时时间内终止")
            else: print("自动读取线程已终止")
        except Exception as e: print(f"停止自动读取线程时出错: {e}")
        self.auto_read_thread = None
        print("自动读取已停止")
