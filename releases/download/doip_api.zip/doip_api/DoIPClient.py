#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# DoIPClient.py - DoIP客户端实现 (v3.2.0)
# 适配新API：移除 SetReconnect/SetReadUDS，新增 IsConnected，
# reconnectFlag/readUDS 通过连接参数字符串传入

from DoIPClientMessage import *
import time
import sys
import os
import platform
import threading
import ctypes
from ctypes import *


def build_doip_connect_command(
    server_ip,
    server_port,
    source_address,
    target_address,
    local_ip=None,
    reconnect_flag=True,
    read_uds=True,
    auto_security_27=False,
    algo_name=None,
    algo_type=None,
    dll_path=None,
    function_name=None,
    variant=None,
    seed_byte_order=None,
    key_byte_order=None,
    extra_suffix=None,
):
    """组装与 C 端 DoIPClientConnect 一致的命令行字符串。"""
    cmd_parts = [
        f"--serverIp {server_ip}",
        f"--serverTcpPort {server_port}",
        f"--sourceAddress 0x{source_address:04X}",
        f"--targetAddress 0x{target_address:04X}",
        "--version 0x02",
        "--activationType 0x00",
        "--routingActivation true",
        "--aliveCheckResponse true",
        "--useOEMSpecific false",
        "--oemSpecific 0x00,0x00,0x00,0x00",
        "--futureStandardization 0x00,0x00,0x00,0x00",
        "--routingActivationWaitTime 2000",
        "--diagnoseResponseWaitTime 2000",
        "--timeout 2000",
        f"--reconnectFlag {'true' if reconnect_flag else 'false'}",
        f"--readUDS {'true' if read_uds else 'false'}",
    ]
    if local_ip:
        cmd_parts.append(f"--bindLocalIp {local_ip}")
    if auto_security_27:
        cmd_parts.append("--autoSecurity27 true")
    if algo_name:
        cmd_parts.append(f"--algoName {algo_name}")
    if algo_type:
        cmd_parts.append(f"--algoType {algo_type}")
    if dll_path:
        cmd_parts.append(f"--dllPath {dll_path}")
    if function_name:
        cmd_parts.append(f"--functionName {function_name}")
    if variant:
        cmd_parts.append(f"--variant {variant}")
    if seed_byte_order:
        cmd_parts.append(f"--seedByteOrder {seed_byte_order}")
    if key_byte_order:
        cmd_parts.append(f"--keyByteOrder {key_byte_order}")
    if extra_suffix:
        cmd_parts.append(extra_suffix.strip())
    return " ".join(cmd_parts)


class DoIPClient:
    def __init__(self):
        self.doip_dll = None
        self.instance_id = None
        self.source_address = 0
        self.target_address = 0
        self.periodic_ids = {}
        self.running = True
        self.auto_read_thread = None
        self.auto_read_enabled = False
        
        # 用于缓存未完成的多包消息
        self.reassembly_buffer = {}
        self.reassembly_lock = threading.Lock()
        
        self.load_dll()
        
    def load_dll(self):
        """加载DoIP DLL库并初始化函数原型"""
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            current_arch = platform.architecture()[0]
            if current_arch == "64bit":
                lib_path = os.path.join(base_dir, "lib", "Winx64")
            else:
                lib_path = os.path.join(base_dir, "lib", "Winx86")
                
            os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
            print(f"加载库路径: {lib_path}")
            
            if platform.system() == "Windows":
                self.doip_dll = ctypes.WinDLL(os.path.join(lib_path, "doip_api.dll"))
            else:
                self.doip_dll = ctypes.CDLL(os.path.join(lib_path, "libdoip_api.so"))
            
            # --- 函数原型定义 ---
            # 日志
            self.doip_dll.DoIPOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
            self.doip_dll.DoIPOpenLog.restype = c_int
            self.doip_dll.DoIPCloseLog.argtypes = []
            self.doip_dll.DoIPCloseLog.restype = c_int
            
            # 实例管理
            self.doip_dll.DoIPClientGetSize.argtypes = []
            self.doip_dll.DoIPClientGetSize.restype = c_int

            # 连接状态查询（新增）
            self.doip_dll.DoIPClientIsConnected.argtypes = [c_int]
            self.doip_dll.DoIPClientIsConnected.restype = c_int

            # 连接（参数改为命令字符串）
            self.doip_dll.DoIPClientConnect.argtypes = [c_char_p, POINTER(c_int)]
            self.doip_dll.DoIPClientConnect.restype = c_int
            self.doip_dll.DoIPClientConnectWithId.argtypes = [c_int, c_char_p]
            self.doip_dll.DoIPClientConnectWithId.restype = c_int

            # 断开
            self.doip_dll.DoIPClientDisconnect.argtypes = [c_int]
            self.doip_dll.DoIPClientDisconnect.restype = c_int

            # 发送
            self.doip_dll.DoIPClientSend.argtypes = [c_int, POINTER(c_ubyte), c_uint]
            self.doip_dll.DoIPClientSend.restype = c_int

            # 周期发送
            self.doip_dll.DoIPClientPeriodSend.argtypes = [c_int, POINTER(c_ubyte), c_uint, c_uint, POINTER(c_int)]
            self.doip_dll.DoIPClientPeriodSend.restype = c_int
            self.doip_dll.DoIPClientPeriodSendEx.argtypes = [c_int, POINTER(c_ubyte), c_uint, c_char_p, POINTER(c_int)]
            self.doip_dll.DoIPClientPeriodSendEx.restype = c_int
            self.doip_dll.DoIPClientPeriodStop.argtypes = [c_int, c_int]
            self.doip_dll.DoIPClientPeriodStop.restype = c_int

            # 读取
            self.doip_dll.DoIPClientRead.argtypes = [c_int, POINTER(DoIPOutputMessage), c_int, POINTER(c_int)]
            self.doip_dll.DoIPClientRead.restype = c_int
            self.doip_dll.DoIPClientClearMessages.argtypes = [c_int]
            self.doip_dll.DoIPClientClearMessages.restype = c_int

            self.doip_dll.DoIPClientSetSecurityAlgorithm.argtypes = [c_int, c_char_p]
            self.doip_dll.DoIPClientSetSecurityAlgorithm.restype = c_int
            self.doip_dll.DoIPClientSecurityAccess.argtypes = [c_int, c_uint, c_int]
            self.doip_dll.DoIPClientSecurityAccess.restype = c_int

            # 注意：DoIPClientSetReconnect 和 DoIPClientSetReadUDS 已移除
            # 相关配置通过连接参数 --reconnectFlag / --readUDS 传入
            
            os.makedirs("logs", exist_ok=True)
            log_path = os.path.join("logs", "doip_client_test.log").encode("utf-8")
            self.doip_dll.DoIPOpenLog(log_path, 0, -1, -1)
            print("DoIP API 库加载成功，日志已打开")
            return True
            
        except Exception as e:
            print(f"加载 DoIP API 库失败: {e}")
            import traceback
            traceback.print_exc()
            return False

    def connect(self, server_ip, port, source_address, target_address,
                local_ip=None, reconnect_flag=True, read_uds=True,
                auto_security_27=False,
                algo_name=None, algo_type=None, dll_path=None,
                function_name=None, variant=None,
                seed_byte_order=None, key_byte_order=None,
                connect_extra=None):
        """连接到DoIP服务器
        
        Args:
            server_ip: 服务器IP地址
            port: 服务器TCP端口
            source_address: 源逻辑地址
            target_address: 目标逻辑地址
            local_ip: 本地绑定IP（可选）
            reconnect_flag: 是否启用自动重连（默认True）
            read_uds: 是否只输出UDS消息（默认True）
            auto_security_27: 为 True 时，Send 两字节 0x27+奇数子功能将自动完成解锁（需配置算法）
            algo_name: 如 DH_27；仅 DH_27 且无 dll_path 时使用内置算法
            algo_type: canoe | custom_u32 | dh27
            dll_path: 外部 DLL 路径（内置 DH_27 可不填）
            connect_extra: 追加到连接串末尾的原始片段（高级用法）
        """
        if self.instance_id is not None:
            print("警告: 已存在连接，将先断开旧连接再重新连接")
            self.disconnect()
        
        self.source_address = source_address
        self.target_address = target_address
        
        print(f"正在准备连接到 DoIP 服务器: {server_ip}:{port}")
        if local_ip:
            print(f"绑定本地 IP: {local_ip}")
        print(f"自动重连: {'启用' if reconnect_flag else '禁用'}")
        print(f"UDS 读取模式: {'启用' if read_uds else '禁用'}")
        if auto_security_27:
            print("自动 27 安全访问(Send 拦截): 启用")
        commands = build_doip_connect_command(
            server_ip, port, source_address, target_address,
            local_ip=local_ip, reconnect_flag=reconnect_flag, read_uds=read_uds,
            auto_security_27=auto_security_27,
            algo_name=algo_name, algo_type=algo_type, dll_path=dll_path,
            function_name=function_name, variant=variant,
            seed_byte_order=seed_byte_order, key_byte_order=key_byte_order,
            extra_suffix=connect_extra,
        )
        
        instance_id = c_int(0)
        print("正在连接到 DoIP 服务器...")
        status = self.doip_dll.DoIPClientConnect(commands.encode('utf-8'), byref(instance_id))
        
        if status != DOIP_RESULT_OK:
            print(f"连接失败: {get_status_description(status)} (错误代码: {status})")
            return False
        
        self.instance_id = instance_id.value
        print(f"连接成功，实例 ID: {self.instance_id}")
        return True

    def connect_with_id(self, instance_id, server_ip, port, source_address, target_address,
                        local_ip=None, reconnect_flag=True, read_uds=True,
                        auto_security_27=False,
                        algo_name=None, algo_type=None, dll_path=None,
                        function_name=None, variant=None,
                        seed_byte_order=None, key_byte_order=None,
                        connect_extra=None):
        """使用指定ID连接到DoIP服务器
        
        如果指定ID已被使用，会先自动断开旧连接再重新连接。
        
        Args:
            instance_id: 用户指定的实例ID
            server_ip: 服务器IP地址
            port: 服务器TCP端口
            source_address: 源逻辑地址
            target_address: 目标逻辑地址
            local_ip: 本地绑定IP（可选）
            reconnect_flag: 是否启用自动重连（默认True）
            read_uds: 是否只输出UDS消息（默认True）
        """
        self.source_address = source_address
        self.target_address = target_address
        
        print(f"正在使用指定ID {instance_id} 连接到 DoIP 服务器: {server_ip}:{port}")
        commands = build_doip_connect_command(
            server_ip, port, source_address, target_address,
            local_ip=local_ip, reconnect_flag=reconnect_flag, read_uds=read_uds,
            auto_security_27=auto_security_27,
            algo_name=algo_name, algo_type=algo_type, dll_path=dll_path,
            function_name=function_name, variant=variant,
            seed_byte_order=seed_byte_order, key_byte_order=key_byte_order,
            extra_suffix=connect_extra,
        )
        
        status = self.doip_dll.DoIPClientConnectWithId(instance_id, commands.encode('utf-8'))
        
        if status != DOIP_RESULT_OK:
            print(f"连接失败: {get_status_description(status)} (错误代码: {status})")
            return False
        
        self.instance_id = instance_id
        print(f"连接成功，实例 ID: {self.instance_id}")
        return True

    def disconnect(self):
        """断开与DoIP服务器的连接"""
        if self.instance_id is None:
            print("错误: 未连接到 DoIP 服务器")
            return False
        
        self.stop_auto_read()
        self.stop_all_periodic_tasks()
        
        print("正在从 DoIP 服务器断开连接...")
        status = self.doip_dll.DoIPClientDisconnect(self.instance_id)
        
        if status != DOIP_RESULT_OK:
            print(f"断开连接失败: {get_status_description(status)}")
            return False
        
        self.instance_id = None
        print("成功断开连接")
        return True

    def is_connected(self):
        """检查当前是否有有效的实例ID（本地检查）"""
        return self.instance_id is not None

    def check_connection(self):
        """查询服务器端实际连接状态（调用DLL接口）
        
        综合判断DoIP层和TCP层的实际连接状态。
        当网线断开、服务器关闭等情况发生后，此方法会返回False。
        
        Returns:
            True: 连接有效, False: 未连接或连接已断开
        """
        if self.instance_id is None:
            return False
        result = self.doip_dll.DoIPClientIsConnected(self.instance_id)
        return result == 1

    def _process_and_reassemble(self, raw_messages, count):
        """处理原始消息并重组分包"""
        completed_messages = []
        with self.reassembly_lock:
            # 1. 清理超时的不完整消息
            current_time = time.time()
            timeout = 10.0
            stale_keys = [
                key for key, data in self.reassembly_buffer.items()
                if current_time - data['received_time'] > timeout
            ]
            for key in stale_keys:
                print(f"警告: 消息 {key} 重组超时，已丢弃。")
                del self.reassembly_buffer[key]

            # 2. 处理新收到的消息
            for i in range(count):
                msg = raw_messages[i]
                
                if msg.package_count <= 1:
                    completed_messages.append(msg)
                else:
                    key = (msg.timestamp, msg.payload_type)
                    
                    if key not in self.reassembly_buffer:
                        self.reassembly_buffer[key] = {
                            'total': msg.package_count,
                            'fragments': {},
                            'received_time': current_time
                        }
                    
                    buffer_entry = self.reassembly_buffer[key]
                    if msg.package_number not in buffer_entry['fragments']:
                        fragment_data = bytes(msg.payload[:msg.payload_length])
                        buffer_entry['fragments'][msg.package_number] = fragment_data
                    
                    if len(buffer_entry['fragments']) == buffer_entry['total']:
                        full_payload = bytearray()
                        for num in sorted(buffer_entry['fragments'].keys()):
                            full_payload.extend(buffer_entry['fragments'][num])
                        
                        reassembled_msg = DoIPOutputMessage()
                        reassembled_msg.timestamp = msg.timestamp
                        reassembled_msg.payload_type = msg.payload_type
                        reassembled_msg.payload_length = len(full_payload)
                        reassembled_msg.package_count = msg.package_count
                        reassembled_msg.package_number = 0
                        
                        ctypes.memmove(reassembled_msg.payload, bytes(full_payload), len(full_payload))
                        
                        completed_messages.append(reassembled_msg)
                        del self.reassembly_buffer[key]
                        
        return completed_messages

    def read_messages(self):
        """读取并重组接收到的DoIP消息"""
        if not self.is_connected():
            print("错误: 未连接到 DoIP 服务器")
            return False
        
        messages_buffer = (DoIPOutputMessage * 10)()
        actual_count = c_int(0)
        
        status = self.doip_dll.DoIPClientRead(self.instance_id, messages_buffer, 10, byref(actual_count))
        
        if status != DOIP_RESULT_OK and status != DOIP_RESULT_NO_READ_DATA:
            print(f"读取消息失败: {get_status_description(status)}")
            return False
        
        if status == DOIP_RESULT_NO_READ_DATA or actual_count.value == 0:
            print("无可读取的消息")
            return True
        
        completed_messages = self._process_and_reassemble(messages_buffer, actual_count.value)
        
        if completed_messages:
            print_doip_messages(completed_messages, len(completed_messages))
        else:
            print("收到分包数据，等待后续包...")
            
        return True

    def _auto_read_worker(self, interval):
        """自动读取工作线程"""
        while self.auto_read_enabled and self.running:
            try:
                if self.instance_id is not None:
                    messages_buffer = (DoIPOutputMessage * 10)()
                    actual_count = c_int(0)
                    
                    status = self.doip_dll.DoIPClientRead(self.instance_id, messages_buffer, 10, byref(actual_count))
                    
                    if status == DOIP_RESULT_OK and actual_count.value > 0:
                        completed_messages = self._process_and_reassemble(messages_buffer, actual_count.value)
                        
                        if completed_messages:
                            print("\n--- [自动读取] ---")
                            print_doip_messages(completed_messages, len(completed_messages))
                            print(">>> ", end="", flush=True)
                
                for _ in range(int(interval * 10)):
                    if not self.auto_read_enabled or not self.running:
                        break
                    time.sleep(0.1)
            except Exception as e:
                print(f"\n自动读取线程出错: {e}")
                time.sleep(0.5)

    def cleanup(self):
        """清理资源"""
        print("开始清理资源...")
        self.running = False
        
        if self.auto_read_thread is not None:
            self.stop_auto_read()
        
        if self.periodic_ids:
            self.stop_all_periodic_tasks()
        
        if self.instance_id is not None:
            try:
                self.doip_dll.DoIPClientDisconnect(self.instance_id)
                self.instance_id = None
                time.sleep(1.0)
                print("DoIP 连接已断开")
            except Exception as e:
                print(f"断开连接时出错: {e}")
        
        with self.reassembly_lock:
            self.reassembly_buffer.clear()
            
        if self.doip_dll is not None:
            try:
                self.doip_dll.DoIPCloseLog()
                time.sleep(1.2)
            except Exception as e:
                print(f"关闭日志时出错: {e}")
        
        print("资源清理完成")

    def send_diagnostic(self, payload_str):
        """发送诊断消息"""
        if not self.is_connected():
            print("错误: 未连接到服务器")
            return False
        try:
            clean_str = payload_str.replace(" ", "")
            if not all(c in '0123456789ABCDEFabcdef' for c in clean_str) or len(clean_str) % 2 != 0:
                print("错误: 诊断消息必须为偶数长度的十六进制格式")
                return False
            data = bytes.fromhex(clean_str)
            formatted_str = ' '.join([f"{b:02X}" for b in data])
            print(f"发送诊断请求: {formatted_str}")
            return self._send_diagnostic_message(data)
        except Exception as e:
            print(f"发送诊断请求失败: {e}")
            return False

    def _send_diagnostic_message(self, data_bytes):
        """内部发送诊断消息"""
        if self.instance_id is None:
            return False
        try:
            data_array = (c_ubyte * len(data_bytes))(*data_bytes)
            status = self.doip_dll.DoIPClientSend(self.instance_id, data_array, len(data_bytes))
            if status != DOIP_RESULT_OK:
                print(f"发送诊断消息失败: {get_status_description(status)}")
                return False
            print("诊断消息发送成功")
            return True
        except Exception as e:
            print(f"发送诊断消息失败: {e}")
            return False

    def add_periodic_diagnostic(self, message_hex, period_ms, target_address=None):
        """添加周期性诊断消息，可选显式指定目标地址"""
        if not self.is_connected():
            return False
        try:
            clean_str = message_hex.replace(" ", "")
            if not all(c in '0123456789ABCDEFabcdef' for c in clean_str) or len(clean_str) % 2 != 0:
                print("错误: 诊断消息必须为偶数长度的十六进制格式")
                return False
            data = bytes.fromhex(clean_str)
            formatted_str = ' '.join([f"{b:02X}" for b in data])
            data_array = (c_ubyte * len(data))(*data)
            period_id = c_int(0)

            if target_address is None:
                print(f"添加周期诊断请求: {formatted_str}, 周期: {period_ms}ms")
                status = self.doip_dll.DoIPClientPeriodSend(self.instance_id, data_array, len(data), period_ms, byref(period_id))
            else:
                print(f"添加周期诊断请求: {formatted_str}, 周期: {period_ms}ms, 目标地址: 0x{target_address:04X}")
                commands = f"--periodMs {period_ms} --targetAddress 0x{target_address:04X}".encode('utf-8')
                status = self.doip_dll.DoIPClientPeriodSendEx(self.instance_id, data_array, len(data), commands, byref(period_id))

            if status != DOIP_RESULT_OK:
                print(f"添加周期诊断消息失败: {get_status_description(status)}")
                return False
            period_id_value = period_id.value
            stored_desc = message_hex if target_address is None else f"{message_hex} @ 0x{target_address:04X}"
            self.periodic_ids[period_id_value] = stored_desc
            print(f"周期诊断消息添加成功，周期 ID: {period_id_value}")
            return period_id_value
        except Exception as e:
            print(f"添加周期诊断消息失败: {e}")
            return False

    def delete_periodic_diagnostic(self, period_id):
        """删除周期性诊断消息"""
        if not self.is_connected() or period_id not in self.periodic_ids:
            return False
        try:
            print(f"删除周期诊断消息，周期 ID: {period_id}")
            status = self.doip_dll.DoIPClientPeriodStop(self.instance_id, period_id)
            if status != DOIP_RESULT_OK:
                print(f"删除周期诊断消息失败: {get_status_description(status)}")
                return False
            del self.periodic_ids[period_id]
            print(f"周期诊断消息删除成功，周期 ID: {period_id}")
            return True
        except Exception as e:
            print(f"删除周期诊断消息时出错: {e}")
            return False

    def stop_all_periodic_tasks(self):
        """停止所有周期性诊断消息"""
        if self.instance_id is None or not self.periodic_ids:
            return
        try:
            print("正在停止所有周期诊断消息...")
            status = self.doip_dll.DoIPClientPeriodStop(self.instance_id, -1)
            if status != DOIP_RESULT_OK:
                print(f"停止所有周期诊断消息失败: {get_status_description(status)}")
                return False
            self.periodic_ids.clear()
            print("所有周期诊断消息已停止")
            return True
        except Exception as e:
            print(f"停止所有周期诊断消息时出错: {e}")
            return False

    def clear_messages(self):
        """清空消息缓存"""
        if not self.is_connected():
            return False
        status = self.doip_dll.DoIPClientClearMessages(self.instance_id)
        if status != DOIP_RESULT_OK:
            print(f"清空消息缓存失败: {get_status_description(status)}")
            return False
        print("消息缓存已清空")
        return True

    def set_security_algorithm(self, commands: str) -> bool:
        """配置 27 算法，commands 与 C API DoIPClientSetSecurityAlgorithm 相同（--algoName ... 空格分隔）。"""
        if self.instance_id is None:
            print("错误: 未连接")
            return False
        st = self.doip_dll.DoIPClientSetSecurityAlgorithm(
            self.instance_id, commands.encode("utf-8"))
        if st != DOIP_RESULT_OK:
            print(f"配置安全算法失败: {get_status_description(st)} ({st})")
            return False
        print("安全算法配置已更新")
        return True

    def security_access(self, request_level: int, timeout_ms: int = 0) -> bool:
        """显式执行完整 27 流程（request_level 为奇数子功能，如 0x09）。timeout_ms<=0 用 DLL 默认等待。"""
        if self.instance_id is None:
            print("错误: 未连接")
            return False
        st = self.doip_dll.DoIPClientSecurityAccess(
            self.instance_id, c_uint(request_level & 0xFF), c_int(timeout_ms))
        if st != DOIP_RESULT_OK:
            print(f"SecurityAccess 失败: {get_status_description(st)} ({st})")
            return False
        print("SecurityAccess 完成")
        return True

    def start_auto_read(self, interval=1.0):
        """启动自动读取线程"""
        if not self.is_connected():
            print("错误: 未连接到服务器")
            return
        if self.auto_read_thread is not None:
            print("自动读取已启动")
            return
        self.auto_read_enabled = True
        self.auto_read_thread = threading.Thread(target=self._auto_read_worker, args=(interval,), daemon=True)
        self.auto_read_thread.start()
        print(f"自动读取已启动，间隔: {interval}秒")

    def stop_auto_read(self):
        """停止自动读取线程"""
        if self.auto_read_thread is None:
            return
        print("正在停止自动读取线程...")
        self.auto_read_enabled = False
        try:
            self.auto_read_thread.join(timeout=0.5)
            if self.auto_read_thread.is_alive():
                print("警告: 自动读取线程未能在超时时间内终止")
            else:
                print("自动读取线程已终止")
        except Exception as e:
            print(f"停止自动读取线程时出错: {e}")
        self.auto_read_thread = None
        print("自动读取已停止")
