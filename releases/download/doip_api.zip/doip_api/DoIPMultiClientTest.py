#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
DoIPMultiClientTest.py - DoIP 多客户端测试脚本

用途：
- 同时管理多个 DoIP 客户端
- 验证相同 serverIp、不同 localIP 的多连接场景
- 验证周期 3E、ECU reset、断连/重连场景不会把进程打崩
"""

from DoIPClient import DoIPClient
import signal
import sys
import time

clients = {}
next_idx = 1


def add_client():
    global next_idx
    client = DoIPClient()
    idx = next_idx
    clients[idx] = client
    next_idx += 1
    return idx, client


def get_client(idx):
    c = clients.get(idx)
    if c is None:
        print(f"错误: 客户端 {idx} 不存在")
    return c


def get_connected_clients():
    return {k: v for k, v in clients.items() if v.is_connected()}


def disconnect_all():
    for c in clients.values():
        try:
            c.stop_auto_read()
        except Exception:
            pass
        try:
            if c.is_connected():
                c.disconnect()
        except Exception as e:
            print(f"断开客户端时出错: {e}")


def signal_handler(sig, frame):
    print("\n接收到中断信号，正在清理...")
    disconnect_all()
    sys.exit(0)


def print_help():
    print("\n可用命令:")
    print("  help")
    print("  add")
    print("  list")
    print("  connect <idx> <serverIp> <sourceHex> <targetHex> [localIp] [reconnect on|off]")
    print("  disconnect <idx>")
    print("  disconnectall")
    print("  send <idx> <hex message>")
    print("  read <idx>")
    print("  autoread <idx> on|off")
    print("  addperiod <idx> <periodMs> <hex message> [targetHex]")
    print("  delperiod <idx> <periodId>")
    print("  stopperiods <idx>")
    print("  crashflow <idx>        # 仅做人工复现流程提示")
    print("  status")
    print("  exit")
    print("\n示例:")
    print("  add")
    print("  add")
    print("  connect 1 192.168.1.10 0x0E80 0x0E01 192.168.1.88 on")
    print("  connect 2 192.168.1.10 0x0E81 0x0E01 192.168.2.88 on")
    print("  addperiod 1 2000 3E 80")
    print("  addperiod 2 2000 3E 80 0x0E3E")
    print("  send 1 11 01")


def cmd_add():
    idx, _ = add_client()
    print(f"已创建客户端 {idx}")


def cmd_list():
    if not clients:
        print("当前没有客户端")
        return
    print("\n当前客户端:")
    for idx, c in sorted(clients.items()):
        state = "connected" if c.is_connected() else "idle"
        print(f"  {idx}: state={state}, instance={c.instance_id}, source=0x{c.source_address:04X}, target=0x{c.target_address:04X}")


def cmd_connect(parts):
    if len(parts) < 5:
        print("用法: connect <idx> <serverIp> <sourceHex> <targetHex> [localIp] [reconnect on|off]")
        return
    idx = int(parts[1])
    client = get_client(idx)
    if not client:
        return
    server_ip = parts[2]
    source_address = int(parts[3], 0)
    target_address = int(parts[4], 0)
    local_ip = parts[5] if len(parts) >= 6 and parts[5].lower() not in ("on", "off") else None
    reconnect_flag = True
    if parts[-1].lower() in ("on", "off"):
        reconnect_flag = parts[-1].lower() == "on"

    ok = client.connect(
        server_ip=server_ip,
        port=13400,
        source_address=source_address,
        target_address=target_address,
        local_ip=local_ip,
        reconnect_flag=reconnect_flag,
        read_uds=True,
    )
    print("连接成功" if ok else "连接失败")


def cmd_disconnect(parts):
    if len(parts) != 2:
        print("用法: disconnect <idx>")
        return
    client = get_client(int(parts[1]))
    if client and client.is_connected():
        client.disconnect()


def cmd_send(parts, line):
    if len(parts) < 3:
        print("用法: send <idx> <hex message>")
        return
    client = get_client(int(parts[1]))
    if not client:
        return
    msg = line.split(None, 2)[2]
    client.send_diagnostic(msg)


def cmd_read(parts):
    if len(parts) != 2:
        print("用法: read <idx>")
        return
    client = get_client(int(parts[1]))
    if client:
        client.read_messages()


def cmd_autoread(parts):
    if len(parts) != 3:
        print("用法: autoread <idx> on|off")
        return
    client = get_client(int(parts[1]))
    if not client:
        return
    if parts[2].lower() == "on":
        client.start_auto_read()
    else:
        client.stop_auto_read()


def cmd_addperiod(parts, line):
    if len(parts) < 4:
        print("用法: addperiod <idx> <periodMs> <hex message> [targetHex]")
        return
    client = get_client(int(parts[1]))
    if not client:
        return
    period_ms = int(parts[2], 0)
    payload = parts[3:]
    target = None
    if len(payload) >= 2:
        last = payload[-1]
        if last.lower().startswith("0x"):
            try:
                target = int(last, 0)
                payload = payload[:-1]
            except ValueError:
                pass
    msg = " ".join(payload)
    result = client.add_periodic_diagnostic(msg, period_ms, target_address=target)
    print(f"period result: {result}")


def cmd_delperiod(parts):
    if len(parts) != 3:
        print("用法: delperiod <idx> <periodId>")
        return
    client = get_client(int(parts[1]))
    if client:
        client.delete_periodic_diagnostic(int(parts[2]))


def cmd_stopperiods(parts):
    if len(parts) != 2:
        print("用法: stopperiods <idx>")
        return
    client = get_client(int(parts[1]))
    if client:
        client.stop_all_periodic_tasks()


def cmd_status():
    connected = get_connected_clients()
    print(f"已连接客户端数量: {len(connected)}")
    for idx, c in sorted(connected.items()):
        print(f"  {idx}: instance={c.instance_id}, target=0x{c.target_address:04X}, realConnected={c.check_connection()}")


def cmd_crashflow(parts):
    if len(parts) != 2:
        print("用法: crashflow <idx>")
        return
    idx = int(parts[1])
    print(f"\n客户端 {idx} 的推荐复现步骤:")
    print("  1. send <idx> 10 03")
    print("  2. addperiod <idx> 2000 3E 80")
    print("  3. send <idx> 27 01")
    print("  4. send <idx> 11 01")
    print("  5. read <idx> / status")
    print("  6. 确认程序不崩溃，且 realConnected 变为 False 或自动恢复")


def main():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    print("DoIP 多客户端测试工具")
    print_help()

    try:
        while True:
            line = input("\n>>> ").strip()
            if not line:
                continue
            parts = line.split()
            cmd = parts[0].lower()

            if cmd == "help":
                print_help()
            elif cmd == "add":
                cmd_add()
            elif cmd == "list":
                cmd_list()
            elif cmd == "connect":
                cmd_connect(parts)
            elif cmd == "disconnect":
                cmd_disconnect(parts)
            elif cmd == "disconnectall":
                disconnect_all()
            elif cmd == "send":
                cmd_send(parts, line)
            elif cmd == "read":
                cmd_read(parts)
            elif cmd == "autoread":
                cmd_autoread(parts)
            elif cmd == "addperiod":
                cmd_addperiod(parts, line)
            elif cmd == "delperiod":
                cmd_delperiod(parts)
            elif cmd == "stopperiods":
                cmd_stopperiods(parts)
            elif cmd == "status":
                cmd_status()
            elif cmd == "crashflow":
                cmd_crashflow(parts)
            elif cmd == "exit":
                break
            else:
                print("未知命令，输入 help 查看帮助")
    finally:
        disconnect_all()


if __name__ == "__main__":
    main()
