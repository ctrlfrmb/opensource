#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# DoIPClientMessage.py - DoIP消息类型定义和常量

import ctypes
from ctypes import *
import datetime

# DoIP消息类型定义常量
DOIP_GENERIC_DOIP_NACK = 0x0000
DOIP_VEHICLE_IDENTIFICATION_REQUEST = 0x0001
DOIP_VEHICLE_IDENTIFICATION_REQUEST_WITH_EID = 0x0002
DOIP_VEHICLE_IDENTIFICATION_REQUEST_WITH_VIN = 0x0003
DOIP_VEHICLE_ANNOUNCEMENT = 0x0004
DOIP_ROUTING_ACTIVATION_REQUEST = 0x0005
DOIP_ROUTING_ACTIVATION_RESPONSE = 0x0006
DOIP_ALIVE_CHECK_REQUEST = 0x0007
DOIP_ALIVE_CHECK_RESPONSE = 0x0008
DOIP_DOIP_ENTITY_STATUS_REQUEST = 0x4001
DOIP_DOIP_ENTITY_STATUS_RESPONSE = 0x4002
DOIP_DIAGNOSTIC_POWER_MODE_INFORMATION_REQUEST = 0x4003
DOIP_DIAGNOSTIC_POWER_MODE_INFORMATION_RESPONSE = 0x4004
DOIP_DIAGNOSTIC_MESSAGE = 0x8001
DOIP_DIAGNOSTIC_ACK = 0x8002
DOIP_DIAGNOSTIC_NACK = 0x8003

# 结果状态码
DOIP_RESULT_OK = 0

# 通用错误扩展
DOIP_RESULT_INVALID_PARAMETER = 1001
DOIP_RESULT_INTERNAL_ERROR = 1002
DOIP_RESULT_MESSAGE_PARSE_ERROR = 1003
DOIP_RESULT_INVALID_DATA = 1004
DOIP_RESULT_PENDING = 1005
DOIP_RESULT_TOO_MANY_INSTANCES = 1011
DOIP_RESULT_INVALID_INSTANCE_ID = 1012
DOIP_RESULT_ROUTING_ACTIVATION_TIMEOUT = 1021
DOIP_RESULT_ROUTING_ACTIVATION_ERROR = 1022
DOIP_RESULT_SEND_FAILED = 1041
DOIP_RESULT_DIAGNOSTIC_RESPONSE_TIMEOUT = 1045
DOIP_RESULT_DIAGNOSTIC_RESPONSE_NACK = 1046
DOIP_RESULT_NO_READ_DATA = 1061

# 网络相关错误
DOIP_RESULT_NOT_CONNECTED = 8001
DOIP_RESULT_CONNECTION_FAILED = 8002
DOIP_RESULT_NETWORK_ERROR = 8003

# ISO 13400-2 标准定义的错误码
DOIP_RESULT_HDR_ERROR = 13401
DOIP_RESULT_TIMEOUT_A = 13402
DOIP_RESULT_UNKNOWN_SA = 13403
DOIP_RESULT_INVALID_SA = 13404
DOIP_RESULT_UNKNOWN_TA = 13405
DOIP_RESULT_MESSAGE_TOO_LARGE = 13406
DOIP_RESULT_OUT_OF_MEMORY = 13407
DOIP_RESULT_TARGET_UNREACHABLE = 13408
DOIP_RESULT_NO_LINK = 13409
DOIP_RESULT_NO_SOCKET = 13410
DOIP_RESULT_ERROR = 13411

# 状态码映射到中文描述
STATUS_DESCRIPTIONS = {
    DOIP_RESULT_OK: "操作成功完成",
    
    # 通用错误扩展
    DOIP_RESULT_INVALID_PARAMETER: "无效参数",
    DOIP_RESULT_INTERNAL_ERROR: "内部错误",
    DOIP_RESULT_MESSAGE_PARSE_ERROR: "消息解析错误",
    DOIP_RESULT_INVALID_DATA: "无效数据",
    DOIP_RESULT_PENDING: "操作挂起",
    DOIP_RESULT_TOO_MANY_INSTANCES: "实例过多",
    DOIP_RESULT_INVALID_INSTANCE_ID: "无效实例ID",
    DOIP_RESULT_ROUTING_ACTIVATION_TIMEOUT: "路由激活超时",
    DOIP_RESULT_ROUTING_ACTIVATION_ERROR: "路由激活错误",
    DOIP_RESULT_SEND_FAILED: "发送失败",
    DOIP_RESULT_DIAGNOSTIC_RESPONSE_TIMEOUT: "诊断响应超时",
    DOIP_RESULT_DIAGNOSTIC_RESPONSE_NACK: "诊断否定响应",
    DOIP_RESULT_NO_READ_DATA: "无读取数据",
    
    # 网络相关错误
    DOIP_RESULT_NOT_CONNECTED: "未连接",
    DOIP_RESULT_CONNECTION_FAILED: "连接失败",
    DOIP_RESULT_NETWORK_ERROR: "网络错误",
    
    # ISO 13400-2 标准定义的错误码
    DOIP_RESULT_HDR_ERROR: "头部错误",
    DOIP_RESULT_TIMEOUT_A: "超时 A",
    DOIP_RESULT_UNKNOWN_SA: "未知源地址",
    DOIP_RESULT_INVALID_SA: "无效源地址",
    DOIP_RESULT_UNKNOWN_TA: "未知目标地址",
    DOIP_RESULT_MESSAGE_TOO_LARGE: "消息过大",
    DOIP_RESULT_OUT_OF_MEMORY: "内存不足",
    DOIP_RESULT_TARGET_UNREACHABLE: "目标不可达",
    DOIP_RESULT_NO_LINK: "无链接",
    DOIP_RESULT_NO_SOCKET: "无套接字",
    DOIP_RESULT_ERROR: "一般错误"
}

# 定义DoIP输出消息结构体 - 基于新的结构体布局
class DoIPOutputMessage(Structure):
    _pack_ = 8  # 设置对齐方式为8字节
    _fields_ = [
        ("timestamp", c_ulonglong),      # 64位时间戳（毫秒）
        ("payload_type", c_ushort),      # 消息类型
        ("payload_length", c_ushort),    # 负载长度
        ("reserved", c_uint),            # 填充至8字节边界
        ("payload", c_ubyte * 4096)      # 负载数据
    ]

def get_status_description(status):
    """获取状态码对应的描述"""
    return STATUS_DESCRIPTIONS.get(status, f"未知状态码: {status}")

def hex_dump(data, length):
    """将字节数组转换为十六进制字符串"""
    return ' '.join(f"{b:02X}" for b in data[:length])

def format_timestamp(timestamp_ms):
    """将毫秒时间戳格式化为人类可读的时间字符串"""
    try:
        # 转换毫秒时间戳为datetime对象
        dt = datetime.datetime.fromtimestamp(timestamp_ms / 1000.0)
        
        # 格式化为字符串 (年-月-日 时:分:秒.毫秒)
        return dt.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]  # 截取到毫秒
    except (ValueError, OverflowError, OSError) as e:
        # 处理无效时间戳
        return f"无效时间戳 ({timestamp_ms}): {str(e)}"

def print_doip_messages(messages, actual_count):
    """打印DoIP消息列表
    
    Args:
        messages: DoIPOutputMessage数组
        actual_count: 实际的消息数量
    """
    print(f"读取了 {actual_count} 条消息")
    
    # 打印接收到的消息
    for i in range(actual_count):
        msg = messages[i]
        print(f"\n消息 {i+1}:")
        formatted_time = format_timestamp(msg.timestamp)
        print(f"  时间戳: {formatted_time} ({msg.timestamp} ms)")
        print(f"  负载类型: 0x{msg.payload_type:04X}")
        print(f"  负载长度: {msg.payload_length}")
        print(f"  负载数据: {hex_dump(msg.payload, msg.payload_length)}")
