// doipmessage.h
#ifndef DOIP_MESSAGE_H
#define DOIP_MESSAGE_H

// 确保结构体在所有平台上字节对齐
#ifdef _MSC_VER
    #pragma pack(push, 4)
#else
    #pragma pack(4)
#endif

// DoIP 通用头部长度
#define DOIP_GENERIC_HEADER_LENGTH 8
#define DOIP_PROTOCOL_VERSION_MAX 0xFFU

// DoIP 消息类型定义
#define DOIP_GENERIC_DOIP_NACK 0x0000
#define DOIP_VEHICLE_IDENTIFICATION_REQUEST 0x0001
#define DOIP_VEHICLE_IDENTIFICATION_REQUEST_WITH_EID 0x0002
#define DOIP_VEHICLE_IDENTIFICATION_REQUEST_WITH_VIN 0x0003
#define DOIP_VEHICLE_ANNOUNCEMENT 0x0004
#define DOIP_ROUTING_ACTIVATION_REQUEST 0x0005
#define DOIP_ROUTING_ACTIVATION_RESPONSE 0x0006
#define DOIP_ALIVE_CHECK_REQUEST 0x0007
#define DOIP_ALIVE_CHECK_RESPONSE 0x0008
#define DOIP_DOIP_ENTITY_STATUS_REQUEST 0x4001
#define DOIP_DOIP_ENTITY_STATUS_RESPONSE 0x4002
#define DOIP_DIAGNOSTIC_POWER_MODE_INFORMATION_REQUEST 0x4003
#define DOIP_DIAGNOSTIC_POWER_MODE_INFORMATION_RESPONSE 0x4004
#define DOIP_DIAGNOSTIC_MESSAGE 0x8001
#define DOIP_DIAGNOSTIC_ACK 0x8002
#define DOIP_DIAGNOSTIC_NACK 0x8003

// DoIP 各类消息的长度定义
#define DOIP_VEHICLE_IDENTIFICATION_REQUEST_WITH_EID_LENGTH 6
#define DOIP_VEHICLE_IDENTIFICATION_REQUEST_WITH_VIN_LENGTH 17
#define DOIP_VEHICLE_ANNOUNCEMENT_MIN_LENGTH 32
#define DOIP_VEHICLE_ANNOUNCEMENT_MAX_LENGTH 33
#define DOIP_ENTITY_STATUS_RESPONSE_MIN_LENGTH 3
#define DOIP_ENTITY_STATUS_RESPONSE_MAX_LENGTH 7
#define DOIP_DIAGNOSTIC_POWER_MODE_INFORMATION_RESPONSE_LENGTH 1
#define DOIP_ROUTE_ACTIVATION_RESERVED_ISO13400_LENGTH 4
#define DOIP_ROUTE_ACTIVATION_RESERVED_OEM_LENGTH 4
#define DOIP_ROUTE_ACTIVATION_RESPONSE_MIN_LENGTH 9
#define DOIP_DIAGNOSTIC_RESPONSE_MIN_LENGTH 5
#define DOIP_DIAGNOSTIC_MESSAGE_USER_DATA_MIN_LENGTH 4

// DoIP 路由激活响应代码
#define DOIP_ROUTING_ACTIVATION_DENIED_UNKNOWN_SA 0x00
#define DOIP_ROUTING_ACTIVATION_DENIED_ALL_SOCKETS_REGISTERED 0x01
#define DOIP_ROUTING_ACTIVATION_DENIED_SA_DIFFERENT 0x02
#define DOIP_ROUTING_ACTIVATION_DENIED_SA_ALREADY_REGISTERED_AND_ACTIVE 0x03
#define DOIP_ROUTING_ACTIVATION_DENIED_MISSING_AUTHENTICATION 0x04
#define DOIP_ROUTING_ACTIVATION_DENIED_REJECTED_CONFIRMATION 0x05
#define DOIP_ROUTING_ACTIVATION_DENIED_UNSUPPORTED_ROUTING_ACTIVATION_TYPE 0x06
#define DOIP_ROUTING_ACTIVATION_SUCCESSFULLY_ACTIVATED 0x10
#define DOIP_ROUTING_ACTIVATION_WILL_ACTIVATED_CONFIRMATION_REQUIRED 0x11

#define DOIP_OUTPUT_PAYLOAD_SIZE 4096

// 统一的 DoIP 结果枚举（基于 ISO 13400-2:2012 标准）
typedef enum {
    // 标准成功状态 (0)
    DOIP_RESULT_OK = 0,                                 // 操作成功完成

    // 通用错误扩展
    DOIP_RESULT_INVALID_PARAMETER = 1001,               // 无效参数
    DOIP_RESULT_INTERNAL_ERROR = 1002,                  // 内部错误
    DOIP_RESULT_MESSAGE_PARSE_ERROR = 1003,             // 消息解析失败
    DOIP_RESULT_INVALID_DATA = 1004,                    // 无效数据
    DOIP_RESULT_PENDING = 1005,                         // 操作挂起
    DOIP_RESULT_OPERATION_NOT_ALLOWED = 1006,           // 操作不允许（例如，有活动连接时重置ID）
    DOIP_RESULT_TOO_MANY_INSTANCES = 1011,
    DOIP_RESULT_INVALID_INSTANCE_ID = 1012,
    DOIP_RESULT_ROUTING_ACTIVATION_TIMEOUT = 1021,      // 路由激活超时
    DOIP_RESULT_ROUTING_ACTIVATION_ERROR = 1022,        // 路由激活通用错误
    DOIP_RESULT_SEND_FAILED = 1041,                     // 发送失败
    DOIP_RESULT_DIAGNOSTIC_RESPONSE_TIMEOUT = 1045,     // 诊断响应超时
    DOIP_RESULT_DIAGNOSTIC_RESPONSE_NACK = 1046,        // 诊断消极响应
    DOIP_RESULT_NO_READ_DATA = 1061,                    // 无可读数据

    // 网络相关错误
    DOIP_RESULT_NOT_CONNECTED = 8001,                   // 未连接
    DOIP_RESULT_CONNECTION_FAILED = 8002,               // 连接失败
    DOIP_RESULT_NETWORK_ERROR = 8003,                   // 网络错误

    // ISO 13400-2 标准定义的错误码 (1-11)
    DOIP_RESULT_HDR_ERROR = 13401,                      // 头部错误
    DOIP_RESULT_TIMEOUT_A = 13402,                      // 超时A
    DOIP_RESULT_UNKNOWN_SA = 13403,                     // 未知源地址
    DOIP_RESULT_INVALID_SA = 13404,                     // 无效源地址
    DOIP_RESULT_UNKNOWN_TA = 13405,                     // 未知目标地址
    DOIP_RESULT_MESSAGE_TOO_LARGE = 13406,              // 消息过大
    DOIP_RESULT_OUT_OF_MEMORY = 13407,                  // 内存不足
    DOIP_RESULT_TARGET_UNREACHABLE = 13408,             // 目标不可达
    DOIP_RESULT_NO_LINK = 13409,                        // 无链接
    DOIP_RESULT_NO_SOCKET = 13410,                      // 无套接字
    DOIP_RESULT_ERROR = 13411,                          // 通用错误

} DOIP_RESULT;

/*
 * DoIP 消息结构体
 * 8字节对齐结构布局
 */
typedef struct DoIPOutputMessage_ {
    /* 64位边界 - 0 */
    // 时间戳字符串
    unsigned long long timestamp;           // 时间戳（毫秒）

    /* 64位边界 - 8 */
    // 负载类型和长度，放在一起填充到8字节
    unsigned short payload_type;            // 消息类型
    unsigned short payload_length;          // 负载长度
    unsigned short package_count;           // 组包数量，默认0表示单包数据， > 1表示组包数据分包数量
    unsigned short package_number;          // 分包序号，范围：1~package_count

    /* 64位边界 - 16 */
    // 负载数据 (4096字节，为8的倍数)
    unsigned char payload[DOIP_OUTPUT_PAYLOAD_SIZE];            // 负载数据

    /* 64位边界 - 4112 */
    unsigned int reserved;                  // 保留位
    unsigned int reserved2;                 // 保留位
    // 总大小: 4120字节 (515个8字节块)
} DoIPOutputMessage;

// 恢复默认的打包对齐
#ifdef _MSC_VER
    #pragma pack(pop)
#else
    #pragma pack()
#endif

#endif // DOIP_MESSAGE_H
