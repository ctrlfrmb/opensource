// doipapi.h
/*----------------------------------------------------------------------------
* DoIP API - 诊断通信协议接口
*
* 提供用于ISO 13400标准定义的DoIP(Diagnostics over Internet Protocol)通信的接口。
* 该API支持基于TCP/IP的车辆诊断通信，允许客户端与支持DoIP协议的ECU(电子控制单元)建立连接，
* 发送和接收诊断数据。
*
* 主要功能:
* - 支持DoIP客户端连接管理(连接、断开、重连等)
* - 路由激活和通道建立
* - 常规诊断消息发送
* - 周期性诊断消息发送
* - 消息接收和缓存管理
* - 完整的错误处理和日志记录
*
* 使用示例:
*   // 配置连接参数为命令行字符串
*   const char* connectCommand =
*      "--serverIp 192.168.1.10 --sourceAddress 0x0E80 --targetAddress 0x0E01 "
*      "--serverTcpPort 13400 --routingActivation true --aliveCheckResponse true";
*
*   // 建立连接
*   int instanceId = 0;
*   int result = DoIPClientConnect(connectCommand, &instanceId);
*   if (result == DOIP_RESULT_OK) {
*     // 发送诊断消息
*     unsigned char diagData[] = {0x10, 0x01}; // 诊断启动会话
*     DoIPClientSend(instanceId, diagData, sizeof(diagData));
*
*     // 读取响应
*     DoIPOutputMessage messages[10];
*     int actualCount = 0;
*     DoIPClientRead(instanceId, messages, 10, &actualCount);
*
*     // 断开连接
*     DoIPClientDisconnect(instanceId);
*   }
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2022 leiwei。保留所有权利。
*
* 本软件根据 MIT 许可证发布；
* 您可以在以下网址获取许可证副本：
* https://opensource.org/licenses/MIT
*
* 本软件是自由软件，您可以自由使用、修改和分发，
* 但需保留原作者版权信息和许可证声明。
*
* 作者: leiwei
* 版本: v3.2.0
* 日期: 2026-05-11
*----------------------------------------------------------------------------*/

#ifndef DOIP_API_H
#define DOIP_API_H

#ifdef _WIN32
    #ifdef BUILD_DOIP_API
        #define DOIP_API extern "C" __declspec(dllexport)
    #else
        #define DOIP_API extern "C" __declspec(dllimport)
    #endif
#else
    #define DOIP_API extern "C" __attribute__((visibility("default")))
#endif

#include "doipmessage.h"

/**
 * @brief 打开日志，用于调试和故障诊断
 *
 * 建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源
 *
 * @param logFile 日志文件路径，例如：logs/doip_api.log
 * @param level 日志等级，-1:默认（1） 0:DEBUG 1:INFO 2:WARN 3:ERROR
 * @param maxSize 文件大小，范围(1~20)，单位MB，-1:默认5MB
 * @param maxFiles 文件个数，范围(1~20)，-1:默认保留10个文件
 * @return 成功返回 0，失败返回其他值
 */
DOIP_API int DoIPOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志
 * @return 成功返回 0，失败返回其他值
 */
DOIP_API int DoIPCloseLog();

/**
 * @brief 获取当前已有连接个数（即DoIP客户端）
 * @return 客户端数量
 */
DOIP_API int DoIPClientGetSize();

/**
 * @brief 查询指定实例的连接状态
 *
 * 综合判断DoIP层连接标志和底层TCP实际连接状态。
 * 当网线断开、服务器关闭等情况发生后，此接口会返回断开状态。
 *
 * @param instanceId 连接实例ID
 * @return 1: 已连接, 0: 未连接或实例ID无效
 */
DOIP_API int DoIPClientIsConnected(int instanceId);

/**
 * @brief 建立 DoIP 客户端连接
 *
 * 如果已存在到相同服务器IP的连接，会先自动断开旧连接，再建立新连接。
 *
 * @param commands 命令行格式的连接参数，用于配置 DoIP 客户端连接。
 *                 参数以键值对形式提供，格式为 "--key value"，多个参数之间以空格分隔。
 *                 必需参数：
 *                   --serverIp <IP地址>        - 服务器 IP 地址（例如：192.168.1.100）
 *                   --sourceAddress <地址>     - 源逻辑地址，支持十六进制（例如：0x0E00）或十进制
 *                   --targetAddress <地址>     - 目标逻辑地址，支持十六进制（例如：0xBBBB）或十进制
 *                 可选参数：
 *                   --bindLocalIp <IP地址>     - 本地绑定 IP 地址（默认：空）
 *                   --serverTcpPort <端口>     - 服务器 TCP 端口（默认：13400）
 *                   --version <版本号>         - DoIP 协议版本（默认：0x02）
 *                   --routingActivation <true/false> - 是否需要路由激活（默认：true）
 *                   --activationType <类型>    - 路由激活类型（默认：0）
 *                   --useOEMSpecific <true/false> - 是否使用 OEM 特定数据（默认：false）
 *                   --oemSpecific <字节1>,<字节2>,<字节3>,<字节4> - OEM 特定数据（默认：0x00,0x00,0x00,0x00）
 *                   --futureStandardization <字节1>,<字节2>,<字节3>,<字节4> - 未来标准化数据
 *                   --routingActivationWaitTime <毫秒> - 路由激活等待时间（默认：2000）
 *                   --diagnoseResponseWaitTime <毫秒> - 诊断响应等待时间（默认：2000）
 *                   --aliveCheckResponse <true/false> - 是否响应活跃检查（默认：true）
 *                   --timeout <毫秒>           - 连接超时时间（默认：2000）
 *                   --reconnectFlag <true/false> - 是否启用自动重连（默认：true）
 *                   --readUDS <true/false>     - 是否只输出UDS消息（默认：true）
 *                   --autoSecurity27 <true/false> - 为 true 时，DoIPClientSend 仅发标准两字节「请求种子」
 *                         (0x27 + 奇数子功能) 将自动完成算钥与发送密钥子功能；默认 false 保持透传。
 *                   安全算法（可与 DoIPClientSetSecurityAlgorithm 二选一或叠加；连接串解析结果写入实例配置）：
 *                   --algoName <名称> --algoType <canoe|custom_u32|dh27> --dllPath <路径>
 *                         当 --algoName DH_27 且未提供 --dllPath 时，自动选用内置 DH_27（无需 DLL）。
 *                   --functionName <导出函数名> --variant <CANoe变体名>
 *                   --seedByteOrder <be|le> --keyByteOrder <be|le>
 *                 示例：
 *                   "--serverIp 192.168.1.100 --sourceAddress 0x0E80 --targetAddress 0x0E01 "
 *                   "--serverTcpPort 13400 --timeout 3000 --reconnectFlag true --readUDS true"
 * @param instanceId 输出参数，成功时存储分配的实例 ID
 * @return 成功返回 DOIP_RESULT_OK，失败返回其他 DOIP_RESULT 值
 */
DOIP_API int DoIPClientConnect(const char* commands, int* instanceId);

/**
 * @brief 使用指定的ID建立DoIP客户端连接
 *
 * 如果指定的ID已被使用，会先自动断开旧连接，再使用该ID建立新连接。
 *
 * @param instanceId 用户指定的实例ID
 * @param commands 命令行格式的连接参数 (与 DoIPClientConnect 相同)
 * @return 成功返回 DOIP_RESULT_OK。失败返回其他 DOIP_RESULT 值。
 */
DOIP_API int DoIPClientConnectWithId(int instanceId, const char* commands);

/**
 * @brief 断开 DoIP 客户端连接
 * @param instanceId 连接实例ID
 * @return 成功返回 DOIP_RESULT_OK，失败返回其他 DOIP_RESULT 值
 */
DOIP_API int DoIPClientDisconnect(int instanceId);

/**
 * @brief 发送诊断消息
 * @param instanceId 连接实例ID
 * @param userData 用户数据（诊断消息内容）
 * @param userDataLength 用户数据长度
 * @return 成功返回 DOIP_RESULT_OK，失败返回其他 DOIP_RESULT 值
 */
DOIP_API int DoIPClientSend(int instanceId,
                                  const unsigned char* userData,
                                  unsigned int userDataLength);

/**
 * @brief 开始周期性发送诊断消息
 * @param instanceId 连接实例ID
 * @param userData 用户数据（诊断消息内容）
 * @param userDataLength 用户数据长度
 * @param periodMs 周期时间，单位毫秒
 * @param periodId 输出参数，成功时存储周期任务ID
 * @return 成功返回 DOIP_RESULT_OK，失败返回其他 DOIP_RESULT 值
 */
DOIP_API int DoIPClientPeriodSend(int instanceId,
                                       const unsigned char* userData,
                                       unsigned int userDataLength,
                                       unsigned int periodMs,
                                       int* periodId);

/**
 * @brief 使用字符串参数扩展周期诊断发送配置
 * @param instanceId 连接实例ID
 * @param userData 用户数据（诊断消息内容）
 * @param userDataLength 用户数据长度
 * @param commands 周期发送参数，支持例如：
 *                 --periodMs 2000 --targetAddress 0x0E3E
 * @param periodId 输出参数，成功时存储周期任务ID
 * @return 成功返回 DOIP_RESULT_OK，失败返回其他 DOIP_RESULT 值
 */
DOIP_API int DoIPClientPeriodSendEx(int instanceId,
                                    const unsigned char* userData,
                                    unsigned int userDataLength,
                                    const char* commands,
                                    int* periodId);

/**
 * @brief 停止周期性发送诊断消息
 * @param instanceId 连接实例ID
 * @param periodId 周期任务ID， 特殊值 -1 表示停止所有周期诊断消息
 * @return 成功返回 DOIP_RESULT_OK，失败返回其他 DOIP_RESULT 值
 */
DOIP_API int DoIPClientPeriodStop(int instanceId, int periodId);

/**
 * @brief 读取接收到的DoIP消息
 * @param instanceId 连接实例ID
 * @param messages 消息数组，用于存储读取的消息
 * @param maxCount 最大读取消息数量
 * @param actualCount 输出参数，实际读取的消息数量
 * @return 成功返回 DOIP_RESULT_OK，失败返回其他 DOIP_RESULT 值
 */
DOIP_API int DoIPClientRead(int instanceId,
                                  DoIPOutputMessage* messages,
                                  int maxCount,
                                  int* actualCount);

/**
 * @brief 清空消息缓存
 * @param instanceId 连接实例ID
 * @return 成功返回 DOIP_RESULT_OK，失败返回其他 DOIP_RESULT 值
 */
DOIP_API int DoIPClientClearMessages(int instanceId);

/**
 * @brief 配置DoIP 27安全访问算法（按实例）
 *
 * commands 采用命令行风格，例如：
 * "--algoName DH_27 --algoType canoe --dllPath D:/algo/dh27.dll --functionName GenerateKeyEx --variant DH_27"
 * 或：
 * "--algoName DH_27 --algoType custom_u32 --dllPath D:/algo/dh27.dll --functionName CalcKey --seedByteOrder be --keyByteOrder be"
 *
 * @param instanceId DoIP实例ID
 * @param commands 配置命令
 * @return 成功返回 DOIP_RESULT_OK
 */
DOIP_API int DoIPClientSetSecurityAlgorithm(int instanceId, const char* commands);

/**
 * @brief 执行 27 安全访问（请求种子 + 计算密钥 + 发送密钥）
 * @param instanceId DoIP实例ID
 * @param requestLevel 请求种子的子功能（通常为奇数，如0x09）
 * @param timeoutMs 超时时间（毫秒），<=0 使用默认2s
 * @return 成功返回 DOIP_RESULT_OK
 */
DOIP_API int DoIPClientSecurityAccess(int instanceId, unsigned int requestLevel, int timeoutMs);

#endif // DOIP_API_H
