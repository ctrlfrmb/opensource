﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# DoIPServer.py - DoIP服务器实现，支持主动保活检测

import socket
import threading
import time
import logging
import struct
from DoIPUDS import UDSHandler

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('DoIPServer')

# DoIP协议常量
PROTOCOL_VERSION = 0x02
INVERSE_PROTOCOL_VERSION = 0xFD

# DoIP消息类型
DOIP_VEHICLE_ANNOUNCEMENT = 0x0004
DOIP_ROUTING_ACTIVATION_REQUEST = 0x0005
DOIP_ROUTING_ACTIVATION_RESPONSE = 0x0006
DOIP_ALIVE_CHECK_REQUEST = 0x0007
DOIP_ALIVE_CHECK_RESPONSE = 0x0008
DOIP_DIAGNOSTIC_MESSAGE = 0x8001
DOIP_DIAGNOSTIC_POSITIVE_ACK = 0x8002
DOIP_DIAGNOSTIC_NEGATIVE_ACK = 0x8003

class DoIPServer:
    """DoIP服务器实现，支持主动保活检测"""
    
    def __init__(self, host='0.0.0.0', port=13400, logical_address=0x0E01, 
                 alive_check_interval=5, alive_check_timeout=2, max_alive_check_retries=3):
        """
        初始化DoIP服务器
        
        参数:
            host: 监听的IP地址
            port: 监听的端口
            logical_address: 服务器逻辑地址(十六进制)
            alive_check_interval: 发送保活检测的间隔时间(秒)
            alive_check_timeout: 等待保活响应的超时时间(秒)
            max_alive_check_retries: 最大允许的保活检测失败次数
        """
        self.host = host
        self.port = port
        self.logical_address = logical_address
        self.socket = None
        self.running = False
        self.clients = {}  # 存储客户端连接: {socket: {'addr': (ip, port), 'tester_address': 0xXXXX, 'activated': False, 'last_activity': time.time(), 'alive_check_pending': False, 'alive_check_failures': 0}}
        self.accept_thread = None
        self.alive_check_thread = None
        self.alive_check_interval = alive_check_interval
        self.alive_check_timeout = alive_check_timeout
        self.max_alive_check_retries = max_alive_check_retries
        
        # 创建UDS处理器
        self.uds_handler = UDSHandler()
    
    def start(self):
        """启动DoIP服务器"""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            self.socket.bind((self.host, self.port))
            self.socket.listen(5)
            self.socket.settimeout(1)  # 设置超时，使accept可以被中断
            
            self.running = True
            logger.info(f"DoIP服务器已启动，监听于 {self.host}:{self.port}")
            logger.info(f"逻辑地址: 0x{self.logical_address:04X}")
            logger.info(f"保活检测配置: 间隔={self.alive_check_interval}秒, 超时={self.alive_check_timeout}秒, 最大重试={self.max_alive_check_retries}次")
            
            # 创建接受连接的线程
            self.accept_thread = threading.Thread(target=self._accept_connections)
            self.accept_thread.daemon = True
            self.accept_thread.start()
            
            # 创建保活检测线程
            self.alive_check_thread = threading.Thread(target=self._alive_check_thread)
            self.alive_check_thread.daemon = True
            self.alive_check_thread.start()
            
            return True
            
        except Exception as e:
            logger.error(f"启动服务器时出错: {e}")
            return False
    
    def stop(self):
        """停止DoIP服务器"""
        if not self.running:
            return
            
        self.running = False
        
        # 关闭所有客户端连接
        for sock in list(self.clients.keys()):
            try:
                sock.close()
            except:
                pass
        
        # 关闭服务器socket
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
                
        logger.info("DoIP服务器已停止")
    
    def _alive_check_thread(self):
        """保活检测线程，定期检查客户端连接是否活跃"""
        logger.info("保活检测线程已启动")
        
        while self.running:
            time.sleep(1)  # 每秒检查一次
            
            current_time = time.time()
            # 复制客户端列表，防止在迭代过程中修改
            clients_copy = dict(self.clients)
            
            for client_sock, client_info in clients_copy.items():
                # 如果客户端未激活，跳过保活检测
                if not client_info.get('activated', False):
                    continue
                
                # 计算上次活动后的时间
                last_activity = client_info.get('last_activity', current_time)
                time_since_last_activity = current_time - last_activity
                
                # 检查是否有待处理的保活请求
                if client_info.get('alive_check_pending', False):
                    # 如果保活请求已发送但超时未收到响应
                    time_since_alive_check = current_time - client_info.get('alive_check_sent', current_time)
                    
                    if time_since_alive_check > self.alive_check_timeout:
                        # 增加失败计数
                        failures = client_info.get('alive_check_failures', 0) + 1
                        self.clients[client_sock]['alive_check_failures'] = failures
                        self.clients[client_sock]['alive_check_pending'] = False
                        
                        logger.warning(f"客户端 {client_info['addr'][0]}:{client_info['addr'][1]} 未响应保活检测 "
                                      f"({failures}/{self.max_alive_check_retries})")
                        
                        # 如果超过最大失败次数，断开连接
                        if failures >= self.max_alive_check_retries:
                            logger.warning(f"客户端 {client_info['addr'][0]}:{client_info['addr'][1]} "
                                          f"连续 {self.max_alive_check_retries} 次未响应保活检测，断开连接")
                            
                            try:
                                client_sock.close()
                            except:
                                pass
                            
                            # 客户端连接会在_handle_client中被清理
                            continue
                
                # 如果超过保活检测间隔且没有待处理的保活请求，发送新的保活请求
                elif time_since_last_activity > self.alive_check_interval:
                    self._send_alive_check(client_sock)
                    self.clients[client_sock]['alive_check_pending'] = True
                    self.clients[client_sock]['alive_check_sent'] = current_time
                    
    def _send_alive_check(self, client_sock):
        """发送保活检测请求"""
        logger.info(f"发送保活检测请求到客户端 {self.clients[client_sock]['addr'][0]}:{self.clients[client_sock]['addr'][1]}")
        
        # 构建保活检测请求
        message = bytearray()
        # 头部
        message.extend([PROTOCOL_VERSION, INVERSE_PROTOCOL_VERSION])
        message.extend(struct.pack(">H", DOIP_ALIVE_CHECK_REQUEST))  # 类型
        message.extend(struct.pack(">I", 0))  # 长度为0，没有payload
        
        # 发送请求
        self._send_message(client_sock, message)
    
    def _accept_connections(self):
        """接受新连接的线程函数"""
        while self.running:
            try:
                client_sock, client_addr = self.socket.accept()
                
                self.clients[client_sock] = {
                    'addr': client_addr,
                    'tester_address': None,
                    'activated': False,
                    'last_activity': time.time(),
                    'alive_check_pending': False,
                    'alive_check_failures': 0
                }
                
                logger.info(f"接受新连接: {client_addr[0]}:{client_addr[1]}")
                
                # 为每个客户端创建新线程
                client_thread = threading.Thread(
                    target=self._handle_client,
                    args=(client_sock, client_addr)
                )
                client_thread.daemon = True
                client_thread.start()
                
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:  # 只在服务运行时记录错误
                    logger.error(f"处理新连接时出错: {e}")
    
    def _handle_client(self, client_sock, client_addr):
        """处理客户端连接"""
        logger.info(f"处理客户端 {client_addr[0]}:{client_addr[1]} 的连接")
        
        try:
            while self.running:
                try:
                    # 接收数据
                    data = client_sock.recv(4096)
                    
                    if not data or len(data) == 0:
                        # 空数据可能表示客户端断开连接
                        time.sleep(0.1)
                        continue
                    
                    # 更新最后活动时间
                    self.clients[client_sock]['last_activity'] = time.time()
                    # 重置保活检测状态
                    self.clients[client_sock]['alive_check_pending'] = False
                    self.clients[client_sock]['alive_check_failures'] = 0
                    
                    # 打印接收到的原始数据
                    logger.info(f"RX: {data.hex().upper()}")
                    
                    # 处理接收到的数据
                    self._process_message(client_sock, data)
                    
                except ConnectionResetError:
                    logger.info(f"客户端 {client_addr[0]}:{client_addr[1]} 已关闭连接")
                    break
                except socket.timeout:
                    continue
                except Exception as e:
                    logger.error(f"处理客户端数据时出错: {e}")
                    break
        finally:
            try:
                client_sock.close()
            except:
                pass
                
            if client_sock in self.clients:
                del self.clients[client_sock]
                
            logger.info(f"客户端 {client_addr[0]}:{client_addr[1]} 的连接已关闭")
    
    def _process_message(self, client_sock, data):
        """处理接收到的DoIP消息"""
        # 检查数据长度是否足够包含DoIP头
        if len(data) < 8:
            logger.warning(f"接收到的数据太短，无法解析DoIP头: {data.hex()}")
            return
        
        # 解析DoIP头
        proto_version = data[0]
        inverse_proto_version = data[1]
        payload_type = (data[2] << 8) | data[3]
        payload_length = (data[4] << 24) | (data[5] << 16) | (data[6] << 8) | data[7]
        
        # 验证协议版本
        if proto_version != PROTOCOL_VERSION or inverse_proto_version != INVERSE_PROTOCOL_VERSION:
            logger.warning(f"无效的DoIP协议版本: {proto_version:02X}/{inverse_proto_version:02X}")
            return
        
        # 检查payload长度是否匹配
        if len(data) < 8 + payload_length:
            logger.warning(f"不完整的DoIP消息，期望Payload长度: {payload_length}，实际接收: {len(data)-8}")
            return
        
        payload = data[8:8+payload_length]
        
        logger.info(f"收到消息类型: 0x{payload_type:04X}, 长度: {payload_length}")
        
        # 根据消息类型处理
        if payload_type == DOIP_ROUTING_ACTIVATION_REQUEST:
            self._handle_routing_activation(client_sock, payload)
        elif payload_type == DOIP_ALIVE_CHECK_REQUEST:
            self._handle_alive_check(client_sock, payload)
        elif payload_type == DOIP_ALIVE_CHECK_RESPONSE:
            self._handle_alive_check_response(client_sock, payload)
        elif payload_type == DOIP_DIAGNOSTIC_MESSAGE:
            self._handle_diagnostic_message(client_sock, payload)
        else:
            logger.warning(f"未处理的DoIP消息类型: 0x{payload_type:04X}")
    
    def _send_message(self, client_sock, message):
        """发送DoIP消息"""
        try:
            client_sock.send(message)
            logger.info(f"TX: {message.hex().upper()}")
        except Exception as e:
            logger.error(f"发送消息时出错: {e}")
    
    def _handle_routing_activation(self, client_sock, payload):
        """处理路由激活请求"""
        if len(payload) < 7:
            logger.warning("路由激活请求数据不完整")
            return
        
        # 提取测试设备逻辑地址
        source_address = (payload[0] << 8) | payload[1]
        activation_type = payload[2]
        
        # 存储测试设备地址
        self.clients[client_sock]['tester_address'] = source_address
        self.clients[client_sock]['activated'] = True
        
        logger.info(f"路由激活请求，测试设备地址: 0x{source_address:04X}, 激活类型: 0x{activation_type:02X}")
        
        # 构建路由激活响应
        response = bytearray()
        # 头部
        response.extend([PROTOCOL_VERSION, INVERSE_PROTOCOL_VERSION])
        response.extend(struct.pack(">H", DOIP_ROUTING_ACTIVATION_RESPONSE))  # 类型
        response.extend(struct.pack(">I", 9))  # 长度
        
        # 有效负载
        response.extend(struct.pack(">H", source_address))  # 测试设备地址
        response.extend(struct.pack(">H", self.logical_address))  # ECU逻辑地址
        response.append(0x10)  # 响应代码：路由激活成功
        response.extend([0x00, 0x00, 0x00, 0x00])  # 保留字节
        
        # 发送响应
        self._send_message(client_sock, response)
    
    def _handle_alive_check(self, client_sock, payload):
        """处理活跃检查请求"""
        logger.info(f"收到客户端 {self.clients[client_sock]['addr'][0]}:{self.clients[client_sock]['addr'][1]} 的保活检测请求")
        
        # 更新客户端活动时间
        self.clients[client_sock]['last_activity'] = time.time()
        
        # 构建活跃检查响应
        response = bytearray()
        # 头部
        response.extend([PROTOCOL_VERSION, INVERSE_PROTOCOL_VERSION])
        response.extend(struct.pack(">H", DOIP_ALIVE_CHECK_RESPONSE))  # 类型
        response.extend(struct.pack(">I", 2))  # 长度
        
        # 有效负载
        response.extend(struct.pack(">H", self.logical_address))  # 源地址(ECU)
        
        # 发送响应
        self._send_message(client_sock, response)
    
    def _handle_alive_check_response(self, client_sock, payload):
        """处理活跃检查响应"""
        logger.info(f"收到客户端 {self.clients[client_sock]['addr'][0]}:{self.clients[client_sock]['addr'][1]} 的保活检测响应")
        
        # 更新客户端活动状态
        self.clients[client_sock]['last_activity'] = time.time()
        self.clients[client_sock]['alive_check_pending'] = False
        self.clients[client_sock]['alive_check_failures'] = 0
    
    def _handle_diagnostic_message(self, client_sock, payload):
        """处理诊断消息请求"""
        if len(payload) < 4:
            logger.warning("诊断消息数据不完整")
            return
        
        # 提取源地址和目标地址
        source_address = (payload[0] << 8) | payload[1]  # 测试设备地址
        target_address = (payload[2] << 8) | payload[3]  # ECU地址
        user_data = payload[4:]
        
        logger.info(f"诊断消息: 源地址=0x{source_address:04X}, 目标地址=0x{target_address:04X}, 数据={user_data.hex().upper()}")
        
        # 检查路由是否已激活
        if not self.clients[client_sock]['activated']:
            logger.warning("收到诊断消息，但路由未激活")
            return
        
        # 检查目标地址是否匹配
        if target_address != self.logical_address:
            logger.warning(f"目标地址不匹配: 0x{target_address:04X} != 0x{self.logical_address:04X}")
            return
        
        # 发送ACK确认
        self._send_diagnostic_ack(client_sock, self.logical_address, source_address)
        
        # 检查用户数据是否为空
        if not user_data:
            logger.warning("诊断消息中没有用户数据")
            return
        
        # 处理UDS请求
        response_data = self.uds_handler.process_request(user_data)
        
        # 如果有响应数据，发送诊断响应
        if response_data is not None:
            self._send_diagnostic_response(client_sock, self.logical_address, source_address, response_data)
    
    def _send_diagnostic_ack(self, client_sock, source_address, target_address):
        """发送诊断消息确认（ACK）"""
        response = bytearray()
        # 头部
        response.extend([PROTOCOL_VERSION, INVERSE_PROTOCOL_VERSION])
        response.extend(struct.pack(">H", DOIP_DIAGNOSTIC_POSITIVE_ACK))  # 类型
        response.extend(struct.pack(">I", 5))  # 长度
        
        # 有效负载
        response.extend(struct.pack(">H", source_address))  # 源地址(ECU)
        response.extend(struct.pack(">H", target_address))  # 目标地址(测试设备)
        response.append(0x00)  # ACK代码：确认
        
        # 发送响应
        self._send_message(client_sock, response)
    
    def _send_diagnostic_response(self, client_sock, source_address, target_address, response_data):
        """发送诊断响应"""
        response = bytearray()
        # 头部
        response.extend([PROTOCOL_VERSION, INVERSE_PROTOCOL_VERSION])
        response.extend(struct.pack(">H", DOIP_DIAGNOSTIC_MESSAGE))  # 类型
        response.extend(struct.pack(">I", 4 + len(response_data)))  # 长度
        
        # 有效负载
        response.extend(struct.pack(">H", source_address))  # 源地址(ECU)
        response.extend(struct.pack(">H", target_address))  # 目标地址(测试设备)
        response.extend(response_data)  # 诊断响应数据
        
        # 发送响应
        self._send_message(client_sock, response)
    
    def set_did_data(self, did, data):
        """设置DID数据"""
        self.uds_handler.set_did_data(did, data)
    
    def add_writable_did(self, did):
        """添加可写入的DID"""
        self.uds_handler.add_writable_did(did)
