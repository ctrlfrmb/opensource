﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# DoIPUDS.py - UDS诊断服务模拟实现

import logging
import time
import random
import struct

# UDS服务ID常量
UDS_DIAGNOSTIC_SESSION_CONTROL = 0x10
UDS_ECU_RESET = 0x11
UDS_CLEAR_DTC = 0x14
UDS_READ_DTC = 0x19
UDS_READ_DATA_BY_ID = 0x22
UDS_SECURITY_ACCESS = 0x27
UDS_COMMUNICATION_CONTROL = 0x28
UDS_WRITE_DATA_BY_ID = 0x2E
UDS_ROUTINE_CONTROL = 0x31
UDS_REQUEST_DOWNLOAD = 0x34
UDS_TRANSFER_DATA = 0x36
UDS_REQUEST_TRANSFER_EXIT = 0x37
UDS_TESTER_PRESENT = 0x3E

# UDS响应代码
UDS_POSITIVE_RESPONSE = 0x40  # 正响应偏移量
UDS_NEGATIVE_RESPONSE = 0x7F

# UDS否定响应代码(NRC)
NRC_GENERAL_REJECT = 0x10
NRC_SERVICE_NOT_SUPPORTED = 0x11
NRC_SUB_FUNCTION_NOT_SUPPORTED = 0x12
NRC_INCORRECT_MESSAGE_LENGTH = 0x13
NRC_CONDITIONS_NOT_CORRECT = 0x22
NRC_REQUEST_SEQUENCE_ERROR = 0x24
NRC_REQUEST_OUT_OF_RANGE = 0x31
NRC_SECURITY_ACCESS_DENIED = 0x33
NRC_INVALID_KEY = 0x35
NRC_EXCEEDED_NUMBER_OF_ATTEMPTS = 0x36
NRC_RESPONSE_PENDING = 0x78

logger = logging.getLogger('DoIPUDS')

class UDSHandler:
    """UDS诊断服务处理类"""
    
    def __init__(self):
        # 当前会话状态
        self.current_session = 0x01  # 默认会话
        
        # 安全访问状态
        self.security_level = 0x00  # 未解锁
        self.seed = None
        self.seed_sent = False
        self.unlock_attempts = 0
        self.max_unlock_attempts = 3
        
        # DID数据字典
        self.did_data = {
            0xF180: bytes.fromhex('01020304'),  # 示例DID数据
            0xF181: bytes.fromhex('AABBCCDD'),
            0xF182: bytes.fromhex('55667788'),
            0xF183: bytes.fromhex('99AABBCC'),
            0xF190: bytes.fromhex('0102030405060708'),
            0xF191: bytes.fromhex('AABBCCDDEEFF0011'),
            0xF192: bytes.fromhex('1122334455667788'),
        }
        
        # 可写入的DID
        self.writable_dids = [0xF190, 0xF191]
        
        # 服务处理函数映射
        self.service_handlers = {
            UDS_DIAGNOSTIC_SESSION_CONTROL: self.handle_session_control,
            UDS_ECU_RESET: self.handle_ecu_reset,
            UDS_READ_DATA_BY_ID: self.handle_read_did,
            UDS_WRITE_DATA_BY_ID: self.handle_write_did,
            UDS_SECURITY_ACCESS: self.handle_security_access,
            UDS_TESTER_PRESENT: self.handle_tester_present,
            UDS_ROUTINE_CONTROL: self.handle_routine_control,
            UDS_CLEAR_DTC: self.handle_clear_dtc,
            UDS_READ_DTC: self.handle_read_dtc,
            UDS_COMMUNICATION_CONTROL: self.handle_communication_control,
            UDS_REQUEST_DOWNLOAD: self.handle_request_download,
            UDS_TRANSFER_DATA: self.handle_transfer_data,
            UDS_REQUEST_TRANSFER_EXIT: self.handle_request_transfer_exit
        }
        
        # DTC数据
        self.dtcs = {
            0x123456: {"status": 0x24, "description": "示例DTC 1"},
            0x234567: {"status": 0x28, "description": "示例DTC 2"},
            0x345678: {"status": 0x21, "description": "示例DTC 3"}
        }
        
        # 下载会话数据
        self.download_session_active = False
        self.download_memory_address = 0
        self.download_memory_size = 0
        self.download_block_counter = 0
        self.download_data = bytearray()
    
    def process_request(self, request_data):
        """处理UDS请求并返回响应"""
        if not request_data or len(request_data) == 0:
            logger.warning("空的UDS请求")
            return None
        
        service_id = request_data[0]
        logger.info(f"处理UDS服务: 0x{service_id:02X}")
        
        # 检查是否支持该服务
        if service_id in self.service_handlers:
            return self.service_handlers[service_id](request_data)
        else:
            # 不支持的服务
            logger.warning(f"不支持的UDS服务: 0x{service_id:02X}")
            return bytes([UDS_NEGATIVE_RESPONSE, service_id, NRC_SERVICE_NOT_SUPPORTED])
    
    def handle_session_control(self, request_data):
        """处理诊断会话控制(0x10)"""
        if len(request_data) < 2:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_DIAGNOSTIC_SESSION_CONTROL, NRC_INCORRECT_MESSAGE_LENGTH])
        
        session_type = request_data[1]
        
        # 检查会话类型是否有效
        if session_type not in [0x01, 0x02, 0x03, 0x04]:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_DIAGNOSTIC_SESSION_CONTROL, NRC_SUB_FUNCTION_NOT_SUPPORTED])
        
        # 更新当前会话
        self.current_session = session_type
        logger.info(f"切换到会话类型: 0x{session_type:02X}")
        
        # 返回肯定响应，包含P2和P2*服务器最大响应时间
        p2_server_max = 50  # 50ms
        p2_star_server_max = 5000  # 5000ms
        
        return bytes([UDS_DIAGNOSTIC_SESSION_CONTROL + UDS_POSITIVE_RESPONSE, session_type]) + \
               struct.pack(">HH", p2_server_max, p2_star_server_max)
    
    def handle_ecu_reset(self, request_data):
        """处理ECU复位(0x11)"""
        if len(request_data) < 2:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_ECU_RESET, NRC_INCORRECT_MESSAGE_LENGTH])
        
        reset_type = request_data[1]
        
        # 检查复位类型是否有效
        if reset_type not in [0x01, 0x02, 0x03, 0x04, 0x05]:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_ECU_RESET, NRC_SUB_FUNCTION_NOT_SUPPORTED])
        
        logger.info(f"执行ECU复位，类型: 0x{reset_type:02X}")
        
        # 返回肯定响应
        return bytes([UDS_ECU_RESET + UDS_POSITIVE_RESPONSE, reset_type])
    
    def handle_clear_dtc(self, request_data):
        """处理清除诊断信息(0x14)"""
        if len(request_data) < 3:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_CLEAR_DTC, NRC_INCORRECT_MESSAGE_LENGTH])
        
        group_of_dtc = (request_data[1] << 16) | (request_data[2] << 8) | request_data[3]
        logger.info(f"清除DTC组: 0x{group_of_dtc:06X}")
        
        # 检查安全访问级别
        if self.security_level < 0x01:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_CLEAR_DTC, NRC_SECURITY_ACCESS_DENIED])
        
        # 清除所有DTC或特定组的DTC
        if group_of_dtc == 0xFFFFFF:  # 所有DTC
            self.dtcs.clear()
            logger.info("已清除所有DTC")
        else:
            # 在实际应用中，这里应该根据组过滤DTC
            # 简化实现，我们只是记录请求
            logger.info(f"请求清除DTC组 0x{group_of_dtc:06X}，但未实现过滤")
        
        # 返回肯定响应
        return bytes([UDS_CLEAR_DTC + UDS_POSITIVE_RESPONSE, request_data[1], request_data[2], request_data[3]])
    
    def handle_read_dtc(self, request_data):
        """处理读取DTC信息(0x19)"""
        if len(request_data) < 2:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_READ_DTC, NRC_INCORRECT_MESSAGE_LENGTH])
        
        sub_function = request_data[1]
        logger.info(f"读取DTC信息，子功能: 0x{sub_function:02X}")
        
        # 检查子功能是否支持
        if sub_function not in [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A]:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_READ_DTC, NRC_SUB_FUNCTION_NOT_SUPPORTED])
        
        # 根据子功能返回不同的响应
        if sub_function == 0x01:  # 报告DTC数量
            # 返回DTC数量
            dtc_count = len(self.dtcs)
            status_mask = 0xFF  # 所有状态位
            
            response = bytes([UDS_READ_DTC + UDS_POSITIVE_RESPONSE, sub_function, status_mask]) + \
                      struct.pack(">H", dtc_count)
            
            return response
        
        elif sub_function == 0x02:  # 报告DTC
            # 返回所有DTC及其状态
            status_mask = 0xFF  # 所有状态位
            
            response = bytes([UDS_READ_DTC + UDS_POSITIVE_RESPONSE, sub_function, status_mask])
            
            for dtc_code, dtc_info in self.dtcs.items():
                # 添加DTC代码(3字节)和状态(1字节)
                response += struct.pack(">I", (dtc_code << 8) | dtc_info["status"])
            
            return response
        
        else:
            # 其他子功能简化处理
            return bytes([UDS_READ_DTC + UDS_POSITIVE_RESPONSE, sub_function, 0x00])
    
    def handle_read_did(self, request_data):
        """处理读取数据标识符(0x22)"""
        if len(request_data) < 3 or (len(request_data) - 1) % 2 != 0:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_READ_DATA_BY_ID, NRC_INCORRECT_MESSAGE_LENGTH])
        
        # 可以处理多个DID
        response = bytes([UDS_READ_DATA_BY_ID + UDS_POSITIVE_RESPONSE])
        
        for i in range(1, len(request_data), 2):
            if i + 1 >= len(request_data):
                break
                
            did_high = request_data[i]
            did_low = request_data[i+1]
            did = (did_high << 8) | did_low
            
            logger.info(f"读取DID: 0x{did:04X}")
            
            # 检查DID是否存在
            if did in self.did_data:
                # 添加DID和数据到响应
                response += bytes([did_high, did_low]) + self.did_data[did]
            else:
                # DID不存在，返回否定响应
                return bytes([UDS_NEGATIVE_RESPONSE, UDS_READ_DATA_BY_ID, NRC_REQUEST_OUT_OF_RANGE])
        
        return response
    
    def handle_security_access(self, request_data):
        """处理安全访问(0x27)"""
        if len(request_data) < 2:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_SECURITY_ACCESS, NRC_INCORRECT_MESSAGE_LENGTH])
        
        sub_function = request_data[1]
        
        # 检查子功能是否有效
        if sub_function not in [0x01, 0x02, 0x03, 0x04, 0x05, 0x06]:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_SECURITY_ACCESS, NRC_SUB_FUNCTION_NOT_SUPPORTED])
        
        # 请求种子
        if sub_function % 2 == 1:
            level = (sub_function + 1) // 2
            logger.info(f"请求安全访问种子，级别: {level}")
            
            # 检查是否已经解锁该级别
            if self.security_level >= level:
                # 已解锁，返回零种子
                self.seed = bytes([0x00, 0x00, 0x00, 0x00])
            else:
                # 生成随机种子
                self.seed = bytes([random.randint(1, 255) for _ in range(4)])
            
            self.seed_sent = True
            return bytes([UDS_SECURITY_ACCESS + UDS_POSITIVE_RESPONSE, sub_function]) + self.seed
        
        # 发送密钥
        else:
            level = sub_function // 2
            logger.info(f"发送安全访问密钥，级别: {level}")
            
            # 检查是否先请求了种子
            if not self.seed_sent:
                return bytes([UDS_NEGATIVE_RESPONSE, UDS_SECURITY_ACCESS, NRC_REQUEST_SEQUENCE_ERROR])
            
            # 检查密钥长度
            if len(request_data) < 6:  # 服务ID + 子功能 + 至少4字节密钥
                return bytes([UDS_NEGATIVE_RESPONSE, UDS_SECURITY_ACCESS, NRC_INCORRECT_MESSAGE_LENGTH])
            
            # 检查尝试次数
            if self.unlock_attempts >= self.max_unlock_attempts:
                self.unlock_attempts = 0
                return bytes([UDS_NEGATIVE_RESPONSE, UDS_SECURITY_ACCESS, NRC_EXCEEDED_NUMBER_OF_ATTEMPTS])
            
            key = request_data[2:6]
            
            # 简单的密钥验证逻辑 - 在实际应用中应该更复杂
            # 这里我们使用一个简单的算法：每个字节+1
            expected_key = bytes([(b + 1) & 0xFF for b in self.seed])
            
            if key == expected_key:
                # 密钥正确
                self.security_level = level
                self.unlock_attempts = 0
                self.seed_sent = False
                logger.info(f"安全访问成功，级别: {level}")
                return bytes([UDS_SECURITY_ACCESS + UDS_POSITIVE_RESPONSE, sub_function])
            else:
                # 密钥错误
                self.unlock_attempts += 1
                logger.warning(f"安全访问密钥错误，尝试次数: {self.unlock_attempts}/{self.max_unlock_attempts}")
                return bytes([UDS_NEGATIVE_RESPONSE, UDS_SECURITY_ACCESS, NRC_INVALID_KEY])
    
    def handle_communication_control(self, request_data):
        """处理通信控制(0x28)"""
        if len(request_data) < 3:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_COMMUNICATION_CONTROL, NRC_INCORRECT_MESSAGE_LENGTH])
        
        control_type = request_data[1]
        communication_type = request_data[2]
        
        logger.info(f"通信控制，控制类型: 0x{control_type:02X}, 通信类型: 0x{communication_type:02X}")
        
        # 检查安全访问级别
        if self.security_level < 0x01:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_COMMUNICATION_CONTROL, NRC_SECURITY_ACCESS_DENIED])
        
        # 检查控制类型是否有效
        if control_type not in [0x00, 0x01, 0x02, 0x03]:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_COMMUNICATION_CONTROL, NRC_SUB_FUNCTION_NOT_SUPPORTED])
        
        # 返回肯定响应
        return bytes([UDS_COMMUNICATION_CONTROL + UDS_POSITIVE_RESPONSE, control_type])
    
    def handle_write_did(self, request_data):
        """处理写入数据标识符(0x2E)"""
        if len(request_data) < 4:  # 至少需要服务ID + DID(2字节) + 1字节数据
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_WRITE_DATA_BY_ID, NRC_INCORRECT_MESSAGE_LENGTH])
        
        did_high = request_data[1]
        did_low = request_data[2]
        did = (did_high << 8) | did_low
        data = request_data[3:]
        
        logger.info(f"写入DID: 0x{did:04X}, 数据: {data.hex().upper()}")
        
        # 检查安全访问级别
        if self.security_level < 0x01:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_WRITE_DATA_BY_ID, NRC_SECURITY_ACCESS_DENIED])
        
        # 检查DID是否可写
        if did not in self.writable_dids:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_WRITE_DATA_BY_ID, NRC_REQUEST_OUT_OF_RANGE])
        
        # 更新DID数据
        self.did_data[did] = data
        
        # 返回肯定响应
        return bytes([UDS_WRITE_DATA_BY_ID + UDS_POSITIVE_RESPONSE, did_high, did_low])
    
    def handle_routine_control(self, request_data):
        """处理例程控制(0x31)"""
        if len(request_data) < 4:  # 服务ID + 子功能 + 例程ID(2字节)
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_ROUTINE_CONTROL, NRC_INCORRECT_MESSAGE_LENGTH])
        
        sub_function = request_data[1]
        routine_id_high = request_data[2]
        routine_id_low = request_data[3]
        routine_id = (routine_id_high << 8) | routine_id_low
        
        # 检查子功能是否有效
        if sub_function not in [0x01, 0x02, 0x03]:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_ROUTINE_CONTROL, NRC_SUB_FUNCTION_NOT_SUPPORTED])
        
        logger.info(f"例程控制，子功能: 0x{sub_function:02X}, 例程ID: 0x{routine_id:04X}")
        
        # 简单模拟一些例程
        if routine_id == 0xFF00:  # 检查编程依赖性
            return bytes([UDS_ROUTINE_CONTROL + UDS_POSITIVE_RESPONSE, sub_function, 
                          routine_id_high, routine_id_low, 0x00])  # 0x00表示通过
        elif routine_id == 0xFF01:  # 擦除内存
            return bytes([UDS_ROUTINE_CONTROL + UDS_POSITIVE_RESPONSE, sub_function,
                          routine_id_high, routine_id_low, 0x00])  # 0x00表示成功
        else:
            # 不支持的例程ID
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_ROUTINE_CONTROL, NRC_REQUEST_OUT_OF_RANGE])
    
    def handle_request_download(self, request_data):
        """处理请求下载(0x34)"""
        if len(request_data) < 3:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_REQUEST_DOWNLOAD, NRC_INCORRECT_MESSAGE_LENGTH])
        
        # 检查安全访问级别
        if self.security_level < 0x01:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_REQUEST_DOWNLOAD, NRC_SECURITY_ACCESS_DENIED])
        
        data_format = request_data[1]
        addr_len = (data_format >> 4) & 0x0F
        size_len = data_format & 0x0F
        
        if len(request_data) < 2 + addr_len + size_len:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_REQUEST_DOWNLOAD, NRC_INCORRECT_MESSAGE_LENGTH])
        
        # 解析内存地址和大小
        memory_address = 0
        for i in range(addr_len):
            memory_address = (memory_address << 8) | request_data[2 + i]
        
        memory_size = 0
        for i in range(size_len):
            memory_size = (memory_size << 8) | request_data[2 + addr_len + i]
        
        logger.info(f"请求下载，地址: 0x{memory_address:X}, 大小: {memory_size}字节")
        
        # 初始化下载会话
        self.download_session_active = True
        self.download_memory_address = memory_address
        self.download_memory_size = memory_size
        self.download_block_counter = 0
        self.download_data = bytearray()
        
        # 返回肯定响应，包含最大块大小
        max_block_length = 4096  # 示例值
        return bytes([UDS_REQUEST_DOWNLOAD + UDS_POSITIVE_RESPONSE, 0x20]) + struct.pack(">H", max_block_length)
    
    def handle_transfer_data(self, request_data):
        """处理传输数据(0x36)"""
        if len(request_data) < 2:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_TRANSFER_DATA, NRC_INCORRECT_MESSAGE_LENGTH])
        
        # 检查下载会话是否活跃
        if not self.download_session_active:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_TRANSFER_DATA, NRC_REQUEST_SEQUENCE_ERROR])
        
        block_counter = request_data[1]
        data = request_data[2:]
        
        # 检查块计数器
        expected_counter = (self.download_block_counter + 1) & 0xFF
        if block_counter != expected_counter:
            logger.warning(f"块计数器错误，期望: {expected_counter}，收到: {block_counter}")
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_TRANSFER_DATA, NRC_REQUEST_SEQUENCE_ERROR])
        
        self.download_block_counter = block_counter
        
        # 添加数据到下载缓冲区
        self.download_data.extend(data)
        logger.info(f"接收到数据块 {block_counter}，大小: {len(data)}字节")
        
        # 返回肯定响应
        return bytes([UDS_TRANSFER_DATA + UDS_POSITIVE_RESPONSE, block_counter])
    
    def handle_request_transfer_exit(self, request_data):
        """处理请求传输退出(0x37)"""
        # 检查下载会话是否活跃
        if not self.download_session_active:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_REQUEST_TRANSFER_EXIT, NRC_REQUEST_SEQUENCE_ERROR])
        
        logger.info(f"传输完成，总接收: {len(self.download_data)}字节")
        
        # 重置下载会话
        self.download_session_active = False
        
        # 返回肯定响应
        return bytes([UDS_REQUEST_TRANSFER_EXIT + UDS_POSITIVE_RESPONSE])
    
    def handle_tester_present(self, request_data):
        """处理测试设备在线(0x3E)"""
        if len(request_data) < 2:
            return bytes([UDS_NEGATIVE_RESPONSE, UDS_TESTER_PRESENT, NRC_INCORRECT_MESSAGE_LENGTH])
        
        sub_function = request_data[1]
        suppress_response = (sub_function & 0x80) != 0
        
        logger.info(f"测试设备在线，抑制响应: {suppress_response}")
        
        # 如果抑制响应标志设置，则不返回响应
        if suppress_response:
            return None
        
        # 返回肯定响应
        return bytes([UDS_TESTER_PRESENT + UDS_POSITIVE_RESPONSE, sub_function & 0x7F])
    
    def set_did_data(self, did, data):
        """设置DID数据"""
        if isinstance(data, str):
            data = bytes.fromhex(data)
        self.did_data[did] = data
        logger.info(f"设置DID 0x{did:04X} 数据: {data.hex().upper()}")
    
    def add_writable_did(self, did):
        """添加可写入的DID"""
        if did not in self.writable_dids:
            self.writable_dids.append(did)
            logger.info(f"添加可写入DID: 0x{did:04X}")
    
    def add_dtc(self, dtc_code, status, description=""):
        """添加DTC"""
        self.dtcs[dtc_code] = {"status": status, "description": description}
        logger.info(f"添加DTC: 0x{dtc_code:06X}, 状态: 0x{status:02X}, 描述: {description}")
    
    def clear_all_dtcs(self):
        """清除所有DTC"""
        self.dtcs.clear()
        logger.info("已清除所有DTC")
