#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import time
import threading
import shlex
import ctypes
from ctypes import *

# ==============================================================================
# 1. 基础配置与 DLL 加载
# ==============================================================================

ZCAN_USBCAN_2E_U = 21
STATUS_OK = 1
STATUS_ERR = 0

TYPE_CAN = 0
TYPE_CANFD = 1

# 数据类型定义 (ZCANDataObj用)
ZCAN_DT_ZCAN_CAN_CANFD_DATA = 1

current_dir = os.path.dirname(os.path.abspath(__file__))
dll_path = os.path.join(current_dir, "zlgcan.dll")

print(f"[*] 工作目录: {current_dir}")
print(f"[*] 尝试加载: {dll_path}")

if not os.path.exists(dll_path):
    print(f"[!] 错误: 找不到文件 {dll_path}")
    sys.exit(1)

# 添加搜索路径
os.environ['PATH'] = current_dir + os.pathsep + os.environ['PATH']
if hasattr(os, 'add_dll_directory'):
    try:
        os.add_dll_directory(current_dir)
    except Exception:
        pass

try:
    zlg = cdll.LoadLibrary(dll_path)
    print("[*] zlgcan.dll 加载成功！")
except Exception as e:
    print(f"[!] zlgcan.dll 加载失败: {e}")
    sys.exit(1)

# ==============================================================================
# 2. ctypes 数据结构定义
# ==============================================================================

DEVICE_HANDLE = c_void_p
CHANNEL_HANDLE = c_void_p
UINT = c_uint
BYTE = c_ubyte
USHORT = c_ushort
UCHAR = c_ubyte
UINT64 = c_ulonglong

class ZCAN_DEVICE_INFO(Structure):
    _fields_ = [
        ("hw_Version", USHORT),
        ("fw_Version", USHORT),
        ("dr_Version", USHORT),
        ("in_Version", USHORT),
        ("irq_Num", USHORT),
        ("can_Num", BYTE),
        ("str_Serial_Num", UCHAR * 20),
        ("str_hw_Type", UCHAR * 40),
        ("reserved", USHORT * 4),
    ]

# --- 初始化配置 ---
class ZCAN_CONFIG_CAN(Structure):
    _fields_ = [
        ("acc_code", UINT),
        ("acc_mask", UINT),
        ("reserved", UINT),
        ("filter", BYTE),
        ("timing0", BYTE),
        ("timing1", BYTE),
        ("mode", BYTE),
    ]

class ZCAN_CONFIG_CANFD(Structure):
    _fields_ = [
        ("acc_code", UINT),
        ("acc_mask", UINT),
        ("abit_timing", UINT),
        ("dbit_timing", UINT),
        ("brp", UINT),
        ("filter", BYTE),
        ("mode", BYTE),
        ("pad", USHORT),
        ("reserved", UINT),
    ]

class ZCAN_CONFIG_UNION(Union):
    _fields_ = [
        ("can", ZCAN_CONFIG_CAN),
        ("canfd", ZCAN_CONFIG_CANFD),
    ]

class ZCAN_CHANNEL_INIT_CONFIG(Structure):
    _fields_ = [
        ("can_type", UINT),
        ("config", ZCAN_CONFIG_UNION),
    ]

# --- 帧结构定义 ---

# Legacy CAN Frame (16 bytes)
class CAN_FRAME(Structure):
    _fields_ = [
        ("can_id", UINT),
        ("can_dlc", BYTE),
        ("__pad", BYTE),
        ("__res0", BYTE),
        ("__res1", BYTE),
        ("data", BYTE * 8), 
    ]

# CAN FD Frame (72 bytes)
class CANFD_FRAME(Structure):
    _fields_ = [
        ("can_id", UINT),
        ("len", BYTE),
        ("flags", BYTE),
        ("__res0", BYTE),
        ("__res1", BYTE),
        ("data", BYTE * 64), 
    ]

# --- 接口传输对象 ---

# 1. ZCAN_Transmit / Receive
class ZCAN_Transmit_Data(Structure):
    _fields_ = [("frame", CAN_FRAME), ("transmit_type", UINT)]

class ZCAN_Receive_Data(Structure):
    _fields_ = [("frame", CAN_FRAME), ("timestamp", UINT64)]

# 2. ZCAN_TransmitFD / ReceiveFD
class ZCAN_TransmitFD_Data(Structure):
    _fields_ = [("frame", CANFD_FRAME), ("transmit_type", UINT)]

class ZCAN_ReceiveFD_Data(Structure):
    _fields_ = [("frame", CANFD_FRAME), ("timestamp", UINT64)]

# 3. ZCAN_TransmitData / ReceiveData (Complex ZCANDataObj)

# ZCANDataObj 内部的 Flag 联合体
class ZCAN_CANFD_FLAG_BITS(Structure):
    _fields_ = [
        ("frameType", UINT, 2),    # 0:CAN, 1:CANFD
        ("txDelay", UINT, 2),
        ("transmitType", UINT, 4),
        ("txEchoRequest", UINT, 1),
        ("txEchoed", UINT, 1),
        ("reserved", UINT, 22),
    ]
class ZCAN_CANFD_FLAG(Union):
    _fields_ = [("unionVal", ZCAN_CANFD_FLAG_BITS), ("rawVal", UINT)]

# ZCANCANFDData
class ZCANCANFDData(Structure):
    _fields_ = [
        ("timeStamp", UINT64),
        ("flag", ZCAN_CANFD_FLAG),
        ("extraData", BYTE * 4),
        ("frame", CANFD_FRAME)
    ]

# ZCANDataObj Data Union (Simplified to support CAN/CANFD mainly)
class ZCANDataObj_Data(Union):
    _fields_ = [
        ("zcanCANFDData", ZCANCANFDData),
        ("raw", BYTE * 92)
    ]

# ZCANDataObj
class ZCANDataObj(Structure):
    _fields_ = [
        ("dataType", BYTE), # ZCAN_DT_ZCAN_CAN_CANFD_DATA = 1
        ("chnl", BYTE),
        ("flag", USHORT),   # union omitted for brevity
        ("extraData", BYTE * 4),
        ("data", ZCANDataObj_Data)
    ]

# ==============================================================================
# 3. API 函数原型
# ==============================================================================

def setup_func(func_name, argtypes, restype):
    try:
        func = getattr(zlg, func_name)
        func.argtypes = argtypes
        func.restype = restype
        return func
    except AttributeError:
        # print(f"[!] 警告: 找不到函数 {func_name}")
        return None

# 日志与扫描
ZCAN_OpenLog = setup_func("ZCAN_OpenLog", [c_char_p, c_int, c_int, c_int], UINT)
ZCAN_CloseLog = setup_func("ZCAN_CloseLog", [], UINT)
ZCAN_ScanDevice = setup_func("ZCAN_ScanDevice", [POINTER(UINT), POINTER(UINT), UINT], UINT)

# 设备与通道控制
ZCAN_OpenDevice = setup_func("ZCAN_OpenDevice", [UINT, UINT, UINT], DEVICE_HANDLE)
ZCAN_CloseDevice = setup_func("ZCAN_CloseDevice", [DEVICE_HANDLE], UINT)
ZCAN_GetDeviceInf = setup_func("ZCAN_GetDeviceInf", [DEVICE_HANDLE, POINTER(ZCAN_DEVICE_INFO)], UINT)
ZCAN_InitCAN = setup_func("ZCAN_InitCAN", [DEVICE_HANDLE, UINT, POINTER(ZCAN_CHANNEL_INIT_CONFIG)], CHANNEL_HANDLE)
ZCAN_StartCAN = setup_func("ZCAN_StartCAN", [CHANNEL_HANDLE], UINT)
ZCAN_ResetCAN = setup_func("ZCAN_ResetCAN", [CHANNEL_HANDLE], UINT)
ZCAN_GetReceiveNum = setup_func("ZCAN_GetReceiveNum", [CHANNEL_HANDLE, BYTE], UINT)

# --- 收发接口 ---

# 1. Standard CAN
ZCAN_Transmit = setup_func("ZCAN_Transmit", [CHANNEL_HANDLE, POINTER(ZCAN_Transmit_Data), UINT], UINT)
ZCAN_Receive = setup_func("ZCAN_Receive", [CHANNEL_HANDLE, POINTER(ZCAN_Receive_Data), UINT, c_int], UINT)

# 2. CAN FD
ZCAN_TransmitFD = setup_func("ZCAN_TransmitFD", [CHANNEL_HANDLE, POINTER(ZCAN_TransmitFD_Data), UINT], UINT)
ZCAN_ReceiveFD = setup_func("ZCAN_ReceiveFD", [CHANNEL_HANDLE, POINTER(ZCAN_ReceiveFD_Data), UINT, c_int], UINT)

# 3. Generic Data
ZCAN_TransmitData = setup_func("ZCAN_TransmitData", [DEVICE_HANDLE, POINTER(ZCANDataObj), UINT], UINT)
ZCAN_ReceiveData = setup_func("ZCAN_ReceiveData", [DEVICE_HANDLE, POINTER(ZCANDataObj), UINT, c_int], UINT)

# ==============================================================================
# 4. 辅助函数
# ==============================================================================

def get_baud_timing(baud_rate):
    mapping = {
        1000000: (0x00, 0x14), 800000: (0x00, 0x16), 500000: (0x00, 0x1C),
        250000: (0x01, 0x1C), 125000: (0x03, 0x1C), 100000: (0x04, 0x1C),
    }
    return mapping.get(baud_rate, (0x00, 0x1C))

def hex_dump(data, length):
    max_len = min(length, len(data), 64)
    if max_len <= 0: return ""
    return " ".join(f"{data[i]:02X}" for i in range(max_len))

def safe_int(val_str, default=0):
    if not isinstance(val_str, str):
        try: return int(val_str)
        except: return default
    val_str = val_str.strip()
    try: return int(val_str, 0)
    except ValueError:
        try: return int(val_str, 16)
        except ValueError: return default

# ==============================================================================
# 5. 交互式测试类
# ==============================================================================

class ZlgCanTest:
    def __init__(self):
        self.running = True
        self.dev_handles = {}   # idx -> handle
        self.ch_handles = {}    # (dev_idx, ch_idx) -> handle
        self.ch_configs = {}    # (dev_idx, ch_idx) -> "can" or "canfd"
        
        self.auto_recv_thread = None
        self.auto_recv_flag = False
        self.auto_recv_args = {} # Store args for thread
        self.log_opened = False

    def print_help(self):
        print("\n=== ZLG CAN Wrapper 命令手册 ===")
        
        print("\n[系统命令]")
        print("  --scan [-wait <ms>]            扫描在线设备")
        print("  --log on|off                   开启/关闭调试日志")
        print("  --exit                         退出程序")

        print("\n[设备管理]")
        print("  --open -dev <idx> [-res <ip>]  打开设备")
        print("    例1: --open -dev 0           (连接设备0, 由系统自动选择网卡)")
        print("    例2: --open -dev 1 -res 87   (连接设备1, 并绑定本地 IP 192.168.201.87)")
        print("  --close -dev <idx>             关闭设备")
        print("  --info -dev <idx>              获取设备信息")

        print("\n[通道初始化]")
        print("  --init -dev <idx> -ch <ch> [参数...]")
        print("    [CAN模式]")
        print("      例: --init -dev 0 -ch 0 -mode can -baud 500000")
        print("    [CANFD模式]")
        print("      例: --init -dev 0 -ch 0 -mode canfd -abit 500000 -dbit 2000000")

        print("\n[通道控制]")
        print("  --start -dev <idx> -ch <ch>    启动通道")
        print("  --reset -dev <idx> -ch <ch>    复位通道")

        print("\n[数据收发]")
        print("  --send -dev <idx> -ch <ch> -id <hex> [-data <bytes>] [-fd 0|1]")
        print("    例: --send -dev 0 -ch 0 -id 123 -data 11 22 33 AA -fd 1")
        print("  --recv -dev <idx> -ch <ch> [-method legacy|fd|data] [-wait <ms>]")
        print("    例: --recv -dev 0 -ch 0 -wait 1000")
        print("  --autorecv on|off -dev <idx> -ch <ch> [-method legacy|fd|data]")
        print("    例: --autorecv on -dev 0 -ch 0 -method fd")
        print("============================\n")

    def extract_arg(self, args, key, default=None):
        if key in args:
            idx = args.index(key)
            if idx + 1 < len(args): return args[idx+1]
        return default

    def run(self):
        print("\n=== ZLG CAN Wrapper 交互式终端 (输入 --help 查看帮助) ===")
        while self.running:
            try:
                cmd_str = input("\nZLG>>> ").strip()
                if not cmd_str: continue
                args = shlex.split(cmd_str)
                cmd = args[0].lower()

                if cmd == "--exit": self.cleanup(); break
                elif cmd == "--help": self.print_help()
                elif cmd == "--log": self.do_log(args)
                elif cmd == "--scan": self.do_scan(args)
                elif cmd == "--open": self.do_open(args)
                elif cmd == "--close": self.do_close(args)
                elif cmd == "--info": self.do_info(args)
                elif cmd == "--init": self.do_init(args)
                elif cmd == "--start": self.do_start(args)
                elif cmd == "--reset": self.do_reset(args)
                elif cmd == "--send": self.do_send(args)
                elif cmd == "--recv": self.do_recv(args)
                elif cmd == "--autorecv": self.do_autorecv(args)
                else: print("[!] 未知命令 (输入 --help 查看帮助)")
            except KeyboardInterrupt:
                print("\n[!] Ctrl+C detected. Exiting...")
                self.cleanup(); break
            except Exception as e:
                print(f"[!] 异常: {e}"); import traceback; traceback.print_exc()

    def cleanup(self):
        self.running = False
        self.stop_autorecv()
        print("[*] 清理资源...")
        for idx in list(self.dev_handles.keys()):
            h = self.dev_handles.pop(idx)
            ZCAN_CloseDevice(h)
            print(f"[*] 设备 {idx} 已关闭")
        if self.log_opened: 
            ZCAN_CloseLog()
            print("[*] 日志已关闭")
        print("[*] 程序退出")

    def get_dev_handle(self, args):
        idx = safe_int(self.extract_arg(args, "-dev", "0"))
        if idx in self.dev_handles: return idx, self.dev_handles[idx]
        print(f"[!] 设备 {idx} 未打开"); return idx, None

    def get_ch_handle(self, args):
        dev = safe_int(self.extract_arg(args, "-dev", "0"))
        ch = safe_int(self.extract_arg(args, "-ch", "0"))
        if (dev, ch) in self.ch_handles: return dev, ch, self.ch_handles[(dev, ch)]
        print(f"[!] 通道 {dev}-{ch} 未初始化"); return dev, ch, None

    # --- Commands ---

    def do_log(self, args):
        if not ZCAN_OpenLog: return
        mode = args[1].lower() if len(args) > 1 else "on"
        if mode == "on":
            if not self.log_opened and ZCAN_OpenLog(b"zlg_debug.log", 0, 5, 5) == STATUS_OK:
                self.log_opened = True; print("[*] 日志已开启")
        else:
            if self.log_opened: ZCAN_CloseLog(); self.log_opened = False; print("[*] 日志已关闭")

    def do_scan(self, args):
        if not ZCAN_ScanDevice: print("[!] DLL 不支持 ScanDevice"); return
        wait_time = safe_int(self.extract_arg(args, "-wait", "500"))
        print(f"[*] 开始扫描 (超时 {wait_time}ms)...")
        max_count = 20
        indices = (UINT * max_count)()
        count = UINT(max_count)
        ret = ZCAN_ScanDevice(indices, byref(count), wait_time)
        if ret == 1:
            print(f"[*] 发现 {count.value} 个设备:")
            for i in range(count.value):
                print(f"    - Device Index: {indices[i]}")
        else:
            print("[!] 扫描失败")

    def do_open(self, args):
        idx = safe_int(self.extract_arg(args, "-dev", "0"))
        res = safe_int(self.extract_arg(args, "-res", "0"))
        if idx in self.dev_handles: print(f"[!] 设备 {idx} 已存在"); return
        print(f"[*] 打开设备 {idx} ...")
        h = ZCAN_OpenDevice(ZCAN_USBCAN_2E_U, idx, res)
        if h: self.dev_handles[idx] = h; print(f"[*] 成功, Handle: {h}")
        else: print("[!] 打开失败")

    def do_close(self, args):
        idx, h = self.get_dev_handle(args)
        if h:
            ZCAN_CloseDevice(h); del self.dev_handles[idx]
            self.ch_handles = {k:v for k,v in self.ch_handles.items() if k[0]!=idx}
            self.ch_configs = {k:v for k,v in self.ch_configs.items() if k[0]!=idx}
            print(f"[*] 设备 {idx} 已关闭")

    def do_info(self, args):
        idx, h = self.get_dev_handle(args)
        if h:
            inf = ZCAN_DEVICE_INFO()
            if ZCAN_GetDeviceInf(h, byref(inf)) == STATUS_OK:
                print(f"[*] HW:{inf.can_Num} Channels")
            else: print("[!] 获取失败")

    def do_init(self, args):
        idx, h = self.get_dev_handle(args)
        if not h: return
        ch = safe_int(self.extract_arg(args, "-ch", "0"))
        mode_str = self.extract_arg(args, "-mode", "can").lower()
        
        cfg = ZCAN_CHANNEL_INIT_CONFIG()
        cfg.config.can.acc_mask = 0xFFFFFFFF
        cfg.config.can.filter = 1 # Dual filter

        if mode_str == "canfd":
            print("[*] 初始化 CANFD")
            cfg.can_type = TYPE_CANFD
            cfg.config.canfd.abit_timing = safe_int(self.extract_arg(args, "-abit", "500000"))
            cfg.config.canfd.dbit_timing = safe_int(self.extract_arg(args, "-dbit", "2000000"))
            cfg.config.canfd.mode = 0
            self.ch_configs[(idx, ch)] = "canfd"
        else:
            print("[*] 初始化 CAN")
            cfg.can_type = TYPE_CAN
            baud = safe_int(self.extract_arg(args, "-baud", "500000"))
            t0, t1 = get_baud_timing(baud)
            cfg.config.can.timing0 = t0; cfg.config.can.timing1 = t1; cfg.config.can.mode = 0
            self.ch_configs[(idx, ch)] = "can"

        h_ch = ZCAN_InitCAN(h, ch, byref(cfg))
        if h_ch:
            self.ch_handles[(idx, ch)] = h_ch
            print(f"[*] 通道 {idx}-{ch} 初始化成功")
        else: print("[!] 初始化失败")

    def do_start(self, args):
        _, _, h = self.get_ch_handle(args)
        if h and ZCAN_StartCAN(h) == STATUS_OK: print("[*] 启动成功")
        else: print("[!] 启动失败")

    def do_reset(self, args):
        _, _, h = self.get_ch_handle(args)
        if h: ZCAN_ResetCAN(h); print("[*] 复位成功")

    def do_send(self, args):
        dev_idx, ch_idx, h_ch = self.get_ch_handle(args)
        if not h_ch: return
        
        _, h_dev = self.get_dev_handle(args) # TransmitData need Device Handle

        cid = safe_int(self.extract_arg(args, "-id", "0"))
        data = []
        if "-data" in args:
            for x in args[args.index("-data")+1:]:
                if x.startswith("-"): break
                data.append(safe_int(x))
        if not data: data = [0]*8
        
        # 自动检测是否需要 FD 发送
        is_fd_init = (self.ch_configs.get((dev_idx, ch_idx)) == "canfd")
        is_fd_arg = safe_int(self.extract_arg(args, "-fd", "0"))
        use_fd = is_fd_init or is_fd_arg
        
        # 使用 ZCAN_TransmitData (通用接口) 测试
        if "-generic" in args:
            obj = ZCANDataObj()
            obj.dataType = ZCAN_DT_ZCAN_CAN_CANFD_DATA
            obj.chnl = ch_idx
            
            # Setup FD flag
            if use_fd:
                obj.data.zcanCANFDData.flag.unionVal.frameType = 1 # FD
                if len(data) > 8: # BRS assumption for large data
                    obj.data.zcanCANFDData.frame.flags = 0x01
            else:
                obj.data.zcanCANFDData.flag.unionVal.frameType = 0 # CAN
            
            obj.data.zcanCANFDData.frame.can_id = cid
            obj.data.zcanCANFDData.frame.len = len(data)
            for i, val in enumerate(data[:64]):
                obj.data.zcanCANFDData.frame.data[i] = val
            
            ret = ZCAN_TransmitData(h_dev, byref(obj), 1)
            print(f"[*] Generic Transmit Result: {ret}")
            return

        # 使用 TransmitFD
        if use_fd:
            t = ZCAN_TransmitFD_Data()
            t.frame.can_id = cid
            t.frame.len = len(data)
            t.frame.flags = 0x01 # Bitrate Switch
            for i, val in enumerate(data[:64]): t.frame.data[i] = val
            ret = ZCAN_TransmitFD(h_ch, byref(t), 1)
            print(f"[*] FD Transmit Result: {ret}")
        else:
            # Standard
            t = ZCAN_Transmit_Data()
            t.frame.can_id = cid
            t.frame.can_dlc = len(data)
            for i, val in enumerate(data[:8]): t.frame.data[i] = val
            ret = ZCAN_Transmit(h_ch, byref(t), 1)
            print(f"[*] Legacy Transmit Result: {ret}")

    def do_recv(self, args):
        dev_idx, ch_idx, h_ch = self.get_ch_handle(args)
        if not h_ch: return
        _, h_dev = self.get_dev_handle(args)

        wait_time = safe_int(self.extract_arg(args, "-wait", "-1")) # 默认为 -1 阻塞
        method = self.extract_arg(args, "-method", "legacy") # legacy, fd, data

        print(f"[*] 接收模式: {method}, Wait: {wait_time}ms ...")

        if method == "data":
            # 通用接口 (需要设备句柄)
            cnt = 50
            objs = (ZCANDataObj * cnt)()
            real = ZCAN_ReceiveData(h_dev, objs, cnt, wait_time)
            print(f"[*] RecvData 收到 {real} 帧")
            for i in range(real):
                fdata = objs[i].data.zcanCANFDData
                fid = fdata.frame.can_id
                flen = fdata.frame.len
                print(f"  [DataObj] Ch:{objs[i].chnl} ID:{fid:X} Len:{flen} Data:{hex_dump(fdata.frame.data, flen)}")

        elif method == "fd":
            # FD 接口
            cnt = 50
            objs = (ZCAN_ReceiveFD_Data * cnt)()
            real = ZCAN_ReceiveFD(h_ch, objs, cnt, wait_time)
            print(f"[*] RecvFD 收到 {real} 帧")
            for i in range(real):
                f = objs[i].frame
                print(f"  [FD] ID:{f.can_id:X} Len:{f.len} Flags:{f.flags} Data:{hex_dump(f.data, f.len)}")

        else:
            # Legacy 接口
            cnt = 50
            objs = (ZCAN_Receive_Data * cnt)()
            real = ZCAN_Receive(h_ch, objs, cnt, wait_time)
            print(f"[*] Recv 收到 {real} 帧")
            for i in range(real):
                f = objs[i].frame
                print(f"  [Legacy] ID:{f.can_id:X} DLC:{f.can_dlc} Data:{hex_dump(f.data, f.can_dlc)}")

    def do_autorecv(self, args):
        if "off" in args: self.stop_autorecv(); return
        dev, ch, h = self.get_ch_handle(args)
        if not h or self.auto_recv_thread: return
        
        _, h_dev = self.get_dev_handle(args)

        self.auto_recv_flag = True
        
        # 解析参数传给线程
        self.auto_recv_args = {
            "h_ch": h, 
            "h_dev": h_dev,
            "method": self.extract_arg(args, "-method", "legacy")
        }

        self.auto_recv_thread = threading.Thread(target=self._worker)
        self.auto_recv_thread.daemon = True
        self.auto_recv_thread.start()
        print(f"[*] 自动接收开启 {dev}-{ch} Mode: {self.auto_recv_args['method']}")

    def stop_autorecv(self):
        if self.auto_recv_thread:
            self.auto_recv_flag = False; self.auto_recv_thread.join(1); self.auto_recv_thread = None
            print("[*] 自动接收停止")

    def _worker(self):
        h_ch = self.auto_recv_args["h_ch"]
        h_dev = self.auto_recv_args["h_dev"]
        method = self.auto_recv_args["method"]

        while self.auto_recv_flag:
            try:
                # 使用 -1 阻塞模式测试优化后的逻辑
                # 或者使用 100ms 超时
                wait_time = 100 
                
                real_cnt = 0
                output = []

                if method == "data":
                    cnt = 10
                    objs = (ZCANDataObj * cnt)()
                    real_cnt = ZCAN_ReceiveData(h_dev, objs, cnt, wait_time)
                    for i in range(real_cnt):
                        f = objs[i].data.zcanCANFDData.frame
                        output.append(f"[Data] ID:{f.can_id:08X} Len:{f.len} Data:{hex_dump(f.data, f.len)}")
                elif method == "fd":
                    cnt = 10
                    objs = (ZCAN_ReceiveFD_Data * cnt)()
                    real_cnt = ZCAN_ReceiveFD(h_ch, objs, cnt, wait_time)
                    for i in range(real_cnt):
                        f = objs[i].frame
                        output.append(f"[FD] ID:{f.can_id:08X} Len:{f.len} Data:{hex_dump(f.data, f.len)}")
                else:
                    cnt = 10
                    objs = (ZCAN_Receive_Data * cnt)()
                    real_cnt = ZCAN_Receive(h_ch, objs, cnt, wait_time)
                    for i in range(real_cnt):
                        f = objs[i].frame
                        output.append(f"[Legacy] ID:{f.can_id:08X} DLC:{f.can_dlc} Data:{hex_dump(f.data, f.can_dlc)}")

                if real_cnt > 0:
                    sys.stdout.write("\r\033[K")
                    for line in output:
                        print(line)
                    sys.stdout.write("ZLG>>> ")
                    sys.stdout.flush()
                else:
                    # 如果是 polling 模式 (wait=0)，加一点 sleep 防止 CPU 100%
                    if wait_time == 0: time.sleep(0.01)

            except Exception as e:
                print(f"[!] Thread Error: {e}"); break

if __name__ == "__main__":
    ZlgCanTest().run()
