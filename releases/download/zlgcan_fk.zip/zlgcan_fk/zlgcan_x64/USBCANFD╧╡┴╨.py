'''
    支持的设备有 USBCANFD-100U mini   USBCANFD-100U/200U/400U/800U
    例程使用之前，请确定 opendevice 打开的是对应型号的设备
'''

from zlgcan import *
import threading
import time
import signal
import sys
import os

# 全局变量，用于在信号处理函数中访问
g_zcanlib = None
g_device_handle = INVALID_DEVICE_HANDLE
g_chn_handles = []
g_threads = []
g_thread_flag = True
g_print_lock = threading.Lock() 

enable_merge_receive = 0        # 合并接收标识
enable_bus_usage = 0            # 总线利用率上报标识

# ---------------------------------------------------------
# 辅助功能函数
# ---------------------------------------------------------

# 读取设备信息
def Read_Device_Info(device_handle):
    info = g_zcanlib.GetDeviceInf(device_handle)
    if info:
        print("设备信息: \n%s" % info)
        print("----------------------: %s" % info.fw_version)
        return info.can_num
    else:
        print("获取设备信息失败")
        return 0

# 接收线程函数
def receive_thread(device_handle, chn_handle):
    CANType_width = len("CANFD加速    ")
    id_width = len(hex(0x1FFFFFFF))

    while g_thread_flag:
        time.sleep(0.005)
        # 1. 接收 CAN 报文
        rcv_num = g_zcanlib.GetReceiveNum(chn_handle, ZCAN_TYPE_CAN)
        if rcv_num:
            read_cnt = 100 if rcv_num > 100 else rcv_num
            rcv_msg, rcv_actual = g_zcanlib.Receive(chn_handle, read_cnt, 100)
            with g_print_lock:
                for msg in rcv_msg[:rcv_actual]:
                    frame = msg.frame
                    can_type = "CAN   "
                    direction = "TX" if frame._pad & 0x20 else "RX"
                    frame_type = "扩展帧" if frame.can_id & (1 << 31) else "标准帧"
                    frame_format = "远程帧" if frame.can_id & (1 << 30) else "数据帧"
                    can_id = hex(frame.can_id & 0x1FFFFFFF)

                    data_str = ""
                    dlc = 0
                    if not (frame.can_id & (1 << 30)):
                        dlc = frame.can_dlc
                        data_str = " ".join([f"{num:02X}" for num in frame.data[:dlc]])

                    print(f"[{msg.timestamp}] CAN{chn_handle & 0xFF} {can_type:<{CANType_width}}\t{direction} ID: {can_id:<{id_width}}\t{frame_type} {frame_format}"
                          f" DLC: {dlc}\tDATA(hex): {data_str}")

        # 2. 接收 CANFD 报文
        rcv_canfd_num = g_zcanlib.GetReceiveNum(chn_handle, ZCAN_TYPE_CANFD)
        if rcv_canfd_num:
            read_cnt = 100 if rcv_canfd_num > 100 else rcv_canfd_num
            rcv_canfd_msgs, rcv_actual = g_zcanlib.ReceiveFD(chn_handle, read_cnt, 100)
            with g_print_lock:
                for msg in rcv_canfd_msgs[:rcv_actual]:
                    frame = msg.frame
                    brs = "加速" if frame.flags & 0x1 else "   "
                    can_type = "CANFD" + brs
                    direction = "TX" if frame.flags & 0x20 else "RX"
                    frame_type = "扩展帧" if frame.can_id & (1 << 31) else "标准帧"
                    frame_format = "远程帧" if frame.can_id & (1 << 30) else "数据帧"
                    can_id = hex(frame.can_id & 0x1FFFFFFF)
                    data_str = " ".join([f"{num:02X}" for num in frame.data[:frame.len]])

                    print(f"[{msg.timestamp}] CAN{chn_handle & 0xFF} {can_type:<{CANType_width}}\t{direction} ID: {can_id:<{id_width}}\t{frame_type} {frame_format}"
                          f" DLC: {frame.len}\tDATA(hex): {data_str}")

# 设置滤波  白名单过滤(只接收范围内的数据)
def Set_Filter(device_handle, chn):
    print(f"正在配置通道 {chn} 的滤波...")
    
    # 1. 清除滤波
    ret = g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_clear", "0".encode("utf-8"))
    if ret != ZCAN_STATUS_OK:
        print("Set CH%d filter_clear failed!" % chn)
        return None

    # 流程为：for【set_mode(与前一组滤波同类型可以省略) + set_start + set_end】+ ack
    
    # --- 第一组：标准帧 0~0x7F ---
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_mode", "0".encode("utf-8"))  # 标准帧
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_start", "0".encode("utf-8"))
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_end", "0x7F".encode("utf-8"))
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_ack", "0".encode("utf-8")) # 提交

    # --- 第二组：标准帧 0xFF~0x1FF ---
    # mode 与上一组相同，可省略 set_mode
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_start", "0xFF".encode("utf-8"))
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_end", "0x1FF".encode("utf-8"))
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_ack", "0".encode("utf-8")) # 提交

    # --- 第三组：扩展帧 0xFF~0x2FF ---
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_mode", "1".encode("utf-8"))  # 扩展帧
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_start", "0xFF".encode("utf-8"))
    g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_end", "0x2FF".encode("utf-8"))
    
    ret = g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/filter_ack", "0".encode("utf-8"))  # 提交
    if ret != ZCAN_STATUS_OK:
        print("Set CH%d filter_ack failed!" % chn)
    else:
        print(f"通道 {chn} 滤波设置成功")

# 启动通道
def USBCANFD_Start(zcanlib, device_handle, chn):
    # 设置波特率 仲裁域500k 数据域2M
    ret = zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/canfd_abit_baud_rate", "500000".encode("utf-8"))
    ret = zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/canfd_dbit_baud_rate", "2000000".encode("utf-8"))
    
    # 开启终端电阻
    ret = zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/initenal_resistance", "1".encode("utf-8"))

    # 初始化通道
    chn_init_cfg = ZCAN_CHANNEL_INIT_CONFIG()
    chn_init_cfg.can_type = ZCAN_TYPE_CANFD
    chn_init_cfg.config.canfd.mode = 0  # 0-正常模式
    chn_handle = zcanlib.InitCAN(device_handle, chn, chn_init_cfg)
    
    if chn_handle is None or chn_handle == 0:
        print("initCAN failed for channel %d!" % chn)
        return None

    # 设置滤波 (在StartCAN之前)
    # 如果不需要滤波测试，注释掉下面这一行即可
    Set_Filter(device_handle, chn)

    # 启动通道
    ret = zcanlib.StartCAN(chn_handle)
    if ret != ZCAN_STATUS_OK:
        print("startCAN failed for channel %d!" % chn)
        return None

    return chn_handle

# 定时发送设置
def Auto_Send_test(device_handle, chn):
    # 先清除
    zcanlib = g_zcanlib
    ret = zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/clear_auto_send", "0".encode("utf-8"))
    
    # 添加一条 CANFD 定时发送
    auto_canfd = ZCANFD_AUTO_TRANSMIT_OBJ()
    memset(addressof(auto_canfd), 0, sizeof(auto_canfd))
    auto_canfd.index = 0
    auto_canfd.enable = 1
    auto_canfd.interval = 1000 # 1000ms = 1s
    auto_canfd.obj.transmit_type = 0
    auto_canfd.obj.frame.can_id = 0x100
    auto_canfd.obj.frame.len = 64
    for j in range(64):
        auto_canfd.obj.frame.data[j] = j

    ret = zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/auto_send", byref(auto_canfd))
    if ret != ZCAN_STATUS_OK:
        print("设置定时发送失败!")
    else:
        print("设置定时发送成功 (ID:0x100, 1s周期)")

    # 应用
    ret = zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/apply_auto_send", "0".encode("utf-8"))

# 关闭发送任务
def Clear_Send_Task(device_handle, chn):
    if g_zcanlib:
        g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/clear_auto_send", "0".encode("utf-8"))
        g_zcanlib.ZCAN_SetValue(device_handle, str(chn) + "/clear_delay_send_queue", "0".encode("utf-8"))

# 发送测试
def Transmit_Test(chn_handle):
    # 发送 CANFD 报文
    transmit_num = 10
    msgs = (ZCAN_TransmitFD_Data * transmit_num)()
    for i in range(transmit_num):
        msgs[i].transmit_type = 0
        msgs[i].frame.can_id = 0x100 + i
        msgs[i].frame.len = 64
        msgs[i].frame.flags = 0 # 0x1 for BRS
        for j in range(64):
            msgs[i].frame.data[j] = i + j
            
    ret = g_zcanlib.TransmitFD(chn_handle, msgs, transmit_num)
    print("成功发送 %d 条CANFD报文" % ret)

# 总线利用率线程
def read_bus_usage(device_handle, chn_index):
    while g_thread_flag:
        time.sleep(1)
        pBus = g_zcanlib.ZCAN_GetValue(device_handle, "0/get_bus_usage/1")
        if pBus:
            usage = cast(pBus, POINTER(BusUsage))
            new_usage = float(usage.contents.nBusUsage) / 100
            # print(f"busload: {new_usage:.2f}%")

# ---------------------------------------------------------
# 资源清理与程序入口
# ---------------------------------------------------------

def cleanup():
    """清理所有资源，确保日志写入磁盘"""
    global g_thread_flag, g_zcanlib, g_device_handle, g_chn_handles, g_threads

    print("\n--- 开始清理资源 ---")
    
    # 1. 停止线程
    g_thread_flag = False
    for t in g_threads:
        if t.is_alive():
            t.join(timeout=1.0) # 等待线程结束
    
    if g_zcanlib and g_device_handle != INVALID_DEVICE_HANDLE:
        # 2. 停止定时发送
        Clear_Send_Task(g_device_handle, 0)
        
        # 3. 复位通道
        for chn in g_chn_handles:
            g_zcanlib.ResetCAN(chn)
            print(f"通道 {chn} 已复位")
        
        # 4. 关闭设备
        g_zcanlib.CloseDevice(g_device_handle)
        print("设备已关闭")
        g_device_handle = INVALID_DEVICE_HANDLE

        # 5. 【关键】关闭日志
        g_zcanlib.CloseLog()
        print("日志已关闭 (zlgcan.log)")

    print("资源清理完毕。")

def signal_handler(sig, frame):
    """处理 Ctrl+C 信号"""
    print(f"\n接收到中断信号 ({sig})，正在退出...")
    cleanup()
    sys.exit(0)

def main():
    global g_zcanlib, g_device_handle, g_chn_handles, g_threads

    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    g_zcanlib = ZCAN()

    # 开启日志
    log_file = "zlgcan.log"
    # 如果文件存在，先删除，确保看到的是新的
    if os.path.exists(log_file):
        try: os.remove(log_file)
        except: pass
    
    ret = g_zcanlib.OpenLog(log_file, 0, 10, 5) # level 0=DEBUG
    if ret == ZCAN_STATUS_OK:
        print("日志已开启: %s" % log_file)
    else:
        print("日志开启失败")

    # 打开设备
    print("正在打开设备...")
    # 注意：请根据实际设备类型修改第一个参数
    handle = g_zcanlib.OpenDevice(ZCAN_USBCANFD_200U, 1, 0)
    if handle == INVALID_DEVICE_HANDLE:
        print("打开设备失败！")
        g_zcanlib.CloseLog()
        return

    g_device_handle = handle
    print("设备句柄: %d" % handle)

    # 获取通道数
    can_number = Read_Device_Info(handle)
    # 如果 DLL 尚未修复，可能返回 8，这里做一个保护
    if can_number >= 2: can_number = 2 
    
    print(f"检测到设备通道数: {can_number}")

    # 启动通道
    for i in range(can_number):
        chn_handle = USBCANFD_Start(g_zcanlib, handle, i)
        if chn_handle:
            g_chn_handles.append(chn_handle)
            print(f"通道 {i} 启动成功，句柄: {chn_handle}")
        else:
            print(f"通道 {i} 启动失败 (可能不存在)，跳过。")
            # 如果是顺序的，通常遇到失败就可以停止尝试了
            # break 

    if not g_chn_handles:
        print("没有成功启动任何通道，程序退出。")
        cleanup()
        return

    # 启动接收线程
    if enable_merge_receive == 1:
        t = threading.Thread(target=receive_thread, args=(handle, g_chn_handles[0]))
        t.daemon = True # 设置为守护线程，防止阻塞退出
        g_threads.append(t)
        t.start()
    else:
        for chn_handle in g_chn_handles:
            t = threading.Thread(target=receive_thread, args=(handle, chn_handle))
            t.daemon = True
            g_threads.append(t)
            t.start()

    if enable_bus_usage:
        t = threading.Thread(target=read_bus_usage, args=(handle, 0))
        t.daemon = True
        g_threads.append(t)
        t.start()

    # 测试功能
    print("\n开始发送测试数据...")
    Transmit_Test(g_chn_handles[0])
    
    # 定时发送 (可选)
    # Auto_Send_test(handle, 0)

    print("\n" + "="*50)
    print("程序正在运行中...")
    print("按 Enter 键停止并退出，或按 Ctrl+C 强制退出。")
    print("="*50 + "\n")

    # 主循环等待
    try:
        # 使用 input() 阻塞主线程
        input() 
    except KeyboardInterrupt:
        # 即使 input 被中断，这里也能捕获到
        pass
    except Exception as e:
        print(f"发生未知错误: {e}")
    
    # 正常退出流程
    cleanup()

if __name__ == "__main__":
    main()
