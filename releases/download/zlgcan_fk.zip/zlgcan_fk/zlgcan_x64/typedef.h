#ifndef TYPEDEF_H_
#define TYPEDEF_H_

typedef unsigned char      BYTE;
typedef unsigned int       UINT;
typedef unsigned long      ULONG;
typedef unsigned long long UINT64;
typedef unsigned short     USHORT;
typedef unsigned char      UCHAR;

#endif //TYPEDEF_H_
