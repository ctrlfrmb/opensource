#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# LxiClient.py - LXI客户端Python封装实现 (v2.1.0)

from LxiMessage import *
import ctypes
import platform
import os
import threading
import time

class LxiClient:
    def __init__(self, lib_path=None):
        self.lxi_dll = None
        self.instance_id = None
        self.current_sampling_info = None
        self._load_dll(lib_path)
        
        self._auto_read_thread = None
        self._auto_read_stop_event = None

    def _load_dll(self, lib_path):
        if lib_path is None:
            arch = platform.architecture()[0]
            if arch == "64bit":
                lib_path = os.path.abspath("./lib/Winx64")
            else:
                lib_path = os.path.abspath("./lib/Winx86")
        
        if not os.path.isdir(lib_path):
            print(f"错误: 库路径 '{lib_path}' 不存在或不是一个目录。")
            raise FileNotFoundError(f"Library path not found: {lib_path}")

        os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
        print(f"加载库路径: {lib_path}")

        try:
            if platform.system() == "Windows":
                dll_name = "lxi_api.dll"
                self.lxi_dll = ctypes.WinDLL(os.path.join(lib_path, dll_name))
            else:
                dll_name = "liblxi_api.so"
                self.lxi_dll = ctypes.CDLL(os.path.join(lib_path, dll_name))
        except OSError as e:
            print(f"加载 {dll_name} 失败: {e}")
            raise

        self._define_api_prototypes()
        
        log_path = b"lxi_client_test.log"
        self.lxi_dll.LXIOpenLog(log_path, 1, 5, 10)
        print("LXI API 库加载成功，日志已自动打开 -> lxi_client_test.log")

    def _define_api_prototypes(self):
        self.lxi_dll.LXIOpenLog.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
        self.lxi_dll.LXIConnect.argtypes = [ctypes.c_char_p]
        self.lxi_dll.LXIDisconnect.argtypes = [ctypes.c_int]
        self.lxi_dll.LXIClearAll.argtypes = []
        self.lxi_dll.LXICloseLog.argtypes = []
        self.lxi_dll.LXIAIStartSampling.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.lxi_dll.LXIAIStopSampling.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.lxi_dll.LXIAIGetSamplingInfo.argtypes = [ctypes.c_int, ctypes.POINTER(LxiSamplingInfo)]
        
        self.lxi_dll.LXIAIReadVoltages.argtypes = [ctypes.c_int, ctypes.POINTER(LxiVoltagePacket), ctypes.POINTER(ctypes.c_int)]
        self.lxi_dll.LXIAIReadResponse.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_ubyte), ctypes.POINTER(ctypes.c_int)]
        
        self.lxi_dll.LXIOpenLog.restype = ctypes.c_int
        self.lxi_dll.LXIConnect.restype = ctypes.c_int
        self.lxi_dll.LXIDisconnect.restype = ctypes.c_int
        self.lxi_dll.LXIClearAll.restype = ctypes.c_int
        self.lxi_dll.LXICloseLog.restype = ctypes.c_int
        self.lxi_dll.LXIAIStartSampling.restype = ctypes.c_int
        self.lxi_dll.LXIAIStopSampling.restype = ctypes.c_int
        self.lxi_dll.LXIAIGetSamplingInfo.restype = ctypes.c_int
        self.lxi_dll.LXIAIReadVoltages.restype = ctypes.c_int
        self.lxi_dll.LXIAIReadResponse.restype = ctypes.c_int

    def connect(self, connect_params):
        if self.is_connected():
            print("错误: 客户端已连接。请先断开连接。")
            return False
        # connect 接口的返回值是特殊的：>0 是ID，<0 是错误码
        result = self.lxi_dll.LXIConnect(connect_params.encode('utf-8'))
        if result > 0:
            self.instance_id = result
            print(f"连接成功，实例 ID: {self.instance_id}")
            return True
        else:
            print(f"连接失败: {get_status_description(result)} (错误码: {result})")
            return False

    def disconnect(self):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
        self.stop_auto_read()
        status = self.lxi_dll.LXIDisconnect(self.instance_id)
        if status == LXI_RESULT_OK:
            print("成功断开连接。")
            self.instance_id = None
            self.current_sampling_info = None
            return True
        else:
            print(f"断开连接失败: {get_status_description(status)} (错误码: {status})")
            return False

    def start_sampling(self, params_str):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
        status = self.lxi_dll.LXIAIStartSampling(self.instance_id, params_str.encode('utf-8'))
        if status == LXI_RESULT_OK:
            print("启动采样命令已发送并被设备确认。")
            self.get_sampling_info() # 启动成功后自动获取一次信息
            return True
        else:
            print(f"启动采样失败: {get_status_description(status)} (错误码: {status})")
            return False

    def stop_sampling(self, params_str=""):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
        c_params = params_str.encode('utf-8') if params_str else None
        status = self.lxi_dll.LXIAIStopSampling(self.instance_id, c_params)
        if status == LXI_RESULT_OK:
            print("停止采样命令已发送并被设备确认。")
            return True
        else:
            print(f"停止采样失败: {get_status_description(status)} (错误码: {status})")
            return False

    def get_sampling_info(self):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return None
        info = LxiSamplingInfo()
        status = self.lxi_dll.LXIAIGetSamplingInfo(self.instance_id, ctypes.byref(info))
        if status == LXI_RESULT_OK:
            self.current_sampling_info = info
            return info
        else:
            print(f"获取采样信息失败: {get_status_description(status)} (错误码: {status})")
            return None

    def read_voltages(self, max_count=200):
        if not self.is_connected():
            return []
        
        buffer_type = LxiVoltagePacket * max_count
        buffer = buffer_type()
        # 创建 in/out 参数，并传入其地址
        count_in_out = ctypes.c_int(max_count)
        
        # 调用 C 函数，接收状态码
        status = self.lxi_dll.LXIAIReadVoltages(self.instance_id, buffer, ctypes.byref(count_in_out))
        
        # 检查状态码
        if status == LXI_RESULT_OK:
            # 成功时，实际读取数量在 count_in_out.value 中
            return [buffer[i] for i in range(count_in_out.value)]
        else:
            # 失败时，打印错误并返回空列表
            print(f"读取电压数据失败: {get_status_description(status)} (错误码: {status})")
            return []

    def read_response(self, buffer_size=256):
        if not self.is_connected():
            return None
            
        buffer = ctypes.create_string_buffer(buffer_size)
        buffer_ptr = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
        # 创建 in/out 参数，并传入其地址
        size_in_out = ctypes.c_int(buffer_size)
        
        # 调用 C 函数，接收状态码
        status = self.lxi_dll.LXIAIReadResponse(self.instance_id, buffer_ptr, ctypes.byref(size_in_out))
        
        # 检查状态码
        if status == LXI_RESULT_OK:
            # 成功时，实际读取字节数在 size_in_out.value 中
            return buffer.raw[:size_in_out.value]
        else:
            # 失败时，打印错误并返回 None
            print(f"读取响应失败: {get_status_description(status)} (错误码: {status})")
            return None

    def _auto_read_worker(self):
        print("\n[AutoRead] 线程已启动，开始接收数据...")
        if not self.current_sampling_info:
            self.get_sampling_info()
        
        while not self._auto_read_stop_event.is_set():
            packets = self.read_voltages(max_count=500)
            if packets:
                for packet in packets:
                    first_6_volts = packet.voltages[:6]
                    voltages_str = ", ".join(f"{v:.4f}" for v in first_6_volts)
                    
                    print(f"[AutoRead] -> Index={packet.index}, SN={packet.serial_code}, LastSN={packet.last_serial_code}, "
                          f"Voltages=[{voltages_str}]V")
            time.sleep(0.01)
        print("[AutoRead] 线程已停止。")

    def start_auto_read(self):
        if not self.is_connected():
            print("错误: 无法启动自动读取，客户端未连接。")
            return
        if self._auto_read_thread and self._auto_read_thread.is_alive():
            print("自动读取线程已在运行中。")
            return
        self._auto_read_stop_event = threading.Event()
        self._auto_read_thread = threading.Thread(target=self._auto_read_worker, daemon=True)
        self._auto_read_thread.start()

    def stop_auto_read(self):
        if self._auto_read_thread and self._auto_read_thread.is_alive():
            self._auto_read_stop_event.set()
            self._auto_read_thread.join(timeout=1)
        self._auto_read_thread = None
        self._auto_read_stop_event = None

    def clear_all(self):
        print("正在清理所有LXI客户端实例...")
        self.stop_auto_read()
        status = self.lxi_dll.LXIClearAll()
        if status == LXI_RESULT_OK:
            print("所有实例已清理。")
            self.instance_id = None
            self.current_sampling_info = None
            return True
        else:
            print(f"清理所有实例时发生未知错误: {get_status_description(status)}")
            return False

    def is_connected(self):
        return self.instance_id is not None

    def cleanup(self):
        print("开始清理资源...")
        self.stop_auto_read()
        if self.is_connected():
            self.disconnect()
        if self.lxi_dll:
            self.lxi_dll.LXICloseLog()
            print("日志已关闭。")
        print("资源清理完成。")
