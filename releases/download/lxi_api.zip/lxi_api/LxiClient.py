#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# LxiClient.py - LXI客户端Python封装实现

from LxiMessage import *
import ctypes
import platform
import os
import threading
import time

class LxiClient:
    def __init__(self, lib_path=None):
        """
        初始化LxiClient，加载动态链接库并设置函数原型。
        """
        self.lxi_dll = None
        self.instance_id = None
        self._load_dll(lib_path)
        
        self._auto_read_thread = None
        self._auto_read_stop_event = None

    def _load_dll(self, lib_path):
        """
        根据操作系统和架构加载lxi_api动态库。
        """
        if lib_path is None:
            arch = platform.architecture()[0]
            if arch == "64bit":
                lib_path = os.path.abspath("./lib/Winx64")
            else:
                lib_path = os.path.abspath("./lib/Winx86")
        
        os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
        print(f"加载库路径: {lib_path}")

        try:
            if platform.system() == "Windows":
                dll_name = "lxi_api.dll"
                self.lxi_dll = ctypes.WinDLL(os.path.join(lib_path, dll_name))
            else:
                dll_name = "liblxi_api.so"
                self.lxi_dll = ctypes.CDLL(os.path.join(lib_path, dll_name))
        except OSError as e:
            print(f"加载 {dll_name} 失败: {e}")
            raise

        self._define_api_prototypes()
        
        log_path = b"lxi_client_test.log"
        self.lxi_dll.LXIOpenLog(log_path, 1, -1, -1) # level=1 (INFO)
        print("LXI API 库加载成功，日志已自动打开 -> lxi_client_test.log")

    def _define_api_prototypes(self):
        """
        定义所有从DLL中调用的C函数的参数类型和返回类型。
        """
        self.lxi_dll.LXIOpenLog.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
        self.lxi_dll.LXIOpenLog.restype = ctypes.c_int

        self.lxi_dll.LXICloseLog.argtypes = []
        self.lxi_dll.LXICloseLog.restype = ctypes.c_int

        self.lxi_dll.LXIConnect.argtypes = [ctypes.c_char_p]
        self.lxi_dll.LXIConnect.restype = ctypes.c_int

        self.lxi_dll.LXIDisconnect.argtypes = [ctypes.c_int]
        self.lxi_dll.LXIDisconnect.restype = ctypes.c_int

        self.lxi_dll.LXIStartCollecting.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.lxi_dll.LXIStartCollecting.restype = ctypes.c_int

        self.lxi_dll.LXIStopCollecting.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.lxi_dll.LXIStopCollecting.restype = ctypes.c_int
        
        self.lxi_dll.LXIReadData.argtypes = [ctypes.c_int, ctypes.POINTER(LXIOutputData), ctypes.c_int]
        self.lxi_dll.LXIReadData.restype = ctypes.c_int

        self.lxi_dll.LXIReadResponse.argtypes = [ctypes.c_int, ctypes.POINTER(ctypes.c_ubyte), ctypes.c_int]
        self.lxi_dll.LXIReadResponse.restype = ctypes.c_int

        self.lxi_dll.LXIClearAll.argtypes = []
        self.lxi_dll.LXIClearAll.restype = ctypes.c_int

    def connect(self, server_ip, server_port, local_ip=None, local_port=0):
        if self.is_connected():
            print("错误: 客户端已连接。请先断开连接。")
            return False

        cmd_parts = [f"--serverIp {server_ip}", f"--serverPort {server_port}"]
        if local_ip: cmd_parts.append(f"--localIp {local_ip}")
        if local_port > 0: cmd_parts.append(f"--localPort {local_port}")
            
        commands = " ".join(cmd_parts)
        print(f"正在使用参数连接: \"{commands}\"")
        result = self.lxi_dll.LXIConnect(commands.encode('utf-8'))

        if result > 0:
            self.instance_id = result
            print(f"连接成功，实例 ID: {self.instance_id}")
            return True
        else:
            print(f"连接失败: {get_status_description(result)} (错误码: {result})")
            return False

    def disconnect(self):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
        
        self.stop_auto_read()
        print(f"正在断开实例 ID: {self.instance_id}...")
        status = self.lxi_dll.LXIDisconnect(self.instance_id)

        if status == LXI_RESULT_OK:
            print("成功断开连接。")
            self.instance_id = None
            return True
        else:
            print(f"断开连接失败: {get_status_description(status)} (错误码: {status})")
            return False

    def start_collecting(self, command_str):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
        
        print_command(command_str)
        status = self.lxi_dll.LXIStartCollecting(self.instance_id, command_str.encode('utf-8'))

        if status == LXI_RESULT_OK:
            print("启动采集命令发送成功。")
            return True
        else:
            print(f"启动采集命令发送失败: {get_status_description(status)} (错误码: {status})")
            return False

    def stop_collecting(self, command_str):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False

        print_command(command_str)
        status = self.lxi_dll.LXIStopCollecting(self.instance_id, command_str.encode('utf-8'))
        
        if status == LXI_RESULT_OK:
            print("停止采集命令发送成功。")
            return True
        else:
            print(f"停止采集命令发送失败: {get_status_description(status)} (错误码: {status})")
            return False

    def read_data(self, max_count=200):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return []
        
        buffer_type = LXIOutputData * max_count
        buffer = buffer_type()
        
        count_read = self.lxi_dll.LXIReadData(self.instance_id, buffer, max_count)
        
        if count_read >= 0:
            return [buffer[i] for i in range(count_read)]
        else:
            print(f"读取数据失败: {get_status_description(count_read)} (错误码: {count_read})")
            return []

    def read_response(self, buffer_size=256):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return None
        
        buffer = ctypes.create_string_buffer(buffer_size)
        buffer_ptr = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
        
        bytes_read = self.lxi_dll.LXIReadResponse(self.instance_id, buffer_ptr, buffer_size)
        
        if bytes_read >= 0:
            return buffer.raw[:bytes_read]
        else:
            print(f"读取响应失败: {get_status_description(bytes_read)} (错误码: {bytes_read})")
            return None

    def _auto_read_worker(self):
        print("\n[AutoRead] 线程已启动。")
        while not self._auto_read_stop_event.is_set():
            packets = self.read_data(max_count=500)
            if packets:
                for pkt in packets:
                    print(f"[AutoRead] -> Index: {pkt.index:<8} SN: {pkt.serial_code:<3} Last SN: {pkt.last_serial_code:<3}")
            else:
                time.sleep(0.001)
        print("[AutoRead] 线程已停止。")

    def start_auto_read(self):
        if not self.is_connected():
            print("错误: 客户端未连接，无法启动自动读取。")
            return
        if self._auto_read_thread and self._auto_read_thread.is_alive():
            print("自动读取线程已在运行中。")
            return

        self._auto_read_stop_event = threading.Event()
        self._auto_read_thread = threading.Thread(target=self._auto_read_worker, daemon=True)
        self._auto_read_thread.start()

    def stop_auto_read(self):
        if self._auto_read_thread and self._auto_read_thread.is_alive():
            print("正在停止自动读取线程...")
            self._auto_read_stop_event.set()
            self._auto_read_thread.join(timeout=2)
            if self._auto_read_thread.is_alive():
                print("警告: 自动读取线程未能正常停止。")
        self._auto_read_thread = None
        self._auto_read_stop_event = None

    def clear_all(self):
        print("正在清理所有LXI客户端实例...")
        self.stop_auto_read()
        status = self.lxi_dll.LXIClearAll()
        if status == LXI_RESULT_OK:
            print("所有实例已清理。")
            self.instance_id = None
            return True
        else:
            print(f"清理所有实例时发生未知错误: {get_status_description(status)}")
            return False

    def is_connected(self):
        return self.instance_id is not None

    def cleanup(self):
        print("开始清理资源...")
        self.stop_auto_read()
        if self.is_connected():
            self.disconnect()
        
        if self.lxi_dll:
            self.lxi_dll.LXICloseLog()
            print("日志已关闭。")
        print("资源清理完成。")
