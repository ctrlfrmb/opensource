﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: leiwei
LxiClient.py - LXI 客户端 Python 封装实现

v3.6.0 更新：
- 与 DLL v3.6.0 对齐；量程换算按协议满量程定义同步

v3.4.0 更新：
- AutoRead 识别 LXI_RESULT_PACKET_LOSS
- cleanup() 末尾调用 LXICloseLog() 确保 DLL 日志刷盘
- 新增 close_log() 方法
- disconnect() 未连接时静默返回
"""

from LxiMessage import *
import ctypes
import platform
import os
import threading
import time


class LxiClient:
    """LXI 数据采集卡客户端封装类"""
    
    def __init__(self, lib_path=None):
        self.lxi_dll = None
        self.instance_id = None
        self.current_sampling_info = None
        self.current_channel_config = None
        self.current_read_mode = "single"
        
        self._auto_read_thread = None
        self._auto_read_stop_event = None
        self._cleaned_up = False
        
        self._load_dll(lib_path)

    def _load_dll(self, lib_path):
        """加载 DLL/SO 库"""
        if lib_path is None:
            arch = platform.architecture()[0]
            if arch == "64bit":
                lib_path = os.path.abspath("./lib/Winx64")
            else:
                lib_path = os.path.abspath("./lib/Winx86")
        
        if not os.path.isdir(lib_path):
            print(f"错误: 库路径 '{lib_path}' 不存在。")
            raise FileNotFoundError(f"Library path not found: {lib_path}")

        os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
        print(f"加载库路径: {lib_path}")

        try:
            if platform.system() == "Windows":
                dll_name = "lxi_api.dll"
                self.lxi_dll = ctypes.WinDLL(os.path.join(lib_path, dll_name))
            else:
                dll_name = "liblxi_api.so"
                self.lxi_dll = ctypes.CDLL(os.path.join(lib_path, dll_name))
        except OSError as e:
            print(f"加载 {dll_name} 失败: {e}")
            raise

        self._define_api_prototypes()
        
        os.makedirs("logs", exist_ok=True)
        log_path = os.path.join("logs", "lxi_client_test.log").encode("utf-8")
        self.lxi_dll.LXIOpenLog(log_path, 1, 20, 10)
        print("LXI API 库加载成功，日志 -> logs/lxi_client_test.log")

    def _define_api_prototypes(self):
        """定义所有 API 函数的原型"""
        
        self.lxi_dll.LXIOpenLog.argtypes = [
            ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_int
        ]
        self.lxi_dll.LXIOpenLog.restype = ctypes.c_int
        
        self.lxi_dll.LXICloseLog.argtypes = []
        self.lxi_dll.LXICloseLog.restype = ctypes.c_int
        
        self.lxi_dll.LXIConnect.argtypes = [ctypes.c_char_p]
        self.lxi_dll.LXIConnect.restype = ctypes.c_int
        
        self.lxi_dll.LXIDisconnect.argtypes = [ctypes.c_int]
        self.lxi_dll.LXIDisconnect.restype = ctypes.c_int
        
        self.lxi_dll.LXIClearAll.argtypes = []
        self.lxi_dll.LXIClearAll.restype = ctypes.c_int
        
        self.lxi_dll.LXIAIStartSampling.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.lxi_dll.LXIAIStartSampling.restype = ctypes.c_int
        
        self.lxi_dll.LXIAIStopSampling.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.lxi_dll.LXIAIStopSampling.restype = ctypes.c_int
        
        self.lxi_dll.LXIAIGetSamplingInfo.argtypes = [
            ctypes.c_int, ctypes.POINTER(LxiSamplingInfo)
        ]
        self.lxi_dll.LXIAIGetSamplingInfo.restype = ctypes.c_int
        
        self.lxi_dll.LXIAIGetChannelConfig.argtypes = [
            ctypes.c_int, ctypes.POINTER(LxiChannelConfig)
        ]
        self.lxi_dll.LXIAIGetChannelConfig.restype = ctypes.c_int
        
        self.lxi_dll.LXIAIGetSamplingRateCalibration.argtypes = [
            ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(ctypes.c_byte), ctypes.c_int
        ]
        self.lxi_dll.LXIAIGetSamplingRateCalibration.restype = ctypes.c_int
        
        self.lxi_dll.LXIAIGetNumChannels.argtypes = [ctypes.c_int]
        self.lxi_dll.LXIAIGetNumChannels.restype = ctypes.c_int
        
        self.lxi_dll.LXIAIReadData.argtypes = [
            ctypes.c_int,
            ctypes.POINTER(ctypes.c_float),
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.POINTER(ctypes.c_uint),
            ctypes.c_int
        ]
        self.lxi_dll.LXIAIReadData.restype = ctypes.c_int
        
        self.lxi_dll.LXIAIReadResponse.argtypes = [
            ctypes.c_int,
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.POINTER(ctypes.c_int)
        ]
        self.lxi_dll.LXIAIReadResponse.restype = ctypes.c_int

    # =========================================================================
    # 连接管理
    # =========================================================================
    
    def connect(self, connect_params):
        """连接到 LXI 设备"""
        if self.is_connected():
            print("警告: 客户端已连接，请先断开。")
            return False
            
        result = self.lxi_dll.LXIConnect(connect_params.encode('utf-8'))
        
        if result > 0:
            self.instance_id = result
            print(f"连接成功，实例 ID: {self.instance_id}")
            return True
        else:
            print(f"连接失败: {get_status_description(result)} (错误码: {result})")
            return False

    def disconnect(self):
        """断开与 LXI 设备的连接"""
        if not self.is_connected():
            return False
            
        self.stop_auto_read()
        
        status = self.lxi_dll.LXIDisconnect(self.instance_id)
        if status == LXI_RESULT_OK:
            print("成功断开连接。")
            self._reset_state()
            return True
        else:
            print(f"断开失败: {get_status_description(status)} (错误码: {status})")
            return False

    def is_connected(self):
        return self.instance_id is not None

    def _reset_state(self):
        self.instance_id = None
        self.current_sampling_info = None
        self.current_channel_config = None
        self.current_read_mode = "single"

    # =========================================================================
    # 采集控制
    # =========================================================================
    
    def start_sampling(self, params_str):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
        
        if "--readMode" in params_str:
            if "continue" in params_str.lower():
                self.current_read_mode = "continue"
            else:
                self.current_read_mode = "single"
        else:
            self.current_read_mode = "single"
            
        status = self.lxi_dll.LXIAIStartSampling(
            self.instance_id, params_str.encode('utf-8')
        )
        
        if status == LXI_RESULT_OK:
            print(f"启动采样成功 (读取模式: {self.current_read_mode.upper()})。")
            self.get_sampling_info()
            self.get_channel_config()
            return True
        else:
            print(f"启动采样失败: {get_status_description(status)} (错误码: {status})")
            return False

    def stop_sampling(self, params_str=""):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
            
        c_params = params_str.encode('utf-8') if params_str else None
        status = self.lxi_dll.LXIAIStopSampling(self.instance_id, c_params)
        
        if status == LXI_RESULT_OK:
            print("停止采样成功。")
            return True
        else:
            print(f"停止采样失败: {get_status_description(status)} (错误码: {status})")
            return False

    def get_sampling_info(self):
        if not self.is_connected():
            return None
        info = LxiSamplingInfo()
        status = self.lxi_dll.LXIAIGetSamplingInfo(self.instance_id, ctypes.byref(info))
        if status == LXI_RESULT_OK:
            self.current_sampling_info = info
            return info
        return None

    def get_channel_config(self):
        if not self.is_connected():
            return None
        config = LxiChannelConfig()
        status = self.lxi_dll.LXIAIGetChannelConfig(self.instance_id, ctypes.byref(config))
        if status == LXI_RESULT_OK:
            self.current_channel_config = config
            return config
        return None

    def get_num_channels(self):
        if not self.is_connected():
            return LXI_RESULT_INVALID_INSTANCE_ID
        return self.lxi_dll.LXIAIGetNumChannels(self.instance_id)

    # =========================================================================
    # 采样率标定值读取
    # =========================================================================
    
    def get_sampling_rate_calibration(self, channel, timeout_ms=500):
        if not self.is_connected():
            return (LXI_RESULT_INVALID_INSTANCE_ID, 0)
        calibration = ctypes.c_byte(0)
        status = self.lxi_dll.LXIAIGetSamplingRateCalibration(
            self.instance_id, channel,
            ctypes.byref(calibration), timeout_ms
        )
        return (status, calibration.value)

    # =========================================================================
    # 数据读取（标准版，受 10000 限制）
    # =========================================================================
    
    def read_data(self, channel_count, sample_count, timeout_ms=0):
        if not self.is_connected():
            return (LXI_RESULT_INVALID_INSTANCE_ID, None, 0, 0)
        
        channel_count = min(max(channel_count, 0), 255)
        sample_count = min(max(sample_count, 0), LXI_MAX_SAMPLES_PER_READ)
        
        buffer_size = channel_count * sample_count
        if buffer_size == 0:
            return (LXI_RESULT_INVALID_PARAM, None, 0, 0)
            
        data_buffer = (ctypes.c_float * buffer_size)()
        c_channel_count = ctypes.c_ubyte(channel_count)
        c_sample_count = ctypes.c_uint(sample_count)
        
        status = self.lxi_dll.LXIAIReadData(
            self.instance_id, data_buffer,
            ctypes.byref(c_channel_count),
            ctypes.byref(c_sample_count),
            timeout_ms
        )
        
        actual_channels = c_channel_count.value
        actual_samples = c_sample_count.value
        
        if status == LXI_RESULT_OK and actual_samples > 0:
            data_2d = []
            for ch in range(actual_channels):
                ch_start = ch * actual_samples
                ch_data = [data_buffer[ch_start + i] for i in range(actual_samples)]
                data_2d.append(ch_data)
            return (status, data_2d, actual_channels, actual_samples)
        else:
            return (status, None, actual_channels, actual_samples)

    # =========================================================================
    # 大数据量读取（返回 numpy 数组，支持 quiet 模式）
    # =========================================================================

    def read_data_large(self, channel_count, sample_count, timeout_ms=5000, quiet=False):
        try:
            import numpy as np
        except ImportError:
            print("错误: read_data_large 需要 numpy 库。请运行: pip install numpy")
            return (LXI_RESULT_INTERNAL_ERROR, None, 0, 0)

        if not self.is_connected():
            return (LXI_RESULT_INVALID_INSTANCE_ID, None, 0, 0)

        channel_count = min(max(channel_count, 1), 255)
        sample_count = max(sample_count, 1)
        buffer_size = channel_count * sample_count

        if not quiet:
            print(f"  分配缓冲区: {channel_count} 通道 × {sample_count:,} 采样点 = "
                  f"{buffer_size:,} floats ({buffer_size * 4 / 1024 / 1024:.1f} MB)")

        data_buffer = (ctypes.c_float * buffer_size)()
        c_channel_count = ctypes.c_ubyte(channel_count)
        c_sample_count = ctypes.c_uint(sample_count)

        if not quiet:
            print(f"  开始读取数据 (超时: {timeout_ms}ms)...")

        t0 = time.time()

        status = self.lxi_dll.LXIAIReadData(
            self.instance_id, data_buffer,
            ctypes.byref(c_channel_count),
            ctypes.byref(c_sample_count),
            timeout_ms
        )

        elapsed = time.time() - t0
        actual_channels = c_channel_count.value
        actual_samples = c_sample_count.value

        if status == LXI_RESULT_OK and actual_samples > 0:
            if not quiet:
                print(f"  读取完成: {actual_channels} 通道 × {actual_samples:,} 采样点, "
                      f"耗时 {elapsed:.3f}s")

            total_elements = actual_channels * actual_samples
            raw = np.frombuffer(data_buffer, dtype=np.float32, count=total_elements).copy()
            data_2d = raw.reshape(actual_channels, actual_samples)
            return (status, data_2d, actual_channels, actual_samples)
        else:
            if not quiet:
                print(f"  读取失败: {get_status_description(status)} ({status}), "
                      f"耗时 {elapsed:.3f}s")
            return (status, None, actual_channels, actual_samples)

    # =========================================================================
    # 自动读取线程
    # =========================================================================
    
    def _auto_read_worker(self, print_interval_ms=500):
        mode_str = self.current_read_mode.upper()
        print(f"\n[AutoRead] 线程启动 (模式: {mode_str})，每 {print_interval_ms}ms 打印一次...")
        
        num_channels = self.get_num_channels()
        if num_channels <= 0:
            print(f"[AutoRead] 错误: 获取通道数失败 ({num_channels})，线程退出。")
            return
        
        sample_count = 100
        total_reads = 0
        total_samples = 0
        overflow_count = 0
        packet_loss_count = 0
        last_print_time = time.time()
        period_reads = 0
        period_samples = 0
        period_last_data = None
        
        while not self._auto_read_stop_event.is_set():
            status, data, actual_ch, actual_s = self.read_data(
                num_channels, sample_count, timeout_ms=100
            )
            
            if status == LXI_RESULT_BUFFER_OVERFLOW:
                overflow_count += 1
                if overflow_count == 1 or overflow_count % 10 == 0:
                    print(f"\n[AutoRead] ⚠️  缓存溢出！(累计 {overflow_count} 次)")
                continue

            if status == LXI_RESULT_PACKET_LOSS:
                packet_loss_count += 1
                if packet_loss_count == 1 or packet_loss_count % 10 == 0:
                    print(f"\n[AutoRead] ⚠️  UDP/序列号丢包 (LXI_RESULT_PACKET_LOSS)，累计 {packet_loss_count} 次")
                continue
            
            if status == LXI_RESULT_OK and data is not None and actual_s > 0:
                total_reads += 1
                total_samples += actual_ch * actual_s
                period_reads += 1
                period_samples += actual_ch * actual_s
                period_last_data = data
            
            now = time.time()
            elapsed_ms = (now - last_print_time) * 1000
            
            if elapsed_ms >= print_interval_ms:
                if period_reads > 0 and period_last_data is not None:
                    overflow_info = f", 溢出: {overflow_count}" if overflow_count > 0 else ""
                    if packet_loss_count > 0:
                        overflow_info += f", 丢包: {packet_loss_count}"
                    print(f"\n[AutoRead] 读取 {total_reads} 次, 累计 {total_samples} 采样点 "
                          f"(本周期: {period_reads} 次{overflow_info})")
                    
                    ch0_data = period_last_data[0]
                    preview_count = min(10, len(ch0_data))
                    preview_str = ", ".join(f"{v:.3f}" for v in ch0_data[:preview_count])
                    print(f"    CH0: [{preview_str}] V")
                    
                    if len(period_last_data) > 1:
                        ch1_data = period_last_data[1]
                        preview_str = ", ".join(f"{v:.3f}" for v in ch1_data[:preview_count])
                        print(f"    CH1: [{preview_str}] V")
                    
                    if len(period_last_data) > 2:
                        print(f"    ... 还有 {len(period_last_data) - 2} 个通道")
                
                last_print_time = now
                period_reads = 0
                period_samples = 0
                period_last_data = None
        
        overflow_info = f", 溢出 {overflow_count} 次" if overflow_count > 0 else ""
        if packet_loss_count > 0:
            overflow_info += f", 丢包 {packet_loss_count} 次"
        print(f"\n[AutoRead] 线程停止，共读取 {total_reads} 次，"
              f"累计 {total_samples} 采样点{overflow_info}。")

    def start_auto_read(self, print_interval_ms=500):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return
        if self._auto_read_thread and self._auto_read_thread.is_alive():
            print("自动读取线程已在运行。")
            return
        self._auto_read_stop_event = threading.Event()
        self._auto_read_thread = threading.Thread(
            target=self._auto_read_worker,
            args=(print_interval_ms,),
            daemon=True
        )
        self._auto_read_thread.start()

    def stop_auto_read(self):
        if self._auto_read_thread and self._auto_read_thread.is_alive():
            self._auto_read_stop_event.set()
            self._auto_read_thread.join(timeout=2)
            print("自动读取已停止。")
        self._auto_read_thread = None
        self._auto_read_stop_event = None

    # =========================================================================
    # 命令响应读取
    # =========================================================================
    
    def read_response(self, buffer_size=256):
        if not self.is_connected():
            return None
        buffer = ctypes.create_string_buffer(buffer_size)
        buffer_ptr = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
        size_in_out = ctypes.c_int(buffer_size)
        status = self.lxi_dll.LXIAIReadResponse(
            self.instance_id, buffer_ptr, ctypes.byref(size_in_out)
        )
        if status == LXI_RESULT_OK:
            return buffer.raw[:size_in_out.value]
        return None

    # =========================================================================
    # 实例管理
    # =========================================================================
    
    def clear_all(self):
        print("正在清理所有实例...")
        self.stop_auto_read()
        status = self.lxi_dll.LXIClearAll()
        if status == LXI_RESULT_OK:
            print("所有实例已清理。")
            self._reset_state()
            return True
        return False

    def close_log(self):
        """关闭 DLL 日志系统（确保日志刷盘）"""
        if self.lxi_dll:
            self.lxi_dll.LXICloseLog()

    def cleanup(self):
        """清理资源（程序退出前调用，幂等安全）"""
        if self._cleaned_up:
            return
        self._cleaned_up = True

        print("开始清理资源...")
        self.stop_auto_read()
        
        if self.is_connected():
            self.disconnect()
        
        # 关闭 DLL 日志，确保所有日志刷盘
        self.close_log()
        print("资源清理完成。")


