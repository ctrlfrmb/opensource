#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# LxiMessage.py - LXI API消息类型定义和常量

import ctypes

# --- LXI API 结果状态码 ---
# 这些值与 lximessage.h 中的 LxiResultCode 枚举完全对应
LXI_RESULT_OK = 0
LXI_RESULT_INVALID_PARAM = 1
LXI_RESULT_INTERNAL_ERROR = 2
LXI_RESULT_CONNECTION_FAILED = 6
LXI_RESULT_TOO_MANY_INSTANCES = 11
LXI_RESULT_INVALID_INSTANCE_ID = 12
LXI_RESULT_SEND_FAILED = 21
LXI_RESULT_NO_DATA = 22

# 错误码到中文描述的映射
STATUS_DESCRIPTIONS = {
    LXI_RESULT_OK: "操作成功完成",
    LXI_RESULT_INVALID_PARAM: "无效参数",
    LXI_RESULT_INTERNAL_ERROR: "内部错误",
    LXI_RESULT_CONNECTION_FAILED: "连接失败",
    LXI_RESULT_TOO_MANY_INSTANCES: "实例数量达到上限",
    LXI_RESULT_INVALID_INSTANCE_ID: "无效的实例ID",
    LXI_RESULT_SEND_FAILED: "发送数据失败",
    LXI_RESULT_NO_DATA: "无数据",
}

# LXI_OUTPUT_DATA_MAX_SIZE 必须与 C++ lximessage.h 中的定义一致
LXI_OUTPUT_DATA_MAX_SIZE = 1500

class LXIOutputData(ctypes.Structure):
    """
    对应 C++ 中的 LXIOutputData 结构体。
    根据 lximessage.h 精确定义，特别是字段顺序和4字节对齐。
    """
    # ctypes 默认的对齐方式通常与C编译器的平台默认对齐方式一致。
    # 对于 #pragma pack(4)，我们不设置 _pack_ 属性，让 ctypes 自动处理，
    # 这通常能正确处理4字节对齐规则。
    _fields_ = [
        ("index", ctypes.c_uint),
        ("serial_code", ctypes.c_ubyte),
        ("last_serial_code", ctypes.c_ubyte),
        ("length", ctypes.c_ushort),
        ("data", ctypes.c_ubyte * LXI_OUTPUT_DATA_MAX_SIZE),
        ("reserved", ctypes.c_uint)
    ]

    def __repr__(self):
        """
        提供一个友好的字符串表示形式，方便打印和调试。
        """
        return (f"LXIOutputData(index={self.index}, length={self.length}, "
                f"sn={self.serial_code}, last_sn={self.last_serial_code})")

def get_status_description(status_code):
    """
    根据给定的状态码，返回对应的中文描述。
    如果状态码未知，则返回一个通用的未知错误消息。
    """
    return STATUS_DESCRIPTIONS.get(status_code, f"未知错误码: {status_code}")

def print_command(command_str):
    """
    格式化并打印将要发送的命令。
    """
    try:
        parts = command_str.strip().split()
        formatted_parts = [f"{int(p, 16):02X}" for p in parts]
        print(f"发送命令: {' '.join(formatted_parts)}")
    except ValueError:
        print(f"发送原始命令字符串: {command_str}")

