﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: leiwei
LxiMessage.py - LXI API 消息类型定义和错误码
版本: v3.6.0 (与 lxi_api 库版本对齐)
"""

import ctypes

LXI_MAX_CHANNELS = 48
LXI_MAX_SAMPLES_PER_READ = 10000

LXI_RESULT_OK = 0
LXI_RESULT_INVALID_PARAM = -1
LXI_RESULT_INTERNAL_ERROR = -2
LXI_RESULT_INVALID_CHANNEL_SPEC = -3
LXI_RESULT_BUFFER_TOO_SMALL = -4
LXI_RESULT_CHANNEL_NOT_CONFIGURED = -5
LXI_RESULT_CHANNEL_COUNT_MISMATCH = -6
LXI_RESULT_NOT_SAMPLING = -7
LXI_RESULT_SAMPLE_COUNT_EXCEEDED = -8
LXI_RESULT_SAMPLING_IN_PROGRESS = -9
LXI_RESULT_CONNECTION_FAILED = -11
LXI_RESULT_TOO_MANY_INSTANCES = -12
LXI_RESULT_INVALID_INSTANCE_ID = -13
LXI_RESULT_DEVICE_NOT_FOUND = -14
LXI_RESULT_SEND_FAILED = -21
LXI_RESULT_NO_DATA = -22
LXI_RESULT_READ_TIMEOUT = -23
LXI_RESULT_DATA_NOT_READY = -24
LXI_RESULT_BUFFER_OVERFLOW = -25
LXI_RESULT_PACKET_LOSS = -26
LXI_RESULT_COMMAND_NO_RESPONSE = -404

STATUS_DESCRIPTIONS = {
    LXI_RESULT_OK: "操作成功",
    LXI_RESULT_INVALID_PARAM: "无效参数",
    LXI_RESULT_INTERNAL_ERROR: "内部错误",
    LXI_RESULT_INVALID_CHANNEL_SPEC: "无效通道配置",
    LXI_RESULT_BUFFER_TOO_SMALL: "缓冲区太小",
    LXI_RESULT_CHANNEL_NOT_CONFIGURED: "通道未配置",
    LXI_RESULT_CHANNEL_COUNT_MISMATCH: "通道数量不匹配",
    LXI_RESULT_NOT_SAMPLING: "未处于采样状态",
    LXI_RESULT_SAMPLE_COUNT_EXCEEDED: "采样数量超过限制",
    LXI_RESULT_SAMPLING_IN_PROGRESS: "正在采样中",
    LXI_RESULT_CONNECTION_FAILED: "连接失败",
    LXI_RESULT_TOO_MANY_INSTANCES: "实例过多",
    LXI_RESULT_INVALID_INSTANCE_ID: "无效实例 ID",
    LXI_RESULT_DEVICE_NOT_FOUND: "设备未找到",
    LXI_RESULT_SEND_FAILED: "发送失败",
    LXI_RESULT_NO_DATA: "无数据",
    LXI_RESULT_READ_TIMEOUT: "读取超时",
    LXI_RESULT_DATA_NOT_READY: "数据未就绪",
    LXI_RESULT_BUFFER_OVERFLOW: "缓冲区溢出",
    LXI_RESULT_PACKET_LOSS: "UDP 数据包序列号不连续，存在丢包或缓存断点",
    LXI_RESULT_COMMAND_NO_RESPONSE: "命令无响应",
}


def get_status_description(status_code):
    return STATUS_DESCRIPTIONS.get(status_code, f"未知错误码: {status_code}")


class LxiSamplingInfo(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("total_channel_count", ctypes.c_ubyte),
        ("samples_per_packet", ctypes.c_ubyte),
        ("selected_channel_count", ctypes.c_ubyte),
        ("reserved", ctypes.c_ubyte),
        ("sampling_rate", ctypes.c_uint),
    ]

    def __repr__(self):
        return (f"LxiSamplingInfo(total={self.total_channel_count}, "
                f"samples_per_packet={self.samples_per_packet}, "
                f"selected={self.selected_channel_count}, rate={self.sampling_rate})")


class LxiChannelConfig(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("channel_indices", ctypes.c_ubyte * LXI_MAX_CHANNELS),
        ("selected_channel_count", ctypes.c_ubyte),
        ("total_available_channels", ctypes.c_ubyte),
        ("samples_per_packet", ctypes.c_ubyte),
        ("reserved", ctypes.c_ubyte),
    ]

    def selected_channels(self):
        return [self.channel_indices[i] for i in range(self.selected_channel_count)]

    def __repr__(self):
        return (f"LxiChannelConfig(selected={self.selected_channel_count}, "
                f"total={self.total_available_channels}, samples_per_packet={self.samples_per_packet}, "
                f"channels={self.selected_channels()})")
