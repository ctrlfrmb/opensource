#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# LxiMessage.py - LXI API消息类型定义和常量 (v2.1.0)

import ctypes

# --- LXI API 结果状态码 (与 lximessage.h 完全对应) ---
LXI_RESULT_OK = 0
LXI_RESULT_INVALID_PARAM = -1
LXI_RESULT_INTERNAL_ERROR = -2
LXI_RESULT_CONNECTION_FAILED = -6
LXI_RESULT_TOO_MANY_INSTANCES = -11
LXI_RESULT_INVALID_INSTANCE_ID = -12
LXI_RESULT_SEND_FAILED = -21
LXI_RESULT_NO_DATA = -22
LXI_RESULT_COMMAND_NO_RESPONSE = -404

STATUS_DESCRIPTIONS = {
    LXI_RESULT_OK: "操作成功完成",
    LXI_RESULT_INVALID_PARAM: "无效参数",
    LXI_RESULT_INTERNAL_ERROR: "内部错误",
    LXI_RESULT_CONNECTION_FAILED: "连接失败",
    LXI_RESULT_TOO_MANY_INSTANCES: "实例数量达到上限",
    LXI_RESULT_INVALID_INSTANCE_ID: "无效的实例ID",
    LXI_RESULT_SEND_FAILED: "发送数据失败",
    LXI_RESULT_NO_DATA: "无数据 (队列为空)",
    LXI_RESULT_COMMAND_NO_RESPONSE: "命令发送后，在超时时间内未收到响应",
}

# --- 常量 (与 lximessage.h 完全对应) ---
LXI_MAX_DATA_POINTS = 600

# --- C 结构体定义 ---

class LxiSamplingInfo(ctypes.Structure):
    _fields_ = [
        ("channel_count", ctypes.c_int),
        ("sample_count_per_channel", ctypes.c_int),
    ]

    def __repr__(self):
        return (f"有效通道数: {self.channel_count}, "
                f"每通道采样点数: {self.sample_count_per_channel}")

class LxiVoltagePacket(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("index", ctypes.c_uint),
        ("serial_code", ctypes.c_ubyte),
        ("last_serial_code", ctypes.c_ubyte),
        ("reserved", ctypes.c_ubyte),
        ("reserved2", ctypes.c_ubyte),
        ("voltages", ctypes.c_float * LXI_MAX_DATA_POINTS)
    ]

    def __repr__(self):
        """
        提供一个清晰的字符串表示形式，显示基础信息和前6个电压值。
        """
        first_6_volts = self.voltages[:6]
        voltages_str = ", ".join(f"{v:.4f}" for v in first_6_volts)
        
        return (f"Index={self.index}, SN={self.serial_code}, "
                f"LastSN={self.last_serial_code}, Voltages=[{voltages_str}]V")

def get_status_description(status_code):
    return STATUS_DESCRIPTIONS.get(status_code, f"未知错误码: {status_code}")
