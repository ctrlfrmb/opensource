#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# LxiClientTest.py - LXI客户端API测试和命令行界面

from LxiClient import LxiClient
import signal
import sys
import time
import platform

client = None

def signal_handler(sig, frame):
    print("\n接收到中断信号，正在清理资源...")
    if client:
        client.cleanup()
    print("程序已终止。")
    sys.exit(0)

def print_help():
    help_text = """
可用命令:
  help                                        显示此帮助信息
  connect <params>                            连接到LXI设备 (例: connect --serverIp 192.168.201.0)
  disconnect                                  断开与LXI设备的连接
  start <params>                              发送开始采样命令 (参数详情如下)
  stop <params>                               发送停止采样命令 (参数详情如下)
  info                                        获取并显示当前采样配置信息
  read                                        手动非阻塞读取一次电压数据
  read_block <timeout_ms>                     手动阻塞读取一次电压数据 (例: read_block 100)
  response                                    读取一次命令响应
  autoRead                                    启动后台线程自动读取数据
  stopRead                                    停止后台自动读取
  runtest <duration_sec>                      运行一个自动化的连接-采集-停止-断开测试
  clearall                                    断开所有连接并清理所有实例
  status                                      检查当前连接状态
  exit                                        退出程序

--------------------------------------------------------------------------------
'start' 命令参数详解:
  用法: start --key1 value1 --key2 value2 ...

  [必填参数]:
    --rateMode <string>       : 速率模式。可选值: 'high' (高速), 'low' (低速)。
    --channelMode <string>    : 通道模式。可选值: 'single' (单端), 'diff' (差分)。

  [可选参数]:
    --slotId <int>            : 目标板卡的卡槽ID (可选, 默认从IP地址推断)。
    --rate <int>              : 采样率代码 (1-100)。高速: 10K-1000KHz, 低速: 1K-100KHz。
    --packets <int>           : 采集包数 (0-65535)。'0' 表示持续采集。
    --range <int>             : 量程代码。'1'(±5V), '2'(±10V), '3'(±20V)。
    --timeout <int>           : 等待响应的超时(毫秒)。默认500。0表示异步。

  [条件参数]:
    --channels <c1>...<c6>   : 6个通道值，用空格隔开。高速模式下必填，低速模式下忽略。
                              (通道选择规则请参考API文档)

  [常用示例]:
    start --rateMode high --channelMode single --channels 1 9 16 24 31 39
    start --slotId 1 --rateMode high --channelMode diff --channels 1 9 16 24 31 39 --timeout 0
--------------------------------------------------------------------------------
'stop' 命令参数详解:
  用法: stop [--timeout <value>]

  [可选参数]:
    --timeout <int>           : 等待响应的超时(毫-秒)。默认100。0表示异步。

  [常用示例]:
    stop                      # 使用默认100ms超时，同步停止
    stop --timeout 500        # 自定义500ms超时，同步停止
    stop --timeout 0          # 异步停止，不等待响应
--------------------------------------------------------------------------------
"""
    print(help_text)

def main():
    global client
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("=" * 60)
    print(f" LXI 客户端命令行测试工具 v2.1.1 ({platform.architecture()[0]})")
    print("=" * 60)
    print("输入 'help' 获取帮助, 输入 'exit' 退出程序。")
    
    try:
        client = LxiClient()
    except Exception as e:
        print(f"初始化LXI客户端失败: {e}")
        return

    default_connect_params = "--serverIp 192.168.201.0 --serverPort 8080"
    # 默认启动参数中移除 slotId，以测试自动推断功能
    default_start_params = "--rateMode high --channelMode diff --rate 100 --packets 0 --channels 1 9 16 24 31 39"

    while True:
        try:
            cmd_line = input("LXI> ").strip()
            if not cmd_line:
                continue
            parts = cmd_line.split()
            command = parts[0].lower()
            if command == "help":
                print_help()
            elif command == "exit":
                break
            elif command == "connect":
                params = " ".join(parts[1:]) if len(parts) > 1 else default_connect_params
                client.connect(params)
            elif command == "disconnect":
                client.disconnect()
            elif command == "start":
                params = " ".join(parts[1:]) if len(parts) > 1 else default_start_params
                client.start_sampling(params)
            elif command == "stop":
                params = " ".join(parts[1:])
                client.stop_sampling(params)
            elif command == "info":
                info = client.get_sampling_info()
                if info:
                    print(f"当前采样信息: {info}")
                else:
                    print("未能获取采样信息，请先成功启动一次采集。")
            elif command == "read":
                packets = client.read_voltages() # 默认 timeout_ms=0, 非阻塞
                if packets:
                    print(f"成功非阻塞读取 {len(packets)} 个数据包:")
                    for pkt in packets:
                        print(f"  -> {pkt}")
                else:
                    print("未读取到数据包 (队列为空或发生错误)。")
            elif command == "read_block":
                if len(parts) != 2:
                    print("用法: read_block <timeout_ms>")
                else:
                    try:
                        timeout = int(parts[1])
                        print(f"开始阻塞读取，最多等待 {timeout}ms...")
                        packets = client.read_voltages(timeout_ms=timeout)
                        if packets:
                            print(f"成功阻塞读取 {len(packets)} 个数据包:")
                            for pkt in packets:
                                print(f"  -> {pkt}")
                        else:
                            print("未读取到数据包 (超时或发生错误)。")
                    except ValueError:
                        print("错误: 超时时间必须是整数。")
            elif command == "response":
                resp = client.read_response()
                if resp is not None:
                    hex_str = ' '.join(f'{b:02X}' for b in resp)
                    print(f"成功读取响应 ({len(resp)}字节): {hex_str}")
                else:
                    print("未读取到响应或读取时发生错误。")
            elif command == "autoread":
                client.start_auto_read()
            elif command == "stopread":
                client.stop_auto_read()
            elif command == "runtest":
                if len(parts) != 2:
                    print("用法: runtest <duration_sec>")
                else:
                    try:
                        duration = int(parts[1])
                        print("\n--- 开始自动化测试 ---")
                        if client.connect(default_connect_params):
                            time.sleep(0.1)
                            if client.start_sampling(default_start_params):
                                print(f"采集中，将持续 {duration} 秒...")
                                client.start_auto_read()
                                time.sleep(duration)
                                client.stop_auto_read()
                                client.stop_sampling("--timeout 100")
                            time.sleep(0.1)
                            client.disconnect()
                        print("--- 自动化测试结束 ---\n")
                    except ValueError:
                        print("错误: 测试时长必须是整数。")
            elif command == "clearall":
                client.clear_all()
            elif command == "status":
                if client.is_connected():
                    print(f"状态: 已连接, 实例 ID: {client.instance_id}")
                else:
                    print("状态: 未连接")
            else:
                print(f"未知命令: '{command}'. 输入 'help' 查看可用命令。")
        except Exception as e:
            print(f"发生未预料的错误: {e}")

    if client:
        client.cleanup()
    print("程序已退出。")

if __name__ == "__main__":
    main()
