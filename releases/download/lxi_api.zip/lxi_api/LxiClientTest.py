﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LxiClientTest.py - LXI 客户端测试工具 v3.6.0
Author: leiwei

v3.6.0 更新：
- 与 DLL / LxiMessage / ReleaseNote 版本统一为 v3.6.0

v3.4.0 更新：
- 与 DLL / LxiMessage 错误码对齐（含 PACKET_LOSS -26）
- 修复 Ctrl+C 退出时 DLL 日志未刷盘的问题（cleanup 末尾调用 LXICloseLog）
- 信号处理改为设置全局标志位，不再直接 sys.exit()
- 移除 runtest / looptest 命令，精简工具
"""

from LxiClient import LxiClient
from LxiMessage import *
import signal
import sys
import time
import platform
import threading

VERSION = "3.6.0"

client = None

# 全局中断标志，信号处理器设置此标志，测试循环检查此标志
_interrupted = threading.Event()


def signal_handler(sig, frame):
    """信号处理：仅设置中断标志，不直接退出"""
    _interrupted.set()
    # 如果在 input() 阻塞中，抛出 KeyboardInterrupt 让主循环退出
    raise KeyboardInterrupt


def print_help():
    print(f"""
================================================================================
                    LXI 客户端测试工具 v{VERSION}
================================================================================

命令列表:
  help                              显示帮助
  connect [params]                  连接设备
    示例: connect --serverIp 192.168.201.1 --serverPort 8080

  disconnect                        断开连接

  start [params]                    启动采样
    示例: start --rateMode high --channelMode single --rate 100 --packets 0
                --range 1 --openChannels 1 9 17 25 33 41 --readMode single

  stop [params]                     停止采样

  info                              获取采样信息
  chconfig                          获取通道配置
  numch                             获取通道数

  read <ch> <samples> [timeout]     读取数据
    示例: read 6 100 1000

  autoread [interval_ms]            启动自动读取 (默认 500ms)
  stopread                          停止自动读取

  calibration <channel> [timeout]   读取采样率标定值 (PPM)
    示例: calibration 1 500

  packettest [options]              分段读取压力测试
    --loops N        循环次数 (0=无限, 默认0)
    --packets N      板卡发包总数 (默认 15000)
    --firstread M    第一次读取包数 (默认 10000)
    --delay S        两次读取间延时秒数 (默认 2.0)
    --interval N     循环间隔毫秒 (默认 100)
    流程: 连接→采样(发N包)→读M包→延时→读剩余(预期超时)→停止→断开→循环
    示例:
      packettest                                  ← 默认: 发15000包,读10000,延2s
      packettest --packets 20000 --firstread 8000 ← 发20000包,读8000,延2s
      packettest --delay 5 --loops 100            ← 延时5秒,跑100轮

  plottest [options]                循环压力测试 + 波形
    --samples N    每次读取采样点数/通道 (默认 1200000)
    --timeout N    单次读取超时毫秒 (默认 5000)
    --interval N   循环间隔毫秒 (默认 100)
    --decimate N   绘图降采样因子 (0=自动, 默认 0)
    --save PATH    单次采集并保存图片 (不进入循环模式)
    示例: plottest

  clearall                          清理所有实例
  status                            查看状态
  verify                            验证结构体大小
  exit                              退出
================================================================================
""")


# =============================================================================
# 可中断的 sleep（检查全局中断标志）
# =============================================================================

def interruptible_sleep(seconds):
    """可中断的 sleep，每 100ms 检查一次中断标志"""
    end_time = time.time() + seconds
    while time.time() < end_time:
        if _interrupted.is_set():
            return False  # 被中断
        time.sleep(min(0.1, end_time - time.time()))
    return True  # 正常完成


# =============================================================================
# 分段读取压力测试（终端打印版）
# =============================================================================

def run_packet_test(client, loops, total_packets, first_read_packets,
                    delay_sec, interval_ms, connect_params, start_params):
    """分段读取压力测试"""
    samples_per_packet = 100
    first_read_samples = first_read_packets * samples_per_packet
    remaining_packets = total_packets - first_read_packets
    remaining_samples = remaining_packets * samples_per_packet

    cycle = 0
    success_count = 0
    fail_count = 0
    read2_ok = 0
    read2_timeout = 0
    read2_partial = 0
    t0 = time.time()

    # 清除之前可能残留的中断标志
    _interrupted.clear()

    print(f"\n{'='*70}")
    print(f"  分段读取压力测试")
    print(f"  循环次数: {'无限' if loops == 0 else loops}")
    print(f"  板卡发包: {total_packets} 包 ({total_packets * samples_per_packet:,} 采样点/通道)")
    print(f"  第一次读: {first_read_packets} 包 ({first_read_samples:,} 采样点/通道)")
    print(f"  延时:     {delay_sec}s")
    print(f"  第二次读: {remaining_packets} 包 ({remaining_samples:,} 采样点/通道)")
    print(f"  循环间隔: {interval_ms}ms")
    print(f"  预期: 第二次读取大概率超时（SINGLE 模式延时期间数据被丢弃）")
    print(f"{'='*70}")

    try:
        while (loops == 0 or cycle < loops) and not _interrupted.is_set():
            cycle += 1
            cycle_t0 = time.time()
            print(f"\n--- 循环 #{cycle} [{time.strftime('%H:%M:%S')}] ---")

            # === 1. 连接 ===
            if not client.connect(connect_params):
                fail_count += 1
                print(f"  ❌ 连接失败")
                if not interruptible_sleep(interval_ms / 1000.0):
                    break
                continue
            time.sleep(0.05)

            # === 2. 启动采样 ===
            if not client.start_sampling(start_params):
                fail_count += 1
                print(f"  ❌ 启动采样失败")
                client.disconnect()
                if not interruptible_sleep(interval_ms / 1000.0):
                    break
                continue

            info = client.get_sampling_info()
            if info:
                sampling_rate = info.sampling_rate
                num_channels = info.selected_channel_count
            else:
                sampling_rate = 1000000
                num_channels = 6

            first_timeout = max(5000, int(first_read_samples / sampling_rate * 1000) + 3000)
            second_timeout = 3000

            # === 3. 第一次读取 ===
            print(f"  [读取1] {num_channels}CH × {first_read_samples:,} 采样点, "
                  f"超时: {first_timeout}ms ...")
            t_r1 = time.time()
            status1, data1, ach1, asp1 = client.read_data_large(
                num_channels, first_read_samples, first_timeout, quiet=True
            )
            elapsed1 = time.time() - t_r1

            if status1 == LXI_RESULT_OK and data1 is not None and asp1 > 0:
                print(f"  [读取1] ✅ {ach1}CH × {asp1:,} 点, 耗时 {elapsed1:.3f}s")
                for ch in range(min(3, ach1)):
                    d = data1[ch]
                    preview = ", ".join(f"{v:.4f}" for v in d[:6])
                    print(f"    CH{ch}: [{preview} ...] "
                          f"min={d.min():.4f} max={d.max():.4f} mean={d.mean():.4f}")
                if ach1 > 3:
                    print(f"    ... 还有 {ach1 - 3} 个通道")
            else:
                print(f"  [读取1] ❌ {get_status_description(status1)} ({status1}), "
                      f"耗时 {elapsed1:.3f}s")
                fail_count += 1
                client.stop_sampling()
                time.sleep(0.05)
                client.disconnect()
                if not interruptible_sleep(interval_ms / 1000.0):
                    break
                continue

            # === 4. 延时 ===
            print(f"  [延时] {delay_sec}s (SINGLE 模式下此期间数据将被丢弃) ...")
            if not interruptible_sleep(delay_sec):
                # 被中断，清理当前连接
                print(f"\n  延时期间被中断，正在清理...")
                client.stop_sampling()
                time.sleep(0.02)
                client.disconnect()
                break

            # === 5. 第二次读取（预期超时）===
            if _interrupted.is_set():
                client.stop_sampling()
                time.sleep(0.02)
                client.disconnect()
                break

            print(f"  [读取2] {num_channels}CH × {remaining_samples:,} 采样点, "
                  f"超时: {second_timeout}ms (预期超时) ...")
            t_r2 = time.time()
            status2, data2, ach2, asp2 = client.read_data_large(
                num_channels, remaining_samples, second_timeout, quiet=True
            )
            elapsed2 = time.time() - t_r2

            if status2 == LXI_RESULT_OK and data2 is not None and asp2 > 0:
                read2_ok += 1
                print(f"  [读取2] ⚠️ 意外成功! {ach2}CH × {asp2:,} 点, 耗时 {elapsed2:.3f}s")
                for ch in range(min(2, ach2)):
                    d = data2[ch]
                    preview = ", ".join(f"{v:.4f}" for v in d[:6])
                    print(f"    CH{ch}: [{preview} ...]")
            elif asp2 > 0:
                read2_partial += 1
                print(f"  [读取2] ⚠️ 部分读取: {asp2:,} 点 "
                      f"(请求 {remaining_samples:,}), 耗时 {elapsed2:.3f}s")
            else:
                read2_timeout += 1
                print(f"  [读取2] ✅ 如预期超时: {get_status_description(status2)} ({status2}), "
                      f"耗时 {elapsed2:.3f}s")

            # === 6. 停止 + 断开 ===
            client.stop_sampling()
            time.sleep(0.02)
            client.disconnect()

            success_count += 1
            cycle_elapsed = time.time() - cycle_t0

            print(f"  周期耗时: {cycle_elapsed:.2f}s  "
                  f"统计: ✓{success_count} ✗{fail_count}  "
                  f"读取2: OK={read2_ok} 超时={read2_timeout} 部分={read2_partial}")

            if (loops == 0 or cycle < loops) and not _interrupted.is_set():
                if not interruptible_sleep(interval_ms / 1000.0):
                    break

    except KeyboardInterrupt:
        print("\n  中断测试...")
        if client.is_connected():
            try:
                client.stop_sampling()
                time.sleep(0.05)
                client.disconnect()
            except Exception:
                pass

    elapsed = time.time() - t0
    print(f"\n{'='*70}")
    print(f"  分段读取压力测试结束")
    print(f"  总循环: {cycle}  成功: {success_count}  失败: {fail_count}")
    if cycle > 0:
        print(f"  成功率: {success_count/cycle*100:.1f}%")
        print(f"  平均周期: {elapsed/cycle:.2f}s")
    print(f"  第二次读取统计:")
    print(f"    完整读取: {read2_ok}  (不应发生)")
    print(f"    预期超时: {read2_timeout}  (正常)")
    print(f"    部分读取: {read2_partial}  (可能发生)")
    print(f"  总耗时: {elapsed:.1f}s")
    print(f"{'='*70}\n")


# =============================================================================
# 连接/断开循环压力测试 + 实时波形
# =============================================================================

def run_plot_stress_test(client, connect_params, start_params, sample_count,
                         timeout_ms, interval_ms, decimate):
    """连接/断开循环压力测试 + 实时波形绘制"""
    try:
        import numpy as np
        import matplotlib
        import matplotlib.pyplot as plt
    except ImportError as e:
        print(f"错误: 需要 numpy 和 matplotlib。请运行: pip install numpy matplotlib")
        return False

    _interrupted.clear()

    print(f"\n{'='*70}")
    print(f"  连接/断开循环压力测试 + 实时波形")
    print(f"  每次读取: {sample_count:,} 采样点/通道  超时: {timeout_ms}ms")
    print(f"  循环间隔: {interval_ms}ms")
    print(f"  关闭窗口或 Ctrl+C 退出")
    print(f"{'='*70}")

    print("\n[准备] 获取设备采样信息...")
    if not client.connect(connect_params):
        return False

    if not client.start_sampling(start_params):
        client.disconnect()
        return False

    info = client.get_sampling_info()
    if info:
        sampling_rate = info.sampling_rate
        num_channels = info.selected_channel_count
        print(f"  采样率: {sampling_rate:,} Hz, 通道数: {num_channels}")
    else:
        sampling_rate = 1000000
        num_channels = 6

    client.stop_sampling()
    time.sleep(0.05)
    client.disconnect()
    print("  准备完成。\n")
    time.sleep(0.1)

    plt.ion()

    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b',
              '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']

    fig_height = max(6, min(2.2 * num_channels, 18))
    fig, axes = plt.subplots(num_channels, 1, figsize=(14, fig_height), sharex=True)
    if num_channels == 1:
        axes = [axes]

    lines = []
    stat_titles = []
    for i, ax in enumerate(axes):
        color = colors[i % len(colors)]
        line, = ax.plot([], [], linewidth=0.4, color=color, alpha=0.85)
        lines.append(line)
        ax.set_ylabel(f'CH{i} (V)', fontsize=9)
        ax.grid(True, alpha=0.3, linestyle='--')
        ax.tick_params(labelsize=8)
        stat_titles.append(ax.set_title('', fontsize=9, fontfamily='monospace', loc='left'))

    axes[-1].set_xlabel('Time (s)', fontsize=10)
    rate_str = (f"{sampling_rate / 1e6:.1f} MHz" if sampling_rate >= 1e6
                else f"{sampling_rate / 1e3:.0f} KHz")
    fig.suptitle(f'LXI Stress Test — Starting...', fontsize=12, fontweight='bold')
    plt.tight_layout()
    fig.canvas.draw()
    fig.canvas.flush_events()

    cycle = 0
    success_count = 0
    fail_count = 0
    t_start = time.time()

    try:
        while plt.fignum_exists(fig.number) and not _interrupted.is_set():
            cycle += 1
            cycle_t0 = time.time()

            if not client.connect(connect_params):
                fail_count += 1
                if plt.fignum_exists(fig.number):
                    time.sleep(interval_ms / 1000.0)
                continue

            if not client.start_sampling(start_params):
                fail_count += 1
                client.disconnect()
                if plt.fignum_exists(fig.number):
                    time.sleep(interval_ms / 1000.0)
                continue

            status, data, actual_ch, actual_sp = client.read_data_large(
                num_channels, sample_count, timeout_ms, quiet=True
            )

            client.stop_sampling()
            time.sleep(0.02)
            client.disconnect()

            cycle_elapsed = time.time() - cycle_t0

            if not plt.fignum_exists(fig.number):
                break

            if status == LXI_RESULT_OK and data is not None and actual_sp > 0:
                success_count += 1
                time_axis = np.arange(actual_sp, dtype=np.float64) / sampling_rate

                MAX_PLOT_POINTS = 50000
                actual_dec = decimate if decimate > 0 else max(1, actual_sp // MAX_PLOT_POINTS)
                plot_time = time_axis[::actual_dec] if actual_dec > 1 else time_axis

                for i in range(min(actual_ch, len(lines))):
                    plot_y = data[i, ::actual_dec] if actual_dec > 1 else data[i]
                    lines[i].set_data(plot_time, plot_y)
                    axes[i].relim()
                    axes[i].autoscale_view()
                    ch_data = data[i]
                    v_min, v_max = ch_data.min(), ch_data.max()
                    v_mean, v_std = ch_data.mean(), ch_data.std()
                    stat_titles[i].set_text(
                        f'CH{i}: Min={v_min:.4f}V  Max={v_max:.4f}V  '
                        f'Mean={v_mean:.4f}V  Std={v_std:.4f}V  '
                        f'Vpp={v_max - v_min:.4f}V'
                    )

                total_elapsed = time.time() - t_start
                fig.suptitle(
                    f'LXI Stress Test — {actual_ch}CH, {rate_str}, '
                    f'{actual_sp:,} pts  |  '
                    f'Cycle #{cycle}  ✓{success_count} ✗{fail_count}  '
                    f'({cycle_elapsed:.2f}s/cycle, {total_elapsed:.0f}s total)',
                    fontsize=11, fontweight='bold'
                )
                fig.canvas.draw_idle()
                fig.canvas.flush_events()

                if cycle % 50 == 0:
                    print(f"  [#{cycle}] ✓{success_count} ✗{fail_count}  "
                          f"cycle={cycle_elapsed:.2f}s  total={total_elapsed:.0f}s")
            else:
                fail_count += 1

            if plt.fignum_exists(fig.number) and interval_ms > 0 and not _interrupted.is_set():
                plt.pause(interval_ms / 1000.0)

    except KeyboardInterrupt:
        print("\n  Ctrl+C 中断测试。")
    finally:
        try:
            plt.close(fig)
        except Exception:
            pass
        plt.ioff()

        if client.is_connected():
            try:
                client.stop_sampling()
            except Exception:
                pass
            time.sleep(0.05)
            client.disconnect()

        total_elapsed = time.time() - t_start
        print(f"\n{'='*70}")
        print(f"  压力测试结束: 循环{cycle}  ✓{success_count}  ✗{fail_count}  "
              f"耗时{total_elapsed:.1f}s")
        print(f"{'='*70}")

    return True


# =============================================================================
# 单次截图保存
# =============================================================================

def run_plot_save(client, connect_params, start_params, sample_count,
                  timeout_ms, save_path, decimate):
    """单次截图：连接 → 采样 → 读取 → 保存图片 → 停止 → 断开"""
    try:
        import numpy as np
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError as e:
        print(f"错误: 绘图需要 numpy 和 matplotlib: {e}")
        return False

    print(f"\n{'='*70}")
    print(f"  波形截图保存: {sample_count:,} 点/通道, 超时: {timeout_ms}ms")
    print(f"{'='*70}")

    t_start = time.time()

    if not client.connect(connect_params):
        return False
    time.sleep(0.05)

    if not client.start_sampling(start_params):
        client.disconnect()
        return False

    info = client.get_sampling_info()
    sampling_rate = info.sampling_rate if info else 1000000
    num_channels = info.selected_channel_count if info else 6
    time.sleep(0.1)

    status, data, actual_ch, actual_sp = client.read_data_large(
        num_channels, sample_count, timeout_ms
    )

    client.stop_sampling()
    time.sleep(0.05)
    client.disconnect()

    if status == LXI_RESULT_OK and data is not None:
        time_axis = np.arange(actual_sp, dtype=np.float64) / sampling_rate

        if decimate <= 0:
            decimate = max(1, actual_sp // 50000)
        plot_time = time_axis[::decimate] if decimate > 1 else time_axis
        plot_data = data[:, ::decimate] if decimate > 1 else data

        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']
        fig_height = max(6, min(2.5 * actual_ch, 20))
        fig, axes = plt.subplots(actual_ch, 1, figsize=(16, fig_height), sharex=True)
        if actual_ch == 1:
            axes = [axes]

        for i, ax in enumerate(axes):
            color = colors[i % len(colors)]
            ax.plot(plot_time, plot_data[i], linewidth=0.4, color=color, alpha=0.8)
            cd = data[i]
            ax.set_title(
                f'CH{i}: Min={cd.min():.4f}V Max={cd.max():.4f}V '
                f'Mean={cd.mean():.4f}V Std={cd.std():.4f}V',
                fontsize=9, fontfamily='monospace', loc='left'
            )
            ax.set_ylabel(f'CH{i} (V)', fontsize=9)
            ax.grid(True, alpha=0.3, linestyle='--')

        axes[-1].set_xlabel('Time (s)', fontsize=10)
        rate_str = f"{sampling_rate / 1e6:.1f} MHz" if sampling_rate >= 1e6 else f"{sampling_rate / 1e3:.0f} KHz"
        fig.suptitle(f'{actual_ch}CH, {actual_sp:,} Samples, {rate_str}', fontsize=12, fontweight='bold')
        plt.tight_layout()
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"  ✅ 已保存: {save_path}, 耗时: {time.time() - t_start:.2f}s")
        return True
    else:
        print(f"  ❌ 无数据: {get_status_description(status)}")
        return False


# =============================================================================
# 主函数
# =============================================================================

def main():
    global client

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    print(f"LXI 测试工具 v{VERSION} ({platform.architecture()[0]}) - 输入 help 获取帮助")

    try:
        client = LxiClient()
    except Exception as e:
        print(f"初始化失败: {e}")
        return

    DEF_CONN = "--serverIp 192.168.201.1 --serverPort 8080"
    DEF_START = ("--rateMode high --channelMode single --rate 100 --packets 0 "
                 "--range 1 --openChannels 1 9 17 25 33 41 --readMode single")

    while True:
        try:
            _interrupted.clear()  # 每次命令前清除中断标志
            line = input("LXI> ").strip()
            if not line:
                continue

            parts = line.split()
            cmd = parts[0].lower()

            if cmd == "help":
                print_help()

            elif cmd == "exit":
                break

            elif cmd == "verify":
                verify_struct_sizes()

            elif cmd == "connect":
                params = " ".join(parts[1:]) if len(parts) > 1 else DEF_CONN
                client.connect(params)

            elif cmd == "disconnect":
                client.disconnect()

            elif cmd == "start":
                params = " ".join(parts[1:]) if len(parts) > 1 else DEF_START
                client.start_sampling(params)

            elif cmd == "stop":
                params = " ".join(parts[1:]) if len(parts) > 1 else ""
                client.stop_sampling(params)

            elif cmd == "info":
                info = client.get_sampling_info()
                if info:
                    print(f"采样信息: {info}, 模式: {client.current_read_mode.upper()}")

            elif cmd == "chconfig":
                cfg = client.get_channel_config()
                if cfg:
                    print(f"通道配置: {cfg}")

            elif cmd == "numch":
                n = client.get_num_channels()
                print(f"通道数: {n}" if n > 0 else f"获取失败: {n}")

            elif cmd == "read":
                if len(parts) < 3:
                    print("用法: read <ch> <samples> [timeout]")
                    continue
                ch, sp = int(parts[1]), int(parts[2])
                timeout = int(parts[3]) if len(parts) > 3 else 100

                status, data, ach, asp = client.read_data(ch, sp, timeout)
                if status == LXI_RESULT_OK and data:
                    print(f"成功: {ach}ch x {asp}点")
                    for i in range(min(2, ach)):
                        d = data[i]
                        print(f"  CH{i}: [{', '.join(f'{v:.3f}' for v in d[:8])}...] "
                              f"min={min(d):.3f} max={max(d):.3f}")
                elif status == LXI_RESULT_BUFFER_OVERFLOW:
                    print("⚠️ 缓存溢出")
                else:
                    print(f"失败: {get_status_description(status)} ({status})")

            elif cmd == "response":
                resp = client.read_response()
                if resp:
                    print(f"响应: {' '.join(f'{b:02X}' for b in resp)}")
                else:
                    print("无响应")

            elif cmd == "calibration":
                if len(parts) < 2:
                    print("用法: calibration <channel> [timeout]")
                    continue
                ch = int(parts[1])
                timeout = int(parts[2]) if len(parts) > 2 else 500
                status, cal = client.get_sampling_rate_calibration(ch, timeout)
                if status == LXI_RESULT_OK:
                    print(f"通道{ch}标定值: {cal} PPM")
                else:
                    print(f"失败: {get_status_description(status)}")

            elif cmd == "autoread":
                interval = int(parts[1]) if len(parts) > 1 else 500
                client.start_auto_read(interval)

            elif cmd == "stopread":
                client.stop_auto_read()

            # =================================================================
            # packettest — 分段读取压力测试
            # =================================================================
            elif cmd == "packettest":
                loops = 0
                total_packets = 15000
                first_read_packets = 10000
                delay_sec = 2.0
                interval_ms = 100

                i = 1
                while i < len(parts):
                    if parts[i] == "--loops" and i+1 < len(parts):
                        loops = int(parts[i+1]); i += 2
                    elif parts[i] == "--packets" and i+1 < len(parts):
                        total_packets = int(parts[i+1]); i += 2
                    elif parts[i] == "--firstread" and i+1 < len(parts):
                        first_read_packets = int(parts[i+1]); i += 2
                    elif parts[i] == "--delay" and i+1 < len(parts):
                        delay_sec = float(parts[i+1]); i += 2
                    elif parts[i] == "--interval" and i+1 < len(parts):
                        interval_ms = int(parts[i+1]); i += 2
                    else:
                        i += 1

                if first_read_packets >= total_packets:
                    print(f"错误: --firstread ({first_read_packets}) 必须小于 --packets ({total_packets})")
                    continue

                start_p = DEF_START.replace("--packets 0", f"--packets {total_packets}")
                start_p = start_p.replace("--readMode continue", "--readMode single")

                run_packet_test(client, loops, total_packets, first_read_packets,
                                delay_sec, interval_ms, DEF_CONN, start_p)

            # =================================================================
            # plottest — 循环压力测试 + 波形
            # =================================================================
            elif cmd == "plottest":
                sample_count = 1200000
                timeout_ms = 5000
                interval_ms = 100
                save_path = None
                decimate = 0

                i = 1
                while i < len(parts):
                    if parts[i] == "--samples" and i+1 < len(parts):
                        sample_count = int(parts[i+1]); i += 2
                    elif parts[i] == "--timeout" and i+1 < len(parts):
                        timeout_ms = int(parts[i+1]); i += 2
                    elif parts[i] == "--interval" and i+1 < len(parts):
                        interval_ms = int(parts[i+1]); i += 2
                    elif parts[i] == "--save" and i+1 < len(parts):
                        save_path = parts[i+1]; i += 2
                    elif parts[i] == "--decimate" and i+1 < len(parts):
                        decimate = int(parts[i+1]); i += 2
                    else:
                        i += 1

                start_p = DEF_START.replace("--readMode continue", "--readMode single")
                if "--readMode" not in start_p:
                    start_p += " --readMode single"

                if save_path:
                    run_plot_save(client, DEF_CONN, start_p, sample_count,
                                  timeout_ms, save_path, decimate)
                else:
                    run_plot_stress_test(client, DEF_CONN, start_p, sample_count,
                                        timeout_ms, interval_ms, decimate)

            elif cmd == "clearall":
                client.clear_all()

            elif cmd == "status":
                if client.is_connected():
                    print(f"已连接 (ID:{client.instance_id}), "
                          f"模式:{client.current_read_mode.upper()}")
                    n = client.get_num_channels()
                    if n > 0:
                        print(f"  通道数: {n}")
                else:
                    print("未连接")

            else:
                print(f"未知命令: {cmd}")

        except KeyboardInterrupt:
            print()  # 换行
            # 如果在 input() 处被中断，只是回到提示符
            # 如果在测试函数中被中断，测试函数自己处理了清理
            break

        except EOFError:
            break

        except ValueError as e:
            print(f"参数错误: {e}")
        except Exception as e:
            print(f"错误: {e}")

    # 正常退出
    if client:
        client.cleanup()
    print("已退出")


if __name__ == "__main__":
    main()

