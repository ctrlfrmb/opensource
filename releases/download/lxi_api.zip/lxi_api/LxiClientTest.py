#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# LxiClientTest.py - LXI客户端API测试和命令行界面

from LxiClient import LxiClient
import signal
import sys
import time

client = None

def signal_handler(sig, frame):
    print("\n接收到中断信号，正在清理资源...")
    if client:
        client.cleanup()
    print("程序已终止。")
    sys.exit(0)

def print_help():
    print("\n可用命令:")
    print("  help                                      显示此帮助信息")
    print("  connect <server_ip> <server_port>           连接到LXI设备 (例如: connect 192.168.1.10 5000)")
    print("  disconnect                                  断开与LXI设备的连接")
    print("  start [hex_command]                         发送开始采集命令 (不带参数则使用默认命令)")
    print("  stop [hex_command]                          发送停止采集命令 (不带参数则使用默认命令)")
    print("  read                                        手动读取一次数据")
    print("  response                                    读取一次命令响应")
    print("  autoRead                                    启动后台线程自动读取数据")
    print("  stopRead                                    停止后台自动读取")
    print("  runtest <duration_sec>                      运行一个自动化的连接-采集-停止-断开测试")
    print("  clearall                                    断开所有连接并清理所有实例")
    print("  status                                      检查当前连接状态")
    print("  exit                                        退出程序")
    print("\n示例:")
    print("  connect 192.168.1.10 5000")
    print("  start")
    print("  autoRead")
    print("  (等待一段时间后)")
    print("  stopRead")
    print("  stop")


def main():
    global client
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("=" * 60)
    print(" LXI 客户端命令行测试工具 v1.1.0 (新增读数据功能)")
    print("=" * 60)
    print("输入 'help' 获取帮助, 输入 'exit' 退出程序。")
    
    try:
        client = LxiClient()
    except Exception as e:
        print(f"初始化LXI客户端失败: {e}")
        return

    default_start_cmd = "AA 55 D7 01 A0 01 00 14 06 64 00 32 03 01 09 10 18 1F 27 A3"
    default_stop_cmd = "AA 55 D7 01 A0 00 00 0B 00 78"

    while True:
        try:
            cmd_line = input("LXI> ").strip()
            if not cmd_line:
                continue

            parts = cmd_line.split()
            command = parts[0].lower()

            if command == "help":
                print_help()
            
            elif command == "exit":
                break

            elif command == "connect":
                if len(parts) != 3:
                    print("用法: connect <server_ip> <server_port>")
                else:
                    try:
                        client.connect(parts[1], int(parts[2]))
                    except ValueError:
                        print("错误: 端口号必须是整数。")
            
            elif command == "disconnect":
                client.disconnect()
            
            elif command == "start":
                hex_cmd = " ".join(parts[1:]) if len(parts) > 1 else default_start_cmd
                client.start_collecting(hex_cmd)

            elif command == "stop":
                hex_cmd = " ".join(parts[1:]) if len(parts) > 1 else default_stop_cmd
                client.stop_collecting(hex_cmd)

            elif command == "read":
                packets = client.read_data()
                if packets:
                    print(f"成功读取 {len(packets)} 个数据包:")
                    for pkt in packets:
                        print(f"  -> {pkt}")
                else:
                    print("未读取到数据包。")

            elif command == "response":
                resp = client.read_response()
                if resp:
                    hex_str = ' '.join(f'{b:02X}' for b in resp)
                    print(f"成功读取响应 ({len(resp)}字节): {hex_str}")
                else:
                    print("未读取到响应或读取失败。")

            elif command == "autoread":
                client.start_auto_read()
            
            elif command == "stopread":
                client.stop_auto_read()

            elif command == "runtest":
                if len(parts) != 2:
                    print("用法: runtest <duration_sec>")
                else:
                    try:
                        duration = int(parts[1])
                        print("\n--- 开始自动化测试 ---")
                        if client.connect("192.168.1.10", 5000):
                            time.sleep(0.5)
                            if client.start_collecting(default_start_cmd):
                                print(f"采集中，将持续 {duration} 秒... (请在后台查看日志确认丢包情况)")
                                client.start_auto_read()
                                time.sleep(duration)
                                client.stop_auto_read()
                                client.stop_collecting(default_stop_cmd)
                            time.sleep(0.5)
                            client.disconnect()
                        print("--- 自动化测试结束 ---\n")
                    except ValueError:
                        print("错误: 测试时长必须是整数。")

            elif command == "clearall":
                client.clear_all()

            elif command == "status":
                if client.is_connected():
                    print(f"状态: 已连接, 实例 ID: {client.instance_id}")
                else:
                    print("状态: 未连接")

            else:
                print(f"未知命令: '{command}'. 输入 'help' 查看可用命令。")

        except Exception as e:
            print(f"发生未预料的错误: {e}")

    if client:
        client.cleanup()
    print("程序已退出。")

if __name__ == "__main__":
    main()
