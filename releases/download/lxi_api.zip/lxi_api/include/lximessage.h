/*----------------------------------------------------------------------------
*               LXI 通信协议消息定义
*-----------------------------------------------------------------------------
*
* 该文件定义了与 LXI 设备通信所使用的核心数据结构、枚举和宏。
* 此文件对外暴露，供用户应用程序使用。
*
* 使用注意事项：
* - 所有结构体按 4 字节对齐，跨平台兼容
* - 通道索引从 0 开始（ai0 对应物理通道 CH1）
* - 错误码为负数，成功为 0
* - 不包含任何外部头文件，确保 LabView 等工具兼容
*
* 作者: leiwei
* 版本: v3.6.0
* 日期: 2026-05-08
*----------------------------------------------------------------------------*/

#ifndef LXI_MESSAGE_H
#define LXI_MESSAGE_H

#ifdef _MSC_VER
#pragma pack(push, 4)
#else
#pragma pack(4)
#endif

/**
 * @brief 最大支持的通道数
 */
#define LXI_MAX_CHANNELS 48

/**
 * @brief API 操作结果码
 */
typedef enum {
    // === 成功状态 ===
    LXI_RESULT_OK = 0,

    // === 参数和配置错误 (-1 ~ -10) ===
    LXI_RESULT_INVALID_PARAM = -1,
    LXI_RESULT_INTERNAL_ERROR = -2,
    LXI_RESULT_INVALID_CHANNEL_SPEC = -3,
    LXI_RESULT_BUFFER_TOO_SMALL = -4,
    LXI_RESULT_CHANNEL_NOT_CONFIGURED = -5,
    LXI_RESULT_CHANNEL_COUNT_MISMATCH = -6,
    LXI_RESULT_NOT_SAMPLING = -7,
    LXI_RESULT_SAMPLE_COUNT_EXCEEDED = -8,
    LXI_RESULT_SAMPLING_IN_PROGRESS = -9,

    // === 连接相关错误 (-11 ~ -20) ===
    LXI_RESULT_CONNECTION_FAILED = -11,
    LXI_RESULT_TOO_MANY_INSTANCES = -12,
    LXI_RESULT_INVALID_INSTANCE_ID = -13,
    LXI_RESULT_DEVICE_NOT_FOUND = -14,

    // === 数据读写错误 (-21 ~ -30) ===
    LXI_RESULT_SEND_FAILED = -21,
    LXI_RESULT_NO_DATA = -22,
    LXI_RESULT_READ_TIMEOUT = -23,
    LXI_RESULT_DATA_NOT_READY = -24,
    LXI_RESULT_BUFFER_OVERFLOW = -25,
    /** UDP 数据包序列号不连续，缓存时间轴存在间断（FINITE / SINGLE 读路径会返回此码） */
    LXI_RESULT_PACKET_LOSS = -26,

    // === 命令响应错误 (-400 ~ -499) ===
    LXI_RESULT_COMMAND_NO_RESPONSE = -404
} LxiResultCode;

/**
 * @brief 采样状态信息（8 字节，4 字节对齐）
 */
typedef struct LxiSamplingInfo_ {
    unsigned char total_channel_count;
    unsigned char samples_per_packet;
    unsigned char selected_channel_count;
    unsigned char reserved;
    unsigned int sampling_rate;
} LxiSamplingInfo;

/**
 * @brief 通道配置信息（52 字节，4 字节对齐）
 */
typedef struct LxiChannelConfig_ {
    unsigned char channel_indices[LXI_MAX_CHANNELS];
    unsigned char selected_channel_count;
    unsigned char total_available_channels;
    unsigned char samples_per_packet;
    unsigned char reserved;
} LxiChannelConfig;

#ifdef _MSC_VER
#pragma pack(pop)
#else
#pragma pack()
#endif

#endif // LXI_MESSAGE_H
