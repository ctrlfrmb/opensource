/*----------------------------------------------------------------------------
*               LXI 通信协议消息定义
*-----------------------------------------------------------------------------
*
* 该文件定义了与LXI设备通信所使用的核心数据结构、枚举和宏。
*
* 作者: leiwei
* 版本: v2.0.0
* 日期: 2025-10-23
*----------------------------------------------------------------------------*/

#ifndef LXI_MESSAGE_H
#define LXI_MESSAGE_H

typedef unsigned char                                       UINT8_T;

// 确保结构体按4字节对齐
#ifdef _MSC_VER
    #pragma pack(push, 4)
#else
    #pragma pack(4)
#endif

#define LXI_MAX_DATA_POINTS 600

// --- 操作结果枚举 ---
typedef enum {
    LXI_RESULT_OK = 0,
    LXI_RESULT_INVALID_PARAM = -1,
    LXI_RESULT_INTERNAL_ERROR = -2,
    LXI_RESULT_CONNECTION_FAILED = -6,
    LXI_RESULT_TOO_MANY_INSTANCES = -11,
    LXI_RESULT_INVALID_INSTANCE_ID = -12,
    LXI_RESULT_SEND_FAILED = -21,
    LXI_RESULT_NO_DATA = -22,
    LXI_RESULT_COMMAND_NO_RESPONSE = -404
} LxiResultCode;


// --- 外部数据结构 ---

/**
 * @struct LxiSamplingInfo
 * @brief 存储当前采样任务的配置信息。
 */
typedef struct LxiSamplingInfo_ {
    int channel_count;              ///< 有效通道数 (例如: 6 或 48)。
    int sample_count_per_channel;   ///< 每个通道的采样点数 (例如: 100 或 10)。
} LxiSamplingInfo;

/**
 * @struct LxiVoltagePacket
 * @brief 存储一个完整数据包解析后的电压数据。这是一个纯数据容器。
 *        如何解析内部的 voltages 数组，需要结合 LxiSamplingInfo 的信息。
 */
typedef struct LxiVoltagePacket_ {
    unsigned int index;       ///< 数据帧的唯一索引，从1开始单调递增。
    UINT8_T serial_code;      ///< 当前数据帧的序列号。
    UINT8_T last_serial_code; ///< 上一个成功接收的数据帧的序列号。
    UINT8_T reserved;         ///< 保留字段，用于内存对齐。
    UINT8_T reserved2;         ///< 保留字段，用于内存对齐。

    /**
     * @brief 存储所有电压数据的一维数组。
     *
     *        数据按通道顺序排列
     *        形如：
     *          ADC1~ADC6, ADC1~ADC6, ADC1~ADC6...
     *          ADC1~ADC3, ADC1~ADC3, ADC1~ADC3...
     *          ADC1~ADC48, ADC1~ADC48, ADC1~ADC48...
     *          ADC1~ADC24, ADC1~ADC24, ADC1~ADC24...
     */
    float voltages[LXI_MAX_DATA_POINTS];
} LxiVoltagePacket;

// 恢复默认的内存对齐设置
#ifdef _MSC_VER
    #pragma pack(pop)
#else
    #pragma pack()
#endif

#endif // LXI_MESSAGE_H
