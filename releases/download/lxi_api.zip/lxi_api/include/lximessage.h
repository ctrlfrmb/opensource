/*----------------------------------------------------------------------------
*               LXI 通信协议消息定义
*-----------------------------------------------------------------------------
*
* 该文件定义了与LXI设备通信所使用的核心数据结构、枚举和宏。
* 这些定义是上层API和底层网络通信之间的桥梁。
*
* 主要内容:
* - LxiResultCode: 用于标识API调用结果的统一错误码。
* - LXIOutputData: 用于从API接收处理后数据的标准输出结构体。
* - 内存对齐控制: 使用#pragma pack确保结构体在不同平台上的内存布局一致性，
*   这对于跨网络或进行二进制文件操作至关重要。
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2025 丰柯科技。保留所有权利。
*
* 本软件按许可协议提供。使用本软件即表示接受许可条款。
*
* 作者: leiwei
* 版本: v1.0.0
* 日期: 2025-10-17
*----------------------------------------------------------------------------*/

#ifndef LXI_MESSAGE_H
#define LXI_MESSAGE_H

#include <stdint.h> // 用于定义如 uint8_t, uint16_t 等固定宽度的整数类型

// 确保结构体按4字节对齐，以匹配特定平台的性能要求或协议规范。
// 这可以防止编译器因优化而自由添加填充字节，保证内存布局的确定性。
#ifdef _MSC_VER
    #pragma pack(push, 4)
#else
    #pragma pack(4)
#endif

/**
 * @def LXI_OUTPUT_DATA_MAX_SIZE
 * @brief 定义外部输出数据结构中数据缓冲区的最大尺寸。
 *        该值通常参考网络MTU（最大传输单元）大小（约1500字节）来设定，
 *        以优化网络传输效率并避免IP层分片。
 */
#define LXI_OUTPUT_DATA_MAX_SIZE 1500

// --- 操作结果枚举 ---

/**
 * @brief LXI操作的统一结果代码。
 *        所有API函数返回这些代码以指示操作的成功或失败状态。
 */
typedef enum {
    LXI_RESULT_OK = 0,                  ///< 操作成功完成。

    LXI_RESULT_INVALID_PARAM = 1,       ///< 提供了无效的参数（例如，空指针、范围错误的数值）。
    LXI_RESULT_INTERNAL_ERROR = 2,      ///< 发生意外的内部错误（例如，内存分配失败）。
    LXI_RESULT_CONNECTION_FAILED = 6,   ///< 建立网络连接失败。

    LXI_RESULT_TOO_MANY_INSTANCES = 11, ///< 客户端实例数量已达到上限。
    LXI_RESULT_INVALID_INSTANCE_ID = 12,///< 指定的实例ID无效或不存在。

    LXI_RESULT_SEND_FAILED = 21,        ///< 通过网络发送数据失败。
    LXI_RESULT_NO_DATA = 22,            ///< 在指定的超时时间内没有接收到数据。

} LxiResultCode;


// --- 外部数据结构 ---

/**
 * @struct LXIOutputData
 * @brief 定义了从API获取的、经过处理的数据包结构。
 *        该结构体用于向上层应用传递LXI设备采集到的数据及其元信息。
 *        设计上考虑了64位对齐，以提升在某些架构上的访问性能。
 */
typedef struct LXIOutputData_ {
    /* 64位边界 - 0 */
    unsigned int index;             ///< 数据帧的唯一索引，从1开始单调递增。
    unsigned char serial_code;      ///< 当前数据帧的序列号（通常来自原始LXI数据包）。
    unsigned char last_serial_code; ///< 上一个成功接收的数据帧的序列号，用于上层判断丢包。
    unsigned short length;          ///< `data` 缓冲区中有效数据的实际长度（字节）。

    /* 64位边界 - 8 */
    unsigned char data[LXI_OUTPUT_DATA_MAX_SIZE]; ///< 存储原始或已处理数据的缓冲区。

    /* 64位边界 - 1508 */
    unsigned int reserved;          ///< 保留字段，用于未来扩展或确保结构体总大小为8的倍数。

    // 结构体总大小: 8 + 1500 + 4 = 1512字节 (1512 / 8 = 189，是8字节的整数倍)
} LXIOutputData;

// 恢复默认的内存对齐设置
#ifdef _MSC_VER
    #pragma pack(pop)
#else
    #pragma pack()
#endif

#endif // LXI_MESSAGE_H
