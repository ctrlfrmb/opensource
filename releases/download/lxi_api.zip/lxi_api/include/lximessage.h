/*----------------------------------------------------------------------------
*               LXI 通信协议消息定义
*-----------------------------------------------------------------------------
*
* 该文件定义了与LXI设备通信所使用的核心数据结构、枚举和宏。
* 此文件对外暴露，供用户使用。
*
* 作者: leiwei
* 版本: v3.2.0
* 日期: 2025-11-04
*----------------------------------------------------------------------------*/

#ifndef LXI_MESSAGE_H
#define LXI_MESSAGE_H

// 确保结构体按4字节对齐
#ifdef _MSC_VER
#pragma pack(push, 4)
#else
#pragma pack(4)
#endif

// =============================================================================
// 基础常量
// =============================================================================
#define LXI_MAX_CHANNELS 48              // 最大支持的通道数
#define LXI_MAX_SAMPLES_PER_READ 10000   // 单次读取最大采样点数

// =============================================================================
// 操作结果枚举
// =============================================================================
typedef enum {
    // === 成功状态 ===
    LXI_RESULT_OK = 0,                      // 操作成功

    // === 参数和配置错误 (-1 ~ -10) ===
    LXI_RESULT_INVALID_PARAM = -1,          // 无效的参数（空指针、越界值等）
    LXI_RESULT_INTERNAL_ERROR = -2,         // 内部错误（异常、未知状态等）
    LXI_RESULT_INVALID_CHANNEL_SPEC = -3,   // 无效的通道规格字符串
    LXI_RESULT_BUFFER_TOO_SMALL = -4,       // 缓冲区太小
    LXI_RESULT_CHANNEL_NOT_CONFIGURED = -5, // 通道未配置
    LXI_RESULT_CHANNEL_COUNT_MISMATCH = -6, // 通道数不匹配
    LXI_RESULT_NOT_SAMPLING = -7,           // 未在采样状态
    LXI_RESULT_SAMPLE_COUNT_EXCEEDED = -8,  // 采样点数超过限制

    // === 连接相关错误 (-11 ~ -20) ===
    LXI_RESULT_CONNECTION_FAILED = -11,     // 设备连接失败
    LXI_RESULT_TOO_MANY_INSTANCES = -12,    // 实例数量超过上限
    LXI_RESULT_INVALID_INSTANCE_ID = -13,   // 无效的实例ID
    LXI_RESULT_DEVICE_NOT_FOUND = -14,      // 设备未响应（探测失败）

    // === 数据读写错误 (-21 ~ -30) ===
    LXI_RESULT_SEND_FAILED = -21,           // 发送数据失败
    LXI_RESULT_NO_DATA = -22,               // 没有数据可读
    LXI_RESULT_READ_TIMEOUT = -23,          // 读取超时
    LXI_RESULT_DATA_NOT_READY = -24,        // 数据未就绪

    // === 命令响应错误 (-400 ~ -499) ===
    LXI_RESULT_COMMAND_NO_RESPONSE = -404   // 命令发送后未收到设备响应
} LxiResultCode;

// =============================================================================
// 采样信息结构
// =============================================================================
typedef struct LxiSamplingInfo_ {
    int channel_count;              ///< 有效通道数
    int sample_count_per_channel;   ///< 每个通道每包的采样点数
    int sampling_rate;              ///< 当前采样率 (单位: Hz)
} LxiSamplingInfo;

// =============================================================================
// 通道配置结构
// =============================================================================
typedef struct LxiChannelConfig_ {
    int channel_indices[LXI_MAX_CHANNELS];   ///< 用户选择的通道索引数组（已排序）
    int selected_channel_count;              ///< 用户选择的通道数量
    int total_available_channels;            ///< 当前采样模式下可用的总通道数
    int samples_per_channel;                 ///< 每个通道每包的采样点数
} LxiChannelConfig;

// =============================================================================
// 设备信息结构（探测响应）
// =============================================================================
typedef struct LxiDeviceInfo_ {
    unsigned char device_type;      ///< 设备类型 (0xD7 = AI45)
    unsigned char slot_id;          ///< 设备位置（机箱+卡槽）
    unsigned char hw_version;       ///< 硬件版本
    unsigned char sw_version;       ///< 软件版本
} LxiDeviceInfo;

// 恢复默认的内存对齐设置
#ifdef _MSC_VER
#pragma pack(pop)
#else
#pragma pack()
#endif

#endif // LXI_MESSAGE_H
