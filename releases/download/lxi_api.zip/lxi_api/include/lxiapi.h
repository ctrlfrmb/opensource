/*----------------------------------------------------------------------------
*               LXI 高速数据采集卡 C-API 接口
*-----------------------------------------------------------------------------
*
* 提供高性能的LXI数据采集卡通信接口，支持设备连接、多模式数据采集控制。
* 该API旨在为上层应用提供一个简单、稳定、高效的硬件控制层，并已封装为
* 跨平台的动态链接库（DLL/SO）。
*
* v3.2.0 重大更新：
* - LXIAIGetDataBuffer: sampleCount 改为输入参数，用户指定需要读取的采样点数
* - 环形缓冲区设计：支持累积最多 10000 个采样点
* - 移除 LXIAIReadVoltages 接口（使用 LXIAIGetDataBuffer 替代）
* - 内部数据处理线程优化，提升高速数据流性能
*
* 主要特点：
* - 建立与LXI设备的UDP连接（包含设备探测验证）
* - 支持四种采集模式：高速单端/差分，低速单端/差分
* - 内部实现基于内存池的高性能数据接收，避免丢包
* - 自动检测数据包序列号，监控丢包情况
* - 使用实例ID进行多设备并行管理
* - 环形缓冲区累积数据，用户可指定读取的采样点数
* - 完善的日志功能，便于调试和问题追溯
* - 健壮的错误处理机制和明确的状态码
* - 跨平台支持（Windows/Linux）
* - 线程安全设计
*
* LabVIEW 使用示例（推荐方式）:
* @code
*   // 1. 连接设备（包含设备探测）
*   int instanceId = LXIConnect("--serverIp 192.168.1.10 --serverPort 8080 --connectTimeout 1000");
*   if (instanceId <= 0) {
*       // 连接失败或设备未响应
*       return;
*   }
*
*   // 2. 启动低速单端采集 (48通道，每包10采样点)
*   LXIAIStartSampling(instanceId, "--rateMode low --channelMode single --rate 50 --packets 0");
*
*   // 3. 配置要读取的通道 (只读取通道0和8，对应物理CH1和CH9)
*   LXIAIConfigureChannels(instanceId, "ai0,8");
*
*   // 4. 循环读取数据
*   while (running) {
*       float* dataPtr = NULL;
*       int channelCount = 2;    // 期望2个通道
*       int sampleCount = 100;   // 期望每通道100个采样点
*
*       int result = LXIAIGetDataBuffer(instanceId, &dataPtr, &channelCount, &sampleCount, 1000);
*       if (result == LXI_RESULT_OK && dataPtr != NULL) {
*           // dataPtr 指向DLL内部缓冲区，数据布局：
*           // [ch0_s0, ch0_s1, ..., ch0_s99, ch8_s0, ch8_s1, ..., ch8_s99]
*           // channelCount = 2, sampleCount = 实际返回的采样点数
*
*           // 直接使用数据
*           processData(dataPtr, channelCount, sampleCount);
*       }
*   }
*
*   // 5. 停止采样并断开
*   LXIAIStopSampling(instanceId, NULL);
*   LXIDisconnect(instanceId);
* @endcode
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2025 丰柯科技。保留所有权利。
*
* 作者: leiwei
* 版本: v3.2.0
* 日期: 2025-11-04
*----------------------------------------------------------------------------*/

#ifndef LXI_API_H
#define LXI_API_H

#include "lximessage.h"

#ifdef _WIN32
#ifdef BUILD_LXI_API
#define LXI_API extern "C" __declspec(dllexport)
#else
#define LXI_API extern "C" __declspec(dllimport)
#endif
#else
#define LXI_API extern "C"
#endif

// ============================================================================
//                              日志管理
// ============================================================================

/**
 * @brief 打开日志，用于调试和故障诊断。
 *
 * 建议仅在调试时使用，日志会占用CPU资源和硬盘空间。
 *
 * @param logFile   日志文件路径，例如: "logs/lxi_api.log"
 * @param level     日志等级: 0=DEBUG, 1=INFO, 2=WARN, 3=ERROR
 * @param maxSize   单个日志文件的最大尺寸 (单位: MB, 范围 1-100)
 * @param maxFiles  日志文件的最大保留数量 (范围 1-20)
 * @return 0 表示成功，其他值为失败
 */
LXI_API int LXIOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志系统，释放资源。
 * @return 0 表示成功
 */
LXI_API int LXICloseLog();


// ============================================================================
//                              连接管理
// ============================================================================

/**
 * @brief 连接到LXI设备并创建一个会话实例。
 *
 * 连接过程包含设备探测验证：发送查询命令并等待设备响应。
 * 如果设备在指定超时时间内未响应，返回 LXI_RESULT_DEVICE_NOT_FOUND。
 *
 * @param commands 参数化连接字符串，格式为 key-value 对。
 *
 * @b 支持的参数:
 *   - `--serverIp <string>`: (必填) LXI设备的IP地址
 *   - `--serverPort <int>`: (可选, 默认: 8080) LXI设备的UDP端口
 *   - `--localIp <string>`: (可选) 绑定本地网卡IP，用于多网卡环境
 *   - `--localPort <int>`: (可选) 绑定本地UDP端口
 *   - `--startSn <int>`: (可选, 0-255, 默认: 0) 期望的起始包序列号
 *   - `--connectTimeout <int>`: (可选, 默认: 500) 设备探测超时时间（毫秒）
 *
 * @b 示例:
 * @code
 *   // 基本连接
 *   int id = LXIConnect("--serverIp 192.168.1.10 --serverPort 8080");
 *
 *   // 设置较长的探测超时（网络较慢时）
 *   int id = LXIConnect("--serverIp 192.168.1.10 --connectTimeout 2000");
 * @endcode
 *
 * @return 成功时返回正数实例ID (>0)，失败时返回负数错误码:
 *         - LXI_RESULT_CONNECTION_FAILED (-11): UDP连接失败
 *         - LXI_RESULT_DEVICE_NOT_FOUND (-14): 设备未响应探测命令
 *         - LXI_RESULT_TOO_MANY_INSTANCES (-12): 实例数超过上限
 */
LXI_API int LXIConnect(const char* commands);

/**
 * @brief 断开与LXI设备的连接并销毁指定实例。
 *
 * @param instanceId 由 LXIConnect 返回的实例ID
 * @return LXI_RESULT_OK (0) 表示成功，其他值为错误码
 */
LXI_API int LXIDisconnect(int instanceId);

/**
 * @brief 断开所有连接并清理所有实例资源。
 * @return LXI_RESULT_OK (0) 表示成功
 */
LXI_API int LXIClearAll();


// ============================================================================
//                              采集控制
// ============================================================================

/**
 * @brief 启动任意模式的采样，并同步等待设备响应。
 *
 * @param instanceId 由 LXIConnect 返回的实例ID
 * @param params 参数化配置字符串
 *
 * @b 必填参数:
 *   - `--rateMode <string>`: 速率模式。可选值: `high` (高速), `low` (低速)
 *   - `--channelMode <string>`: 通道模式。可选值: `single` (单端), `diff` (差分)
 *
 * @b 可选参数:
 *   - `--slotId <int>`: 目标板卡的卡槽ID，默认从连接IP的最后一位获取
 *   - `--rate <int>`: 采样率代码 (1-100)，默认: 100
 *     - 高速模式: 1-100 对应 10KHz-1000KHz
 *     - 低速模式: 1-100 对应 1KHz-100KHz
 *   - `--packets <int>`: 采集包数 (0-65535)，默认: 100。`0` 表示持续采集
 *   - `--range <int>`: 量程代码，默认: 3。可选值: `1` (±5V), `2` (±10V), `3` (±20V)
 *   - `--timeout <int>`: 等待设备响应的超时时间（毫秒），默认: 500
 *
 * @b 采样模式与通道数对应关系:
 *   | 模式 | 通道数 | 每包采样点 | 数据排列 |
 *   |------|--------|------------|----------|
 *   | 高速单端 | 6 | 100 | 顺序排列 |
 *   | 高速差分 | 3 | 100 | 顺序排列 |
 *   | 低速单端 | 48 | 10 | 按映射表排列 |
 *   | 低速差分 | 24 | 10 | 按映射表排列 |
 *
 * @return LXI_RESULT_OK (0) 表示成功
 */
LXI_API int LXIAIStartSampling(int instanceId, const char* params);

/**
 * @brief 停止当前正在进行的采样。
 *
 * @param instanceId 由 LXIConnect 返回的实例ID
 * @param params 可选参数字符串
 *   - `--timeout <int>`: 等待响应超时时间（毫秒），默认: 100
 *
 * @return LXI_RESULT_OK (0) 表示成功
 */
LXI_API int LXIAIStopSampling(int instanceId, const char* params);

/**
 * @brief 获取当前采样模式的信息。
 *
 * @param instanceId 实例ID
 * @param info [out] 接收采样信息的结构体指针
 * @return LXI_RESULT_OK (0) 表示成功
 */
LXI_API int LXIAIGetSamplingInfo(int instanceId, LxiSamplingInfo* info);


// ============================================================================
//                      通道配置
// ============================================================================

/**
 * @brief 配置要读取的通道。
 *
 * 配置后，调用 LXIAIGetDataBuffer 时将只返回指定通道的数据。
 * 通道索引从0开始：ai0 对应物理通道 CH1。
 *
 * @param instanceId 实例ID
 * @param channelSpec 通道规格字符串，支持以下格式：
 *   - `"ai0:5"` - 连续通道: ai0, ai1, ai2, ai3, ai4, ai5
 *   - `"ai0,2,5"` - 离散通道: ai0, ai2, ai5
 *   - `"ai0:2,5:7"` - 混合格式: ai0, ai1, ai2, ai5, ai6, ai7
 *   - `"ai0,8"` - 低速模式示例：只读取通道0和通道8（物理CH1和CH9）
 *   - `NULL` 或 `""` - 选择当前模式下的所有通道
 *
 * @b 通道范围 (取决于采样模式):
 *   | 模式 | 有效通道范围 | 说明 |
 *   |------|--------------|------|
 *   | 高速单端 | ai0 ~ ai5 | 6个ADC通道 |
 *   | 高速差分 | ai0 ~ ai2 | 3对差分通道 |
 *   | 低速单端 | ai0 ~ ai47 | 45个外部+3个内部自检 |
 *   | 低速差分 | ai0 ~ ai23 | 21对外部+3对不可用 |
 *
 * @return LXI_RESULT_OK 成功，LXI_RESULT_INVALID_CHANNEL_SPEC (-3) 通道规格无效
 *
 * @note 必须在 LXIAIStartSampling 之后调用
 * @note 通道索引从0开始，ai0 对应物理通道 CH1
 */
LXI_API int LXIAIConfigureChannels(int instanceId, const char* channelSpec);

/**
 * @brief 获取当前通道配置信息。
 *
 * @param instanceId 实例ID
 * @param config [out] 接收配置信息的结构体指针
 * @return LXI_RESULT_OK 成功
 */
LXI_API int LXIAIGetChannelConfig(int instanceId, LxiChannelConfig* config);


// ============================================================================
//                      数据读取
// ============================================================================

/**
 * @brief 获取数据缓冲区指针
 *
 * 返回指向DLL内部缓冲区的指针，数据按通道连续排列：
 * [ch0_s0, ch0_s1, ..., ch0_sN, ch1_s0, ch1_s1, ..., ch1_sN, ...]
 *
 * @param instanceId 实例ID
 * @param dataPtr [out] 返回数据指针（指向DLL内部缓冲区）
 * @param channelCount [in/out] 输入: 期望通道数（可传0表示使用配置的通道数）;
 *                              输出: 实际返回的通道数
 * @param sampleCount [in/out] 输入: 期望每通道采样点数 (1 ~ 10000);
 *                              输出: 实际返回的采样点数
 * @param timeout_ms 超时时间（毫秒）
 *        - `<=0`: 非阻塞，返回当前可用数据
 *        - `>0`: 阻塞等待，直到有足够数据或超时
 *
 * @return LXI_RESULT_OK 成功
 *         LXI_RESULT_NO_DATA (-22) 无数据
 *         LXI_RESULT_READ_TIMEOUT (-23) 超时（数据不足）
 *         LXI_RESULT_NOT_SAMPLING (-7) 未在采样状态
 *         LXI_RESULT_CHANNEL_NOT_CONFIGURED (-5) 通道未配置
 *         LXI_RESULT_SAMPLE_COUNT_EXCEEDED (-8) 采样点数超过限制（最大10000）
 *
 * @b 数据布局说明:
 * @code
 *   假设配置了通道 ai0,ai8（低速单端模式），请求100个采样点：
 *
 *   float* dataPtr;
 *   int channelCount = 2;
 *   int sampleCount = 100;
 *   LXIAIGetDataBuffer(instanceId, &dataPtr, &channelCount, &sampleCount, 1000);
 *
 *   // 返回值：
 *   // channelCount = 2 (实际通道数)
 *   // sampleCount = 100 (实际采样点数，可能小于请求值)
 *
 *   // 数据布局：
 *   // dataPtr[0..99]    = 通道0的100个采样点 (物理CH1)
 *   // dataPtr[100..199] = 通道8的100个采样点 (物理CH9)
 *
 *   // 访问某通道某采样点：
 *   // dataPtr[channel_idx * sampleCount + sample_idx]
 * @endcode
 *
 * @b LabVIEW 调用配置:
 * @code
 *   Call Library Function Node 参数配置：
 *   - instanceId: Numeric (I32), Pass by Value
 *   - dataPtr: Pointer-sized Integer (返回值), Pass Pointer to Value
 *   - channelCount: Numeric (I32), Pass Pointer to Value
 *   - sampleCount: Numeric (I32), Pass Pointer to Value
 *   - timeout_ms: Numeric (I32), Pass by Value
 *   - Return: Numeric (I32)
 *
 *   使用 MoveBlock 函数将 dataPtr 指向的数据复制到 LabVIEW 数组：
 *   总字节数 = channelCount * sampleCount * 4 (float为4字节)
 * @endcode
 *
 * @note 返回的指针在下次调用此函数或停止采样前有效
 * @note 必须先调用 LXIAIConfigureChannels 配置通道
 * @note 数据来自环形缓冲区，返回的是最新的 sampleCount 个采样点
 * @note 如果请求的采样点数超过可用数据，返回实际可用的数据量
 */
LXI_API int LXIAIGetDataBuffer(int instanceId,
                               float** dataPtr,
                               int* channelCount,
                               int* sampleCount,
                               int timeout_ms);


// ============================================================================
//                      命令响应读取
// ============================================================================

/**
 * @brief 从指定实例读取最近的命令响应。
 *
 * 用于获取设备对命令的响应数据，通常用于调试或特殊场景。
 *
 * @param instanceId 实例ID
 * @param response_buffer [out] 接收响应的缓冲区
 * @param size [in,out] 输入时为缓冲区大小，输出时为实际读取字节数
 * @return LXI_RESULT_OK 成功
 *         LXI_RESULT_COMMAND_NO_RESPONSE (-404) 无响应数据
 */
LXI_API int LXIAIReadResponse(int instanceId, unsigned char* response_buffer, int* size);


#endif // LXI_API_H
