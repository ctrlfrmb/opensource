/*----------------------------------------------------------------------------
* LXI 高速数据采集卡 API 接口
*
* 提供高性能的LXI数据采集卡通信接口，支持设备连接、高速数据采集控制。
* 该API旨在为上层应用提供一个简单、稳定、高效的硬件控制层。
*
* 主要特点：
* - 建立与LXI设备的UDP连接
* - 发送开始/停止高速数据采集命令
* - 内部实现基于内存池的高性能数据接收，避免丢包
* - 自动检测数据包序列号，监控丢包情况
* - 使用实例ID进行多设备并行管理
* - 完善的日志功能，便于调试和问题追溯
* - 健壮的错误处理机制和明确的状态码
* - 跨平台支持（Windows/Linux）
* - 线程安全设计
*
* C/C++ 使用示例:
*   #include "lxiapi.h"
*   #include <stdio.h>
*   #include <string.h>
*   #ifdef _WIN32
*   #include <windows.h>
*   #define sleep_ms(ms) Sleep(ms)
*   #else
*   #include <unistd.h>
*   #define sleep_ms(ms) usleep(ms * 1000)
*   #endif
*
*   int main() {
*       // 1. (可选) 打开日志，便于调试
*       LXIOpenLog("logs/lxi_api_test.log", 1, 5, 10); // 日志等级INFO, 5MB, 10个文件
*
*       // 2. 连接设备
*       const char* connect_params = "--serverIp 192.168.1.10 --serverPort 5000";
*       int instanceId = LXIConnect(connect_params);
*
*       if (instanceId > 0) {
*           printf("设备连接成功，实例ID: %d\n", instanceId);
*
*           // 3. 发送开始采集命令
*           const char* start_cmd = "AA 55 D7 01 A0 01 00 14 06 64 00 32 03 01 09 10 18 1F 27 A3";
*           if (LXIStartCollecting(instanceId, start_cmd) == LXI_RESULT_OK) {
*               printf("开始采集命令已发送。\n");
*
*               // 4. 循环读取数据
*               printf("开始读取数据，持续5秒...\n");
*               LXIOutputData data_buffer[200]; // 创建一个缓冲区来接收数据
*               for (int i = 0; i < 500; ++i) { // 循环5秒 (500 * 10ms)
*                   int count = LXIReadData(instanceId, data_buffer, 200);
*                   if (count > 0) {
*                       printf("成功读取 %d 个数据包。第一个包的索引: %u, SN: %u\n",
*                              count, data_buffer[0].index, data_buffer[0].serial_code);
*                   } else if (count < 0) {
*                       printf("读取数据时发生错误，错误码: %d\n", count);
*                       break;
*                   }
*                   sleep_ms(10); // 每10毫秒读取一次
*               }
*
*               // 5. 发送停止采集命令
*               const char* stop_cmd = "AA 55 D7 01 A0 00 00 0B 00 78";
*               if (LXIStopCollecting(instanceId, stop_cmd) == LXI_RESULT_OK) {
*                   printf("停止采集命令已发送。\n");
*
*                   // (可选) 读取停止命令的响应
*                   unsigned char response_buf[32];
*                   sleep_ms(100); // 等待响应返回
*                   int resp_len = LXIReadResponse(instanceId, response_buf, 32);
*                   if (resp_len > 0) {
*                       printf("收到响应数据 (%d字节): ", resp_len);
*                       for(int j=0; j<resp_len; ++j) printf("%02X ", response_buf[j]);
*                       printf("\n");
*                   }
*               }
*           }
*
*           // 6. 断开连接
*           LXIDisconnect(instanceId);
*           printf("设备已断开。\n");
*       } else {
*           printf("设备连接失败，错误码: %d\n", instanceId);
*       }
*
*       // 7. (可选) 关闭日志
*       LXICloseLog();
*       return 0;
*   }
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2025 丰柯科技。保留所有权利。
*
* 本软件按许可协议提供。使用本软件即表示接受许可条款。
*
* 作者: leiwei
* 版本: v1.0.0
* 日期: 2025-10-17
*----------------------------------------------------------------------------*/

#ifndef LXI_API_H
#define LXI_API_H

#include "lximessage.h"

// 定义导入/导出宏
#ifdef _WIN32
    #ifdef BUILD_LXI_API
        #define LXI_API extern "C" __declspec(dllexport)
    #else
        #define LXI_API extern "C" __declspec(dllimport)
    #endif
#else
    #define LXI_API extern "C"
#endif

/**
* @brief 打开日志（建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源）
* @param logFile 日志文件路径，例如："logs/lxi_api.log"
* @param level 日志等级，-1:默认输出（默认1）0:DEBUG 1:INFO 2:WARN 3:ERROR
* @param maxSize 文件大小, 范围(1~20), 单位M. -1:默认5M
* @param maxFiles 文件个数, 范围(1~20), -1:默认保留10个文件
* @return 0:打开成功 其它:失败错误码
*/
LXI_API int LXIOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
* @brief 关闭日志
* @return 0:关闭成功 其它:失败错误码
*/
LXI_API int LXICloseLog();

/**
 * @brief 连接到LXI设备
 * @param commands 连接参数字符串，格式为 "--serverIp 192.168.1.10 --serverPort 5000"。
 *                 支持的参数: --serverIp, --serverPort, --localIp, --localPort, --packetLen, --startSn, --queueSize。
 * @return 成功返回大于0的实例ID，失败返回 LxiResultCode 中定义的负数错误码。
 */
LXI_API int LXIConnect(const char* commands);

/**
 * @brief 断开与LXI设备的连接
 * @param instanceId 实例ID，由 LXIConnect 返回。
 * @return 成功返回 LXI_RESULT_OK，失败返回其他 LxiResultCode 错误码。
 */
LXI_API int LXIDisconnect(int instanceId);

/**
 * @brief 启动高速数据采集
 * @param instanceId 实例ID。
 * @param command 启动命令的十六进制字符串，字节之间用空格分隔，例如 "AA 55 D7 01 A0 01 00 14 ... A3"。
 * @return 成功返回 LXI_RESULT_OK，失败返回其他 LxiResultCode 错误码。
 */
LXI_API int LXIStartCollecting(int instanceId, const char* command);

/**
 * @brief 停止高速数据采集
 * @param instanceId 实例ID。
 * @param command 停止命令的十六进制字符串，字节之间用空格分隔。
 * @return 成功返回 LXI_RESULT_OK，失败返回其他 LxiResultCode 错误码。
 */
LXI_API int LXIStopCollecting(int instanceId, const char* command);

/**
 * @brief 从指定实例读取高速采集数据。
 * @param instanceId 实例ID。
 * @param data_packets [out] 用于接收数据的 LXIOutputData 结构体数组的指针。
 * @param max_count [in] data_packets 数组的最大容量（可以容纳多少个 LXIOutputData 结构体）。
 * @return 成功时返回实际读取到的数据包数量 (>= 0)，失败时返回 LxiResultCode 中定义的负数错误码。
 */
LXI_API int LXIReadData(int instanceId, LXIOutputData* data_packets, int max_count);

/**
 * @brief 从指定实例读取最近的命令响应。
 * @param instanceId 实例ID。
 * @param response_buffer [out] 用于接收响应数据的缓冲区的指针。
 * @param buffer_size [in] 缓冲区的大小（字节）。
 * @return 成功时返回实际读取到的字节数 (>= 0)，失败时返回 LxiResultCode 中定义的负数错误码。
 */
LXI_API int LXIReadResponse(int instanceId, unsigned char* response_buffer, int buffer_size);

/**
 * @brief 断开所有连接并清理资源
 * @return 总是返回 LXI_RESULT_OK。
 */
LXI_API int LXIClearAll();

#endif // LXI_API_H
