/*----------------------------------------------------------------------------
*               LXI 高速数据采集卡 C-API 接口
*-----------------------------------------------------------------------------
*
* 提供高性能的 LXI 数据采集卡通信接口，支持设备连接、多模式数据采集控制。
* 该 API 旨在为上层应用提供一个简单、稳定、高效的硬件控制层，并已封装为
* 跨平台的动态链接库（DLL/SO）。
*
* ═══════════════════════════════════════════════════════════════════════════
*                              主要特点
* ═══════════════════════════════════════════════════════════════════════════
*
* - 建立与 LXI 设备的 UDP 连接（包含设备探测验证）
* - 支持四种采集模式：高速单端/差分，低速单端/差分
* - 支持两种读取模式：单次读取（SINGLE）/ 持续读取（CONTINUE）
* - 内部实现基于内存池的高性能数据接收，避免丢包
* - 自动检测数据包序列号，监控丢包情况
* - 使用实例 ID 进行多设备并行管理
* - 完善的日志功能，便于调试和问题追溯
* - 健壮的错误处理机制和明确的状态码
* - 跨平台支持（Windows/Linux）
* - 线程安全设计
*
* ═══════════════════════════════════════════════════════════════════════════
*                              读取模式说明
* ═══════════════════════════════════════════════════════════════════════════
*
* 1. 单次读取模式（SINGLE，默认）：
*    - 每次调用 readData 时清空旧数据，收集新鲜数据
*    - 适合需要实时数据、不关心历史数据的场景
*    - 每次读取都是从调用时刻开始的最新数据
*
* 2. 持续读取模式（CONTINUE）：
*    - 持续缓存数据，用户循环调用 readData 读取
*    - 适合需要连续记录、不能丢失任何数据的场景
*    - 内部缓存约 2 秒数据，缓存满时返回 BUFFER_OVERFLOW 错误
*    - 需要外部程序及时读取，否则会丢失数据
*
* ═══════════════════════════════════════════════════════════════════════════
*                              典型使用流程
* ═══════════════════════════════════════════════════════════════════════════
*
* @code
*   // ========== 1. 可选：开启日志 ==========
*   LXIOpenLog("logs/lxi.log", 1, 10, 5);
*
*   // ========== 2. 连接设备 ==========
*   int id = LXIConnect("--serverIp 192.168.201.1 --serverPort 8080");
*   if (id <= 0) {
*       printf("连接失败: %d\n", id);
*       return;
*   }
*
*   // ========== 3. 启动采样 ==========
*   // 单次读取模式（默认）
*   int ret = LXIAIStartSampling(id,
*       "--rateMode high --channelMode single "
*       "--rate 10 --packets 0 --range 1 "
*       "--openChannels 1 9 17 25 33 41 "
*       "--readChannels ai0,1 --readMode single");
*
*   // 或持续读取模式
*   // int ret = LXIAIStartSampling(id,
*   //     "--rateMode high --channelMode single "
*   //     "--rate 10 --packets 0 --range 1 "
*   //     "--openChannels 1 9 17 25 33 41 "
*   //     "--readChannels ai0,1 --readMode continue");
*
*   // ========== 4. 预分配缓冲区并循环读取 ==========
*   unsigned char channelCount = 2;
*   unsigned int sampleCount = 100;
*   float* buffer = malloc(channelCount * sampleCount * sizeof(float));
*
*   while (running) {
*       unsigned char ch = channelCount;
*       unsigned int sp = sampleCount;
*       int result = LXIAIReadData(id, buffer, &ch, &sp, 1000);
*
*       if (result == LXI_RESULT_OK) {
*           processData(buffer, ch, sp);
*       } else if (result == LXI_RESULT_BUFFER_OVERFLOW) {
*           printf("缓存溢出！处理速度过慢\n");
*           break;
*       }
*   }
*
*   // ========== 5. 停止并断开 ==========
*   LXIAIStopSampling(id, NULL);
*   LXIDisconnect(id);
*   free(buffer);
*
*   // ========== 6. 可选：关闭日志 ==========
*   LXICloseLog();
* @endcode
*
* ═══════════════════════════════════════════════════════════════════════════
*                              LabVIEW 集成指南
* ═══════════════════════════════════════════════════════════════════════════
*
* 1. 使用 "Call Library Function Node" 调用 DLL
* 2. 字符串参数选择 "C String Pointer"
* 3. 数组参数选择 "Array Data Pointer"
* 4. unsigned char* 参数选择 "Pointer to Value" (U8)
* 5. unsigned int* 参数选择 "Pointer to Value" (U32)
*
* 详细配置请参考各函数的 LabVIEW 注释部分。
*
*-----------------------------------------------------------------------------
*                              版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2025 丰柯科技。保留所有权利。
*
* 作者: leiwei
* 版本: v3.6.0
* 日期: 2026-05-09
*----------------------------------------------------------------------------*/

#ifndef LXI_API_H
#define LXI_API_H

#include "lximessage.h"

#ifdef _WIN32
#ifdef BUILD_LXI_API
#define LXI_API extern "C" __declspec(dllexport)
#else
#define LXI_API extern "C" __declspec(dllimport)
#endif
#else
#define LXI_API extern "C"
#endif


/* ═══════════════════════════════════════════════════════════════════════════
 *                              日志管理
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief 打开日志系统
 *
 * @param logFile   日志文件路径（支持相对/绝对路径，目录不存在时自动创建）
 * @param level     日志等级：0=DEBUG, 1=INFO, 2=WARN, 3=ERROR
 * @param maxSize   单个日志文件最大尺寸（MB），推荐 10
 * @param maxFiles  日志文件最大保留数量，推荐 5
 *
 * @return 0 成功，-1 失败
 *
 * @note 建议在 LXIConnect 之前调用
 * @note 日志会占用 CPU 资源和磁盘空间，生产环境建议关闭或使用高等级
 */
LXI_API int LXIOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志系统
 * @return 0 成功
 */
LXI_API int LXICloseLog();


/* ═══════════════════════════════════════════════════════════════════════════
 *                              连接管理
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief 连接到 LXI 设备
 *
 * 建立与 LXI 数据采集设备的 UDP 连接，包含设备探测验证。
 *
 * @param params 参数字符串，格式为 "--key value" 对
 *
 * @b 必填参数:
 *   - `--serverIp <string>`: LXI 设备的 IP 地址
 *
 * @b 可选参数:
 *   - `--serverPort <int>`: UDP 端口（默认: 8080）
 *   - `--localIp <string>`: 本地网卡 IP（多网卡环境）
 *   - `--localPort <int>`: 本地端口（默认: 0，自动分配）
 *   - `--connectTimeout <int>`: 探测超时（毫秒，默认: 500）
 *   - `--sendBufferSize <int>`: UDP 发送缓冲区大小(字节), < 0: 系统默认值 0: 程序自动调整  > 0: 指定大小
 *   - `--recvBufferSize <int>`: UDP 接收缓冲区大小(字节), < 0: 系统默认值 0: 程序自动调整  > 0: 指定大小
 *
 * @return >0:成功，返回实例 ID  <=0:失败错误码
 *
 * @b 示例:
 * @code
 *   int id = LXIConnect("--serverIp 192.168.201.1 --serverPort 8080 --recvBufferSize 8388608");
 *   if (id <= 0) {
 *       printf("连接失败: %d\n", id);
 *       return;
 *   }
 * @endcode
 *
 */
LXI_API int LXIConnect(const char* params);

/**
 * @brief 断开设备连接
 * @param instanceId 实例 ID
 * @return LXI_RESULT_OK (0) 成功
 */
LXI_API int LXIDisconnect(int instanceId);

/**
 * @brief 断开所有连接并清理资源
 * @return LXI_RESULT_OK (0) 成功
 */
LXI_API int LXIClearAll();


/* ═══════════════════════════════════════════════════════════════════════════
 *                              采集控制
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief 启动采样
 *
 * 启动数据采集，配置采样模式、通道和读取模式。
 *
 * @param instanceId 实例 ID
 * @param params 参数字符串
 *
 * @b 必填参数:
 *   - `--rateMode <high|low>`: 速率模式
 *     - high: 高速模式 (10KHz ~ 1000KHz)
 *     - low: 低速模式 (1KHz ~ 100KHz)
 *
 *   - `--channelMode <single|diff>`: 通道模式
 *     - single: 单端模式
 *     - diff: 差分模式
 *
 * @b 可选参数:
 *   - `--slotId <int>`: 卡槽 ID（默认从 IP 提取）
 *   - `--rate <1~100>`: 采样率系数（默认: 100）
 *     - 高速: rate × 10KHz，低速: rate × 1KHz
 *   - `--packets <0~65535>`: 采集包数（默认: 100，0=持续采集）
 *   - `--range <1|2|3>`: 量程（1=±5V, 2=±10V, 3=±20V，默认: 3）
 *   - `--openChannels <ch1~ch6>`: 高速模式 6 个 ADC 通道映射
 *   - `--readChannels <spec>`: 读取通道（默认: 全部）
 *     - 格式: "ai0,1,2" 或 "ai0:5" 或 "ai0:2,5"
 *   - `--readMode <single|continue>`: 读取模式（默认: single）
 *     - single: 单次读取，每次 readData 清空旧数据获取新数据
 *     - continue: 持续读取，持续缓存数据，缓存满则报错
 *   - `--timeout <int>`: 响应超时（毫秒，默认: 500）
 *
 * @b 采样模式与通道数:
 * @code
 *   ┌────────────┬──────────┬────────────┐
 *   │ 模式       │ 总通道数 │ 每包采样点 │
 *   ├────────────┼──────────┼────────────┤
 *   │ 高速单端   │ 6        │ 100        │
 *   │ 高速差分   │ 3        │ 100        │
 *   │ 低速单端   │ 48       │ 10         │
 *   │ 低速差分   │ 24       │ 10         │
 *   └────────────┴──────────┴────────────┘
 * @endcode
 *
 * @b 读取模式说明:
 * @code
 *   ┌──────────┬────────────────────────────────────────────┐
 *   │ 模式     │ 行为                                       │
 *   ├──────────┼────────────────────────────────────────────┤
 *   │ single   │ 每次 readData 清空缓存，获取实时新数据     │
 *   │          │ 适合实时监控场景                           │
 *   ├──────────┼────────────────────────────────────────────┤
 *   │ continue │ 持续缓存数据，用户循环读取                 │
 *   │          │ 缓存约 2 秒数据，满则返回 BUFFER_OVERFLOW  │
 *   │          │ 适合连续记录场景                           │
 *   └──────────┴────────────────────────────────────────────┘
 * @endcode
 *
 * @return LXI_RESULT_OK (0) 成功
 * @return 错误码:
 *         - LXI_RESULT_INVALID_PARAM (-1): 参数无效
 *         - LXI_RESULT_INVALID_CHANNEL_SPEC (-3): 通道规格无效
 *         - LXI_RESULT_INVALID_INSTANCE_ID (-13): 无效实例
 *         - LXI_RESULT_SEND_FAILED (-21): 发送失败
 *         - LXI_RESULT_COMMAND_NO_RESPONSE (-404): 设备无响应
 *
 * @b 示例:
 * @code
 *   // 高速单端，单次读取模式（默认）
 *   LXIAIStartSampling(id,
 *       "--rateMode high --channelMode single "
 *       "--rate 100 --packets 0 --range 1 "
 *       "--openChannels 1 9 17 25 33 41 "
 *       "--readChannels ai0,1 --readMode single");
 *
 *   // 高速单端，持续读取模式
 *   LXIAIStartSampling(id,
 *       "--rateMode high --channelMode single "
 *       "--rate 100 --packets 0 --range 1 "
 *       "--openChannels 1 9 17 25 33 41 "
 *       "--readChannels ai0,1 --readMode continue");
 *
 *   // 低速单端，读取指定通道
 *   LXIAIStartSampling(id,
 *       "--rateMode low --channelMode single "
 *       "--rate 50 --readChannels ai0,8,16");
 * @endcode
 */
LXI_API int LXIAIStartSampling(int instanceId, const char* params);

/**
 * @brief 停止采样
 *
 * 发送停止命令给板卡，停止数据采集。由于 UDP 无连接特性，命令可能会丢失，
 * 此接口内置了重发机制以提高兼容性和稳定性。
 *
 * @param instanceId 实例 ID
 * @param params 可选参数（可为 NULL）
 *   - `--timeout <int>`: 每次命令发送后的响应超时时间（毫秒，默认: 500）
 *   - `--retryCount <int>`: 停止命令最大发送/重试次数（默认: 3，即最多发送 3 次）
 *   - `--retryInterval <int>`: 未收到响应时，两次发送之间的间隔时间（毫秒，默认: 100）
 *
 * @return LXI_RESULT_OK (0) 成功（收到板卡响应，或未开启重发直接执行成功）
 * @return LXI_RESULT_COMMAND_NO_RESPONSE (-404) 达到最大重试次数后，仍未收到板卡响应（但本地采集状态仍会被重置）
 *
 * @note 重复调用是安全的（幂等操作）。无论板卡是否响应，客户端本地的采集状态和数据处理线程都会被强制停止。
 *
 * @b 示例:
 * @code
 *   // 使用默认参数（最多尝试 3 次，每次间隔 100ms，每次超时 500ms）
 *   LXIAIStopSampling(id, NULL);
 *
 *   // 自定义重发参数：最多尝试 5 次，每次间隔 500ms
 *   LXIAIStopSampling(id, "--timeout 500 --retryCount 5 --retryInterval 100");
 * @endcode
 */
LXI_API int LXIAIStopSampling(int instanceId, const char* params);

/**
 * @brief 读取指定通道的采样率标定值
 *
 * 用于高精度采样程序读取硬件采样率标定参数，正常测试程序无需调用此接口。
 *
 * @param instanceId 实例 ID
 * @param channel 通道号 (1-based，即 1, 2, 3...)
 * @param calibration [out] 标定值（单位: PPM，有符号，范围 -128 ~ +127）
 *                    - 正值：实际采样率略高于标称值
 *                    - 负值：实际采样率略低于标称值
 *                    - 例如：+10 表示实际采样率比标称值高 10 PPM
 * @param timeout_ms 响应超时时间（毫秒，推荐 500）
 *
 * @return LXI_RESULT_OK (0) 成功
 */
LXI_API int LXIAIGetSamplingRateCalibration(int instanceId, int channel,
                                            signed char* calibration, int timeout_ms);

/**
 * @brief 获取采样信息
 *
 * @param instanceId 实例 ID
 * @param info [out] 接收 LxiSamplingInfo 结构体
 *
 * @return LXI_RESULT_OK (0) 成功
 */
LXI_API int LXIAIGetSamplingInfo(int instanceId, LxiSamplingInfo* info);

/**
 * @brief 获取通道配置信息
 *
 * @param instanceId 实例 ID
 * @param config [out] 接收 LxiChannelConfig 结构体
 *
 * @return LXI_RESULT_OK (0) 成功
 */
LXI_API int LXIAIGetChannelConfig(int instanceId, LxiChannelConfig* config);


/* ═══════════════════════════════════════════════════════════════════════════
 *                              数据读取
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief 获取配置的通道数
 *
 * @param instanceId 实例 ID
 *
 * @return 成功返回通道数 (> 0)，失败返回错误码 (<= 0)
 *
 * @note 必须在 LXIAIStartSampling 之后调用
 */
LXI_API int LXIAIGetNumChannels(int instanceId);

/**
 * @brief 读取数据
 *
 * 从内部缓冲区读取电压数据。行为根据启动时的 readMode 参数不同：
 * - SINGLE 模式：每次调用清空旧数据，收集新鲜数据后返回
 * - CONTINUE 模式：从持续缓存中读取数据，缓存满时返回溢出错误
 *
 * @param instanceId 实例 ID
 *
 * @param dataBuffer [out] 用户预分配的浮点数组
 *                   大小: >= channelCount × sampleCount × sizeof(float)
 *
 * @param channelCount [in/out]
 *                     输入: 期望通道数（必须与配置一致）
 *                     输出: 实际返回的通道数
 *
 * @param sampleCount [in/out]
 *                    输入: 期望采样点数 (1 ~ 10000)
 *                    输出: 实际返回的采样点数
 *
 * @param timeout_ms 超时时间（毫秒）
 *        - > 0: 阻塞等待直到数据足够或超时
 *        - <= 0: 非阻塞，返回已有数据
 *
 * @return LXI_RESULT_OK (0) 成功
 * @return 错误码:
 *         - LXI_RESULT_INVALID_PARAM (-1): 参数无效
 *         - LXI_RESULT_NOT_SAMPLING (-7): 未在采样
 *         - LXI_RESULT_CHANNEL_COUNT_MISMATCH (-6): 通道数不匹配
 *         - LXI_RESULT_DATA_NOT_READY (-24): 数据不足（超时）
 *         - LXI_RESULT_BUFFER_OVERFLOW (-25): 缓存溢出（仅 CONTINUE 模式）
 *         - LXI_RESULT_PACKET_LOSS (-26): 序列号不连续/UDP 丢包（FINITE 与 packets=0 的 SINGLE 读）
 *
 * @b 数据布局:
 * @code
 *   buffer[0 .. sampleCount-1]              = 通道 0 的数据
 *   buffer[sampleCount .. 2*sampleCount-1]  = 通道 1 的数据
 *   ...
 *   访问公式: buffer[channel_idx * sampleCount + sample_idx]
 * @endcode
 *
 * @b 两种读取模式行为对比:
 * @code
 *   ┌──────────┬─────────────────────────────────────────────┐
 *   │ 模式     │ readData 行为                               │
 *   ├──────────┼─────────────────────────────────────────────┤
 *   │ SINGLE   │ 1. 清空旧缓存                               │
 *   │          │ 2. 开始收集新数据                           │
 *   │          │ 3. 等待足够数据                             │
 *   │          │ 4. 返回最新数据                             │
 *   │          │ 优点: 每次都是实时数据，无滞后              │
 *   ├──────────┼─────────────────────────────────────────────┤
 *   │ CONTINUE │ 1. 从持续缓存中读取数据                     │
 *   │          │ 2. 数据读完后从缓存移除                     │
 *   │          │ 3. 缓存满时返回 BUFFER_OVERFLOW             │
 *   │          │ 优点: 数据连续，不丢失                      │
 *   │          │ 注意: 需要及时读取，否则缓存溢出            │
 *   └──────────┴─────────────────────────────────────────────┘
 * @endcode
 *
 * @b 示例:
 * @code
 *   unsigned char channelCount = 2;
 *   unsigned int sampleCount = 100;
 *   float* buffer = malloc(channelCount * sampleCount * sizeof(float));
 *
 *   while (running) {
 *       unsigned char ch = channelCount;
 *       unsigned int sp = sampleCount;
 *       int ret = LXIAIReadData(id, buffer, &ch, &sp, 1000);
 *
 *       if (ret == LXI_RESULT_OK) {
 *           // 处理数据
 *           for (int c = 0; c < ch; c++) {
 *               for (int s = 0; s < sp; s++) {
 *                   float v = buffer[c * sp + s];
 *               }
 *           }
 *       } else if (ret == LXI_RESULT_BUFFER_OVERFLOW) {
 *           // 仅 CONTINUE 模式：外部处理过慢
 *           printf("缓存溢出！需要加快处理速度\n");
 *           break;
 *       } else if (ret == LXI_RESULT_DATA_NOT_READY) {
 *           // 超时，数据不足
 *           printf("等待数据超时\n");
 *       }
 *   }
 * @endcode
 *
 * @b LabVIEW 配置:
 * @code
 *   instanceId     Numeric (I32)       Pass by Value
 *   dataBuffer     Array of SGL        Array Data Pointer
 *   channelCount   Numeric (U8)        Pointer to Value
 *   sampleCount    Numeric (U32)       Pointer to Value
 *   timeout_ms     Numeric (I32)       Pass by Value
 *   Return         Numeric (I32)       -
 * @endcode
 */
LXI_API int LXIAIReadData(int instanceId,
                          float* dataBuffer,
                          unsigned char* channelCount,
                          unsigned int* sampleCount,
                          int timeout_ms);


/* ═══════════════════════════════════════════════════════════════════════════
 *                              命令响应
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief 读取命令响应
 *
 * 获取设备对最近一次命令的响应数据，用于调试。
 *
 * @param instanceId 实例 ID
 * @param buffer [out] 接收缓冲区（建议 64 字节）
 * @param size [in/out] 输入缓冲区大小，输出实际读取字节数
 *
 * @return LXI_RESULT_OK (0) 成功
 * @return LXI_RESULT_COMMAND_NO_RESPONSE (-404) 无响应
 */
LXI_API int LXIAIReadResponse(int instanceId, unsigned char* buffer, int* size);


/* ═══════════════════════════════════════════════════════════════════════════
 *                              硬件重启
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief 硬件重启板卡
 *
 * 发送硬件重启命令，设备收到后将执行硬件复位。
 * 板卡位置自动从连接时的设备 IP 末段提取（slot_id），无需手动指定。
 * 设备可能在重启前无法回复响应，此情况视为成功。
 *
 * @param instanceId 实例 ID
 *
 * @return LXI_RESULT_OK (0) 成功
 */
LXI_API int LXIReboot(int instanceId);


#endif // LXI_API_H
