/*----------------------------------------------------------------------------
*               LXI 高速数据采集卡 C-API 接口
*-----------------------------------------------------------------------------
*
* 提供高性能的LXI数据采集卡通信接口，支持设备连接、多模式数据采集控制。
* 该API旨在为上层应用提供一个简单、稳定、高效的硬件控制层，并已封装为
* 跨平台的动态链接库（DLL/SO）。
*
* 主要特点：
* - 建立与LXI设备的UDP连接
* - 支持四种采集模式：高速单端/差分，低速单端/差分
* - 内部实现基于内存池的高性能数据接收，避免丢包
* - 自动检测数据包序列号，监控丢包情况
* - 使用实例ID进行多设备并行管理
* - 完善的日志功能，便于调试和问题追溯
* - 健壮的错误处理机制和明确的状态码
* - 跨平台支持（Windows/Linux）
* - 线程安全设计
*
* C/C++ 使用示例:
*   #include "lxiapi.h"
*   #include <stdio.h>
*   #ifdef _WIN32
*   #include <windows.h>
*   #define sleep_ms(ms) Sleep(ms)
*   #else
*   #include <unistd.h>
*   #define sleep_ms(ms) usleep(ms * 1000)
*   #endif
*
*   int main() {
*       // 1. (可选) 打开日志，便于调试
*       LXIOpenLog("logs/lxi_api_test.log", 1, 5, 10);
*
*       // 2. 连接设备
*       const char* connect_params = "--serverIp 192.168.1.10 --serverPort 8080";
*       int instanceId = LXIConnect(connect_params);
*
*       if (instanceId > 0) {
*           printf("设备连接成功，实例ID: %d\n", instanceId);
*
*           // 3. 启动高速差分采集 (四种模式任选其一)
*           const char* start_params = "--slotId 1 --rateMode high --channelMode diff "
*                                      "--rate 100 --packets 500 --range 3 "
*                                      "--channels 0x01 0x09 0x10 0x18 0x1F 0x27";
*           int result = LXIAIStartSampling(instanceId, start_params);
*
*           if (result == LXI_RESULT_OK) {
*               printf("开始采集命令已发送并确认。\n");
*
*               // 4. 循环读取电压数据
*               LxiVoltagePacket voltage_buffer[200];
*               for (int i = 0; i < 500; ++i) { // 循环5秒
*                   int count_to_read = 200; // 传入缓冲区大小
*                   int read_result = LXIAIReadVoltages(instanceId, voltage_buffer, &count_to_read);
*                   if (read_result == LXI_RESULT_OK) {
*                       if (count_to_read > 0) { // 检查实际读取到的数量
*                           printf("成功读取 %d 个数据包。SN=%u, V=%.4fV\n",
*                                  count_to_read, voltage_buffer[0].serial_code, voltage_buffer[0].voltages[0]);
*                       }
*                   } else {
*                       printf("读取数据时发生错误，错误码: %d\n", read_result);
*                       break;
*                   }
*                   sleep_ms(10);
*               }
*
*               // 5. 发送停止采集命令 (可选择同步等待或异步)
*               LXIAIStopSampling(instanceId, "--timeout 100"); // 同步等待100ms
*               printf("停止采集命令已发送并确认。\n");
*           } else {
*               printf("启动采集失败，错误码: %d\n", result);
*           }
*
*           // 6. 断开连接
*           LXIDisconnect(instanceId);
*           printf("设备已断开。\n");
*       } else {
*           printf("设备连接失败，错误码: %d\n", instanceId);
*       }
*
*       // 7. (可选) 关闭日志
*       LXICloseLog();
*       return 0;
*   }
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2025 丰柯科技。保留所有权利。
*
* 作者: leiwei
* 版本: v2.1.0
* 日期: 2025-10-24
*----------------------------------------------------------------------------*/

#ifndef LXI_API_H
#define LXI_API_H

#include "lximessage.h"

#ifdef _WIN32
    #ifdef BUILD_LXI_API
        #define LXI_API extern "C" __declspec(dllexport)
    #else
        #define LXI_API extern "C" __declspec(dllimport)
    #endif
#else
    #define LXI_API extern "C"
#endif

// --- 日志和连接管理 ---

/**
 * @brief 打开日志，用于调试和故障诊断。
 * @param logFile 日志文件路径，例如: "logs/fkvci.log"。
 * @param level 日志等级, 0:DEBUG, 1:INFO, 2:WARN, 3:ERROR。
 * @param maxSize 单个日志文件的最大尺寸 (单位: MB, 范围 1-100)。
 * @param maxFiles 日志文件的最大保留数量 (范围 1-20)。
 * @return 0 表示成功，其他值为失败。
 */
LXI_API int LXIOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志系统，释放资源。
 * @return 0 表示成功。
 */
LXI_API int LXICloseLog();

/**
 * @brief 连接到LXI设备并创建一个会话实例。
 * @param commands 参数化连接字符串，格式为 key-value 对，例如: "--serverIp 192.168.1.10 --serverPort 8080"。
 *        支持的参数:
 *        - `--serverIp <string>`: (必填) LXI设备的IP地址。
 *        - `--serverPort <int>`: (可选, 默认: 8080) LXI设备的UDP端口。
 *        - `--localIp <string>`: (可选) 绑定本地网卡IP，用于多网卡环境。
 *        - `--localPort <int>`: (可选) 绑定本地UDP端口。
 *        - `--startSn <int>`: (可选, 0-255, 默认: 0) 期望的起始包序列号。
 *        - `--queueSize <int>`: (可选，默认: 10000) 内部数据队列的最大长度。
 * @return 大于 0 的值为成功的实例ID，小于 0 的值为负的错误码 (参考 LxiResultCode)。
 */
LXI_API int LXIConnect(const char* commands);

/**
 * @brief 断开与LXI设备的连接并销毁指定实例。
 * @param instanceId 由 LXIConnect 返回的实例ID。
 * @return 0 (LXI_RESULT_OK) 表示成功，其他值为错误码。
 */
LXI_API int LXIDisconnect(int instanceId);

/**
 * @brief 断开所有连接并清理所有实例资源。
 * @return 0 (LXI_RESULT_OK) 表示成功。
 */
LXI_API int LXIClearAll();


// --- 数据采集控制 ---

/**
 * @brief 启动任意模式的采样，并同步等待设备响应。
 *
 * @param instanceId 由 LXIConnect 返回的实例ID。
 * @param params 参数化配置字符串，通过 key-value 对指定所有采集参数。
 *
 * @b 必填参数:
 *   - `--slotId <int>`: 目标板卡的卡槽ID。
 *   - `--rateMode <string>`: 速率模式。可选值: `high` (高速), `low` (低速)。
 *   - `--channelMode <string>`: 通道模式。可选值: `single` (单端), `diff` (差分)。
 *
 * @b 可选参数:
 *   - `--rate <int>`: 采样率代码，默认: 100。范围 1-100。
 *     - 高速模式下: 1-100 对应 10KHz-1000KHz。
 *     - 低速模式下: 1-100 对应 1KHz-100KHz。
 *   - `--packets <int>`: 采集包数，默认: 100。范围 0-65535。`0` 表示持续采集，直到手动停止。
 *   - `--range <int>`: 量程代码，默认: 3。可选值: `1` (±5V), `2` (±10V), `3` (±20V)。
 *   - `--timeout <int>`: 等待设备响应的超时时间（毫秒）。
 *     - 默认值: `500`。
 *     - `0`: 表示异步发送，不等待响应。
 *     - 大于 `0`: 表示同步等待，直到收到响应或超时。
 *
 * @b 条件参数:
 *   - `--channels <ch1> ... <ch6>`: 6个通道选择字节，用空格隔开。
 *     - 当 `--rateMode` 为 `high` 时, 此参数为 **必填**。
 *     - 当 `--rateMode` 为 `low` 时, 此参数被 **忽略** (通道由设备内部固定)。
 *
 * @b 通道选择详解 (`--channels`):
 *   - **高速单端模式** (`--rateMode high --channelMode single`):
 *     必须提供6个值，每个值从其对应的MUX选择器中选取一个通道。
 *     - `ch1`: 1 ~ 8
 *     - `ch2`: 9 ~ 15, 或 0xD1 (内部自检 V1)
 *     - `ch3`: 16 ~ 23
 *     - `ch4`: 24 ~ 30, 或 0xD2 (内部自检 V2)
 *     - `ch5`: 31 ~ 38
 *     - `ch6`: 39 ~ 45, 或 0xD3 (内部自检 V3)
 *
 *   - **高速差分模式** (`--rateMode high --channelMode diff`):
 *     必须提供6个值，组成3对P/N差分对。配对规则为 `N = P + 8`。
 *     - `ch1` (P1), `ch2` (N1): P1在1-7范围，N1必须为P1+8。
 *     - `ch3` (P2), `ch4` (N2): P2在16-22范围，N2必须为P2+8。
 *     - `ch5` (P3), `ch6` (N3): P3在31-37范围，N3必须为P3+8。
 *     - **注意**: `08-V1`, `23-V2`, `38-V3` 这三对内部通道不可用。
 *
 * @b 完整示例:
 * @code
 *   // 1. 高速单端，采集外部通道，使用默认500ms超时
 *   const char* p1 = "--slotId 1 --rateMode high --channelMode single --channels 1 9 16 24 31 39";
 *
 *   // 2. 高速差分，异步发送 (不等待响应)
 *   const char* p2 = "--slotId 1 --rateMode high --channelMode diff --channels 1 9 16 24 31 39 --timeout 0";
 *
 *   // 3. 低速单端 (无需 --channels)，自定义超时
 *   const char* p3 = "--slotId 2 --rateMode low --channelMode single --rate 50 --packets 1000 --timeout 1000";
 *
 *   // 4. 低速差分 (无需 --channels)
 *   const char* p4 = "--slotId 2 --rateMode low --channelMode diff";
 * @endcode
 *
 * @return 0 (LXI_RESULT_OK) 表示成功，其他值为错误码。如果超时，返回 LXI_RESULT_COMMAND_NO_RESPONSE。
 */
LXI_API int LXIAIStartSampling(int instanceId, const char* params);

/**
 * @brief 停止当前正在进行的任何模式的采样。
 * @param instanceId 由 LXIConnect 返回的实例ID。
 * @param params 可选的参数化配置字符串。
 *        支持的参数:
 *        - `--timeout <int>`: 等待设备响应的超时时间（毫秒）。
 *          - 默认值: `100`。
 *          - `0`: 表示异步发送，不等待响应。
 *          - 大于 `0`: 表示同步等待，直到收到响应或超时。
 *
 * @b 使用示例:
 * @code
 *   // 1. 同步停止，使用默认的100ms超时
 *   LXIAIStopSampling(instanceId, nullptr);
 *
 *   // 2. 异步停止，不等待响应
 *   LXIAIStopSampling(instanceId, "--timeout 0");
 *
 *   // 3. 同步停止，自定义超时
 *   LXIAIStopSampling(instanceId, "--timeout 500");
 * @endcode
 *
 * @return 0 (LXI_RESULT_OK) 表示成功，其他值为错误码。如果超时，返回 LXI_RESULT_COMMAND_NO_RESPONSE。
 */
LXI_API int LXIAIStopSampling(int instanceId, const char* params);

/**
 * @brief 获取当前采样模式下的信息，如通道数量和通道的点数。
 * @param instanceId 实例ID。
 * @param info [out] 一个指向 LxiSamplingInfo 结构体的指针，用于接收返回的信息。
 * @return 0 (LXI_RESULT_OK) 表示成功，其他值为错误码。
 */
LXI_API int LXIAIGetSamplingInfo(int instanceId, LxiSamplingInfo* info);

// --- 数据和响应读取 ---

/**
 * @brief 从指定实例读取已转换为电压的数据包。
 * @param instanceId 由 LXIConnect 返回的实例ID。
 * @param voltage_packets [out] 用于接收数据的 LxiVoltagePacket 结构体数组指针。
 * @param count [in, out] 一个指向整数的指针。
 *              - [in] 调用时，该整数表示 `voltage_packets` 数组的最大容量。
 *              - [out] 返回时，该整数被更新为实际读取到的数据包数量。
 * @return LXI_RESULT_OK (0) 表示操作成功（即使没有读取到数据），小于 0 的值为错误码。
 */
LXI_API int LXIAIReadVoltages(int instanceId, LxiVoltagePacket* voltage_packets, int* count);

/**
 * @brief 从指定实例读取最近的命令响应。
 * @param instanceId 由 LXIConnect 返回的实例ID。
 * @param response_buffer [out] 接收响应数据的缓冲区指针。
 * @param size [in, out] 一个指向整数的指针。
 *             - [in] 调用时，该整数表示 `response_buffer` 的大小（单位：字节）。
 *             - [out] 返回时，该整数被更新为实际读取到的字节数。
 * @return LXI_RESULT_OK (0) 表示操作成功（即使没有读取到响应），小于 0 的值为错误码。
 */
LXI_API int LXIAIReadResponse(int instanceId, unsigned char* response_buffer, int* size);


#endif // LXI_API_H
