#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# NWSwitchClientTest.py - 网络交换机客户端测试和命令行界面

from NWSwitchClient import NWSwitchClient
import sys
import signal
import platform
import threading
import os
import time

def signal_handler(sig, frame):
    """处理信号（如Ctrl+C）"""
    global client
    print("\n接收到中断信号，正在清理资源...")
    
    try:
        if client:
            # 设置一个超时，避免清理过程无限阻塞
            cleanup_thread = threading.Thread(target=client.cleanup)
            cleanup_thread.daemon = True  # 设置为守护线程
            cleanup_thread.start()
            
            # 等待清理完成，但最多等待3秒
            cleanup_thread.join(timeout=3.0)
            
            if cleanup_thread.is_alive():
                print("警告: 清理过程超时，强制退出")
            else:
                print("清理完成")
    except Exception as e:
        print(f"清理过程中出错: {e}")
    
    print("程序已终止")
    # 强制终止程序，不等待其他线程
    os._exit(0)

def print_help():
    """打印帮助信息"""
    print("\n========== 命令控制 API ==========")
    print("  --help                                  显示此帮助信息")
    print("  --connect <IP地址/DUT索引>              连接到网络交换机")
    print("                                          示例: --connect 192.168.1.120/1")
    print("  --disconnect                            断开网络交换机连接")
    print("  --send <命令>                           发送网络交换机命令")
    print("  --read [超时毫秒]                       读取命令执行结果（默认超时5000ms）")
    print("  --stop                                  停止当前命令执行")
    print("  --autoRead [on|off]                     开启/关闭自动读取（默认: on）")
    
    print("\n========== 网络配置管理 API（新增） ==========")
    print("  --configNet <IP地址> <配置文件>         配置交换机网络")
    print("                                          示例: --configNet 192.168.1.120 config.json")
    print("  --syncNet <IP地址> <保存文件>           同步交换机网络配置")
    print("                                          示例: --syncNet 192.168.1.120 backup.json")
    print("  --autoStart <IP地址>                    设置网络配置自启动")
    print("                                          示例: --autoStart 192.168.1.120")
    
    print("\n========== 系统命令 ==========")
    print("  --exit                                  退出程序")
    
    print("\n网络交换机常用命令示例:")
    print("  ping 192.168.1.1                       测试网络连通性")
    
    print("\n完整的网络配置示例:")
    print("  --syncNet 192.168.1.120 nwswitch_backup.json")
    print("  --configNet 192.168.1.120 nwswitch_config.json")
    print("  --autoStart 192.168.1.120")

def handle_connect_command(cmd_parts):
    """处理连接命令"""
    if len(cmd_parts) < 2:
        print("错误: 缺少IP地址/DUT索引参数")
        print("格式: --connect <IP地址/DUT索引>")
        print("示例: --connect 192.168.1.120/1")
        return False
    
    ip_address = cmd_parts[1]
    
    # 检查格式是否正确（应该包含 IP/DUT索引）
    if '/' not in ip_address:
        print("错误: IP地址格式不正确，应该使用 'IP地址/DUT索引' 格式")
        print("示例: 192.168.1.120/1")
        return False
    
    return client.connect(ip_address)

def handle_config_network_command(cmd_parts):
    """处理网络配置命令"""
    if len(cmd_parts) < 3:
        print("错误: 缺少参数")
        print("格式: --configNet <IP地址> <配置文件路径>")
        print("示例: --configNet 192.168.1.120 ./configs/switch_config.json")
        return False
    
    ip_address = cmd_parts[1]
    config_file = cmd_parts[2]
    
    return client.configure_network(ip_address, config_file)

def handle_sync_network_command(cmd_parts):
    """处理网络同步命令"""
    if len(cmd_parts) < 3:
        print("错误: 缺少参数")
        print("格式: --syncNet <IP地址> <保存文件路径>")
        print("示例: --syncNet 192.168.1.120 ./backup/switch_backup.json")
        return False
    
    ip_address = cmd_parts[1]
    save_file = cmd_parts[2]
    
    return client.sync_network(ip_address, save_file)

def handle_autostart_command(cmd_parts):
    """处理自启动命令"""
    if len(cmd_parts) < 2:
        print("错误: 缺少IP地址参数")
        print("格式: --autoStart <IP地址>")
        print("示例: --autoStart 192.168.1.120")
        return False
    
    ip_address = cmd_parts[1]
    return client.setup_autostart(ip_address)

def main():
    global client
    
    # 注册信号处理器
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("=" * 60)
    print(f"网络交换机客户端命令行工具 v3.0.0 (Python {platform.architecture()[0]})")
    print("=" * 60)
    print("输入 --help 获取帮助，输入 --exit 退出程序")
    
    # 创建网络交换机客户端
    client = NWSwitchClient()
    
    # 主循环
    try:
        while client.running:
            try:
                # 提示符
                print(">>> ", end="", flush=True)
                cmd_line = input().strip()
                
                if not cmd_line:
                    continue
                
                # 分割命令行，得到命令和参数部分
                cmd_parts = cmd_line.split()
                cmd_name = cmd_parts[0].lower() if cmd_parts else ""
                
                # 执行相应的命令
                if cmd_name == "--help":
                    print_help()
                
                elif cmd_name == "--exit":
                    print("正在退出程序...")
                    # 使用与信号处理器相同的方法处理退出
                    signal_handler(signal.SIGINT, None)
                    break
                
                elif cmd_name == "--connect":
                    handle_connect_command(cmd_parts)
                
                elif cmd_name == "--disconnect":
                    client.disconnect()
                
                elif cmd_name == "--send":
                    # 获取--send后的所有内容作为完整的命令
                    if len(cmd_line) > len("--send "):
                        command = cmd_line[len("--send "):].strip()
                        if command.startswith('"') and command.endswith('"'):
                            command = command[1:-1]  # 去掉引号
                        client.send_command(command)
                    else:
                        print("错误: 缺少命令内容")
                
                elif cmd_name == "--read":
                    # 可选的超时参数
                    timeout = 5000  # 默认5000ms
                    if len(cmd_parts) > 1:
                        try:
                            timeout = int(cmd_parts[1])
                        except ValueError:
                            print("警告: 无效的超时值，使用默认值5000ms")
                    
                    success, result = client.receive_result(timeout=timeout)
                    if success:
                        print("\n命令输出:")
                        print("-" * 60)
                        print(result)
                        print("-" * 60)
                
                elif cmd_name == "--stop":
                    client.stop_command()
                
                elif cmd_name == "--autoread":
                    # 处理自动读取命令
                    if len(cmd_parts) > 1:
                        state = cmd_parts[1].lower()
                        if state == "on":
                            client.start_auto_read()
                        elif state == "off":
                            client.stop_auto_read()
                        else:
                            print("错误: autoRead 参数必须是 on 或 off")
                    else:
                        # 默认开启
                        client.start_auto_read()
                
                elif cmd_name == "--confignet":
                    handle_config_network_command(cmd_parts)
                
                elif cmd_name == "--syncnet":
                    handle_sync_network_command(cmd_parts)
                
                elif cmd_name == "--autostart":
                    handle_autostart_command(cmd_parts)
                
                else:
                    print(f"未知命令: {cmd_name}，输入 --help 获取帮助")
            
            except KeyboardInterrupt:
                print("\n接收到中断，输入 --exit 退出程序或再次按 Ctrl+C 强制退出")
            
            except Exception as e:
                print(f"错误: {e}")
                import traceback
                traceback.print_exc()
    finally:
        # 确保在任何情况下都会清理资源
        print("程序结束，正在清理资源...")
        try:
            if client:
                # 设置超时清理
                cleanup_thread = threading.Thread(target=client.cleanup)
                cleanup_thread.daemon = True
                cleanup_thread.start()
                cleanup_thread.join(timeout=3.0)
                
                if cleanup_thread.is_alive():
                    print("警告: 清理过程超时")
                else:
                    print("清理完成")
        except Exception as e:
            print(f"最终清理时出错: {e}")

# 全局变量
client = None

# 入口函数
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"主程序异常: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("程序退出")
        # 强制退出，确保不会被阻塞的线程卡住
        os._exit(0)
