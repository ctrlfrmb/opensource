#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# NWSwitchClient.py - 网络交换机客户端API封装

import ctypes
import time
import os
import platform
import threading
from ctypes import c_int, c_char_p, c_uint

# 返回状态码定义
NWSWITCH_SUCCESS = 0
NWSWITCH_ERROR_INVALID_PARAMETER = -1
NWSWITCH_ERROR_CONNECTION_FAILED = -2
NWSWITCH_ERROR_AUTHENTICATION = -3
NWSWITCH_ERROR_COMMAND_EXECUTION = -4
NWSWITCH_ERROR_TIMEOUT = -5
NWSWITCH_ERROR_INSTANCE_NOT_FOUND = -6
NWSWITCH_ERROR_NETWORK = -7
NWSWITCH_ERROR_INTERNAL = -8
NWSWITCH_ERROR_DEVICE_BUSY = -9
NWSWITCH_ERROR_CONFIG_INVALID = -101
NWSWITCH_ERROR_READ_EMPTY = -200

STATUS_DESCRIPTIONS = {
    NWSWITCH_SUCCESS: "操作成功",
    NWSWITCH_ERROR_INVALID_PARAMETER: "无效参数",
    NWSWITCH_ERROR_CONNECTION_FAILED: "连接失败",
    NWSWITCH_ERROR_AUTHENTICATION: "认证失败",
    NWSWITCH_ERROR_COMMAND_EXECUTION: "命令执行失败",
    NWSWITCH_ERROR_TIMEOUT: "操作超时",
    NWSWITCH_ERROR_INSTANCE_NOT_FOUND: "实例不存在",
    NWSWITCH_ERROR_NETWORK: "网络错误",
    NWSWITCH_ERROR_INTERNAL: "内部错误",
    NWSWITCH_ERROR_DEVICE_BUSY: "设备忙碌",
    NWSWITCH_ERROR_CONFIG_INVALID: "配置无效（文件格式错误）",
    NWSWITCH_ERROR_READ_EMPTY: "读取为空（无数据）"
}


class NWSwitchClient:
    def __init__(self):
        self.nwswitch_dll = None
        self.instance_id = None
        self.running = True
        self.auto_read_thread = None
        self.auto_read_enabled = False
        self.load_dll()

    def load_dll(self):
        try:
            arch = platform.architecture()[0]
            lib_path = os.path.abspath("./lib/Winx64" if arch == "64bit" else "./lib/Winx86")
            os.environ['PATH'] = lib_path + os.pathsep + os.environ.get('PATH', '')
            print(f"加载库路径: {lib_path}")
            self.nwswitch_dll = ctypes.WinDLL(os.path.join(lib_path, "nwswitch_api.dll"))

            self.nwswitch_dll.ComOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
            self.nwswitch_dll.ComOpenLog.restype = c_int
            self.nwswitch_dll.ComCloseLog.argtypes = []
            self.nwswitch_dll.ComCloseLog.restype = c_int
            self.nwswitch_dll.NWSwitchConnect.argtypes = [c_char_p]
            self.nwswitch_dll.NWSwitchConnect.restype = c_int
            self.nwswitch_dll.NWSwitchSendCmd.argtypes = [c_int, c_char_p]
            self.nwswitch_dll.NWSwitchSendCmd.restype = c_int
            self.nwswitch_dll.NWSwitchReceiveCmdResult.argtypes = [c_int, c_char_p, c_uint, c_uint]
            self.nwswitch_dll.NWSwitchReceiveCmdResult.restype = c_int
            self.nwswitch_dll.NWSwitchStopCommand.argtypes = [c_int]
            self.nwswitch_dll.NWSwitchStopCommand.restype = c_int
            self.nwswitch_dll.NWSwitchClose.argtypes = [c_int]
            self.nwswitch_dll.NWSwitchClose.restype = c_int

            self.nwswitch_dll.NWSwitchConfigureNetwork.argtypes = [c_char_p, c_char_p]
            self.nwswitch_dll.NWSwitchConfigureNetwork.restype = c_int
            self.nwswitch_dll.NWSwitchSyncNetwork.argtypes = [c_char_p, c_char_p]
            self.nwswitch_dll.NWSwitchSyncNetwork.restype = c_int
            self.nwswitch_dll.NWSwitchSetupAutostart.argtypes = [c_char_p]
            self.nwswitch_dll.NWSwitchSetupAutostart.restype = c_int

            self.nwswitch_dll.ComOpenLog(b"nwswitch_client.log", 0, -1, -1)
            print("网络交换机 API 库加载成功，日志已打开")
        except Exception as e:
            print(f"加载网络交换机 API 库失败: {e}")

    def connect(self, ip_address):
        if self.is_connected():
            print("错误: 已连接，请先断开")
            return False
        print(f"正在连接: {ip_address}")
        instance = self.nwswitch_dll.NWSwitchConnect(ip_address.encode('utf-8'))

        if instance <= 0:
            print(f"连接失败: {self.get_status_description(instance)}")
            return False

        self.instance_id = instance
        print(f"连接成功，实例ID: {self.instance_id}")
        return True

    def disconnect(self):
        if not self.is_connected():
            print("错误: 未连接")
            return False
        self.stop_auto_read()
        status = self.nwswitch_dll.NWSwitchClose(self.instance_id)
        if status != NWSWITCH_SUCCESS:
            print(f"断开失败: {self.get_status_description(status)}")
            return False
        self.instance_id = None
        print("连接已断开")
        return True

    def is_connected(self):
        return isinstance(self.instance_id, int) and self.instance_id > 0

    def send_command(self, command):
        if not self.is_connected():
            print("未连接")
            return False
        status = self.nwswitch_dll.NWSwitchSendCmd(self.instance_id, command.encode('utf-8'))
        if status != NWSWITCH_SUCCESS:
            print(f"发送失败: {self.get_status_description(status)}")
            return False
        print("命令发送成功")
        return True

    def receive_result(self, buffer_size=4096, timeout=5000):
        if not self.is_connected():
            return False, ""
        buffer = ctypes.create_string_buffer(buffer_size)
        status = self.nwswitch_dll.NWSwitchReceiveCmdResult(self.instance_id, buffer, buffer_size, timeout)
        if status == NWSWITCH_ERROR_READ_EMPTY or status == NWSWITCH_ERROR_TIMEOUT:
            return False, ""
        if status != NWSWITCH_SUCCESS:
            print(f"接收命令结果失败: {self.get_status_description(status)}")
            return False, ""
        return True, buffer.value.decode('utf-8', errors='replace')

    def stop_command(self):
        if not self.is_connected():
            print("未连接")
            return False
        status = self.nwswitch_dll.NWSwitchStopCommand(self.instance_id)
        if status != NWSWITCH_SUCCESS:
            print(f"停止失败: {self.get_status_description(status)}")
            return False
        print("命令已停止")
        return True

    def configure_network(self, ip_address, config_file_path):
        """配置交换机网络"""
        print(f"正在配置交换机网络: {ip_address}")
        print(f"配置文件: {config_file_path}")
        
        if not os.path.exists(config_file_path):
            print(f"错误: 配置文件不存在: {config_file_path}")
            return False
            
        status = self.nwswitch_dll.NWSwitchConfigureNetwork(
            ip_address.encode('utf-8'), 
            config_file_path.encode('utf-8')
        )
        
        if status != NWSWITCH_SUCCESS:
            print(f"网络配置失败: {self.get_status_description(status)}")
            return False
        
        print("网络配置成功")
        return True

    def sync_network(self, ip_address, save_file_path):
        """同步交换机网络配置"""
        print(f"正在同步交换机网络配置: {ip_address}")
        print(f"保存到文件: {save_file_path}")
        
        # 确保目录存在
        save_dir = os.path.dirname(save_file_path)
        if save_dir and not os.path.exists(save_dir):
            os.makedirs(save_dir)
        
        status = self.nwswitch_dll.NWSwitchSyncNetwork(
            ip_address.encode('utf-8'), 
            save_file_path.encode('utf-8')
        )
        
        if status != NWSWITCH_SUCCESS:
            print(f"网络同步失败: {self.get_status_description(status)}")
            return False
        
        print("网络同步成功")
        return True

    def setup_autostart(self, ip_address):
        """设置交换机网络配置自启动"""
        print(f"正在设置自启动: {ip_address}")
        
        status = self.nwswitch_dll.NWSwitchSetupAutostart(ip_address.encode('utf-8'))
        
        if status != NWSWITCH_SUCCESS:
            print(f"自启动设置失败: {self.get_status_description(status)}")
            return False
        
        print("自启动设置成功")
        return True

    # ========== 自动读取功能 ==========

    def start_auto_read(self, interval=1.0):
        if not self.is_connected():
            print("未连接")
            return False
        if self.auto_read_thread is not None:
            return True
        self.auto_read_enabled = True
        self.auto_read_thread = threading.Thread(target=self._auto_read_worker, args=(interval,), daemon=True)
        self.auto_read_thread.start()
        print(f"自动读取启动，间隔 {interval} 秒")
        return True

    def stop_auto_read(self):
        if self.auto_read_thread is None:
            return True
        self.auto_read_enabled = False
        try:
            self.auto_read_thread.join(timeout=0.5)
        except:
            pass
        self.auto_read_thread = None
        return True

    def _auto_read_worker(self, interval):
        while self.auto_read_enabled and self.running:
            try:
                if self.is_connected():
                    success, result = self.receive_result(timeout=100)
                    if success and result:
                        print("\n[自动读取] 收到输出:")
                        print("-" * 60)
                        print(result)
                        print("-" * 60)
                        print("[自动读取] >>> ", end="", flush=True)
                time.sleep(interval)
            except:
                time.sleep(0.5)

    def cleanup(self):
        self.running = False
        if self.auto_read_thread:
            self.stop_auto_read()
        if self.instance_id:
            try:
                self.nwswitch_dll.NWSwitchClose(self.instance_id)
            except:
                pass
            self.instance_id = None
        if self.nwswitch_dll:
            try:
                self.nwswitch_dll.ComCloseLog()
                time.sleep(0.5)
            except:
                pass

    def get_status_description(self, status):
        return STATUS_DESCRIPTIONS.get(status, f"未知状态码: {status}")
