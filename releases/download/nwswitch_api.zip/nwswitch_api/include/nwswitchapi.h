﻿/*----------------------------------------------------------------------------
* 网络交换机(Network Switch) API 接口
*
* 提供高性能的网络交换机通信接口，支持命令传输、结果接收、连接管理和网络配置。
* 该API设计用于在多种平台上提供一致的交换机控制体验。
*
* 主要特点：
* - 建立与交换机的安全连接
* - 发送命令并获取执行结果
* - 支持命令执行超时控制
* - 完整的网络配置管理功能
* - JSON配置文件的自动化部署
* - 网络配置自启动设置
* - 配置同步和备份功能
* - 完善的日志功能便于调试
* - 健壮的错误处理机制和详细的状态码
* - 支持多种交换机设备类型和配置
* - 跨平台支持（Windows/Linux）
* - 线程安全设计
* - 使用实例ID进行多连接管理
* - 标准化的错误报告系统
* - 支持DUT（Device Under Test）索引管理
* - SSH协议的安全通信
* - 自动化脚本生成和执行
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2024 丰柯科技。保留所有权利。
*
* 本软件按许可协议提供。使用本软件即表示接受许可条款。
*
* 作者: leiwei
* 版本: v3.1.0
* 日期: 2025-10-27
*----------------------------------------------------------------------------*/

// nwswitch.h
#ifndef NWSWITCH_API_H
#define NWSWITCH_API_H

// 定义导入/导出宏
#ifdef _WIN32
    #ifdef BUILD_NWSWITCH_API
        #define NWSWITCH_API extern "C" __declspec(dllexport)
    #else
        #define NWSWITCH_API extern "C" __declspec(dllimport)
    #endif
#else
    #define NWSWITCH_API extern "C"
#endif

/**
 * @brief API返回状态码
 */
typedef enum {
    NWSWITCH_SUCCESS = 0,                       // 操作成功
    NWSWITCH_ERROR_INVALID_PARAMETER = -1,      // 无效参数
    NWSWITCH_ERROR_CONNECTION_FAILED = -2,      // 连接失败
    NWSWITCH_ERROR_AUTHENTICATION = -3,         // 认证失败
    NWSWITCH_ERROR_COMMAND_EXECUTION = -4,      // 命令执行失败
    NWSWITCH_ERROR_TIMEOUT = -5,                // 操作超时
    NWSWITCH_ERROR_INSTANCE_NOT_FOUND = -6,     // 实例不存在
    NWSWITCH_ERROR_NETWORK = -7,                // 网络错误
    NWSWITCH_ERROR_INTERNAL = -8,               // 内部错误
    NWSWITCH_ERROR_DEVICE_BUSY = -9,            // 设备忙碌
    NWSWITCH_ERROR_CONFIG_INVALID = -101,         // 配置无效（文件格式错误）
    NWSWITCH_ERROR_READ_EMPTY = -200            // 读取为空，一般不代表错误
} NWSWITCH_RETURN_STATUS;

/**
 * @brief 打开日志，用于调试和故障诊断。
 *
 * 建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源
 *
 * @param logFile 日志文件路径，例如: "logs/nwswitch_api.log"。
 * @param level 日志等级, 0:DEBUG, 1:INFO, 2:WARN, 3:ERROR。
 * @param maxSize 单个日志文件的最大尺寸 (单位: MB, 范围 1-100)。
 * @param maxFiles 日志文件的最大保留数量 (范围 1-20)。
 * @return 0 表示成功，其他值为失败。
 */
NWSWITCH_API int NWSwitchOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
* @brief 关闭日志
* @return 0:关闭成功 其它:失败错误码
*/
NWSWITCH_API int NWSwitchCloseLog();

/**
 * @brief 连接到交换机
 * @param ipAddress 交换机IP地址，格式为"IP/DUT索引"，例如"192.168.1.120/1"
 * @return 成功返回大于0的实例ID，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchConnect(const char* ipAddress);

/**
 * @brief 向交换机发送命令
 * @param instance 实例ID，由NWSwitchConnect返回
 * @param cmdStr 要执行的命令
 * @return 成功返回NWSWITCH_SUCCESS，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchSendCmd(int instance, const char* cmdStr);

/**
 * @brief 接收交换机命令执行结果
 * @param instance 实例ID，由NWSwitchConnect返回
 * @param recvBuffer 接收缓冲区，用于存储命令执行结果
 * @param bufferSize 缓冲区大小
 * @param timeout 超时时间，单位毫秒
 * @return 成功返回NWSWITCH_SUCCESS，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchReceiveCmdResult(int instance,
                                          char* recvBuffer,
                                          unsigned int bufferSize,
                                          unsigned int timeout);

/**
 * @brief 停止当前正在执行的命令
 * @param instance 实例ID，由NWSwitchConnect返回
 * @return 成功返回NWSWITCH_SUCCESS，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchStopCommand(int instance);
/**
 * @brief 停止当前正在执行的命令并清空缓存
 * @param instance 实例ID，由NWSwitchConnect返回
 * @return 成功返回NWSWITCH_SUCCESS，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchStopAndClearCommand(int instance);

/**
 * @brief 关闭与交换机的连接
 * @param instance 实例ID，由NWSwitchConnect返回
 * @return 成功返回NWSWITCH_SUCCESS，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchClose(int instance);

//=============================================================================
// 网络配置管理 API
//=============================================================================

/**
 * @brief 配置交换机网络
 * @param ipAddress 交换机IP地址，例如："192.168.1.120"
 * @param configFilePath JSON配置文件路径
 * @return 成功返回NWSWITCH_SUCCESS，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchConfigureNetwork(const char* ipAddress, const char* configFilePath);

/**
 * @brief 同步交换机网络配置
 * @param ipAddress 交换机IP地址
 * @param saveFilePath 保存配置的文件路径
 * @return 成功返回NWSWITCH_SUCCESS，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchSyncNetwork(const char* ipAddress, const char* saveFilePath);

/**
 * @brief 设置交换机网络配置自启动
 * @param ipAddress 交换机IP地址
 * @return 成功返回NWSWITCH_SUCCESS，失败返回NWSWITCH_RETURN_STATUS
 */
NWSWITCH_API int NWSwitchSetupAutostart(const char* ipAddress);


#endif // NWSWITCH_API_H
