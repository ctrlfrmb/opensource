﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# BSCollectorTest.py - 采集卡测试脚本

import argparse
import time
import datetime
import os
import signal
import sys
import threading
from BSCollectorApi import BSCollectorApi
from BSConfig import BSConfig

# 全局变量
api = None
is_running = True

def signal_handler(sig, frame):
    """处理信号（如Ctrl+C）"""
    global api, is_running
    print("\n接收到中断信号，正在清理资源...")
    is_running = False
    
    try:
        if api:
            # 设置一个超时，避免清理过程无限阻塞
            def cleanup():
                try:
                    print("停止保存文件...")
                    api.stop_save_file()
                    print("关闭设备...")
                    api.close_can()
                    print("关闭日志...")
                    api.close_log()
                except Exception as e:
                    print(f"清理过程中出错: {e}")
            
            cleanup_thread = threading.Thread(target=cleanup)
            cleanup_thread.daemon = True  # 设置为守护线程
            cleanup_thread.start()
            
            # 等待清理完成，但最多等待5秒
            cleanup_thread.join(timeout=5.0)
            
            if cleanup_thread.is_alive():
                print("警告: 清理过程超时，强制退出")
            else:
                print("清理完成")
    except Exception as e:
        print(f"清理过程中出错: {e}")
    
    print("程序已终止")
    # 强制终止程序，不等待其他线程
    os._exit(0)

def format_data_row(data):
    """按照C++代码中的格式化方式格式化数据行，但使用更紧凑的格式"""
    # 格式化CAN ID
    id_str = f"0x{data['CanID']:03X}"
    
    # 格式化时间和ID
    row = f"{data['Time']:<26} {id_str:<6} "
    
    # 格式化通道数据 - 从20字符宽度减少到12字符宽度
    for i in range(8):
        row += f"{data['Data'][i]:<12} "
    
    return row

def main():
    global api
    
    # 注册信号处理器
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    parser = argparse.ArgumentParser(description='数据采集测试工具v1.2.0')
    parser.add_argument('--config', type=str, default='BSConfig.ini',
                        help='配置文件路径')
    parser.add_argument('--device', type=int,
                        help='设备索引 (0-15)')
    parser.add_argument('--channel', type=int,
                        help='通道索引')
    parser.add_argument('--baudrate', type=int,
                        help='CAN波特率')
    parser.add_argument('--fdbaudrate', type=int,
                        help='CANFD波特率')
    parser.add_argument('--serial', type=str,
                        help='模块序列号 (支持0x前缀的十六进制)')
    parser.add_argument('--freq', type=int,
                        help='采样频率(ms)')
    parser.add_argument('--arraysize', type=int,
                        help='读取数据数组大小')
    parser.add_argument('--save', action='store_true',
                        help='是否保存文件')
    parser.add_argument('--readtime', type=float, default=600.0,
                        help='读取数据的总时间（秒）')
    parser.add_argument('--interval', type=float, default=0.1,
                        help='读取数据的时间间隔（秒）')
    # 新增日志相关参数
    parser.add_argument('--log-enable', action='store_true',
                        help='启用日志')
    parser.add_argument('--log-level', type=int, choices=[0, 1, 2, 3],
                        help='日志级别(0:DEBUG, 1:INFO, 2:WARN, 3:ERROR)')
    parser.add_argument('--log-path', type=str,
                        help='日志文件路径')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print(f"数据采集测试工具v2.0.0")
    print("=" * 60)
    
    # 加载配置
    config = BSConfig()
    
    # 优先从文件加载配置
    file_loaded = config.load_from_file(args.config)
    
    # 检查有无需要从命令行参数中覆盖的设置
    has_cmd_args = False
    cmd_args_list = [
        args.device, args.channel, args.baudrate, args.fdbaudrate,
        args.serial, args.freq, args.arraysize
    ]
    # 特别处理布尔型参数
    if args.save:
        has_cmd_args = True
    if args.log_enable:
        has_cmd_args = True
    if args.log_level is not None:
        has_cmd_args = True
    if args.log_path is not None:
        has_cmd_args = True
    
    # 如果文件加载失败或有命令行参数覆盖，则从命令行参数加载
    if not file_loaded or has_cmd_args or any(arg is not None for arg in cmd_args_list):
        config.load_from_args(args)
    
    # 打印配置信息
    config.print_config()
    
    # 初始化API
    api = BSCollectorApi()
    if not api.dll:
        print("初始化失败，退出测试")
        return
    
    try:
        # 打开日志（根据配置决定是否打开）
        if config.log['enable']:
            print("\n## 1. 打开日志 ##")
            # 确保日志目录存在
            log_path = config.log['path']
            log_dir = os.path.dirname(log_path)
            if log_dir and not os.path.exists(log_dir):
                try:
                    os.makedirs(log_dir)
                    print(f"创建日志目录: {log_dir}")
                except Exception as e:
                    print(f"创建日志目录失败: {e}")
            
            print(f"日志路径: {log_path}")
            print(f"日志级别: {config.log['level']}")
            print(f"日志大小: {config.log['maxsize']}MB")
            print(f"日志文件数: {config.log['maxfiles']}")
            
            result = api.open_log(
                log_path=log_path,
                level=config.log['level'],
                max_size=config.log['maxsize'],
                max_files=config.log['maxfiles']
            )
            if result != 0:
                print(f"打开日志失败，错误码: {result}，但继续测试")
            else:
                print(f"成功打开日志: {log_path}")
        else:
            print("\n## 1. 日志功能已禁用 ##")
        
        # 打开设备
        print("\n## 2. 打开设备 ##")
        device_name = f"Device{config.device['device']}"
        print(f"正在打开 {device_name}...")
        
        if config.device.get('fdbaudrate', 0) > 0:
            # 使用CANFD
            result = api.open_canfd(
                config.device['device'],
                config.device['channel'],
                config.device['baudrate'],
                config.device['fdbaudrate']
            )
        else:
            # 使用标准CAN
            result = api.open_can(
                config.device['device'],
                config.device['channel'],
                config.device['baudrate']
            )
            
        if result != 0:
            print(f"打开设备失败，错误码: {result}，退出测试")
            if config.log['enable']:
                api.close_log()
            return
        
        print(f"成功打开 {device_name} CAN{config.device['channel']}")
        
        # 设置所有模块的采样频率
        print("\n## 3. 设置采样频率 ##")
        for module in config.modules:
            print(f"正在设置模块 {module['name']} (0x{module['serial']:08X}) 采样频率为 {module['freq']}ms...")
            result = api.set_module_sampling_frequency(
                module['serial'],
                module['freq']
            )
            if result != 0:
                print(f"设置模块 {module['name']} 采样频率失败，错误码: {result}，但继续测试")
            else:
                print(f"成功设置模块 {module['name']} 采样频率")
        
        time.sleep(1)
        
        # 清空缓冲区
        print("\n## 4. 清空缓冲区 ##")
        result = api.clear_buffer()
        if result != 0:
            print(f"清空缓冲区失败，错误码: {result}，但继续测试")
        else:
            print("成功清空缓冲区")

        # 保存文件测试 - 需要在读取数据前开始保存
        save_file_started = False
        if config.collection['save']:
            print("\n## 5. 开始保存文件 ##")
            
            # 生成文件名，包含当前时间
            file_name = "Current_monitor_data.csv"
            print(f"将数据保存到文件: {file_name} (DLL将根据此名称生成最终文件名)")
            
            # 开始保存文件
            result = api.start_save_file(
                file_name,
                config.collection['filesize'],
                config.collection['filecount']
            )
            if result != 0:
                print(f"开始保存文件失败，错误码: {result}")
            else:
                save_file_started = True
                print("成功开始保存文件")
        else:
            print("\n## 5. 文件保存功能已禁用 ##")
        
        # 读取数据
        print("\n## 6. 读取数据 ##")
        print(f"每{args.interval}秒读取一次数据，持续{args.readtime}秒...")
        
        # 打印表头 - 调整为更紧凑的格式
        print("\n时间                       CAN ID  通道1         通道2         通道3         通道4         通道5         通道6         通道7         通道8         ")
        print("-" * 140)  # 减少分隔线长度

        # 用于保存所有读取的数据
        all_data = []

        # 计算需要读取的次数
        read_interval = args.interval
        read_duration = args.readtime
        read_times = int(read_duration / read_interval)

        # 循环读取数据
        for i in range(read_times):
            # 检查是否收到了终止信号
            if not is_running:
                break
                
            # 读取数据
            print(f"正在读取数据，最多 {config.collection['arraysize']} 条...")
            count, data_list = api.read_buffer(config.collection['arraysize'])
            
            # 将本次读取的数据添加到总数据列表中
            if count > 0:
                all_data.extend(data_list)
                
                # 直接打印数据
                for data in data_list:
                    formatted_row = format_data_row(data)
                    print(formatted_row)
                
                print(f"成功读取 {count} 条数据")
                print(f"第 {i+1}/{read_times} 次读取，获取 {count} 条数据")
            else:
                print(f"第 {i+1}/{read_times} 次读取，没有新数据")
            
            # 等待指定间隔
            if is_running and i < read_times - 1:  # 不在最后一次循环后等待
                time.sleep(read_interval)

        # 显示统计信息
        total_count = len(all_data)
        print(f"\n总共读取 {total_count} 条数据")
        
        # 如果开启了文件保存，则在测试结束时停止保存
        if save_file_started:
            print("\n## 7. 停止保存文件 ##")
            result = api.stop_save_file()
            if result != 0:
                print(f"停止保存文件失败，错误码: {result}")
            else:
                print("成功停止保存文件")
        
        # 关闭设备
        print(f"\n## 8. 关闭设备 ({device_name}) ##")
        result = api.close_can()
        if result != 0:
            print(f"关闭设备失败，错误码: {result}")
        else:
            print(f"成功关闭 {device_name}")
        
        # 关闭日志
        if config.log['enable']:
            print("\n## 9. 关闭日志 ##")
            result = api.close_log()
            if result != 0:
                print(f"关闭日志失败，错误码: {result}")
            else:
                print("成功关闭日志")
        
        print("\n测试完成!")
    
    except Exception as e:
        print(f"\n测试过程中发生错误: {e}")
        import traceback
        traceback.print_exc()
        
        # 尝试清理资源
        try:
            if 'save_file_started' in locals() and save_file_started:
                api.stop_save_file()
            api.close_can()
            if config.log['enable']:
                api.close_log()
        except Exception as cleanup_error:
            print(f"清理资源时发生错误: {cleanup_error}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"主程序异常: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # 确保在程序退出前尝试清理资源
        if api:
            try:
                # 检查是否已经尝试过清理
                if 'save_file_started' in locals() and save_file_started:
                    api.stop_save_file()
                api.close_can()
                # 根据全局配置决定是否关闭日志
                if 'config' in locals() and config.log['enable']:
                    api.close_log()
            except:
                pass
        print("程序退出")
