﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# BSCollectorTest.py - 采集卡测试脚本

import argparse
import time
import os
import signal
import sys
import threading
from BSCollectorApi import BSCollectorApi
from BSConfig import BSConfig

# 全局变量
api = None
is_running = True
config = None # 将config也设为全局，以便清理时使用

def signal_handler(sig, frame):
    """处理信号（如Ctrl+C）"""
    global api, is_running, config
    print("\n接收到中断信号，正在清理资源...")
    is_running = False
    
    # 留出一点时间让主循环检测到 is_running 标志
    time.sleep(0.2) 
    
    # 清理函数
    def cleanup():
        try:
            if api:
                # 仅当配置中启用了保存时才停止保存
                if config and config.collection.get('save', False):
                    api.stop_save_file()
                api.close_can()
                if config and config.log.get('enable', False):
                    api.close_log()
        except Exception as e:
            print(f"清理过程中出错: {e}")

    # 使用线程进行清理，并设置超时
    cleanup_thread = threading.Thread(target=cleanup)
    cleanup_thread.daemon = True
    cleanup_thread.start()
    cleanup_thread.join(timeout=5.0)
    
    if cleanup_thread.is_alive():
        print("警告: 清理过程超时，强制退出")
    else:
        print("清理完成")
    
    print("程序已终止")
    os._exit(0)

def format_data_row(data):
    """格式化数据行，使其对齐且易于阅读"""
    id_str = f"0x{data['CanID']:03X}"
    row = f"{data['Time']:<26} {id_str:<6} "
    for i in range(8):
        row += f"{data['Data'][i]:<12} "
    return row

def main():
    global api, config, is_running
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    parser = argparse.ArgumentParser(description='数据采集测试工具v3.0.0')
    parser.add_argument('--config', type=str, default='BSConfig.ini', help='配置文件路径')
    parser.add_argument('--device', type=int, help='设备索引 (0-15)')
    parser.add_argument('--channel', type=int, help='通道索引')
    parser.add_argument('--baudrate', type=int, help='CAN波特率')
    parser.add_argument('--fdbaudrate', type=int, help='CANFD波特率')
    parser.add_argument('--serial', type=str, help='模块序列号 (支持0x前缀)')
    parser.add_argument('--freq', type=int, help='采样频率(ms)')
    parser.add_argument('--arraysize', type=int, help='读取数据数组大小')
    parser.add_argument('--save', action='store_true', help='是否保存文件')
    parser.add_argument('--readtime', type=float, default=600.0, help='读取数据的总时间（秒）')
    parser.add_argument('--interval', type=float, default=0.1, help='读取数据的时间间隔（秒）')
    parser.add_argument('--log-enable', action='store_true', help='启用日志')
    parser.add_argument('--log-level', type=int, choices=[0, 1, 2, 3], help='日志级别')
    parser.add_argument('--log-path', type=str, help='日志文件路径')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print(f"数据采集测试工具v3.0.0")
    print("=" * 60)
    
    config = BSConfig()
    if not config.load_from_file(args.config):
        print("从文件加载配置失败，将使用默认值和命令行参数。")
    config.load_from_args(args) # 命令行参数覆盖文件配置
    config.print_config()
    
    api = BSCollectorApi()
    if not api.dll:
        print("初始化失败，退出测试")
        return
    
    save_file_started = False
    try:
        # 1. 打开日志
        if config.log['enable']:
            print("\n## 1. 打开日志 ##")
            log_dir = os.path.dirname(config.log['path'])
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir)
            api.open_log(
                log_path=config.log['path'], level=config.log['level'],
                max_size=config.log['maxsize'], max_files=config.log['maxfiles']
            )
        else:
            print("\n## 1. 日志功能已禁用 ##")
        
        # 2. 打开设备
        print("\n## 2. 打开设备 ##")
        if config.device.get('fdbaudrate', 0) > 0:
            result = api.open_canfd(
                config.device['device'], config.device['channel'],
                config.device['baudrate'], config.device['fdbaudrate']
            )
        else:
            result = api.open_can(
                config.device['device'], config.device['channel'], config.device['baudrate']
            )
        if result != 0:
            print(f"打开设备失败，错误码: {result}，退出测试")
            return

        # 3. 设置采样频率
        print("\n## 3. 设置采样频率 ##")
        for module in config.modules:
            api.set_module_sampling_frequency(module['serial'], module['freq'])
        
        time.sleep(1)
        
        # 4. 清空缓冲区
        print("\n## 4. 清空缓冲区 ##")
        api.clear_buffer()

        # 5. 开始保存文件
        if config.collection['save']:
            print("\n## 5. 开始保存文件 ##")
            root_dir = config.collection['rootdir']
            if not os.path.exists(root_dir):
                os.makedirs(root_dir)
            result = api.start_save_file(
                root_dir, config.collection['mapping'], config.collection['filesize']
            )
            if result == 0:
                save_file_started = True
        else:
            print("\n## 5. 文件保存功能已禁用 ##")
        
        # 6. 读取数据
        print("\n## 6. 读取数据 ##")
        print(f"每{args.interval}秒读取一次数据，持续{args.readtime}秒...")
        print("\n时间                       CAN ID  通道1         通道2         通道3         通道4         通道5         通道6         通道7         通道8         ")
        print("-" * 140)

        start_time = time.time()
        total_count = 0
        while is_running and (time.time() - start_time) < args.readtime:
            count, data_list = api.read_buffer(config.collection['arraysize'])
            if count > 0:
                total_count += count
                for data in data_list:
                    print(format_data_row(data))
            
            time.sleep(args.interval)

        print(f"\n读取结束，总共读取 {total_count} 条数据")
        
    except Exception as e:
        print(f"\n测试过程中发生错误: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        # 清理资源
        if api:
            print("\n## 清理资源 ##")
            if save_file_started:
                api.stop_save_file()
            api.close_can()
            if config.log['enable']:
                api.close_log()
        print("\n测试完成!")

if __name__ == "__main__":
    main()

