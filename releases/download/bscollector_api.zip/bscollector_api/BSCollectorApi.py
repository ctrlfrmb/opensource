﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# BSCollectorApi.py - 采集卡API封装

import ctypes
from ctypes import *
import os
import platform
import datetime

class BSCollectData(Structure):
    """采集数据结构体"""
    _pack_ = 4
    _fields_ = [
        ("CanID", c_uint),                                     # CAN ID (11位标准或29位扩展)
        ("Time", c_char * 32),                                 # 时间字符串 "YYYY-MM-DD HH:MM:SS.mmm"
        ("Rev", c_uint),                                       # 保留字段
        ("Data", c_int * 8)                                    # 采集数据，8个通道
    ]

class BSCollectorApi:
    """BSCollector API 封装类"""
    
    def __init__(self):
        """初始化API封装类"""
        self.dll = None
        self.device_index = None
        self.channel_index = None
        self.device_online = False
        self.load_dll()
    
    def load_dll(self):
        """加载DLL库
        
        Returns:
            bool: 成功返回True，失败返回False
        """
        try:
            print("正在加载BSCollectorApi...")
            current_arch = platform.architecture()[0]
            print(f"Python 架构: {current_arch}")
            
            if current_arch == "64bit":
                lib_path = os.path.abspath("./lib/Winx64")
            else:
                lib_path = os.path.abspath("./lib/Winx86")
                
            os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
            print(f"库路径: {lib_path}")
            
            print("加载依赖库...")
            try:
                # 显式加载依赖，确保环境干净时也能运行
                ctypes.WinDLL(os.path.join(lib_path, "Qt5Core.dll"))
            except Exception as e:
                print(f"加载依赖库失败: {e}")
                return False
            
            print("加载 bscollector_api.dll...")
            try:
                self.dll = ctypes.WinDLL(os.path.join(lib_path, "bscollector_api.dll"))
                self._init_function_prototypes()
                print("bscollector_api.dll 加载成功")
                return True
            except Exception as e:
                print(f"加载 bscollector_api.dll 失败: {e}")
                return False
        
        except Exception as e:
            print(f"初始化过程中发生错误: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _init_function_prototypes(self):
        """初始化函数原型"""
        # 日志相关函数
        self.dll.BSOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
        self.dll.BSOpenLog.restype = c_int
        
        self.dll.BSCloseLog.argtypes = []
        self.dll.BSCloseLog.restype = c_int
        
        # 设备相关函数
        self.dll.BSOpenDev.argtypes = [c_int, c_int, c_int]
        self.dll.BSOpenDev.restype = c_int
        
        self.dll.BSCloseDev.argtypes = [c_int]
        self.dll.BSCloseDev.restype = c_int
        
        # CAN相关函数
        self.dll.BSInitCAN.argtypes = [c_int, c_int, c_uint]
        self.dll.BSInitCAN.restype = c_int
        
        self.dll.BSInitCANFD.argtypes = [c_int, c_int, c_uint, c_uint]
        self.dll.BSInitCANFD.restype = c_int
        
        self.dll.BSResetCAN.argtypes = [c_int, c_int]
        self.dll.BSResetCAN.restype = c_int
        
        self.dll.BSSetTerminalResistorCAN.argtypes = [c_int, c_int, c_int]
        self.dll.BSSetTerminalResistorCAN.restype = c_int
        
        # 采集相关函数
        self.dll.BSSetModuleSamplingFrequency.argtypes = [c_int, c_int, c_uint, c_int]
        self.dll.BSSetModuleSamplingFrequency.restype = c_int
        
        self.dll.BSClearBuffer.argtypes = [c_int, c_int]
        self.dll.BSClearBuffer.restype = c_int
        
        self.dll.BSReadBuffer.argtypes = [c_int, c_int, POINTER(BSCollectData), c_uint]
        self.dll.BSReadBuffer.restype = c_int
        
        # 文件相关函数 (核心改动)
        self.dll.BSStartSaveFile.argtypes = [c_int, c_int, c_char_p, c_char_p, c_int]
        self.dll.BSStartSaveFile.restype = c_int
        
        self.dll.BSStopSaveFile.argtypes = [c_int, c_int]
        self.dll.BSStopSaveFile.restype = c_int
    
    def device_is_online(self):
        """检查设备是否在线
        
        Returns:
            bool: 设备在线返回True，否则返回False
        """
        return self.device_online
    
    def open_log(self, log_path="bscollector.log", level=1, max_size=-1, max_files=-1):
        """打开日志
        
        Args:
            log_path (str): 日志文件路径
            level (int): 日志级别，0=DEBUG, 1=INFO, 2=WARN, 3=ERROR
            max_size (int): 文件大小，单位M
            max_files (int): 文件个数
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
            
        return self.dll.BSOpenLog(log_path.encode('utf-8'), level, max_size, max_files)
    
    def close_log(self):
        """关闭日志
        
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
            
        return self.dll.BSCloseLog()
    
    def open_can(self, device_index, channel_index, baud_rate):
        """打开CAN设备（标准CAN）
        
        Args:
            device_index (int): 设备索引
            channel_index (int): 通道索引
            baud_rate (int): CAN波特率
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        self.device_index = device_index
        self.channel_index = channel_index
        
        print(f"正在打开设备 {device_index}...")
        result = self.dll.BSOpenDev(0, device_index, 0)
        if result != 0:
            print(f"打开设备失败，错误码: {result}")
            self.device_online = False
            return result
        
        print(f"打开设备成功")
        
        print(f"正在初始化CAN通道 {channel_index}...")
        result = self.dll.BSInitCAN(device_index, channel_index, baud_rate)
        if result != 0:
            print(f"初始化CAN通道失败，错误码: {result}")
            self.dll.BSCloseDev(device_index)
            self.device_online = False
            return result
        
        print(f"初始化CAN通道成功")
        self.device_online = True
        return 0
    
    def open_canfd(self, device_index, channel_index, baud_rate, fd_baud_rate):
        """打开CANFD设备
        
        Args:
            device_index (int): 设备索引
            channel_index (int): 通道索引
            baud_rate (int): 标准CAN波特率
            fd_baud_rate (int): CANFD波特率
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        self.device_index = device_index
        self.channel_index = channel_index
        
        print(f"正在打开设备 {device_index}...")
        result = self.dll.BSOpenDev(0, device_index, 0)
        if result != 0:
            print(f"打开设备失败，错误码: {result}")
            self.device_online = False
            return result
        
        print(f"打开设备成功")
        
        print(f"正在初始化CANFD通道 {channel_index}...")
        result = self.dll.BSInitCANFD(device_index, channel_index, baud_rate, fd_baud_rate)
        if result != 0:
            print(f"初始化CANFD通道失败，错误码: {result}")
            self.dll.BSCloseDev(device_index)
            self.device_online = False
            return result
        
        print(f"初始化CANFD通道成功")
        self.device_online = True
        return 0
    
    def close_can(self):
        """关闭CAN设备
        
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        if not self.device_online:
            # print("设备不在线，无需关闭")
            return 0 # 认为已经是关闭状态，返回成功
        
        print(f"正在关闭设备 {self.device_index}...")
        result = self.dll.BSCloseDev(self.device_index)
        if result != 0:
            print(f"关闭设备失败，错误码: {result}")
            return result
        
        print(f"关闭设备成功")
        self.device_online = False
        return 0
    
    def set_module_sampling_frequency(self, serial_number, sampling_frequency):
        """设置模块采样频率
        
        Args:
            serial_number (int): 模块序列码
            sampling_frequency (int): 采样频率
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll or not self.device_online:
            print("设备未初始化或不在线")
            return -1
        
        print(f"正在设置模块(序列号:0x{serial_number:08X})采样频率为 {sampling_frequency}ms...")
        result = self.dll.BSSetModuleSamplingFrequency(
            self.device_index, self.channel_index, serial_number, sampling_frequency
        )
        if result != 0:
            print(f"设置采样频率失败，错误码: {result}")
        else:
            print(f"设置采样频率成功")
        return result
    
    def clear_buffer(self):
        """清空采集数据缓存
        
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll or not self.device_online:
            print("设备未初始化或不在线")
            return -1
        
        print(f"正在清空缓存...")
        result = self.dll.BSClearBuffer(self.device_index, self.channel_index)
        if result != 0:
            print(f"清空缓存失败，错误码: {result}")
        else:
            print(f"清空缓存成功")
        return result
    
    def read_buffer(self, array_size=1000):
        """读取采集数据
        
        Args:
            array_size (int): 要读取的数据条数
            
        Returns:
            tuple: (读取数据条数, 数据列表)
        """
        if not self.dll or not self.device_online:
            return -1, []
        
        data_array = (BSCollectData * array_size)()
        read_count = self.dll.BSReadBuffer(
            self.device_index, self.channel_index, data_array, array_size
        )
        
        if read_count < 0:
            # -13 表示缓冲区为空，这是正常情况，不打印错误
            if read_count != -13:
                print(f"读取数据失败，错误码: {read_count}")
            return read_count, []
        
        data_list = []
        for i in range(read_count):
            data = data_array[i]
            data_dict = {
                'CanID': data.CanID,
                'Time': data.Time.decode('utf-8').strip('\0'),
                'Data': list(data.Data)
            }
            data_list.append(data_dict)
        
        return read_count, data_list
    
    def start_save_file(self, root_dir, mapping_str, file_size_mb):
        """开始保存数据到文件
        
        Args:
            root_dir (str): 保存文件的根目录
            mapping_str (str): CAN ID到文件名前缀的映射关系字符串
            file_size_mb (int): 单个文件的最大大小 (MB)
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll or not self.device_online:
            print("设备未初始化或不在线")
            return -1
        
        print(f"正在开始保存数据...")
        print(f"  根目录: {root_dir}")
        print(f"  文件大小: {file_size_mb} MB")
        print(f"  ID映射:\n---\n{mapping_str}\n---")

        result = self.dll.BSStartSaveFile(
            self.device_index, 
            self.channel_index, 
            root_dir.encode('utf-8'), 
            mapping_str.encode('utf-8'),
            file_size_mb
        )
        if result != 0:
            print(f"开始保存文件失败，错误码: {result}")
        else:
            print(f"成功开始保存文件")
        return result
    
    def stop_save_file(self):
        """停止保存数据到文件
        
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll or not self.device_online:
            # print("设备不在线，无需停止保存")
            return 0
        
        print(f"正在停止保存文件...")
        result = self.dll.BSStopSaveFile(self.device_index, self.channel_index)
        if result != 0:
            print(f"停止保存文件失败，错误码: {result}")
        else:
            print(f"停止保存文件成功")
        return result

