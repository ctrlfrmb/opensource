﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# BSCollectorApi.py - 采集卡API封装

import ctypes
from ctypes import *
import os
import platform
import datetime

class BSCollectData(Structure):
    """采集数据结构体"""
    _pack_ = 4
    _fields_ = [
        ("CanID", c_uint),                                     # CAN ID (11位标准或29位扩展)
        ("Time", c_char * 32),                                 # 时间字符串 "YYYY-MM-DD HH:MM:SS.mmm"
        ("Rev", c_uint),                                       # 保留字段
        ("Data", c_int * 8)                                    # 采集数据，8个通道（注意：从c_uint改为c_int）
    ]

class BSCollectorApi:
    """BSCollector API 封装类"""
    
    def __init__(self):
        """初始化API封装类"""
        self.dll = None
        self.device_index = None
        self.channel_index = None
        self.device_online = False  # 新增设备在线状态标志
        self.load_dll()
    
    def load_dll(self):
        """加载DLL库
        
        Returns:
            bool: 成功返回True，失败返回False
        """
        try:
            print("正在加载BSCollectorApi...")
            current_arch = platform.architecture()[0]
            print(f"Python 架构: {current_arch}")
            
            # 根据Python系统架构自动选择库路径
            if current_arch == "64bit":
                lib_path = os.path.abspath("./lib/Winx64")
            else:
                lib_path = os.path.abspath("./lib/Winx86")
                
            os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
            print(f"库路径: {lib_path}")
            
            # 先加载依赖库
            print("加载依赖库...")
            try:
                qt_core_dll = ctypes.WinDLL(os.path.join(lib_path, "Qt5Core.dll"))
                # 其他依赖库一般会自动加载
            except Exception as e:
                print(f"加载依赖库失败: {e}")
                return False
            
            # 加载BSCollectorApi DLL
            print("加载 bscollector_api.dll...")
            try:
                self.dll = ctypes.WinDLL(os.path.join(lib_path, "bscollector_api.dll"))
                self._init_function_prototypes()
                print("bscollector_api.dll 加载成功")
                return True
            except Exception as e:
                print(f"加载 bscollector_api.dll 失败: {e}")
                return False
        
        except Exception as e:
            print(f"初始化过程中发生错误: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _init_function_prototypes(self):
        """初始化函数原型"""
        # 日志相关函数
        self.dll.ComOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
        self.dll.ComOpenLog.restype = c_int
        
        self.dll.ComCloseLog.argtypes = []
        self.dll.ComCloseLog.restype = c_int
        
        # 设备相关函数
        self.dll.BSOpenDev.argtypes = [c_int, c_int, c_int]
        self.dll.BSOpenDev.restype = c_int
        
        self.dll.BSCloseDev.argtypes = [c_int]
        self.dll.BSCloseDev.restype = c_int
        
        # CAN相关函数
        self.dll.BSInitCAN.argtypes = [c_int, c_int, c_uint]
        self.dll.BSInitCAN.restype = c_int
        
        self.dll.BSInitCANFD.argtypes = [c_int, c_int, c_uint, c_uint]
        self.dll.BSInitCANFD.restype = c_int
        
        self.dll.BSResetCAN.argtypes = [c_int, c_int]
        self.dll.BSResetCAN.restype = c_int
        
        self.dll.BSSetTerminalResistorCAN.argtypes = [c_int, c_int, c_int]
        self.dll.BSSetTerminalResistorCAN.restype = c_int
        
        # 采集相关函数
        self.dll.BSSetModuleSamplingFrequency.argtypes = [c_int, c_int, c_uint, c_int]
        self.dll.BSSetModuleSamplingFrequency.restype = c_int
        
        self.dll.BSClearBuffer.argtypes = [c_int, c_int]
        self.dll.BSClearBuffer.restype = c_int
        
        self.dll.BSReadBuffer.argtypes = [c_int, c_int, POINTER(BSCollectData), c_uint]
        self.dll.BSReadBuffer.restype = c_int
        
        # 文件相关函数
        self.dll.BSStartSaveFile.argtypes = [c_int, c_int, c_char_p, c_int, c_int]
        self.dll.BSStartSaveFile.restype = c_int
        
        self.dll.BSStopSaveFile.argtypes = [c_int, c_int]
        self.dll.BSStopSaveFile.restype = c_int
    
    def device_is_online(self):
        """检查设备是否在线
        
        Returns:
            bool: 设备在线返回True，否则返回False
        """
        return self.device_online
    
    def open_log(self, log_path="bscollector.log", level=1, max_size=-1, max_files=-1):
        """打开日志
        
        Args:
            log_path (str): 日志文件路径
            level (int): 日志级别，0=DEBUG, 1=INFO, 2=WARN, 3=ERROR
            max_size (int): 文件大小，单位M
            max_files (int): 文件个数
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
            
        return self.dll.ComOpenLog(log_path.encode('utf-8'), level, max_size, max_files)
    
    def close_log(self):
        """关闭日志
        
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
            
        return self.dll.ComCloseLog()
    
    def open_can(self, device_index, channel_index, baud_rate):
        """打开CAN设备（标准CAN）
        
        Args:
            device_index (int): 设备索引
            channel_index (int): 通道索引
            baud_rate (int): CAN波特率
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        # 保存设备和通道索引
        self.device_index = device_index
        self.channel_index = channel_index
        
        # 打开设备
        print(f"正在打开设备 {device_index}...")
        result = self.dll.BSOpenDev(0, device_index, 0)  # deviceType=0, reserved=0
        if result != 0:
            print(f"打开设备失败，错误码: {result}")
            self.device_online = False
            return result
        
        print(f"打开设备成功")
        
        # 初始化CAN通道
        print(f"正在初始化CAN通道 {channel_index}...")
        result = self.dll.BSInitCAN(device_index, channel_index, baud_rate)
        if result != 0:
            print(f"初始化CAN通道失败，错误码: {result}")
            # 关闭已打开的设备
            self.dll.BSCloseDev(device_index)
            self.device_online = False
            return result
        
        print(f"初始化CAN通道成功")
        self.device_online = True  # 设置设备在线状态为True
        return 0
    
    def open_canfd(self, device_index, channel_index, baud_rate, fd_baud_rate):
        """打开CANFD设备
        
        Args:
            device_index (int): 设备索引
            channel_index (int): 通道索引
            baud_rate (int): 标准CAN波特率
            fd_baud_rate (int): CANFD波特率
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        # 保存设备和通道索引
        self.device_index = device_index
        self.channel_index = channel_index
        
        # 打开设备
        print(f"正在打开设备 {device_index}...")
        result = self.dll.BSOpenDev(0, device_index, 0)  # deviceType=0, reserved=0
        if result != 0:
            print(f"打开设备失败，错误码: {result}")
            self.device_online = False
            return result
        
        print(f"打开设备成功")
        
        # 初始化CANFD通道
        print(f"正在初始化CANFD通道 {channel_index}...")
        result = self.dll.BSInitCANFD(device_index, channel_index, baud_rate, fd_baud_rate)
        if result != 0:
            print(f"初始化CANFD通道失败，错误码: {result}")
            # 关闭已打开的设备
            self.dll.BSCloseDev(device_index)
            self.device_online = False
            return result
        
        print(f"初始化CANFD通道成功")
        self.device_online = True  # 设置设备在线状态为True
        return 0
    
    def close_can(self):
        """关闭CAN设备
        
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        if not self.device_online:
            print("设备不在线")
            return -1
        
        print(f"正在关闭设备 {self.device_index}...")
        result = self.dll.BSCloseDev(self.device_index)
        if result != 0:
            print(f"关闭设备失败，错误码: {result}")
            return result
        
        print(f"关闭设备成功")
        self.device_online = False  # 设置设备在线状态为False
        return 0
    
    def set_module_sampling_frequency(self, serial_number, sampling_frequency):
        """设置模块采样频率
        
        Args:
            serial_number (int): 模块序列码
            sampling_frequency (int): 采样频率
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        if not self.device_online:
            print("设备不在线")
            return -1
        
        print(f"正在设置模块(序列号:0x{serial_number:08X})采样频率为 {sampling_frequency}ms...")
        result = self.dll.BSSetModuleSamplingFrequency(
            self.device_index, 
            self.channel_index, 
            serial_number, 
            sampling_frequency
        )
        if result != 0:
            print(f"设置采样频率失败，错误码: {result}")
            return result
        
        print(f"设置采样频率成功")
        return 0
    
    def clear_buffer(self):
        """清空采集数据缓存
        
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        if not self.device_online:
            print("设备不在线")
            return -1
        
        print(f"正在清空缓存...")
        result = self.dll.BSClearBuffer(self.device_index, self.channel_index)
        if result != 0:
            print(f"清空缓存失败，错误码: {result}")
            return result
        
        print(f"清空缓存成功")
        return 0
    
    def read_buffer(self, array_size=1000):
        """读取采集数据
        
        Args:
            array_size (int): 要读取的数据条数
            
        Returns:
            tuple: (读取数据条数, 数据列表)
        """
        if not self.dll:
            print("DLL未加载")
            return -1, []
        
        if not self.device_online:
            print("设备不在线")
            return -1, []
        
        # 创建数据缓冲区
        data_array = (BSCollectData * array_size)()
        
        # 读取数据
        print(f"正在读取数据，最多 {array_size} 条...")
        read_count = self.dll.BSReadBuffer(
            self.device_index, 
            self.channel_index, 
            data_array, 
            array_size
        )
        
        if read_count < 0:
            print(f"读取数据失败，错误码: {read_count}")
            return read_count, []
        elif read_count == 0:
            print("没有新的数据可读取")
            return 0, []
        
        print(f"成功读取 {read_count} 条数据")
        
        # 将结构体转换为Python列表
        data_list = []
        for i in range(read_count):
            data = data_array[i]
            # 构造Python字典便于处理
            data_dict = {
                'CanID': data.CanID,
                'Time': data.Time.decode('utf-8').strip('\0'),  # 解码时间字符串并去除空字符
                'Data': [data.Data[j] for j in range(8)]  # 现在是有符号整数
            }
            data_list.append(data_dict)
        
        return read_count, data_list
    
    def start_save_file(self, file_path, max_size=5, max_files=10):
        """开始保存数据到文件
        
        Args:
            file_path (str): 文件路径
            max_size (int): 文件大小，单位M
            max_files (int): 文件个数
            
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        if not self.device_online:
            print("设备不在线")
            return -1
        
        print(f"正在开始保存数据到文件: {file_path}...")
        result = self.dll.BSStartSaveFile(
            self.device_index, 
            self.channel_index, 
            file_path.encode('utf-8'), 
            max_size, 
            max_files
        )
        if result != 0:
            print(f"开始保存文件失败，错误码: {result}")
            return result
        
        print(f"开始保存文件成功")
        return 0
    
    def stop_save_file(self):
        """停止保存数据到文件
        
        Returns:
            int: 0表示成功，其他表示错误码
        """
        if not self.dll:
            print("DLL未加载")
            return -1
        
        if not self.device_online:
            print("设备不在线")
            return -1
        
        print(f"正在停止保存文件...")
        result = self.dll.BSStopSaveFile(self.device_index, self.channel_index)
        if result != 0:
            print(f"停止保存文件失败，错误码: {result}")
            return result
        
        print(f"停止保存文件成功")
        return 0
