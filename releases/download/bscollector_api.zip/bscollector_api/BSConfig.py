﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# BSConfig.py - 测试配置脚本

import os
import configparser

def parse_int_value(value):
    """解析整数值，支持十六进制格式
    
    Args:
        value: 要解析的值
        
    Returns:
        int: 解析后的整数值
    """
    if isinstance(value, str):
        if value.lower().startswith('0x'):
            return int(value, 16)
    return int(value)

class BSConfig:
    """采集配置类"""
    
    def __init__(self):
        """初始化配置类"""
        self.device = {
            'device': 0,
            'channel': 0,
            'baudrate': 500000,
            'fdbaudrate': 2000000
        }
        
        self.modules = []
        
        self.collection = {
            'arraysize': 100,
            'save': False,
            'rootdir': './data/',  # 新增: 默认根目录
            'filesize': 5,
            'mapping': ''          # 新增: 默认映射字符串
        }
        
        # 日志配置
        self.log = {
            'enable': False,
            'level': 1,
            'path': 'bscollector.log',
            'maxsize': 5,
            'maxfiles': 10
        }
    
    def load_from_file(self, config_path):
        """从配置文件加载
        
        Args:
            config_path (str): 配置文件路径
            
        Returns:
            bool: 加载成功返回True，否则返回False
        """
        if not os.path.exists(config_path):
            print(f"配置文件不存在: {config_path}")
            return False
        
        try:
            config = configparser.ConfigParser()
            config.read(config_path, encoding='utf-8')
            
            # 设备配置
            if 'Device' in config:
                self.device = {
                    'device': config.getint('Device', 'device', fallback=0),
                    'channel': config.getint('Device', 'channel', fallback=0),
                    'baudrate': config.getint('Device', 'baudrate', fallback=500000),
                    'fdbaudrate': config.getint('Device', 'fdbaudrate', fallback=2000000)
                }
            
            # 模块配置
            self.modules = []
            for section in config.sections():
                if section.startswith('Module'):
                    serial_str = config.get(section, 'serial', fallback='0')
                    serial = parse_int_value(serial_str)
                    
                    module = {
                        'name': section,
                        'serial': serial,
                        'freq': config.getint(section, 'freq', fallback=1000)
                    }
                    self.modules.append(module)
            
            # 采集配置
            if 'Collection' in config:
                # 读取原始的多行mapping字符串
                raw_mapping = config.get('Collection', 'mapping', fallback='')
                # 清理并格式化mapping字符串，以确保其符合API要求
                mapping_lines = [line.strip() for line in raw_mapping.splitlines() if line.strip()]
                
                self.collection = {
                    'arraysize': config.getint('Collection', 'arraysize', fallback=100),
                    'save': config.getboolean('Collection', 'save', fallback=False),
                    'rootdir': config.get('Collection', 'rootdir', fallback='./data/'),
                    'filesize': config.getint('Collection', 'filesize', fallback=5),
                    'mapping': '\n'.join(mapping_lines) # 使用清理后的mapping
                }
            
            # 日志配置
            if 'Log' in config:
                self.log = {
                    'enable': config.getboolean('Log', 'enable', fallback=False),
                    'level': config.getint('Log', 'level', fallback=1),
                    'path': config.get('Log', 'path', fallback='bscollector.log'),
                    'maxsize': config.getint('Log', 'maxsize', fallback=5),
                    'maxfiles': config.getint('Log', 'maxfiles', fallback=10)
                }
            
            return True
        
        except Exception as e:
            print(f"加载配置文件失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def load_from_args(self, args):
        """从命令行参数加载
        
        Args:
            args: 命令行参数解析结果
            
        Returns:
            bool: 加载成功返回True，否则返回False
        """
        # (此函数保持不变，因为我们主要通过配置文件来设置新的保存参数)
        try:
            # 设备配置
            if hasattr(args, 'device') and args.device is not None:
                self.device['device'] = args.device
            
            if hasattr(args, 'channel') and args.channel is not None:
                self.device['channel'] = args.channel
            
            if hasattr(args, 'baudrate') and args.baudrate is not None:
                self.device['baudrate'] = args.baudrate
            
            if hasattr(args, 'fdbaudrate') and args.fdbaudrate is not None:
                self.device['fdbaudrate'] = args.fdbaudrate
            
            # 模块配置
            if hasattr(args, 'serial') and args.serial is not None:
                self.modules = [
                    {
                        'name': 'DefaultModule',
                        'serial': parse_int_value(args.serial),
                        'freq': args.freq or 1000
                    }
                ]
            
            # 采集配置
            if hasattr(args, 'arraysize') and args.arraysize is not None:
                self.collection['arraysize'] = args.arraysize
            
            if hasattr(args, 'save') and args.save:
                self.collection['save'] = True
            
            # 日志配置
            if hasattr(args, 'log_enable') and args.log_enable:
                self.log['enable'] = True
                
            if hasattr(args, 'log_level') and args.log_level is not None:
                self.log['level'] = args.log_level
                
            if hasattr(args, 'log_path') and args.log_path is not None:
                self.log['path'] = args.log_path
            
            return True
        
        except Exception as e:
            print(f"加载命令行参数失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def print_config(self):
        """打印配置信息"""
        print("\n配置信息:")
        print(f"设备索引: {self.device['device']}")
        print(f"通道索引: {self.device['channel']}")
        print(f"CAN波特率: {self.device['baudrate']}")
        print(f"CANFD波特率: {self.device['fdbaudrate']}")
        
        print("\n模块信息:")
        for module in self.modules:
            print(f"  {module['name']}:")
            print(f"    序列号: 0x{module['serial']:08X}")
            print(f"    采样频率: {module['freq']} ms")
        
        print("\n采集配置:")
        print(f"读取数据数组大小: {self.collection['arraysize']}")
        print(f"保存文件: {'是' if self.collection['save'] else '否'}")
        if self.collection['save']:
            print(f"保存根目录: {self.collection['rootdir']}")
            print(f"文件大小: {self.collection['filesize']} MB")
            print(f"ID映射关系:\n{self.collection['mapping']}")
            
        print("\n日志配置:")
        print(f"启用日志: {'是' if self.log['enable'] else '否'}")
        if self.log['enable']:
            log_levels = ['DEBUG', 'INFO', 'WARN', 'ERROR']
            level_str = log_levels[self.log['level']] if 0 <= self.log['level'] < len(log_levels) else str(self.log['level'])
            print(f"日志级别: {level_str} ({self.log['level']})")
            print(f"日志路径: {self.log['path']}")
            print(f"日志大小: {self.log['maxsize']} MB")
            print(f"日志文件数: {self.log['maxfiles']}")
