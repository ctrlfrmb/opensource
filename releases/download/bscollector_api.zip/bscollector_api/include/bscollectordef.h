﻿
#ifndef BSCOLLECTOR_DEF_H
#define BSCOLLECTOR_DEF_H

#define BSCOLLECTOR_TIME_STRING_SIZE                            32
#define BSCOLLECTOR_CHANNEL_SIZE                                8

#pragma pack(push, 4)

struct BSCollectData
{
    unsigned int        CanID;         /* CAN ID (11-bit standard or 29-bit extended) */
    char                Time[BSCOLLECTOR_TIME_STRING_SIZE];      /* YYYY-MM-DD HH:MM:SS.mmm */
    unsigned int        Rev;           /* Reserve */
    int                 Data[BSCOLLECTOR_CHANNEL_SIZE];       /* Data acquisition, 8 channels */
};

#pragma pack(pop)

#endif  //BS_COLLECTOR_DEF_H
