﻿/*----------------------------------------------------------------------------
* BSCollector API - 数据采集接口
*
* 提供用于CAN/CANFD设备数据采集的高性能接口，支持多设备、多通道并行采集，
* 并提供数据缓存、文件存储等功能。该API设计用于工业级数据采集应用，
* 确保高吞吐量和低延迟。
*
* 主要功能:
* - 支持多达16个设备(0x00-0x0F)的并行采集
* - 支持标准CAN和CANFD协议
* - 高精度时间戳记录
* - 多通道数据同步采集
* - 自动文件分割和管理
* - 可配置的采样频率
* - 终端电阻控制
* - 日志记录和错误诊断
*
* 使用流程:
* 1. 调用BSOpenDev打开设备
* 2. 调用BSInitCAN或BSInitCANFD初始化通道
* 3. 设置采样频率(BSSetModuleSamplingFrequency)
* 4. 可选：开始保存文件(BSStartSaveFile)
* 5. 循环调用BSReadBuffer读取数据
* 6. 完成后调用BSStopSaveFile停止保存
* 7. 调用BSResetCAN关闭通道
* 8. 调用BSCloseDev关闭设备
*
* 使用示例:
*   // 打开设备和通道
*   BSOpenDev(0, 0, 0);                    // 打开设备0
*   BSInitCAN(0, 0, 500000);               // 初始化CAN通道0，波特率500kbps
*
*   // 设置采样频率
*   BSSetModuleSamplingFrequency(0, 0, 0x12345678, 1000);  // 设置模块采样频率为1000Hz
*
*   // 读取数据
*   BSCollectData data[100];
*   int count = BSReadBuffer(0, 0, data, 100);  // 读取最多100条数据
*
*   // 关闭设备
*   BSCloseDev(0);                         // 关闭设备0
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2025 丰柯科技。保留所有权利。
*
* 本软件按许可协议提供。使用本软件即表示接受许可条款。
*
* 作者: leiwei
* 版本: v2.0.0
* 日期: 2025-08-27
*----------------------------------------------------------------------------*/

#ifndef BSCOLLECTOR_API_H
#define BSCOLLECTOR_API_H

#include "bscollectordef.h"

#ifdef _WIN32
    #ifdef BUILD_BSCOLLECTOR_API
        #define BSCOLLECTOR_API extern "C" __declspec(dllexport)
    #else
        #define BSCOLLECTOR_API extern "C" __declspec(dllimport)
    #endif
#else
    #define BSCOLLECTOR_API extern "C"
#endif

/**
 * @brief 打开日志，用于调试和故障诊断
 *
 * 建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源
 *
 * @param logFile 日志文件路径，形如:logs/bscollector.log
 * @param level 日志等级，-1:默认输出（默认1）0:DEBUG 1:INFO 2:WARN 3:ERROR
 * @param maxSize 文件大小, 范围(1~20), 单位M. -1:默认5M
 * @param maxFiles 文件个数, 范围(1~20), -1:默认保留10个文件
 * @return 0:打开成功 其它:失败错误码
 */
BSCOLLECTOR_API int ComOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志
 *
 * 安全关闭日志记录系统，释放相关资源
 *
 * @return 0:关闭成功 其它:失败错误码
 */
BSCOLLECTOR_API int ComCloseLog();

/**
 * @brief 打开设备
 *
 * 通过指定的设备索引连接到硬件设备，建立通信链路
 *
 * @param deviceType 设置类型（暂未启用）0:LAN 1:USB 2:COM
 * @param deviceIndex 设备索引:0x00~0x0F(对应ip:192.168.201.130~ip:192.168.201.145)
 * @param reserved 默认0，1~254表示绑定本地网卡(本地ip:192.168.reserved)
 * @return 0:打开成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSOpenDev(int deviceType, int deviceIndex, int reserved);

/**
 * @brief 关闭设备
 *
 * 安全地断开与硬件设备的连接，释放通信资源和采集资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F 特殊值-1:停止所有打开的设备
 * @return 0:关闭成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSCloseDev(int deviceIndex);

/**
 * @brief 初始化CAN通道（打开通道）
 *
 * 配置并打开指定的CAN通道，设置基本通信参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param baudRate 同步波特率
 * @return 0:初始化成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSInitCAN(int deviceIndex, int channelIndex, unsigned int baudRate);

/**
 * @brief 初始化CANFD通道（打开通道）
 *
 * 配置并打开指定的CANFD通道，设置基本通信参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param baudRate CAN波特率
 * @param fdBaudRate CANFD波特率
 * @return 0:初始化成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSInitCANFD(int deviceIndex, int channelIndex, unsigned int baudRate, unsigned int fdBaudRate);

/**
 * @brief 复位CAN通道（关闭通道）
 *
 * 停止指定CAN通道的所有活动并释放资源，包括采集任务
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:复位成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSResetCAN(int deviceIndex, int channelIndex);

/**
 * @brief 设置终端电阻使能状态
 *
 * 控制CAN通道的终端电阻是否启用
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param enable 1:使能 0:不使能
 * @return 0:设置成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSSetTerminalResistorCAN(int deviceIndex, int channelIndex, int enable);

/**
 * @brief 设置模块采样频率
 *
 * 为指定的数据采集模块设置采样频率
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param serialNumber 模块序列码
 * @param samplingFrequency 模块采样频率
 * @return 0:设置成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSSetModuleSamplingFrequency(int deviceIndex, int channelIndex, unsigned int serialNumber, int samplingFrequency);

/**
 * @brief 清空采集数据缓存
 *
 * 清除指定通道的数据采集缓冲区
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:清空成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSClearBuffer(int deviceIndex, int channelIndex);

/**
 * @brief 开始保存数据到文件
 *
 * 启动数据文件记录功能，必须在读取数据接口之前调用
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param filePath 保存文件路径，形如: current.csv
 * @param maxSize 文件大小, 范围(1~20), 单位M
 * @param maxFiles 文件个数, 范围(1~20)
 * @return 0:成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSStartSaveFile(int deviceIndex, int channelIndex, const char *filePath, int maxSize, int maxFiles);

/**
 * @brief 读取采集数据
 *
 * 从指定通道读取采集的数据
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param collectDatas 采集数据数组，每条数据对应8个通道数据
 * @param dataLen 采集数据数组长度
 * @return 大于0：读取的数据条数， 等于0: 没有新的数据可读取， 小于0：读取错误
 */
BSCOLLECTOR_API int BSReadBuffer(int deviceIndex, int channelIndex, BSCollectData* collectDatas, unsigned int dataLen);

/**
 * @brief 停止保存数据到文件
 *
 * 停止数据文件记录功能，关闭文件
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:成功 其它:失败错误码
 */
BSCOLLECTOR_API int BSStopSaveFile(int deviceIndex, int channelIndex);

#endif  //BSCOLLECTOR_API_H
