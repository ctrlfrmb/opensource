#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciLinTest.py - 交互式 LIN 控制台 (v1.0.4)

import sys
import signal
import time
import threading
import platform
import shlex
from ctypes import *
from FKVciApi import FKVciApi
from FKVciMessage import FkVciLinDataType, get_vci_status_description

def safe_parse_int(s, base=16):
    """将字符串安全地解析为整数"""
    if not isinstance(s, str): return None
    try:
        return int(s, base)
    except (ValueError, TypeError):
        return None

def hex_dump(data, length=None):
    """将字节数组转换为十六进制字符串"""
    if length is None:
        length = len(data)
    return " ".join(f"{data[i]:02X}" for i in range(length))

def get_full_timestamp(msg):
    """从消息结构体中获取完整的64位时间戳"""
    return (msg.TimesampH << 32) | msg.TimesampL

LIN_DIRECTION_MAP = {
    0x00: "Master Read",
    0x01: "Slave Read",
    0x10: "Master Write",
    0x11: "Slave Write",
}

def get_lin_direction_str(direction_id):
    """将LIN帧方向ID (REV1) 转换为可读字符串"""
    return LIN_DIRECTION_MAP.get(direction_id, f"RawDir({direction_id})")

class FKVciLinTest:
    def __init__(self):
        self.api = None
        self.running = True
        self.auto_recv_thread = None
        self.auto_recv_flag = False
        try:
            self.api = FKVciApi()
        except Exception as e:
            print(f"[致命错误] FKVCI 库初始化失败: {e}")

    def cleanup(self):
        print("\n[退出] 正在清理资源...")
        self.stop_auto_recv()
        time.sleep(0.1)
        if self.api:
            self.api.vci.FkVciCloseDev(-1)
            time.sleep(0.5)
            self.api.vci.FkVciCloseLog()
        print("[退出] 已关闭所有设备和日志")

    def parse_args(self, line):
        try:
            return shlex.split(line)
        except ValueError:
            print("[错误] 命令格式不正确")
            return []

    def extract_arg(self, args, key, default=None, cast_func=str):
        if key in args:
            idx = args.index(key)
            if idx + 1 < len(args):
                try:
                    return cast_func(args[idx + 1])
                except (ValueError, TypeError):
                    pass
        return default

    def run(self):
        print("=" * 60)
        print(f"FKVCI LIN 命令行测试工具 v1.0.4 ({platform.architecture()[0]})")
        print("=" * 60)
        
        if not self.api:
            print("\n[错误] 无法启动，因为 FKVCI 库加载失败。")
            return

        print("输入 --help 查看帮助，--exit 或 Ctrl+C 退出")
        while self.running:
            try:
                raw_input_str = input("LIN >>> ").strip()
                if not raw_input_str:
                    continue
                args = self.parse_args(raw_input_str)
                if not args:
                    continue
                cmd = args[0].lower()

                command_map = {
                    "--exit": lambda a: self.stop_running(),
                    "--help": self.print_help,
                    "--scan": self.do_scan,
                    "--open": self.do_open,
                    "--close": self.do_close,
                    "--log": self.do_log,
                    "--getlinchannels": self.do_get_lin_channels,
                    "--initlin": self.do_init_lin,
                    "--resetlin": self.do_reset_lin,
                    "--clearlin": self.do_clear_lin,
                    "--send": self.do_send,
                    "--recv": self.do_recv,
                    "--autorecv": self.do_auto_recv,
                    "--startschedule": self.do_start_schedule,
                    "--stopschedule": self.do_stop_schedule,
                    "--writeslave": self.do_write_slave,
                }
                
                if cmd in command_map:
                    command_map[cmd](args)
                else:
                    print("[未知命令] 输入 --help 查看支持的命令")

            except (EOFError, KeyboardInterrupt):
                self.stop_running()
                break
            except Exception as e:
                print(f"[异常] {e}")

        self.cleanup()

    def stop_running(self, *args):
        if self.running:
            self.running = False
            print("\n[程序] 正在退出...")

    def print_help(self, *args):
        print("\nLIN可用命令 (所有ID和数据均为16进制, dev/ch/baud等为10进制):")
        print("--- 通用控制 ---")
        print("  --log on|off")
        print("  --scan -timeout 500")
        print("  --open -dev 0")
        print("  --close -dev 0")
        print("  --getLinChannels -dev 0")
        print("--- LIN通道初始化 ---")
        print("  --initLIN -dev 0 -ch 0 -mode 0 -baud 19200 (mode 0:Master, 1:Slave)")
        print("  --resetLIN -dev 0 -ch 0")
        print("  --clearLIN -dev 0 -ch 0")
        print("--- 收发测试 ---")
        print("  --send -dev 0 -ch 0 -id 10 -type 1 -dlc 8 -data 11 22 (type 1:MW, 2:MR)")
        print("  --recv -dev 0 -ch 0 -count 10 -timeout 1000")
        print("  --autoRecv on|off -dev 0 -ch 0")
        print("--- 调度表 (主模式) ---")
        print("  --startSchedule -dev 0 -ch 0 -schedule \"id=10 type=1 dlc=2 data=11,22; id=15 type=2 dlc=4\"")
        print("  --stopSchedule -dev 0 -ch 0")
        print("--- 从机响应 (从模式) ---")
        print("  --writeSlave -dev 0 -ch 0 -id 10 -data 11 22")
        print("  --exit\n")

    def do_scan(self, args):
        timeout = self.extract_arg(args, "-timeout", 500, int)
        print(f"[scan] 正在扫描设备 (超时: {timeout}ms)...")
        max_devices = 16
        indices_array = (c_int * max_devices)()
        count = c_uint8(max_devices)
        ret = self.api.vci.FkVciScanDevice(indices_array, byref(count), timeout)
        if ret == 0:
            devices = [indices_array[i] for i in range(count.value)]
            if devices:
                print(f"[scan] 扫描成功，发现 {len(devices)} 个设备: {devices}")
            else:
                print("[scan] 扫描完成，未发现任何设备。")
        else:
            print(f"[scan] 扫描失败: {get_vci_status_description(ret)}")

    def do_open(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ret = self.api.vci.FkVciOpenDev(0, dev, 0)
        print(f"[open] 打开设备 {dev} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_close(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ret = self.api.vci.FkVciCloseDev(dev)
        print(f"[close] 关闭设备 {dev} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_log(self, args):
        if "on" in args:
            ret = self.api.vci.FkVciOpenLog("logs/fkvci_lin.log".encode('utf-8'), 0, 5, 10)
            print(f"[log] 开启日志返回: {ret}")
        else:
            self.api.vci.FkVciCloseLog()
            print("[log] 已关闭")

    def do_get_lin_channels(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        count = self.api.vci.FkVciGetLinChannelCount(dev)
        if count >= 0:
            print(f"[getLinChannels] 设备 {dev} 支持 {count} 个LIN通道。")
        else:
            print(f"[getLinChannels] 获取失败: {get_vci_status_description(count)}")

    def do_init_lin(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        mode = self.extract_arg(args, "-mode", 0, int)
        baud = self.extract_arg(args, "-baud", 19200, int)
        ret = self.api.vci.FkVciInitLIN(dev, ch, mode, baud)
        print(f"[initLIN] Dev{dev}-Ch{ch} Mode={mode} @ {baud}bps 返回: {ret} ({get_vci_status_description(ret)})")

    def do_reset_lin(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.api.vci.FkVciResetLIN(dev, ch)
        print(f"[resetLIN] Dev{dev}-Ch{ch} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_clear_lin(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.api.vci.FkVciClearLIN(dev, ch)
        print(f"[clearLIN] Dev{dev}-Ch{ch} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_send(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        lin_id_str = self.extract_arg(args, "-id", "10")
        lin_id = safe_parse_int(lin_id_str)
        if lin_id is None:
            print("[错误] 无效的ID。")
            return
        
        msg_type = self.extract_arg(args, "-type", 1, int)
        dlc = self.extract_arg(args, "-dlc", None, int)
        
        data = []
        if "-data" in args:
            start = args.index("-data") + 1
            for i in range(start, len(args)):
                if args[i].startswith("-"): break
                val = safe_parse_int(args[i])
                if val is not None: data.append(val)
        
        buf = FkVciLinDataType()
        buf.LinID = lin_id
        buf.MsgType = msg_type
        buf.CheckType = 1  # Enhanced

        if dlc is not None:
            buf.DLC = dlc
        else:
            buf.DLC = len(data)

        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        
        ret = self.api.vci.FkVciTransmitLIN(dev, ch, byref(buf), 1)
        print(f"[send] ID=0x{lin_id:X}, Type={msg_type}, DLC={buf.DLC}, Data={hex_dump(data)}, 返回: {ret} ({get_vci_status_description(ret)})")

    def do_recv(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        max_count = self.extract_arg(args, "-count", 10, int)
        timeout = self.extract_arg(args, "-timeout", 1000, int)
        
        buffer = (FkVciLinDataType * max_count)()
        count = c_uint32(max_count)
        ret = self.api.vci.FkVciReceiveLIN(dev, ch, buffer, byref(count), timeout)
        
        if ret == 0 and count.value > 0:
            print(f"[recv] 收到 {count.value} 条消息:")
            for i in range(count.value):
                msg = buffer[i]
                ts = get_full_timestamp(msg) / 10.0
                direction_str = get_lin_direction_str(msg.REV1)
                print(f"  [{i+1}] TS={ts:.1f}us, Dir={direction_str}, ID=0x{msg.LinID:X}, PID=0x{msg.PID:X}, DLC={msg.DLC}, Data={hex_dump(msg.Data, msg.DLC)}")
        else:
            print(f"[recv] 无数据或接收失败: {get_vci_status_description(ret)}")

    def do_auto_recv(self, args):
        if "on" in args:
            dev = self.extract_arg(args, "-dev", 0, int)
            ch = self.extract_arg(args, "-ch", 0, int)
            self.start_auto_recv(dev, ch)
        else:
            self.stop_auto_recv()

    def start_auto_recv(self, dev, ch):
        if self.auto_recv_thread and self.auto_recv_thread.is_alive():
            print("[autoRecv] 自动接收已在运行")
            return
        
        self.auto_recv_flag = True
        
        def worker():
            MAX_RECV_COUNT = 100
            buffer_type = FkVciLinDataType * MAX_RECV_COUNT
            buffer = buffer_type()
            
            while self.auto_recv_flag:
                count = c_uint32(MAX_RECV_COUNT)
                ret = self.api.vci.FkVciReceiveLIN(dev, ch, buffer, byref(count), 0)
                
                if ret == 0 and count.value > 0:
                    sys.stdout.write("\r\033[K")
                    for i in range(count.value):
                        msg = buffer[i]
                        ts = get_full_timestamp(msg) / 10.0
                        direction_str = get_lin_direction_str(msg.REV1)
                        print(f"[AutoRecv] TS={ts:.1f}us, Dir={direction_str}, ID=0x{msg.LinID:X}, PID=0x{msg.PID:X}, DLC={msg.DLC}, Data={hex_dump(msg.Data, msg.DLC)}")
                    
                    sys.stdout.write("LIN >>> ")
                    sys.stdout.flush()
                
                time.sleep(0.05)

        self.auto_recv_thread = threading.Thread(target=worker, daemon=True)
        self.auto_recv_thread.start()
        print(f"[autoRecv] 启动 Dev{dev}-Ch{ch} 自动接收")

    def stop_auto_recv(self):
        if self.auto_recv_thread:
            self.auto_recv_flag = False
            self.auto_recv_thread.join(timeout=1.0)
            self.auto_recv_thread = None
            print("\n[autoRecv] 停止")

    def do_start_schedule(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        schedule_str = self.extract_arg(args, "-schedule", "")
        if not schedule_str:
            print("[错误] -schedule 参数不能为空。示例: \"id=10 type=1 dlc=2 data=11,22; id=15 type=2 dlc=4\"")
            return

        try:
            entries = schedule_str.split(';')
            messages = []
            for entry in entries:
                if not entry.strip(): continue
                msg = FkVciLinDataType()
                msg.MsgType = 1
                msg.CheckType = 1  # Enhanced
                
                parts = entry.strip().split()
                for part in parts:
                    key, value = part.split('=', 1)
                    key = key.strip().lower()
                    value = value.strip()
                    if key == 'id':
                        msg.LinID = int(value, 16)
                    elif key == 'dlc':
                        msg.DLC = int(value)
                    elif key == 'type':
                        msg.MsgType = int(value)
                    elif key == 'data':
                        data_bytes = [int(b, 16) for b in value.split(',')]
                        msg.Data[:len(data_bytes)] = (c_uint8 * len(data_bytes))(*data_bytes)
                
                messages.append(msg)

            if not messages:
                print("[错误] 未能从 schedule 字符串中解析出任何有效的条目。")
                return

            msg_array = (FkVciLinDataType * len(messages))(*messages)
            ret = self.api.vci.FkVciStartScheduleLIN(dev, ch, msg_array, len(messages))
            print(f"[startSchedule] 返回: {ret} ({get_vci_status_description(ret)})")

        except Exception as e:
            print(f"[错误] 解析 schedule 字符串失败: {e}")

    def do_stop_schedule(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.api.vci.FkVciStopScheduleLIN(dev, ch)
        print(f"[stopSchedule] 返回: {ret} ({get_vci_status_description(ret)})")

    def do_write_slave(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        lin_id_str = self.extract_arg(args, "-id", "10")
        lin_id = safe_parse_int(lin_id_str)
        if lin_id is None:
            print("[错误] 无效的ID。")
            return
        data = []
        if "-data" in args:
            start = args.index("-data") + 1
            for i in range(start, len(args)):
                if args[i].startswith("-"): break
                val = safe_parse_int(args[i])
                if val is not None: data.append(val)
        
        buf = FkVciLinDataType()
        buf.LinID = lin_id
        buf.DLC = len(data)
        buf.MsgType = 3  # Slave Write
        buf.CheckType = 1  # Enhanced
        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        
        ret = self.api.vci.FkVciWriteSlaveLIN(dev, ch, byref(buf))
        print(f"[writeSlave] ID=0x{lin_id:X}, Data={hex_dump(data)}, 返回: {ret} ({get_vci_status_description(ret)})")

if __name__ == "__main__":
    shell = FKVciLinTest()
    def signal_handler(sig, frame):
        shell.stop_running()
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    shell.run()
