#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKUdsClientTest.py - 独立的、交互式的 UDS 诊断控制台

import sys
import signal
import platform
import shlex
from FKUdsClient import FKUdsClient
from FKVciMessage import get_status_description # 用于CAN/Device接口的非UDS错误码
from FKUdsMessage import hex_dump

def safe_parse_int(s, base=16):
    """将字符串安全地解析为整数，可指定进制"""
    if not isinstance(s, str): return None
    try:
        return int(s, base)
    except (ValueError, TypeError):
        return None

class FKUdsClientTest:
    def __init__(self):
        self.client = FKUdsClient()
        self.running = True
        self.uds_instances = {} # 存储 uds_id -> (dev, ch)
        self.open_devices = set() # 跟踪已打开的设备索引

    def cleanup(self):
        if not self.client.vci:
            print("[退出] 库未加载，无需清理。")
            return

        print("\n[清理] 正在销毁所有UDS服务实例...")
        for uds_id, (dev, ch) in list(self.uds_instances.items()):
            print(f"  - 销毁 UDS ID: {uds_id}")
            self.client.destroy_uds_service(uds_id)
            print(f"  - 重置 CAN 通道: Dev={dev}, Ch={ch}")
            self.client.reset_can(dev, ch)
        
        self.uds_instances.clear()
        
        print("[清理] 正在关闭所有已打开的VCI设备...")
        for dev_index in list(self.open_devices):
            print(f"  - 关闭设备: {dev_index}")
            self.client.close_device(dev_index)
        self.open_devices.clear()

        self.client.close_log()
        print("[退出] 已关闭日志。")

    def parse_args(self, line):
        try:
            return shlex.split(line)
        except ValueError:
            print("[错误] 命令格式不正确，可能引号未闭合。")
            return []

    def extract_arg(self, args, key, default=None, cast_func=str):
        try:
            if key in args:
                idx = args.index(key)
                if idx + 1 < len(args):
                    return cast_func(args[idx + 1])
        except (ValueError, IndexError):
            pass
        return default

    def run(self):
        arch_str = platform.architecture()[0]
        print("=" * 60)
        print(f"FKVCI UDS 诊断命令行工具 v4.1.1 ({arch_str})")
        print("=" * 60)
        
        if not self.client.vci:
            print("\n[错误] 无法启动，因为 FKVCI 库加载失败。")
            print("请检查：")
            print("  1. `lib` 目录下是否存在对应架构的 DLL/SO 文件。")
            print(f"  2. Python架构 ({arch_str}) 与库文件架构是否匹配。")
            return

        print("输入 --help 查看帮助，--exit 或 Ctrl+C 退出")

        while self.running:
            try:
                raw = input("UDS >>> ").strip()
                if not raw: continue
                
                args = self.parse_args(raw)
                if not args: continue
                
                cmd = args[0].lower()

                if cmd == "--exit":
                    break
                elif cmd == "--help":
                    self.print_help()
                elif cmd == "--log":
                    self.do_log(args)
                elif cmd == "--open":
                    self.do_open_device(args)
                elif cmd == "--close":
                    self.do_close_device(args)
                elif cmd == "--initcan":
                    self.do_initcan(args)
                elif cmd == "--initcanfd": # [新增]
                    self.do_initcanfd(args)
                elif cmd == "--resetcan":
                    self.do_resetcan(args)
                elif cmd == "--create":
                    self.do_create_service(args)
                elif cmd == "--destroy":
                    self.do_destroy_service(args)
                elif cmd == "--list":
                    self.do_list_services()
                elif cmd == "--config":
                    self.do_set_config(args)
                elif cmd == "--req":
                    self.do_request_sync(args)
                elif cmd == "--areq":
                    self.do_request_async(args)
                elif cmd == "--read":
                    self.do_read_response(args)
                elif cmd == "--clearq":
                    self.do_clear_queues(args)
                else:
                    print(f"[未知命令] '{cmd}'。输入 --help 查看支持的命令。")

            except (KeyboardInterrupt, EOFError):
                break
            except Exception as e:
                print(f"[运行时异常] {e}")

        self.cleanup()

    def print_help(self):
        # [优化] 提供了可直接复制的示例命令
        print("\nUDS诊断可用命令 (所有ID和数据均为16进制, dev/ch/baud等为10进制):")
        print("--- 通用控制 ---")
        print("  --log on")
        print("  --open -dev 0")
        print("  --close -dev 0")
        print("--- 准备工作 ---")
        print("  --initcan -dev 0 -ch 0 -baud 500000")
        print("  --initcanfd -dev 0 -ch 0 -baud 500000 -fd 2000000")
        print("--- UDS服务管理 ---")
        print("  --create -dev 0 -ch 0 -reqid 7E0 -resid 7E8")
        print("  --destroy -id 1")
        print("  --list")
        print("  --config -id 1 -params \"--stMin 0A --blockSize 08\"")
        print("--- UDS诊断通信 ---")
        print("  --req -id 1 -data 22 F1 90")
        print("  --areq -id 1 -data 3E 00")
        print("  --read -id 1 -timeout 2000")
        print("  --clearq -id 1")
        print("--- 清理工作 ---")
        print("  --resetcan -dev 0 -ch 0")
        print("  --exit\n")

    def do_log(self, args):
        if "on" in args:
            ret = self.client.open_log()
            print(f"[log] 开启日志: {get_status_description(ret)}")
        elif "off" in args:
            ret = self.client.close_log()
            print(f"[log] 关闭日志: {get_status_description(ret)}")
        else:
            print("用法: --log on|off")

    def do_open_device(self, args):
        dev_type = self.extract_arg(args, '-type', 0, int)
        dev_index = self.extract_arg(args, '-dev', None, int)
        res = self.extract_arg(args, '-res', 0, int)
        if dev_index is None:
            print("[错误] 请提供设备索引: -dev <索引>")
            return
        ret = self.client.open_device(dev_type, dev_index, res)
        print(f"[open] 打开设备 {dev_index}: {ret} ({get_status_description(ret)})")
        if ret == 0:
            self.open_devices.add(dev_index)
    
    def do_close_device(self, args):
        dev_index = self.extract_arg(args, '-dev', None, int)
        if dev_index is None:
            print("[错误] 请提供设备索引: -dev <索引>")
            return
        ret = self.client.close_device(dev_index)
        print(f"[close] 关闭设备 {dev_index}: {ret} ({get_status_description(ret)})")
        if ret == 0:
            self.open_devices.discard(dev_index)

    def do_initcan(self, args):
        d = self.extract_arg(args, '-dev', 0, int)
        ch = self.extract_arg(args, '-ch', 0, int)
        baud = self.extract_arg(args, '-baud', 500000, int)
        ret = self.client.init_can(d, ch, baud)
        print(f"[initCAN] 返回: {ret} ({get_status_description(ret)})")

    # [新增] CANFD 初始化处理函数
    def do_initcanfd(self, args):
        d = self.extract_arg(args, '-dev', 0, int)
        ch = self.extract_arg(args, '-ch', 0, int)
        baud = self.extract_arg(args, '-baud', 500000, int)
        fd_baud = self.extract_arg(args, '-fd', 2000000, int)
        ret = self.client.init_canfd(d, ch, baud, fd_baud)
        print(f"[initCANFD] 返回: {ret} ({get_status_description(ret)})")

    def do_resetcan(self, args):
        d = self.extract_arg(args, '-dev', 0, int)
        ch = self.extract_arg(args, '-ch', 0, int)
        ret = self.client.reset_can(d, ch)
        print(f"[resetCAN] 返回: {ret} ({get_status_description(ret)})")

    def do_create_service(self, args):
        dev = self.extract_arg(args, '-dev', 0, int)
        ch = self.extract_arg(args, '-ch', 0, int)
        req_id = self.extract_arg(args, '-reqid', "7E0", lambda x: safe_parse_int(x, 16))
        res_id = self.extract_arg(args, '-resid', "7E8", lambda x: safe_parse_int(x, 16))
        if req_id is None or res_id is None:
            print("[错误] 无效的请求/响应ID，请输入16进制值。")
            return
        result = self.client.create_uds_service(dev, ch, req_id, res_id)
        if isinstance(result, int) and result > 0:
            self.uds_instances[result] = (dev, ch)
            print(f"[create] 成功，为 Dev/Chn {dev}/{ch} 创建/复用 UDS实例，ID = {result}")
        else:
            print(f"[create] 失败: {self.client.get_uds_error_string(result)}")

    def do_destroy_service(self, args):
        uds_id = self.extract_arg(args, "-id", None, int)
        if uds_id is None:
            print("[错误] 请提供 -id 参数 (10进制)。")
            return
        ret = self.client.destroy_uds_service(uds_id)
        if ret == 0:
            if uds_id in self.uds_instances: del self.uds_instances[uds_id]
            print(f"[destroy] 成功销毁 UDS实例 {uds_id}")
        else:
            print(f"[destroy] 失败: {self.client.get_uds_error_string(ret)}")

    def do_list_services(self):
        if not self.uds_instances:
            print("[list] 当前没有活动的UDS实例。")
            return
        print("[list] 活动的UDS实例:")
        for uds_id, (dev, ch) in self.uds_instances.items():
            print(f"  - ID: {uds_id}, 绑定于: 设备 {dev}, 通道 {ch}")

    def do_set_config(self, args):
        uds_id = self.extract_arg(args, "-id", None, int)
        params = self.extract_arg(args, "-params", None, str)
        if uds_id is None or params is None:
            print("[错误] 请提供 -id 和 -params 参数。")
            return
        ret = self.client.set_uds_config(uds_id, params)
        print(f"[config] 设置实例 {uds_id} 的配置: {self.client.get_uds_error_string(ret)}")

    def do_request_sync(self, args):
        uds_id = self.extract_arg(args, "-id", None, int)
        if uds_id is None: print("[错误] 请提供 -id 参数。"); return
        
        try:
            data_idx = args.index("-data")
            data_hex = args[data_idx+1:]
            data = [safe_parse_int(d, 16) for d in data_hex if safe_parse_int(d, 16) is not None]
        except (ValueError, IndexError):
            data = []

        if not data: print("[错误] 请提供有效的 -data 参数 (16进制)。"); return
        
        print(f"[req] 发送同步请求到实例 {uds_id}: {hex_dump(data)}")
        ret, response = self.client.uds_request_sync(uds_id, data)
        print(f"[req] -> 返回码: {ret} ({self.client.get_uds_error_string(ret)})")
        if response: print(f"[req] -> 响应 ({len(response)}字节): {hex_dump(response)}")

    def do_request_async(self, args):
        uds_id = self.extract_arg(args, "-id", None, int)
        if uds_id is None: print("[错误] 请提供 -id 参数。"); return

        try:
            data_idx = args.index("-data")
            data_hex = args[data_idx+1:]
            data = [safe_parse_int(d, 16) for d in data_hex if safe_parse_int(d, 16) is not None]
        except (ValueError, IndexError):
            data = []

        if not data: print("[错误] 请提供有效的 -data 参数 (16进制)。"); return
        
        ret = self.client.uds_request_async(uds_id, data)
        print(f"[areq] 异步请求已入队: {self.client.get_uds_error_string(ret)}")

    def do_read_response(self, args):
        uds_id = self.extract_arg(args, "-id", None, int)
        timeout = self.extract_arg(args, "-timeout", 2000, int)
        if uds_id is None: print("[错误] 请提供 -id 参数。"); return
        
        print(f"[read] 等待实例 {uds_id} 的异步响应 (超时: {timeout}ms)...")
        ret, response = self.client.uds_read_response(uds_id, timeout_ms=timeout)
        print(f"[read] -> 返回码: {ret} ({self.client.get_uds_error_string(ret)})")
        if response: print(f"[read] -> 响应 ({len(response)}字节): {hex_dump(response)}")

    def do_clear_queues(self, args):
        uds_id = self.extract_arg(args, "-id", None, int)
        if uds_id is None: print("[错误] 请提供 -id 参数。"); return
        ret = self.client.uds_clear_async_queues(uds_id)
        print(f"[clearq] 清空实例 {uds_id} 的异步队列: {self.client.get_uds_error_string(ret)}")

if __name__ == "__main__":
    shell = FKUdsClientTest()
    
    def signal_handler(sig, frame):
        print("\n[信号] 收到退出信号，正在清理...")
        shell.running = False
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    shell.run()
