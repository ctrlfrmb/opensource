#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKUdsMessage.py - 对齐 uds/vci_uds_def.h (Pythonic 版本)
# 定义UDS相关结构和错误码。

from ctypes import *

# --- C Macro Definitions ---
VCI_UDS_ERROR_BASE = -15765
VCI_UDS_WARNING_BASE = 15765
VCI_UDS_MAX_PAYLOAD_SIZE = 4095

# --- C Structure Definitions (直接使用 ctypes 类型) ---

class VciUdsFunctionalResponseData(Structure):
    _pack_ = 4
    _fields_ = [
        ("source_address", c_uint),
        ("data_len", c_uint),
        ("data", c_uint8 * VCI_UDS_MAX_PAYLOAD_SIZE),
        ("reserve", c_uint8),
    ]

# --- Error Code Definitions ---
uds_error_code_map = {
    0: "操作成功 (VCI_UDS_RESULT_OK)",
    VCI_UDS_WARNING_BASE + 304: "警告: 响应缓冲区太小 (VCI_UDS_RESULT_BUFFER_TOO_SMALL)",
    VCI_UDS_ERROR_BASE - 101: "错误: ECU返回否定响应 (VCI_UDS_RESULT_NEGATIVE_RESPONSE)",
    VCI_UDS_ERROR_BASE - 201: "错误: 等待首帧/单帧超时 (VCI_UDS_RESULT_TIMEOUT_A)",
    VCI_UDS_ERROR_BASE - 202: "错误: 等待流控帧超时 (VCI_UDS_RESULT_TIMEOUT_BS)",
    VCI_UDS_ERROR_BASE - 203: "错误: 等待连续帧超时 (VCI_UDS_RESULT_TIMEOUT_CR)",
    VCI_UDS_ERROR_BASE - 204: "错误: 等待NRC 0x78后的最终响应超时 (VCI_UDS_RESULT_TIMEOUT_P2_STAR)",
    VCI_UDS_ERROR_BASE - 205: "错误: ECU报告流控溢出 (VCI_UDS_RESULT_FC_OVERFLOW)",
    VCI_UDS_ERROR_BASE - 206: "错误: 连续帧序列号错误 (VCI_UDS_RESULT_SEQUENCE_ERROR)",
    VCI_UDS_ERROR_BASE - 207: "错误: 收到非预期的TP帧 (VCI_UDS_RESULT_UNEXPECTED_FRAME)",
    VCI_UDS_ERROR_BASE - 208: "错误: 超出NRC 0x78最大允许次数 (VCI_UDS_RESULT_NRC78_LIMIT_EXCEEDED)",
    VCI_UDS_ERROR_BASE - 301: "错误: CAN帧发送失败 (VCI_UDS_RESULT_SEND_FAILED)",
    VCI_UDS_ERROR_BASE - 302: "错误: 请求负载对于ISO-TP过大 (VCI_UDS_RESULT_PAYLOAD_TOO_LARGE)",
    VCI_UDS_ERROR_BASE - 303: "错误: 函数参数无效 (VCI_UDS_RESULT_INVALID_PARAM)",
    VCI_UDS_ERROR_BASE - 305: "错误: UDS实例ID无效或不存在 (VCI_UDS_RESULT_INVALID_UDS_ID)",
    VCI_UDS_ERROR_BASE - 306: "错误: UDS配置解析或应用失败 (VCI_UDS_RESULT_CONFIG_FAILED)",
    VCI_UDS_ERROR_BASE - 307: "错误: UDS实例数量已达上限 (VCI_UDS_RESULT_INSTANCE_LIMIT_EXCEEDED)",
    VCI_UDS_ERROR_BASE - 308: "错误: 操作被用户中止 (VCI_UDS_RESULT_ABORTED)",
    VCI_UDS_ERROR_BASE - 401: "错误: 异步队列中无响应 (VCI_UDS_RESULT_NO_RESPONSE_IN_QUEUE)",
    VCI_UDS_ERROR_BASE - 402: "错误: 异步请求队列已满 (VCI_UDS_RESULT_QUEUE_FULL)",
    VCI_UDS_ERROR_BASE - 501: "错误: 库内部发生错误 (VCI_UDS_RESULT_INTERNAL_ERROR)",
    VCI_UDS_ERROR_BASE - 502: "错误: 设备未打开 (VCI_UDS_RESULT_DEVICE_NOT_OPEN)",
    VCI_UDS_ERROR_BASE - 601: "错误: 安全算法配置缺失 (VCI_UDS_RESULT_SECURITY_CONFIG_MISSING)",
    VCI_UDS_ERROR_BASE - 602: "错误: 安全算法DLL加载失败 (VCI_UDS_RESULT_SECURITY_DLL_LOAD_FAILED)",
    VCI_UDS_ERROR_BASE - 603: "错误: 安全算法函数未找到 (VCI_UDS_RESULT_SECURITY_FUNC_NOT_FOUND)",
    VCI_UDS_ERROR_BASE - 604: "错误: 安全算法执行失败 (VCI_UDS_RESULT_SECURITY_ALGO_FAILED)",
    VCI_UDS_ERROR_BASE - 605: "错误: 无效的Seed响应 (VCI_UDS_RESULT_SECURITY_INVALID_SEED)",
    VCI_UDS_ERROR_BASE - 701: "错误: 日志记录失败 (VCI_UDS_RESULT_LOGGING_FAILED)",
}

def get_uds_status_description(code):
    """根据UDS错误码获取描述信息"""
    return uds_error_code_map.get(code, f"未知UDS错误码 ({code})")

def hex_dump(data):
    """将字节或整数列表转换为十六进制字符串"""
    if not data:
        return ""
    return " ".join(f"{b:02X}" for b in data)
