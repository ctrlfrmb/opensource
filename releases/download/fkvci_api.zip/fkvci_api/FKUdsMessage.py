#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKUdsMessage.py - UDS 错误码映射

# 与 vci_uds_def.h 完全同步
uds_error_code_map = {
    # --- Success ---
    0: "操作成功 (VCI_UDS_RESULT_OK)",

    # --- Warnings (Positive Values) ---
    304: "警告: 响应缓冲区太小，数据被截断 (VCI_UDS_RESULT_BUFFER_TOO_SMALL)",

    # --- Errors (Negative Values) ---
    # Application Layer
    -101: "错误: ECU返回否定响应 (NRC) (VCI_UDS_RESULT_NEGATIVE_RESPONSE)",

    # Transport Layer
    -201: "错误: 等待首帧/单帧超时 (N_As/P2) (VCI_UDS_RESULT_TIMEOUT_A)",
    -202: "错误: 等待流控帧超时 (N_Bs) (VCI_UDS_RESULT_TIMEOUT_BS)",
    -203: "错误: 等待连续帧超时 (N_Cr) (VCI_UDS_RESULT_TIMEOUT_CR)",
    -204: "错误: 等待NRC 0x78后的最终响应超时 (N_Ar/P2*) (VCI_UDS_RESULT_TIMEOUT_P2_STAR)",
    -205: "错误: ECU报告流控溢出 (VCI_UDS_RESULT_FC_OVERFLOW)",
    -206: "错误: 连续帧序列号错误 (VCI_UDS_RESULT_SEQUENCE_ERROR)",
    -207: "错误: 收到非预期的TP帧 (VCI_UDS_RESULT_UNEXPECTED_FRAME)",
    -208: "错误: 超出NRC 0x78最大允许次数 (VCI_UDS_RESULT_NRC78_LIMIT_EXCEEDED)",

    # Communication & Pre-check
    -301: "错误: CAN帧发送失败 (VCI_UDS_RESULT_SEND_FAILED)",
    -302: "错误: 请求负载对于ISO-TP过大 (VCI_UDS_RESULT_PAYLOAD_TOO_LARGE)",
    -303: "错误: 函数参数无效 (VCI_UDS_RESULT_INVALID_PARAM)",
    -305: "错误: UDS实例ID无效或不存在 (VCI_UDS_RESULT_INVALID_UDS_ID)",
    -306: "错误: UDS配置解析或应用失败 (VCI_UDS_RESULT_CONFIG_FAILED)",
    -307: "错误: UDS实例数量已达上限 (VCI_UDS_RESULT_INSTANCE_LIMIT_EXCEEDED)",

    # Async API
    -401: "错误: 异步队列中无响应 (VCI_UDS_RESULT_NO_RESPONSE_IN_QUEUE)",
    -402: "错误: 异步请求队列已满 (VCI_UDS_RESULT_QUEUE_FULL)",

    # Internal
    -501: "错误: 库内部发生错误 (VCI_UDS_RESULT_INTERNAL_ERROR)",
}

def get_uds_status_description(code):
    """根据UDS错误码获取描述信息"""
    # 也可以直接调用C库的翻译函数
    # return client.get_uds_error_string(code)
    return uds_error_code_map.get(code, f"未知UDS错误码 ({code})")

def hex_dump(data):
    """将字节数据转换为十六进制字符串"""
    if not data:
        return ""
    return " ".join(f"{b:02X}" for b in data)
