#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciClient.py - 封装 FKVCI 接口调用，提供简洁的 CAN + LIN 操作接口

import os
import platform
import ctypes
from ctypes import *
from FKVciMessage import FkVciCanDataType, FkVciLinDataType, FkVciCanFdConfig, get_status_description, hex_dump

class FKVciClient:
    def __init__(self):
        self.vci = None
        self.load_dll()

    def load_dll(self):
        arch = platform.architecture()[0]
        # 根据系统和架构确定库文件路径
        if platform.system() == "Windows":
            lib_dir = os.path.abspath("./lib/Winx64" if arch == "64bit" else "./lib/Winx86")
            dll_name = "fkvci.dll"
            # 在Windows上，将库目录添加到PATH中，以便加载依赖项
            os.environ['PATH'] = lib_dir + os.pathsep + os.environ.get('PATH', '')
            self.vci = ctypes.CDLL(os.path.join(lib_dir, dll_name))
        else: # Linux or other
            lib_dir = os.path.abspath("./lib/Linux") # 假设Linux库在./lib/Linux
            dll_name = "libfkvci.so"
            self.vci = ctypes.CDLL(os.path.join(lib_dir, dll_name))

        # --- argtypes 定义 ---
        self.vci.FkVciOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
        self.vci.FkVciOpenLog.restype = c_int
        self.vci.FkVciCloseLog.argtypes = []
        self.vci.FkVciCloseLog.restype = c_int

        self.vci.FkVciOpenDev.argtypes = [c_int, c_int, c_int]
        self.vci.FkVciOpenDev.restype = c_int
        self.vci.FkVciCloseDev.argtypes = [c_int]
        self.vci.FkVciCloseDev.restype = c_int

        self.vci.FkVciScanDevice.argtypes = [POINTER(c_int), POINTER(c_uint8), c_uint32]
        self.vci.FkVciScanDevice.restype = c_int
        self.vci.FkVciGetCanChannelCount.argtypes = [c_int]
        self.vci.FkVciGetCanChannelCount.restype = c_int
        self.vci.FkVciGetLinChannelCount.argtypes = [c_int]
        self.vci.FkVciGetLinChannelCount.restype = c_int

        self.vci.FkVciInitCAN.argtypes = [c_int, c_int, c_uint]
        self.vci.FkVciInitCAN.restype = c_int
        self.vci.FkVciInitCANFD.argtypes = [c_int, c_int, c_uint, c_uint]
        self.vci.FkVciInitCANFD.restype = c_int
        
        self.vci.FkVciInitCANFDAdvanced.argtypes = [c_int, c_int, POINTER(FkVciCanFdConfig)]
        self.vci.FkVciInitCANFDAdvanced.restype = c_int

        self.vci.FkVciTransmitCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), c_uint]
        self.vci.FkVciTransmitCAN.restype = c_int

        self.vci.FkVciReceiveCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), POINTER(c_uint32), c_uint32]
        self.vci.FkVciReceiveCAN.restype = c_int

        self.vci.FkVciStartPeriodCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), c_uint]
        self.vci.FkVciStartPeriodCAN.restype = c_int
        self.vci.FkVciStopPeriodCAN.argtypes = [c_int, c_int, c_int]
        self.vci.FkVciStopPeriodCAN.restype = c_int

        self.vci.FkVciSetTerminalResistorCAN.argtypes = [c_int, c_int, c_int]
        self.vci.FkVciSetTerminalResistorCAN.restype = c_int
        self.vci.FkVciGetBusLoadCAN.argtypes = [c_int, POINTER(c_double), c_int]
        self.vci.FkVciGetBusLoadCAN.restype = c_int

        self.vci.FkVciGetVersion.argtypes = [c_int]
        self.vci.FkVciGetVersion.restype = c_uint32
        self.vci.FkVciGetBaseTime.argtypes = [c_int]
        self.vci.FkVciGetBaseTime.restype = c_uint64

        self.vci.FkVciResetCAN.argtypes = [c_int, c_int]
        self.vci.FkVciResetCAN.restype = c_int
        self.vci.FkVciClearCAN.argtypes = [c_int, c_int]
        self.vci.FkVciClearCAN.restype = c_int

        # LIN 接口
        self.vci.FkVciInitLIN.argtypes = [c_int, c_int, c_uint, c_uint]
        self.vci.FkVciInitLIN.restype = c_int
        self.vci.FkVciResetLIN.argtypes = [c_int, c_int]
        self.vci.FkVciResetLIN.restype = c_int
        self.vci.FkVciTransmitLIN.argtypes = [c_int, c_int, POINTER(FkVciLinDataType), c_uint]
        self.vci.FkVciTransmitLIN.restype = c_int
        
        self.vci.FkVciReceiveLIN.argtypes = [c_int, c_int, POINTER(FkVciLinDataType), POINTER(c_uint32), c_uint32]
        self.vci.FkVciReceiveLIN.restype = c_int

    def scan_devices(self, max_devices=16, timeout_ms=500):
        indices_array = (c_int * max_devices)()
        count = c_uint8(max_devices)
        ret = self.vci.FkVciScanDevice(indices_array, byref(count), timeout_ms)
        if ret == 0:
            return [indices_array[i] for i in range(count.value)]
        return None

    def get_can_channel_count(self, dev_index):
        return self.vci.FkVciGetCanChannelCount(dev_index)

    def get_lin_channel_count(self, dev_index):
        return self.vci.FkVciGetLinChannelCount(dev_index)

    def open_log(self, path="logs/fkvci.log", level=1, max_size=5, max_files=10):
        return self.vci.FkVciOpenLog(path.encode('utf-8'), level, max_size, max_files)

    def close_log(self):
        return self.vci.FkVciCloseLog()

    def open_device(self, dev_type=0, dev_index=0, reserved=0):
        return self.vci.FkVciOpenDev(dev_type, dev_index, reserved)

    def close_device(self, dev_index=0):
        return self.vci.FkVciCloseDev(dev_index)

    def get_version(self, dev):
        raw = self.vci.FkVciGetVersion(dev)
        if raw == 0: return "查询失败"
        v = (raw >> 24) & 0xFF
        y = ((raw >> 16) & 0xFF) + 2000
        m = (raw >> 8) & 0xFF
        d = raw & 0xFF
        return f"v{v}.{y:04d}.{m:02d}.{d:02d}"

    def get_base_time(self, dev):
        return self.vci.FkVciGetBaseTime(dev)

    def init_can(self, dev, ch, baud):
        return self.vci.FkVciInitCAN(dev, ch, baud)

    def init_canfd(self, dev, ch, baud, fd_baud):
        return self.vci.FkVciInitCANFD(dev, ch, baud, fd_baud)
    
    def init_canfd_advanced(self, dev, ch, baud=500000, fd_baud=2000000, 
                           n_seg1=0x1F, n_seg2=0x08, d_seg1=0x0F, d_seg2=0x04, 
                           term_resistor=1):
        config = FkVciCanFdConfig(baud, fd_baud, n_seg1, n_seg2, d_seg1, d_seg2, term_resistor)
        return self.vci.FkVciInitCANFDAdvanced(dev, ch, byref(config))

    def send_can(self, dev, ch, can_id, data, flag = 0):
        buf = FkVciCanDataType()
        buf.CanID = can_id
        buf.FLAG = flag
        buf.DLC = len(data)
        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        return self.vci.FkVciTransmitCAN(dev, ch, byref(buf), 1)

    def recv_can_bulk(self, dev, ch, max_count=100, timeout_ms=500):
        buffer_type = FkVciCanDataType * max_count
        buffer = buffer_type()
        actual_count = c_uint32(max_count)
        ret = self.vci.FkVciReceiveCAN(dev, ch, buffer, byref(actual_count), timeout_ms)
        if ret == 0 and actual_count.value > 0:
            return [buffer[i] for i in range(actual_count.value)]
        return []

    def recv_can(self, dev, ch, timeout_ms=500):
        messages = self.recv_can_bulk(dev, ch, max_count=1, timeout_ms=timeout_ms)
        return messages[0] if messages else None

    def start_period(self, dev, ch, can_id, data, period_ms, is_extended=True, is_fd=True):
        buf = FkVciCanDataType()
        buf.CanID = can_id
        flag = 0
        if is_extended: flag |= 0x01
        if is_fd: flag |= 0x40
        buf.FLAG = flag
        buf.DLC = len(data)
        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        return self.vci.FkVciStartPeriodCAN(dev, ch, byref(buf), period_ms)

    def stop_period(self, dev, ch, pid):
        return self.vci.FkVciStopPeriodCAN(dev, ch, pid)

    def reset_can(self, dev, ch):
        return self.vci.FkVciResetCAN(dev, ch)

    def clear_can(self, dev, ch):
        return self.vci.FkVciClearCAN(dev, ch)

    def set_resistor(self, dev, ch, enable):
        return self.vci.FkVciSetTerminalResistorCAN(dev, ch, enable)

    def get_bus_load(self, dev, channels=8): # 默认设备支持8通道
        arr = (c_double * channels)()
        ret = self.vci.FkVciGetBusLoadCAN(dev, arr, channels)
        if ret == 0:
            return [round(arr[i], 2) for i in range(channels)]
        return None

    def init_lin(self, dev, ch, mode, baud):
        return self.vci.FkVciInitLIN(dev, ch, mode, baud)

    def reset_lin(self, dev, ch):
        return self.vci.FkVciResetLIN(dev, ch)

    def send_lin(self, dev, ch, lin_id, data, msg_type=1, check_type=1):
        buf = FkVciLinDataType()
        buf.LinID = lin_id
        buf.DLC = len(data)
        buf.MsgType = msg_type
        buf.CheckType = check_type
        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        return self.vci.FkVciTransmitLIN(dev, ch, byref(buf), 1)

    def recv_lin_bulk(self, dev, ch, max_count=100, timeout_ms=1000):
        """一次性从缓冲区读取多条LIN报文"""
        buffer_type = FkVciLinDataType * max_count
        buffer = buffer_type()
        actual_count = c_uint32(max_count)
        ret = self.vci.FkVciReceiveLIN(dev, ch, buffer, byref(actual_count), timeout_ms)
        if ret == 0 and actual_count.value > 0:
            return [buffer[i] for i in range(actual_count.value)]
        return []

    def recv_lin(self, dev, ch, timeout_ms=1000):
        """从缓冲区读取单条LIN报文"""
        messages = self.recv_lin_bulk(dev, ch, max_count=1, timeout_ms=timeout_ms)
        return messages[0] if messages else None
