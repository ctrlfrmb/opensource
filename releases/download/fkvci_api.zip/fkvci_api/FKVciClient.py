#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciClient.py - 封装 FKVCI 接口调用，提供简洁的 CAN + LIN 操作接口

import os
import platform
import ctypes
from ctypes import *
from FKVciMessage import FkVciCanDataType, FkVciLinDataType, FkVciCanFdConfig, get_status_description, hex_dump

class FKVciClient:
    def __init__(self):
        self.vci = None
        self.load_dll()

    def load_dll(self):
        arch = platform.architecture()[0]
        lib_path = os.path.abspath("./lib/Winx64" if arch == "64bit" else "./lib/Winx86")
        os.environ['PATH'] = lib_path + os.pathsep + os.environ.get('PATH', '')
        dll_name = "fkvci.dll" if platform.system() == "Windows" else "libFkVci.so"
        self.vci = ctypes.WinDLL(os.path.join(lib_path, dll_name))

        # --- argtypes 定义 ---
        self.vci.ComOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
        self.vci.ComOpenLog.restype = c_int
        self.vci.ComCloseLog.argtypes = []
        self.vci.ComCloseLog.restype = c_int

        self.vci.FkVciOpenDev.argtypes = [c_int, c_int, c_int]
        self.vci.FkVciOpenDev.restype = c_int
        self.vci.FkVciCloseDev.argtypes = [c_int]
        self.vci.FkVciCloseDev.restype = c_int

        # --- 新增接口原型定义 ---
        self.vci.FkVciScanDevice.argtypes = [POINTER(c_int), POINTER(c_uint8), c_uint32]
        self.vci.FkVciScanDevice.restype = c_int
        self.vci.FkVciGetCanChannelCount.argtypes = [c_int]
        self.vci.FkVciGetCanChannelCount.restype = c_int
        self.vci.FkVciGetLinChannelCount.argtypes = [c_int]
        self.vci.FkVciGetLinChannelCount.restype = c_int
        # --- 新增接口原型定义结束 ---

        self.vci.FkVciInitCAN.argtypes = [c_int, c_int, c_uint]
        self.vci.FkVciInitCAN.restype = c_int
        self.vci.FkVciInitCANFD.argtypes = [c_int, c_int, c_uint, c_uint]
        self.vci.FkVciInitCANFD.restype = c_int
        
        self.vci.FkVciInitCANFDAdvanced.argtypes = [c_int, c_int, POINTER(FkVciCanFdConfig)]
        self.vci.FkVciInitCANFDAdvanced.restype = c_int

        self.vci.FkVciTransmitCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), c_uint]
        self.vci.FkVciTransmitCAN.restype = c_int

        # 修正 FkVciReceiveCAN 的 argtypes
        self.vci.FkVciReceiveCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), POINTER(c_uint), c_uint]
        self.vci.FkVciReceiveCAN.restype = c_int

        self.vci.FkVciStartPeriodCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), c_uint]
        self.vci.FkVciStartPeriodCAN.restype = c_int
        self.vci.FkVciStopPeriodCAN.argtypes = [c_int, c_int, c_int]
        self.vci.FkVciStopPeriodCAN.restype = c_int

        self.vci.FkVciSetTerminalResistorCAN.argtypes = [c_int, c_int, c_int]
        self.vci.FkVciSetTerminalResistorCAN.restype = c_int
        self.vci.FkVciGetBusLoadCAN.argtypes = [c_int, POINTER(c_double), c_int]
        self.vci.FkVciGetBusLoadCAN.restype = c_int

        self.vci.FkVciGetVersion.argtypes = [c_int]
        self.vci.FkVciGetVersion.restype = c_uint
        self.vci.FkVciGetBaseTime.argtypes = [c_int]
        self.vci.FkVciGetBaseTime.restype = c_ulonglong

        self.vci.FkVciResetCAN.argtypes = [c_int, c_int]
        self.vci.FkVciResetCAN.restype = c_int
        self.vci.FkVciClearCAN.argtypes = [c_int, c_int]
        self.vci.FkVciClearCAN.restype = c_int

        # LIN 接口
        self.vci.FkVciInitLIN.argtypes = [c_int, c_int, c_uint, c_uint]
        self.vci.FkVciInitLIN.restype = c_int
        self.vci.FkVciResetLIN.argtypes = [c_int, c_int]
        self.vci.FkVciResetLIN.restype = c_int
        self.vci.FkVciTransmitLIN.argtypes = [c_int, c_int, POINTER(FkVciLinDataType), c_uint]
        self.vci.FkVciTransmitLIN.restype = c_int
        
        # 修正 FkVciReceiveLIN 的 argtypes
        self.vci.FkVciReceiveLIN.argtypes = [c_int, c_int, POINTER(FkVciLinDataType), POINTER(c_uint), c_uint]
        self.vci.FkVciReceiveLIN.restype = c_int

    # --- 新增接口封装方法 ---
    def scan_devices(self, max_devices=16, timeout_ms=500):
        """
        扫描局域网内的VCI设备。
        
        :param max_devices: 期望接收的设备索引数组的最大长度。
        :param timeout_ms: 扫描超时时间（毫秒）。
        :return: 成功时返回包含设备索引的列表，失败时返回 None。
        """
        indices_array = (c_int * max_devices)()
        # count 是一个输入输出参数，输入时表示缓冲区大小
        count = c_uint8(max_devices)
        
        ret = self.vci.FkVciScanDevice(indices_array, byref(count), timeout_ms)
        
        if ret == 0:
            # 调用成功后，count.value 存储了实际发现的设备数量
            return [indices_array[i] for i in range(count.value)]
        
        return None  # 扫描失败

    def get_can_channel_count(self, dev_index):
        """获取指定设备的CAN通道数量"""
        return self.vci.FkVciGetCanChannelCount(dev_index)

    def get_lin_channel_count(self, dev_index):
        """获取指定设备的LIN通道数量"""
        return self.vci.FkVciGetLinChannelCount(dev_index)
    # --- 新增接口封装方法结束 ---

    # 通用
    def open_log(self, path="logs/fkvci.log", level=1, max_size=5, max_files=10):
        return self.vci.ComOpenLog(path.encode(), level, max_size, max_files)

    def close_log(self):
        return self.vci.ComCloseLog()

    def open_device(self, dev_type=0, dev_index=0, reserved=0):
        return self.vci.FkVciOpenDev(dev_type, dev_index, reserved)

    def close_device(self, dev_index=0):
        return self.vci.FkVciCloseDev(dev_index)

    def get_version(self, dev):
        raw = self.vci.FkVciGetVersion(dev)
        v = (raw >> 24) & 0xFF
        y = ((raw >> 16) & 0xFF) + 2000
        m = (raw >> 8) & 0xFF
        d = raw & 0xFF
        return f"{v}.{y:04d}.{m:02d}.{d:02d}"

    def get_base_time(self, dev):
        return self.vci.FkVciGetBaseTime(dev)

    # CAN 接口
    def init_can(self, dev, ch, baud):
        return self.vci.FkVciInitCAN(dev, ch, baud)

    def init_canfd(self, dev, ch, baud, fd_baud):
        return self.vci.FkVciInitCANFD(dev, ch, baud, fd_baud)
    
    def init_canfd_advanced(self, dev, ch, baud=500000, fd_baud=2000000, 
                           n_seg1=0x1F, n_seg2=0x08, d_seg1=0x0F, d_seg2=0x04, 
                           term_resistor=1):
        config = FkVciCanFdConfig()
        config.baudRate = baud
        config.fdBaudRate = fd_baud
        config.nSeg1 = n_seg1
        config.nSeg2 = n_seg2
        config.dSeg1 = d_seg1
        config.dSeg2 = d_seg2
        config.terminalResistorEnabled = term_resistor
        
        return self.vci.FkVciInitCANFDAdvanced(dev, ch, byref(config))

    def send_can(self, dev, ch, can_id, data, flag = 0):
        buf = FkVciCanDataType()
        buf.CanID = can_id
        buf.FLAG = flag
        buf.DLC = len(data)
        for i in range(buf.DLC):
            buf.Data[i] = data[i]
        return self.vci.FkVciTransmitCAN(dev, ch, byref(buf), 1)

    # --- 一次读取多帧CAN报文 ---
    def recv_can_bulk(self, dev, ch, max_count=100, timeout_ms=500):
        """
        一次性从缓冲区读取多条CAN报文。
        
        :param dev: 设备索引
        :param ch: 通道索引
        :param max_count: 本次调用最多想要读取的报文数量
        :param timeout_ms: 等待超时时间 (毫秒)
        :return: 包含接收到的 FkVciCanDataType 对象的列表，如果没有数据则返回空列表
        """
        # 创建一个足够大的缓冲区来接收数据
        buffer_type = FkVciCanDataType * max_count
        buffer = buffer_type()
        
        # len 是一个输入输出参数，需要传递指针
        actual_count = c_uint(max_count)
        
        ret = self.vci.FkVciReceiveCAN(dev, ch, buffer, byref(actual_count), timeout_ms)
        
        if ret == 0 and actual_count.value > 0:
            # 从缓冲区中提取实际接收到的报文
            return [buffer[i] for i in range(actual_count.value)]
        
        return []

    # --- 保留旧的单帧接收接口，方便使用 ---
    def recv_can(self, dev, ch, timeout_ms=500):
        """
        从缓冲区读取单条CAN报文。
        
        :return: 单个 FkVciCanDataType 对象或 None
        """
        messages = self.recv_can_bulk(dev, ch, max_count=1, timeout_ms=timeout_ms)
        return messages[0] if messages else None

    def start_period(self, dev, ch, can_id, data, period_ms, is_extended=True, is_fd=True):
        buf = FkVciCanDataType()
        buf.CanID = can_id
        
        flag = 0
        if is_extended: flag |= 0x01
        if is_fd: flag |= 0x40
        buf.FLAG = flag

        buf.DLC = len(data)
        for i in range(buf.DLC):
            buf.Data[i] = data[i]
        return self.vci.FkVciStartPeriodCAN(dev, ch, byref(buf), period_ms)

    def stop_period(self, dev, ch, pid):
        return self.vci.FkVciStopPeriodCAN(dev, ch, pid)

    def reset_can(self, dev, ch):
        return self.vci.FkVciResetCAN(dev, ch)

    def clear_can(self, dev, ch):
        return self.vci.FkVciClearCAN(dev, ch)

    def set_resistor(self, dev, ch, enable):
        return self.vci.FkVciSetTerminalResistorCAN(dev, ch, enable)

    def get_bus_load(self, dev, channels=4):
        arr = (c_double * channels)()
        ret = self.vci.FkVciGetBusLoadCAN(dev, arr, channels)
        if ret == 0:
            return [round(arr[i], 2) for i in range(channels)]
        return None

    # LIN 接口
    def init_lin(self, dev, ch, mode, baud):
        return self.vci.FkVciInitLIN(dev, ch, mode, baud)

    def reset_lin(self, dev, ch):
        return self.vci.FkVciResetLIN(dev, ch)

    def send_lin(self, dev, ch, lin_id, data, msg_type=1, check_type=1):
        buf = FkVciLinDataType()
        buf.LinID = lin_id
        buf.DLC = len(data)
        buf.MsgType = msg_type
        buf.CheckType = check_type
        for i in range(buf.DLC):
            buf.Data[i] = data[i]
        return self.vci.FkVciTransmitLIN(dev, ch, byref(buf), 1)

    def recv_lin(self, dev, ch, timeout_ms=1000):
        buf = FkVciLinDataType()
        count = c_uint(1)
        ret = self.vci.FkVciReceiveLIN(dev, ch, byref(buf), byref(count), timeout_ms)
        if ret == 0 and count.value > 0:
            return buf
        return None
