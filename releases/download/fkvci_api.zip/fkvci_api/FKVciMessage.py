#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciMessage.py - FKVCI 消息结构体与错误码映射

from ctypes import *

class FkVciCanDataType(Structure):
    _pack_ = 4  # 关键：与 C++ 的 #pragma pack(4) 保持一致
    _fields_ = [
        ("CanID", c_uint32),
        ("DLC", c_uint8),
        ("FLAG", c_uint8),
        ("REV1", c_uint8),
        ("REV2", c_uint8),
        ("TimesampL", c_uint32),
        ("TimesampH", c_uint32),
        ("Data", c_uint8 * 64),
    ]

    def get_full_timestamp(self):
        """将高低位时间戳合并为一个64位整数 (单位: 0.1微秒)"""
        return (self.TimesampH << 32) | self.TimesampL

class FkVciLinDataType(Structure):
    _pack_ = 4  # 关键：与 C++ 的 #pragma pack(4) 保持一致
    _fields_ = [
        ("LinID", c_uint8),
        ("DLC", c_uint8),
        ("CheckType", c_uint8),
        ("MsgType", c_uint8),
        ("PID", c_uint8),
        ("CheckSum", c_uint8),
        ("REV1", c_uint8),
        ("REV2", c_uint8),
        ("TimesampL", c_uint32),
        ("TimesampH", c_uint32),
        ("Data", c_uint8 * 8),
    ]

    def get_full_timestamp(self):
        """将高低位时间戳合并为一个64位整数 (单位: 0.1微秒)"""
        return (self.TimesampH << 32) | self.TimesampL

class FkVciCanFdConfig(Structure):
    _pack_ = 4  # 关键：与 C++ 的 #pragma pack(4) 保持一致
    _fields_ = [
        ("baudRate", c_uint32),
        ("fdBaudRate", c_uint32),
        ("nSeg1", c_uint8),
        ("nSeg2", c_uint8),
        ("dSeg1", c_uint8),
        ("dSeg2", c_uint8),
        ("terminalResistorEnabled", c_uint8)
    ]

# 全新的、与 C++ 头文件完全同步的错误码字典
error_code_map = {
    0: "操作成功",
    # 通用错误代码
    -1: "无效的输入参数 (FKVCI_ERROR_INVALID_PARAM)",
    -2: "系统异常发生 (FKVCI_ERROR_SYSTEM_EXCEPTION)",
    -3: "操作不支持 (FKVCI_ERROR_NOT_SUPPORTED)",
    -9: "没有可用设备 (FKVCI_ERROR_NO_DEVICES)",
    -11: "达到周期发送限制 (FKVCI_ERROR_PERIOD_SEND_LIMIT)",
    12: "删除周期ID失败 (FKVCI_ERROR_PERIOD_REMOVE_FAILED)",
    61: "达到过滤限制 (FKVCI_ERROR_FILTER_LIMIT)",
    # 设备错误代码
    -101: "无效的设备索引 (FKVCI_ERROR_INVALID_INDEX)",
    -102: "未找到设备 (FKVCI_ERROR_NOT_FOUND)",
    -103: "设备未打开 (FKVCI_ERROR_NOT_OPENED)",
    # 通讯错误代码
    -401: "连接设备失败 (FKSOCKET_ERROR_CONNECT_FAILED)",
    -402: "未连接设备 (FKSOCKET_ERROR_NOT_CONNECTED)",
    -411: "发送消息失败 (FKSOCKET_ERROR_SEND_FAILED)",
    -412: "消息响应超时 (FKSOCKET_ERROR_RESPONSE_TIMEOUT)",
    # 通道错误代码
    -601: "无效的通道索引 (FKVCI_ERROR_INVALID_CHANNEL)",
    621: "通道缓冲区为空 (FKVCI_ERROR_CHANNEL_BUFFER_EMPTY)",
    # CAN通道错误代码
    -1001: "CAN通道打开失败 (FKCAN_ERROR_OPEN_FAILED)",
    -1002: "CAN通道关闭失败 (FKCAN_ERROR_CLOSE_FAILED)",
    -1003: "无效的通道句柄 (FKCAN_ERROR_INVALID_HANDLE)",
    -1011: "配置失败 (FKCAN_ERROR_CONFIG_FAILED)",
    -1021: "设置终端电阻失败 (FKCAN_ERROR_SET_TERMR_FAILED)",
    # KWP错误代码
    -3011: "文件校验失败 (FKKWP_ERROR_FILE_CHECK_FAILED)",
    -3012: "文件读写异常 (FKKWP_ERROR_FILE_EXCEPTION)",
    -3013: "文件传输失败 (FKKWP_ERROR_FILE_TRANSMIT_FAILED)",
    # LIN通道错误代码
    -5001: "LIN通道打开失败 (FKLIN_ERROR_OPEN_FAILED)",
    -5002: "LIN通道关闭失败 (FKLIN_ERROR_CLOSE_FAILED)",
}

def get_status_description(code):
    """根据错误码获取描述信息"""
    return error_code_map.get(code, f"未知错误码 ({code})")

def hex_dump(data):
    """将字节数据转换为十六进制字符串"""
    return " ".join(f"{b:02X}" for b in data)

