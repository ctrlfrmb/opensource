#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciMessage.py - 对齐 fkvci/fkvcimessage.h (Pythonic 版本)
# 定义VCI基础结构和错误码。

from ctypes import *

# --- C Structure Definitions (直接使用 ctypes 类型) ---

class FkVciCanDataType(Structure):
    _pack_ = 4
    _fields_ = [
        ("CanID", c_uint32),
        ("DLC", c_uint8),
        ("FLAG", c_uint8),
        ("REV1", c_uint8),
        ("REV2", c_uint8),
        ("TimesampL", c_uint32),
        ("TimesampH", c_uint32),
        ("Data", c_uint8 * 64),
    ]

class FkVciLinDataType(Structure):
    _pack_ = 4
    _fields_ = [
        ("LinID", c_uint8),
        ("DLC", c_uint8),
        ("CheckType", c_uint8),
        ("MsgType", c_uint8),
        ("PID", c_uint8),
        ("CheckSum", c_uint8),
        ("REV1", c_uint8),
        ("REV2", c_uint8),
        ("TimesampL", c_uint32),
        ("TimesampH", c_uint32),
        ("Data", c_uint8 * 8),
    ]

class FkVciSentDataType(Structure):
    _pack_ = 4
    _fields_ = [
        ("DLC", c_uint8),
        ("REV", c_uint8),
        ("TimesampL", c_uint32),
        ("TimesampH", c_uint32),
        ("Data", c_uint8 * 64),
    ]

class FkVciCanFdConfig(Structure):
    _pack_ = 4
    _fields_ = [
        ("baudRate", c_uint32),
        ("fdBaudRate", c_uint32),
        ("nSeg1", c_uint8),
        ("nSeg2", c_uint8),
        ("dSeg1", c_uint8),
        ("dSeg2", c_uint8),
        ("terminalResistorEnabled", c_uint8),
    ]

# --- Error Code Definitions ---
vci_error_code_map = {
    0: "操作成功",
    -1: "无效的输入参数 (FKVCI_ERROR_INVALID_PARAM)",
    -2: "系统异常发生 (FKVCI_ERROR_SYSTEM_EXCEPTION)",
    -3: "操作不支持 (FKVCI_ERROR_NOT_SUPPORTED)",
    -9: "没有可用设备 (FKVCI_ERROR_NO_DEVICES)",
    -11: "达到周期发送限制 (FKVCI_ERROR_PERIOD_SEND_LIMIT)",
    12: "删除周期ID失败 (FKVCI_ERROR_PERIOD_REMOVE_FAILED)",
    61: "达到过滤限制 (FKVCI_ERROR_FILTER_LIMIT)",
    -101: "无效的设备索引 (FKVCI_ERROR_INVALID_INDEX)",
    -102: "未找到设备 (FKVCI_ERROR_NOT_FOUND)",
    -103: "设备未打开 (FKVCI_ERROR_NOT_OPENED)",
    -401: "连接设备失败 (FKSOCKET_ERROR_CONNECT_FAILED)",
    -402: "未连接设备 (FKSOCKET_ERROR_NOT_CONNECTED)",
    -411: "发送消息失败 (FKSOCKET_ERROR_SEND_FAILED)",
    -412: "消息响应超时 (FKSOCKET_ERROR_RESPONSE_TIMEOUT)",
    -413: "消息负响应 (FKSOCKET_ERROR_RESPONSE_NACK)",
    -601: "无效的通道索引 (FKVCI_ERROR_INVALID_CHANNEL)",
    -602: "通道打开失败 (FKVCI_ERROR_CHANNEL_OPEN_FAILED)",
    -603: "通道关闭失败 (FKVCI_ERROR_CHANNEL_CLOSE_FAILED)",
    -611: "无效的通道句柄 (FKVCI_ERROR_INVALID_HANDLE)",
    -612: "通道配置失败 (FKVCI_ERROR_CHANNEL_CONFIG_FAILED)",
    621: "通道缓冲区为空 (FKVCI_ERROR_CHANNEL_BUFFER_EMPTY)",
    -1004: "CAN通道未打开 (FKCAN_ERROR_NOT_OPENED)",
    -1021: "设置终端电阻失败 (FKCAN_ERROR_SET_TERMR_FAILED)",
    -3004: "ASC通道未打开 (FKKWP_ERROR_NOT_OPENED)",
    -3011: "文件校验失败 (FKKWP_ERROR_FILE_CHECK_FAILED)",
    -3012: "文件读写异常 (FKKWP_ERROR_FILE_EXCEPTION)",
    -3013: "文件传输失败 (FKKWP_ERROR_FILE_TRANSMIT_FAILED)",
    -5004: "LIN通道未打开 (FKLIN_ERROR_NOT_OPENED)",
    -5011: "LIN通道正在执行调度表 (FKLIN_ERROR_SCHEDULE_RUNNING)",
    -6004: "SENT通道未打开 (FKSENT_ERROR_NOT_OPENED)",
}

def get_vci_status_description(code):
    """根据VCI错误码获取描述信息"""
    return vci_error_code_map.get(code, f"未知VCI错误码 ({code})")
