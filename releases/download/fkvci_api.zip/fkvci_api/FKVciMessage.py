#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciMessage.py - FKVCI 消息结构体与错误码映射

from ctypes import *

class FkVciCanDataType(Structure):
    _fields_ = [
        ("CanID", c_uint32),
        ("DLC", c_uint8),
        ("FLAG", c_uint8),
        ("REV1", c_uint8),
        ("REV2", c_uint8),
        ("TimesampL", c_uint32),
        ("TimesampH", c_uint32),
        ("Data", c_uint8 * 64),
    ]

    def get_full_timestamp(self):
        """将高低位时间戳合并为一个64位整数 (单位: 0.1微秒)"""
        return (self.TimesampH << 32) | self.TimesampL

class FkVciLinDataType(Structure):
    _fields_ = [
        ("LinID", c_uint8),
        ("DLC", c_uint8),
        ("CheckType", c_uint8),
        ("MsgType", c_uint8),
        ("PID", c_uint8),
        ("CheckSum", c_uint8),
        ("REV1", c_uint8),
        ("REV2", c_uint8),
        ("TimesampL", c_uint32),
        ("TimesampH", c_uint32),
        ("Data", c_uint8 * 8),
    ]

    def get_full_timestamp(self):
        """将高低位时间戳合并为一个64位整数 (单位: 0.1微秒)"""
        return (self.TimesampH << 32) | self.TimesampL

class FkVciCanFdConfig(Structure):
    _fields_ = [
        ("baudRate", c_uint32),
        ("fdBaudRate", c_uint32),
        ("nSeg1", c_uint8),
        ("nSeg2", c_uint8),
        ("dSeg1", c_uint8),
        ("dSeg2", c_uint8),
        ("terminalResistorEnabled", c_uint8)
    ]

error_code_map = {
    0: "操作成功",
    -1001: "CAN通道打开失败",
    -1002: "CAN通道关闭失败",
    -8001: "无效的输入参数",
    -8002: "系统异常发生",
    -8102: "未找到设备",
    -8103: "设备未打开",
    -8201: "连接设备失败",
    1011: "设置终端电阻失败",
}

def get_status_description(code):
    return error_code_map.get(code, f"未知错误 ({code})")

def hex_dump(data):
    return " ".join("{:02X}".format(b) for b in data)
