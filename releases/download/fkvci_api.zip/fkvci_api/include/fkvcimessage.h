﻿// fkvcimessage.h
/*----------------------------------------------------------------------------
| FKVCI 消息定义头文件
|
| 本头文件定义了FKVCI系统中CAN和LIN通信的核心数据结构。
| 它包含了设备通信所需的消息格式、错误代码和类型定义。
|
| 此处定义的结构体代表了通过CAN和LIN网络传输和接收数据时使用的基本消息格式。
| 这些定义在整个FKVCI API中用于一致的数据处理和与硬件设备的通信。
|
|-----------------------------------------------------------------------------
|               版 权 声 明
|-----------------------------------------------------------------------------
| 版权所有 (c) 2024 丰柯。保留所有权利。
| 作者: leiwei
| 日期: 2024-06-17
 ----------------------------------------------------------------------------*/

#ifndef FKVCI_MESSAGE_H
#define FKVCI_MESSAGE_H

typedef unsigned char                                       UINT8_T;
typedef unsigned short                                      UINT16_T;
typedef unsigned int                                        UINT32_T;
typedef unsigned long long                                  UINT64_T;

// 正错误码，表示可接受错误，不影响后续执行
// 负错误码，表示发送异常，影响后续执行

/* 通用错误代码 */
#define FKVCI_ERROR_INVALID_PARAM                           (-1)   /* 无效的输入参数 */
#define FKVCI_ERROR_SYSTEM_EXCEPTION                        (-2)   /* 系统异常发生 */
#define FKVCI_ERROR_NOT_SUPPORTED                           (-3)   /* 操作不支持 */
#define FKVCI_ERROR_NO_DEVICES                              (-9)   /* 没有可用设备 */
#define FKVCI_ERROR_PERIOD_SEND_LIMIT                       (-11)  /* 达到周期发送限制 */
#define FKVCI_ERROR_PERIOD_REMOVE_FAILED                    (12)   /* 删除周期ID失败 */
#define FKVCI_ERROR_FILTER_LIMIT                            (61)   /* 达到过滤限制 */

/* 设备错误代码 */
#define FKVCI_ERROR_INVALID_INDEX                           (-101)  /* 无效的设备索引 */
#define FKVCI_ERROR_NOT_FOUND                               (-102)  /* 未找到设备 */
#define FKVCI_ERROR_NOT_OPENED                              (-103)  /* 设备未打开 */

/* 通讯错误代码 */
#define FKSOCKET_ERROR_CONNECT_FAILED                       (-401)  /* 连接设备失败 */
#define FKSOCKET_ERROR_NOT_CONNECTED                        (-402)  /* 未连接设备 */
#define FKSOCKET_ERROR_SEND_FAILED                          (-411)  /* 发送消息失败 */
#define FKSOCKET_ERROR_RESPONSE_TIMEOUT                     (-412)  /* 消息响应超时 */

/* 通道错误代码 */
#define FKVCI_ERROR_INVALID_CHANNEL                         (-601)  /* 无效的通道索引 */
#define FKVCI_ERROR_CHANNEL_BUFFER_EMPTY                    (621)   /* 通道缓冲区为空 */

/* CAN通道错误代码 */
#define FKCAN_ERROR_OPEN_FAILED                             (-1001)  /* CAN通道打开失败 */
#define FKCAN_ERROR_CLOSE_FAILED                            (-1002)  /* CAN通道关闭失败 */
#define FKCAN_ERROR_INVALID_HANDLE                          (-1003)  /* 无效的通道句柄 */
#define FKCAN_ERROR_CONFIG_FAILED                           (-1011)  /* 配置失败 */
#define FKCAN_ERROR_SET_TERMR_FAILED                        (-1021)  /* 设置终端电阻失败 */

/* KWP错误代码 */
#define FKKWP_ERROR_FILE_CHECK_FAILED                       (-3011)  /* 文件校验失败 */
#define FKKWP_ERROR_FILE_EXCEPTION                          (-3012)  /* 文件读写异常 */
#define FKKWP_ERROR_FILE_TRANSMIT_FAILED                    (-3013)  /* 文件传输失败 */

/* LIN通道错误代码 */
#define FKLIN_ERROR_OPEN_FAILED                             (-5001)  /* LIN通道打开失败 */
#define FKLIN_ERROR_CLOSE_FAILED                            (-5002)  /* LIN通道关闭失败 */

#ifdef BUILD_FKKWP_API
#define FKVCI_PROTOCOL_DATA_MAX_LEN                         314     /* 注意：结构体建议保持8字节对齐 320 */
#else
#define FKVCI_PROTOCOL_DATA_MAX_LEN                         122     /* 注意：结构体建议保持8字节对齐 128 */
#endif

#pragma pack(push, 4)

/**
 * @brief CAN消息数据结构
 *
 * 包含CAN或CAN FD帧的所有信息，包括ID、数据长度、
 * 标志位、时间戳和载荷数据。
 */
typedef struct _FkVciCanDataType
{
    UINT32_T CanID;         /* CAN ID（11位标准或29位扩展） */
    UINT8_T  DLC;           /* 数据长度代码（CAN：0-8，CAN FD：0-64） */
    UINT8_T  FLAG;          /* 帧标志位：
                               bit0: 0=标准帧，1=扩展帧
                               bit1: 0=数据帧，1=远程帧
                               bit3: 1=CAN FD BRSEN（位速率切换使能）
                               bit6: 0=CAN，1=CAN FD */
    UINT8_T  REV1;          /* 保留供将来使用 */
    UINT8_T  REV2;          /* 发送时默认0， 接收时表示帧方向：0x01=发送，0x02=接收，0x04=错误 */
    UINT32_T TimesampL;     /* 发送时默认0， 接收时表示时间戳低32位（单位：0.1微秒） */
    UINT32_T TimesampH;     /* 发送时默认0， 接收时表示时间戳高32位 */
    UINT8_T  Data[64];      /* 帧数据（接收时当REV2=错误时，前4字节包含错误代码） */
} FkVciCanDataType;

typedef struct _FkVciKwpDataType
{
    UINT8_T ClientAddr;
    UINT8_T EcuAddr;
    UINT16_T DLC;
    UINT32_T TimesampL;
    UINT32_T TimesampH;
    UINT8_T  Data[256];
} FkVciKwpDataType;

/**
 * @brief LIN消息数据结构
 *
 * 包含LIN帧的所有信息，包括ID、数据长度、
 * 校验和类型、消息类型和载荷数据。
 */
typedef struct _FkVciLinDataType
{
    UINT8_T  LinID;         /* LIN ID（0-63） */
    UINT8_T  DLC;           /* 数据长度（0-8字节） */
    UINT8_T  CheckType;     /* 校验和类型：0=标准，1=增强 */
    UINT8_T  MsgType;       /* 消息类型：
                               0=未知
                               1=主写入
                               2=主读取
                               3=从写入
                               4=从读取
                               5=清除数据 */
    UINT8_T  PID;           /* 发送时默认0， 接收时表示受保护ID（带奇偶校验的ID） */
    UINT8_T  CheckSum;      /* LIN校验和值 */
    UINT8_T  REV1;          /* 发送时默认0， 接收时表示帧方向：
                               0x00=主读取
                               0x01=从读取
                               0x10=主写入
                               0x11=从写入 */
    UINT8_T  REV2;          /* 保留供将来使用 */
    UINT32_T TimesampL;     /* 发送时：间隔（毫秒），默认0
                               接收时：时间戳低32位（单位：0.1微秒） */
    UINT32_T TimesampH;     /* 接收时：时间戳高32位 */
    UINT8_T  Data[8];       /* 帧数据（最多8字节） */
} FkVciLinDataType;

/**
 * @brief CAN和LIN数据类型的联合体
 *
 * 允许通过单一数据结构统一处理CAN和LIN消息。
 */
typedef union _FkVciDataType
{
    FkVciCanDataType Can;   /* CAN/CAN FD消息数据 */
    FkVciLinDataType Lin;   /* LIN消息数据 */
} FkVciDataType;

/**
 * @brief 完整消息结构
 *
 * 包含设备索引、通道、时间戳和实际
 * 消息数据（CAN或LIN）。
 */
typedef struct _FkVciMessage
{
    UINT8_T index;          /* 设备索引 */
    UINT8_T channel;        /* 通道索引 */
    UINT64_T timestamp;     /* 消息时间戳 */
    FkVciDataType frame;    /* 消息数据（CAN或LIN） */
} FkVciMessage;

/// <summary>
/// CANFD通道高级配置结构体
/// </summary>
typedef struct _FkVciCanFdConfig {
    UINT32_T baudRate;                  // CAN波特率
    UINT32_T fdBaudRate;                // CANFD波特率
    UINT8_T nSeg1;                      // 标称位时间第一段参数
    UINT8_T nSeg2;                      // 标称位时间第二段参数
    UINT8_T dSeg1;                      // 数据位时间第一段参数
    UINT8_T dSeg2;                      // 数据位时间第二段参数
    UINT8_T terminalResistorEnabled;    // 终端电阻使能，0: 不使能 >0: 使能
} FkVciCanFdConfig;

typedef struct _FkVciProtocolData {
    UINT8_T protocolId;
    UINT8_T protocolCmd{ 0 };
    UINT8_T protocolChannel;
    UINT8_T rev{ 0 };
    UINT16_T dataLen{ 0 };
    UINT8_T data[FKVCI_PROTOCOL_DATA_MAX_LEN];
} FkVciProtocolData;

#pragma pack(pop)

#endif  //FKVCI_MESSAGE_H
