﻿/*----------------------------------------------------------------------------
* FKVCI API 接口
*
* 提供用于使用FKVCI硬件进行CAN/LIN车辆网络通信的全面接口。支持设备管理、通道配置、
* 消息传输和接收，并包含满足高级协议要求的特殊功能。
*
* 该库同时支持CAN（包括CAN FD）和LIN协议，提供设备管理、日志记录、过滤、
* 周期性消息发送和总线负载监控等功能。
*
* 主要特点：
* - 支持CAN 2.0和CAN FD协议
* - 支持LIN主从模式
* - CAN高级功能配置
* - 设备扫描与发现
* - 消息过滤功能
* - 周期性消息传输
* - 总线负载监控
* - 完整的日志系统
* - 多设备和多通道管理
*
* 使用示例:
*   // 初始化系统并打开设备
*   // FkVciOpenLog("logs/fkvci.log", 1, 5, 10);  // 可选的日志记录
*   int result = FkVciOpenDev(0, 0, 0);  // 打开设备索引0
*
*   if (result == 0) {
*     // === CAN通信示例 ===
*     // 初始化CAN1为500 kbps
*     FkVciInitCAN(0, 0, 500000);
*
*     // === CANFD高级初始化示例 ===
*     // 使用高级配置结构体初始化CANFD
*     FkVciCanFdConfig canfdConfig = {0};
*     canfdConfig.baudRate = 500000;               // 标称波特率500kbps
*     canfdConfig.fdBaudRate = 2000000;            // 数据波特率2Mbps
*     canfdConfig.nSeg1 = 0x1F;                    // 标称位时间段1参数
*     canfdConfig.nSeg2 = 0x08;                    // 标称位时间段2参数
*     canfdConfig.dSeg1 = 0x0F;                    // 数据位时间段1参数
*     canfdConfig.dSeg2 = 0x04;                    // 数据位时间段2参数
*     canfdConfig.terminalResistorEnabled = 1;     // 启用终端电阻
*
*     // 使用高级配置初始化CANFD通道
*     FkVciInitCANFDAdvanced(0, 0, &canfdConfig);
*
*     // 注意：以下是旧的CANFD初始化方法，推荐使用上面的高级配置方法
*     // FkVciInitCANFD(0, 0, 500000, 2000000);
*
*     // 发送CAN消息
*     FkVciCanDataType msg = {0};
*     msg.CanID = 0x100;
*     msg.DLC = 8;
*     for (int i = 0; i < 8; i++) msg.Data[i] = i;
*     FkVciTransmitCAN(0, 0, &msg, 1);
*
*     // 接收CAN消息
*     FkVciCanDataType rxMsgs[10];
*     UINT32_T msgCount = 10;
*     FkVciReceiveCAN(0, 0, rxMsgs, msgCount, 1000);  // 最多等待1秒
*
*     // 开始周期性发送
*     int periodId = FkVciStartPeriodCAN(0, 0, &msg, 100);  // 每100毫秒
*
*     // 完成后停止周期性发送
*     FkVciStopPeriodCAN(0, 0, periodId);
*
*     // 完成后重置CAN通道
*     FkVciResetCAN(0, 0);
*
*     // === LIN通信示例 ===
*     // 以主模式初始化LIN2，波特率为19200 bps
*     FkVciInitLIN(0, 1, 0, 19200);
*
*     // 发送LIN消息
*     FkVciLinDataType linMsg = {0};
*     linMsg.LinID = 0x10;
*     linMsg.DLC = 8;
*     linMsg.CheckType = 1;  // 增强型校验和
*     linMsg.MsgType = 1;    // 主写入
*     for (int i = 0; i < 8; i++) linMsg.Data[i] = i;
*     FkVciTransmitLIN(0, 1, &linMsg, 1);
*
*     // 接收LIN消息
*     FkVciLinDataType rxLinMsgs[10];
*     UINT32_T linMsgCount = 10;
*     FkVciReceiveLIN(0, 1, rxLinMsgs, linMsgCount, 1000);
*
*     // 完成后重置LIN通道
*     FkVciResetLIN(0, 1);
*
*     // 所有操作完成后始终关闭设备
*     FkVciCloseDev(0);
*     // FkVciCloseLog();
*   }
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2024 丰柯科技。保留所有权利。
*
* 本软件按许可协议提供。使用本软件即表示接受许可条款。
*
* 作者: leiwei
* 版本: v2.0.0
* 日期: 2025-09-12
*----------------------------------------------------------------------------*/

#ifndef FKVCI_API_H
#define FKVCI_API_H

#include "fkvci/fkvcimessage.h"

#ifdef _WIN32
    #ifdef BUILD_FKVCI_API
        #define FKVCI_API extern "C" __declspec(dllexport)
    #else
        #define FKVCI_API extern "C" __declspec(dllimport)
    #endif
#else
    #define FKVCI_API extern "C"
#endif

/**
 * @brief 打开日志，用于调试和故障诊断
 *
 * 建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源
 *
 * @param logFile 日志文件路径，形如:logs/fkvci.log
 * @param level 日志等级，-1:默认输出（默认1）0:DEBUG 1:INFO 2:WARN 3:ERROR
 * @param maxSize 文件大小, 范围(1~20), 单位M. -1:默认10M
 * @param maxFiles 文件个数, 范围(1~20), -1:默认保留10个文件
 * @return 0:打开成功 其它:失败错误码
 */
FKVCI_API int ComOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志
 *
 * 安全关闭日志记录系统，释放相关资源
 *
 * @return 0:关闭成功 其它:失败错误码
 */
FKVCI_API int ComCloseLog();

/**
 * @brief 扫描局域网内的VCI设备
 *
 * 扫描会清空现有的设备列表，并用实际扫描到的设备信息进行填充。
 * 如果没有扫描到任何设备，设备列表将为空。
 *
 * @param deviceIndices [out] 用于存储扫描到的设备索引号的数组。
 * @param count [in|out] 输入时表示deviceIndices数组的最大长度，输出时表示实际扫描到的设备数量。
 * @param timeout 扫描超时时间，单位毫秒。 建议100~2000ms之间
 * @return 0:扫描成功 其它:失败错误码
 */
FKVCI_API int FkVciScanDevice(int* deviceIndices, UINT8_T* count, UINT32_T timeout);

/**
 * @brief 获取指定设备支持的CAN通道数量
 *
 * 在调用 FkVciScanDevice 之后或使用默认设备时调用此函数。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return >=0: CAN通道数量, <0: 失败错误码
 */
FKVCI_API int FkVciGetCanChannelCount(int deviceIndex);

/**
 * @brief 获取指定设备支持的LIN通道数量
 *
 * 在调用 FkVciScanDevice 之后或使用默认设备时调用此函数。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return >=0: LIN通道数量, <0: 失败错误码
 */
FKVCI_API int FkVciGetLinChannelCount(int deviceIndex);

/**
 * @brief 打开设备
 *
 * 通过指定的设备索引连接到硬件设备，建立通信链路
 *
 * @param deviceType 设置类型（暂未启用）0:LAN 1:USB 2:COM
 * @param deviceIndex 设备索引:0x00~0x0F(对应ip:192.168.201.130~ip:192.168.201.145)
 * @param reserved 默认0，1~254表示绑定本地网卡(本地ip:192.168.reserved)
 * @return 0:打开成功 其它:失败错误码
 */
FKVCI_API int FkVciOpenDev(int deviceType, int deviceIndex, int reserved);

/**
 * @brief 关闭设备
 *
 * 安全地断开与硬件设备的连接，释放通信资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F 特殊值-1:停止所有打开的设备
 * @return 0:关闭成功 其它:失败错误码
 */
FKVCI_API int FkVciCloseDev(int deviceIndex);

/**
 * @brief 查询设备版本信息
 *
 * 读取设备固件版本信息，格式为: B0(主版本号), B1(年), B2(月), B3(日)
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return 0:查询失败 其它:版本信息 B0:version B1:year B2:month B3:day
 */
FKVCI_API UINT32_T FkVciGetVersion(int deviceIndex);

/**
 * @brief 获取设备基准时间
 *
 * 获取设备当前内部时间基准点，用于时间同步和消息时间戳校准
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return 正数:获取成功 0:获取失败
 */
FKVCI_API UINT64_T FkVciGetBaseTime(int deviceIndex);

/**
 * @brief 初始化CAN通道（打开通道）
 *
 * 配置并打开指定的CAN通道，设置基本通信参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param baudRate 同步波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCAN(int deviceIndex, int channelIndex, UINT32_T baudRate);

/**
 * @brief 初始化CANFD通道（打开通道）
 *
 * 配置并打开指定的CANFD通道，设置基本通信参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param baudRate CAN波特率
 * @param fdBaudRate CANFD波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCANFD(int deviceIndex, int channelIndex, UINT32_T baudRate, UINT32_T fdBaudRate);

/**
 * @brief 使用高级配置结构初始化CANFD通道（打开通道）
 *
 * 使用详细配置参数初始化CANFD通道，提供更精确的位时序控制
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param config CANFD高级配置结构体
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCANFDAdvanced(int deviceIndex, int channelIndex, const FkVciCanFdConfig* config);

/**
 * @brief 复位CAN通道（关闭通道）
 *
 * 停止指定CAN通道的所有活动并释放资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:复位成功 其它:失败错误码
 */
FKVCI_API int FkVciResetCAN(int deviceIndex, int channelIndex);

/**
 * @brief 清空CAN通道接收缓存
 *
 * 清除指定CAN通道的接收消息缓冲区
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号 特殊值-1:清空所有通道缓存
 * @return 0:清空成功 其它:失败错误码
 */
FKVCI_API int FkVciClearCAN(int deviceIndex, int channelIndex);

/**
 * @brief 接收CAN消息
 *
 * 从指定CAN通道读取接收到的消息，默认每个通道缓存2000条数据
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param messages CAN消息数组
 * @param len [in|out] 输入时表示想要接收消息条数，输出时表示实际接收消息条数
 * @param timeout 等待时间，单位ms， 暂未使用
 * @return 0:接收成功 其它:失败错误码
 */
FKVCI_API int FkVciReceiveCAN(int deviceIndex, int channelIndex, FkVciCanDataType *messages, UINT32_T &len, UINT32_T timeout);

/**
 * @brief 发送CAN消息
 *
 * 向指定CAN通道发送一个或多个消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param messages CAN消息数组
 * @param len 发送消息条数，最大值：0x7F
 * @return 0:发送成功 其它:失败错误码
 */
FKVCI_API int FkVciTransmitCAN(int deviceIndex, int channelIndex, const FkVciCanDataType *messages, UINT32_T len);

/**
 * @brief 周期发送CAN消息
 *
 * 设置一个CAN消息以固定周期重复发送
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param message CAN消息
 * @param periodTime 周期时间(毫秒)
 * @return 正数: 周期消息id 其它:失败错误码
 */
FKVCI_API int FkVciStartPeriodCAN(int deviceIndex, int channelIndex, const FkVciCanDataType *message, UINT32_T periodTime);

/**
 * @brief 周期发送CAN消息(首帧发送延迟）
 *
 * 设置一个CAN消息以固定周期重复发送
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param message CAN消息
 * @param periodTime 周期时间(毫秒)
 * @param delayTime 首帧延迟时间(毫秒)
 * @return 正数: 周期消息id 其它:失败错误码
 */
FKVCI_API int FkVciStartPeriodCANWithDelay(int deviceIndex, int channelIndex, const FkVciCanDataType *message, UINT32_T periodTime, UINT32_T delayTime);

/**
 * @brief 停止周期发送CAN消息
 *
 * 停止一个或多个周期性发送的CAN消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param id 周期消息id  特殊值-1:停止当前通道所有周期消息
 * @return 返回值
 *     停止单条周期消息：
 *         - 0: 成功
 *         - 其它: 失败
 *     停止当前通道周期消息:
 *         - >0: 停止的通道周期消息条数
 *         - 0: 当前通道没有正在运行的周期消息
 */
FKVCI_API int FkVciStopPeriodCAN(int deviceIndex, int channelIndex, int id);

/**
 * @brief 过滤CAN消息（非线程安全）
 *
 * 设置CAN消息ID过滤，只接收指定ID的消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param ids 过滤的消息ID数组
 * @param len 过滤数组长度
 * @return 0:过滤设置成功 其它:失败错误码
 */
FKVCI_API int FkVciStartFilterCAN(int deviceIndex, int channelIndex, UINT32_T *ids, UINT32_T len);

/**
 * @brief 停止过滤CAN消息（非线程安全）
 *
 * 清除CAN消息过滤设置，接收所有消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:停止过滤成功 其它:失败错误码
 */
FKVCI_API int FkVciStopFilterCAN(int deviceIndex, int channelIndex);

/**
 * @brief 设置终端电阻使能状态
 *
 * 控制CAN通道的终端电阻是否启用
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param enable 1:使能 0:不使能
 * @return 0:设置成功 其它:失败错误码
 */
FKVCI_API int FkVciSetTerminalResistorCAN(int deviceIndex, int channelIndex, int enable);

/**
 * @brief 获取CAN总线负载率(建议调用周期1000ms)
 *
 * 监测CAN总线利用率，评估网络通信情况
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param busLoad 通道负载率 100.0表示100%
 * @param channelSize 通道数量 (busLoad数组长度应>=channelSize)
 * @return 0:获取成功 其它:失败错误码
 */
FKVCI_API int FkVciGetBusLoadCAN(int deviceIndex, double* busLoad, int channelSize);

///*******************************************************************************/

/**
 * @brief 初始化LIN通道（打开通道）
 *
 * 配置并打开指定的LIN通道，设置通信模式和参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param mode 0:主模式 1:从模式
 * @param baudRate 波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitLIN(int deviceIndex, int channelIndex, UINT32_T mode, UINT32_T baudRate);

/**
 * @brief 复位LIN通道（关闭通道）
 *
 * 停止指定LIN通道的所有活动并释放资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @return 0:复位成功 其它:失败错误码
 */
FKVCI_API int FkVciResetLIN(int deviceIndex, int channelIndex);

/**
 * @brief 接收LIN消息
 *
 * 从指定LIN通道读取接收到的消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param messages LIN消息数组
 * @param len [in|out] 输入时表示想要接收消息条数，输出时表示实际接收消息条数
 * @param timeout 等待时间，单位ms
 * @return 0:接收成功 其它:失败错误码
 */
FKVCI_API int FkVciReceiveLIN(int deviceIndex, int channelIndex, FkVciLinDataType *messages, UINT32_T &len, UINT32_T timeout);

/**
 * @brief 发送LIN消息
 *
 * 向指定LIN通道发送一个或多个消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param messages LIN消息数组
 * @param len 发送消息条数，最大值：0x7F
 * @return 0:发送成功(加入待发送队列) 其它:失败错误码
 */
FKVCI_API int FkVciTransmitLIN(int deviceIndex, int channelIndex, const FkVciLinDataType *messages, UINT32_T len);

#endif  //FKVCI_API_H
