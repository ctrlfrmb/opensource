﻿/**
 * @file vci_uds_def.h
 * @brief Defines public, C-compatible data structures and result codes for the VCI UDS library.
 *
 * This header file is intended for external users of the VCI UDS library. It provides
 * the necessary definitions to interpret the results of UDS operations without exposing
 * internal implementation details.
 *
 * Author: leiwei
 * Copyright (c) 2025. All rights reserved.
 */

#ifndef VCI_UDS_DEF_H
#define VCI_UDS_DEF_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Defines the result codes for VCI UDS operations.
 *
 * Convention:
 * - 0: Success.
 * - Negative values: Errors that terminated the operation.
 * - Positive values: Warnings or success with a special condition.
 */
typedef enum {
    /* =========================================================================
     * == Positive Values: Warnings / Success with Status
     * ========================================================================= */

    /**
     * @brief The provided response buffer was too small to hold the complete data.
     * The buffer has been filled with a truncated portion of the response.
     * The operation itself was successful, but the user should handle the partial data.
     */
    VCI_UDS_RESULT_BUFFER_TOO_SMALL = 304,


    /* =========================================================================
     * == 0: Success
     * ========================================================================= */

    /** @brief Operation completed successfully with a positive response from the ECU. */
    VCI_UDS_RESULT_OK = 0,


    /* =========================================================================
     * == Negative Values: Errors
     * ========================================================================= */

    /**
     * @brief The ECU returned a Negative Response Code (NRC).
     * This is a generic code for most NRCs. The specific NRC value can be
     * found as the third byte in the response payload (e.g., 7F <SID> <NRC>).
     */
    VCI_UDS_RESULT_NEGATIVE_RESPONSE = -101,

    /** @brief Timeout waiting for the first response frame (SF or FF) from the ECU (N_As/P2). */
    VCI_UDS_RESULT_TIMEOUT_A = -201,

    /** @brief Timeout waiting for a Flow Control (FC) frame from the ECU (N_Bs). */
    VCI_UDS_RESULT_TIMEOUT_BS = -202,

    /** @brief Timeout waiting for a Consecutive Frame (CF) from the ECU (N_Cr). */
    VCI_UDS_RESULT_TIMEOUT_CR = -203,

    /**
     * @brief Timeout after receiving one or more NRC 0x78 (Response Pending).
     * The ECU failed to provide a final response within the extended P2* timeout (N_Ar).
     */
    VCI_UDS_RESULT_TIMEOUT_P2_STAR = -204,

    /** @brief The ECU sent a Flow Control frame with an 'Overflow' status, aborting the transfer. */
    VCI_UDS_RESULT_FC_OVERFLOW = -205,

    /** @brief Received a Consecutive Frame with an incorrect sequence number. */
    VCI_UDS_RESULT_SEQUENCE_ERROR = -206,

    /** @brief Received a TP frame that was not expected in the current state (e.g., a CF before an FF). */
    VCI_UDS_RESULT_UNEXPECTED_FRAME = -207,

    /** @brief The ECU sent too many consecutive NRC 0x78 (Response Pending) frames, exceeding the client's limit. */
    VCI_UDS_RESULT_NRC78_LIMIT_EXCEEDED = -208,

    /** @brief The underlying CAN frame sending function failed. Check VCI device connection and CAN bus status. */
    VCI_UDS_RESULT_SEND_FAILED = -301,

    /** @brief The request payload exceeds the maximum size supported by ISO-TP (e.g., 4095 bytes for classic CAN). */
    VCI_UDS_RESULT_PAYLOAD_TOO_LARGE = -302,

    /** @brief A function was called with invalid parameters (e.g., null pointers, empty payload). */
    VCI_UDS_RESULT_INVALID_PARAM = -303,

    /** @brief The provided UDS instance ID is invalid or does not exist. */
    VCI_UDS_RESULT_INVALID_UDS_ID = -305,

    /** @brief Failed to parse or apply the provided configuration string. */
    VCI_UDS_RESULT_CONFIG_FAILED = -306,

    /** @brief Cannot create new UDS instance; the maximum number of instances has been reached. */
    VCI_UDS_RESULT_INSTANCE_LIMIT_EXCEEDED = -307,

    /** @brief For async `readResponse`, no response was available in the queue within the specified timeout. */
    VCI_UDS_RESULT_NO_RESPONSE_IN_QUEUE = -401,

    /** @brief The asynchronous request queue is full. The request was dropped. */
    VCI_UDS_RESULT_QUEUE_FULL = -402,

    /** @brief An internal logic error occurred within the library. This may indicate a bug. */
    VCI_UDS_RESULT_INTERNAL_ERROR = -501,

} VciUdsResultCode;


#ifdef __cplusplus
} // extern "C"
#endif

#endif // VCI_UDS_DEF_H
