﻿/**
 * @file vci_uds_def.h
 * @brief Defines public, C-compatible data structures and result codes for the VCI UDS library.
 *
 * This header file is intended for external users of the VCI UDS library. It provides
 * the necessary definitions to interpret the results of UDS operations without exposing
 * internal implementation details.
 *
 * Author: leiwei E-mail: ctrlfrmb@gmail.com
 * Copyright (c) 2025. All rights reserved.
 */

#ifndef VCI_UDS_DEF_H
#define VCI_UDS_DEF_H

#ifdef __cplusplus
extern "C" {
#endif

/*
 * To ensure UDS result codes are unique and do not conflict with other modules (e.g., VCI),
 * they are based directly on the ISO 15765 standard number. This approach is simple,
 * readable, and safe for all integer sizes.
 */
#define VCI_UDS_ERROR_BASE   (-15765)
#define VCI_UDS_WARNING_BASE ( 15765)


/**
 * @brief Defines the maximum payload size for a single UDS message according to ISO 15765-2.
 * This is limited by the 12-bit length field in the First Frame (0xFFF = 4095).
 */
#define VCI_UDS_MAX_PAYLOAD_SIZE 4095U

/**
 * @brief Defines the result codes for VCI UDS operations, based on ISO 15765-2.
 *
 * Convention:
 * - 0: Success.
 * - Negative values (e.g., -15765 - 101): Errors that terminated the operation.
 * - Positive values (e.g., 15765 + 304): Warnings or success with a special condition.
 */
typedef enum {
    /* =========================================================================
     * == Positive Values: Warnings / Success with Status
     * ========================================================================= */

    /**
     * @brief The provided response buffer was too small to hold the complete data.
     * The buffer has been filled with a truncated portion of the response.
     * The `response_len` parameter of the read function will contain the required size.
     */
    VCI_UDS_RESULT_BUFFER_TOO_SMALL = VCI_UDS_WARNING_BASE + 304,


    /* =========================================================================
     * == 0: Success
     * ========================================================================= */

    /** @brief Operation completed successfully with a positive response from the ECU. */
    VCI_UDS_RESULT_OK = 0,


    /* =========================================================================
     * == Negative Values: Errors
     * ========================================================================= */

    /* --- General Protocol Errors (Offset 1xx) --- */
    /**
     * @brief The ECU returned a Negative Response Code (NRC).
     * The specific NRC value can be found as the third byte in the response payload.
     */
    VCI_UDS_RESULT_NEGATIVE_RESPONSE = VCI_UDS_ERROR_BASE - 101,

    /**
     * @brief The ECU sent a positive response, but the Service ID or Sub-Function
     * did not match the request, or the data format was invalid for the specific step.
     */
    VCI_UDS_RESULT_UNEXPECTED_RESPONSE = VCI_UDS_ERROR_BASE - 102,

    /* --- ISO-TP Layer Errors (Offset 2xx) --- */
    /** @brief Timeout waiting for the first response frame (SF or FF) from the ECU (N_As/P2). */
    VCI_UDS_RESULT_TIMEOUT_A = VCI_UDS_ERROR_BASE - 201,

    /** @brief Timeout waiting for a Flow Control (FC) frame from the ECU (N_Bs). */
    VCI_UDS_RESULT_TIMEOUT_BS = VCI_UDS_ERROR_BASE - 202,

    /** @brief Timeout waiting for a Consecutive Frame (CF) from the ECU (N_Cr). */
    VCI_UDS_RESULT_TIMEOUT_CR = VCI_UDS_ERROR_BASE - 203,

    /** @brief Timeout after receiving NRC 0x78 (Response Pending) (N_Ar/P2*). */
    VCI_UDS_RESULT_TIMEOUT_P2_STAR = VCI_UDS_ERROR_BASE - 204,

    /** @brief The ECU sent a Flow Control frame with an 'Overflow' status. */
    VCI_UDS_RESULT_FC_OVERFLOW = VCI_UDS_ERROR_BASE - 205,

    /** @brief Received a Consecutive Frame with an incorrect sequence number. */
    VCI_UDS_RESULT_SEQUENCE_ERROR = VCI_UDS_ERROR_BASE - 206,

    /** @brief Received an unexpected ISO-TP frame type for the current state. */
    VCI_UDS_RESULT_UNEXPECTED_FRAME = VCI_UDS_ERROR_BASE - 207,

    /** @brief Exceeded the client's limit for receiving NRC 0x78 (Response Pending). */
    VCI_UDS_RESULT_NRC78_LIMIT_EXCEEDED = VCI_UDS_ERROR_BASE - 208,

    /* --- API & Client-Side Errors (Offset 3xx) --- */
    /** @brief The underlying CAN frame sending function failed. */
    VCI_UDS_RESULT_SEND_FAILED = VCI_UDS_ERROR_BASE - 301,

    /** @brief The request payload exceeds the maximum size supported by ISO-TP (4095 bytes). */
    VCI_UDS_RESULT_PAYLOAD_TOO_LARGE = VCI_UDS_ERROR_BASE - 302,

    /** @brief A function was called with invalid parameters (e.g., null pointers). */
    VCI_UDS_RESULT_INVALID_PARAM = VCI_UDS_ERROR_BASE - 303,

    /** @brief The provided UDS instance ID is invalid or does not exist. */
    VCI_UDS_RESULT_INVALID_UDS_ID = VCI_UDS_ERROR_BASE - 305,

    /** @brief Failed to parse or apply the provided configuration. */
    VCI_UDS_RESULT_CONFIG_FAILED = VCI_UDS_ERROR_BASE - 306,

    /** @brief The maximum number of UDS instances has been reached. */
    VCI_UDS_RESULT_INSTANCE_LIMIT_EXCEEDED = VCI_UDS_ERROR_BASE - 307,

    /** @brief The operation was aborted by a user request. */
    VCI_UDS_RESULT_ABORTED = VCI_UDS_ERROR_BASE - 308,

    /* --- Asynchronous Operation Errors (Offset 4xx) --- */
    /** @brief For async `readResponse`, no response was available in the queue. */
    VCI_UDS_RESULT_NO_RESPONSE_IN_QUEUE = VCI_UDS_ERROR_BASE - 401,

    /** @brief The asynchronous request queue is full; the request was dropped. */
    VCI_UDS_RESULT_QUEUE_FULL = VCI_UDS_ERROR_BASE - 402,

    /* --- Internal Library Errors (Offset 5xx) --- */
    /** @brief An internal logic error occurred within the library. */
    VCI_UDS_RESULT_INTERNAL_ERROR = VCI_UDS_ERROR_BASE - 501,
    /** @brief VCI device not opened. */
    VCI_UDS_RESULT_DEVICE_NOT_OPEN = VCI_UDS_ERROR_BASE - 502,

    /* --- Security Access Errors (Offset 6xx) --- */
    /** @brief The security algorithm configuration is missing or incomplete (e.g., DLL path not set). */
    VCI_UDS_RESULT_SECURITY_CONFIG_FAILED = VCI_UDS_ERROR_BASE - 601,
    /** @brief Failed to load the security algorithm DLL. */
    VCI_UDS_RESULT_SECURITY_DLL_LOAD_FAILED = VCI_UDS_ERROR_BASE - 602,
    /** @brief Failed to find the specified function in the security algorithm DLL. */
    VCI_UDS_RESULT_SECURITY_FUNC_NOT_FOUND = VCI_UDS_ERROR_BASE - 603,
    /** @brief The security algorithm function in the DLL returned an error. */
    VCI_UDS_RESULT_SECURITY_ALGO_FAILED = VCI_UDS_ERROR_BASE - 604,
    /** @brief The response from the ECU after requesting the seed was invalid. */
    VCI_UDS_RESULT_SECURITY_INVALID_SEED = VCI_UDS_ERROR_BASE - 605,

    /* --- File I/O & Flashing Errors (Offset 8xx) --- */
    /** @brief Failed to open, read, or parse a firmware file. */
    VCI_UDS_RESULT_FILE_IO_ERROR = VCI_UDS_ERROR_BASE - 801,
    /** @brief Local CRC calculation mismatch or ECU reported checksum failure (that isn't an NRC). */
    VCI_UDS_RESULT_CRC_MISMATCH = VCI_UDS_ERROR_BASE - 802,

    /* --- Logger Errors (Offset 10xx) --- */
    /** @brief Failed to configure or start the file logger. */
    VCI_UDS_RESULT_CONFIG_LOGGER_FAILED = VCI_UDS_ERROR_BASE - 1001,

} VciUdsResultCode;

#pragma pack(push, 4)

/**
 * @struct VciUdsFunctionalResponseData
 * @brief Holds a single, complete response from one ECU during a functional request.
 *
 * This structure is used to retrieve data from the functional response queue. It contains
 * the source address of the responding ECU and the complete data payload.
 *
 * @warning This structure is large (~4KB) due to the fixed-size data buffer. Avoid
 *          creating large arrays of this structure on the stack to prevent stack overflow.
 *          It is best used as a single instance on the stack or allocated on the heap.
 */
typedef struct {
    /** @brief The CAN ID of the ECU that sent this response (e.g., 0x7E8). */
    unsigned int source_address;

    /** @brief The actual length of the received data payload in bytes. */
    unsigned int data_len;

    /** @brief A buffer to hold the received data payload. */
    unsigned char data[VCI_UDS_MAX_PAYLOAD_SIZE];

    unsigned char reserve;  // for 4 byte alignment

} VciUdsFunctionalResponseData;

#pragma pack(pop)

#ifdef __cplusplus
} // extern "C"
#endif

#endif // VCI_UDS_DEF_H
