﻿/*----------------------------------------------------------------------------
* FKVCI API 接口
*
* 提供用于使用FKVCI硬件进行CAN/LIN/SENT车辆网络通信的全面接口。支持设备管理、
* 通道配置、消息传输和接收，并包含满足高级协议要求的特殊功能。
*
* 该库同时支持CAN（包括CAN FD）、LIN、SENT协议以及UDS诊断服务，提供设备管理、
* 日志记录、过滤、周期性消息发送和总线负载监控等功能。
*
* 主要特点：
* - 支持CAN 2.0和CAN FD协议
* - 支持LIN主从模式及调度表
* - 支持SENT协议数据接收
* - 支持ISO 15765-2 (UDS on CAN)
* - CAN/LIN/SENT高级功能配置
* - 设备扫描与发现
* - 消息过滤功能
* - 周期性消息传输
* - 总线负载监控
* - 完整的日志系统
* - 多设备和多通道管理
*
* 使用示例:
*   // 初始化系统并打开设备
*   // FkVciOpenLog("logs/fkvci.log", 1, 5, 10);  // 可选的日志记录
*   int result = FkVciOpenDev(0, 0, 0);  // 打开设备索引0
*
*   if (result == 0) {
*     // === CAN通信示例 ===
*     // 初始化CAN1为500 kbps
*     FkVciInitCAN(0, 0, 500000);
*
*     // 发送CAN消息
*     FkVciCanDataType msg = {0};
*     msg.CanID = 0x100;
*     msg.DLC = 8;
*     for (int i = 0; i < 8; i++) msg.Data[i] = i;
*     FkVciTransmitCAN(0, 0, &msg, 1);
*
*     // 接收CAN消息
*     FkVciCanDataType rxMsgs[10];
*     UINT32_T msgCount = 10;
*     FkVciReceiveCAN(0, 0, rxMsgs, &msgCount, 1000);  // 最多等待1秒
*
*     // 开始周期性发送
*     int periodId = FkVciStartPeriodCAN(0, 0, &msg, 100);  // 每100毫秒
*
*     // 完成后停止周期性发送
*     FkVciStopPeriodCAN(0, 0, periodId);
*
*     // 完成后重置CAN通道
*     FkVciResetCAN(0, 0);
*
*     // === LIN通信示例 ===
*     // 以主模式初始化LIN2，波特率为19200 bps
*     FkVciInitLIN(0, 1, 0, 19200);
*
*     // 发送LIN消息
*     FkVciLinDataType linMsg = {0};
*     linMsg.LinID = 0x10;
*     linMsg.DLC = 8;
*     linMsg.CheckType = 1;  // 增强型校验和
*     linMsg.MsgType = 1;    // 主写入
*     for (int i = 0; i < 8; i++) linMsg.Data[i] = i;
*     FkVciTransmitLIN(0, 1, &linMsg, 1);
*
*     // 接收LIN消息
*     FkVciLinDataType rxLinMsgs[10];
*     UINT32_T linMsgCount = 10;
*     FkVciReceiveLIN(0, 1, rxLinMsgs, &linMsgCount, 1000);
*
*     // 完成后重置LIN通道
*     FkVciResetLIN(0, 1);
*
*     // === UDS诊断示例 ===
*     // 确保用于UDS的CAN通道已初始化 (复用上面的CAN通道0)
*     UINT32_T udsId = 0;
*     // 为设备0的CAN通道0创建一个UDS服务实例
*     result = FkVciCreateUdsService(0, 0, 0x7E0, 0x7E8, &udsId);
*     if (result == 0) {
*         // 配置UDS参数并启动心跳 (每2秒发送一次)
*         FkVciSetUdsConfig(udsId, "--testerPresentInterval 2000 --testerPresentSubFunc 80 --testerPresentId 7DF");
*
*         // 发送一个同步的UDS请求 (例如：读取ECU识别码)
*         UINT8_T request[] = {0x22, 0xF1, 0x90};
*         UINT8_T response[4095];
*         UINT32_T responseLen = sizeof(response);
*
*         result = FkVciUdsRequestSync(udsId, request, sizeof(request), response, &responseLen);
*         if (result >= 0) { // 0表示完全成功, >0表示有警告(如缓冲区不足)
*             // 请求成功，处理response中的数据
*             printf("UDS Response Received (%d bytes)\n", responseLen);
*         } else {
*             // 请求失败，打印错误信息
*             printf("UDS Sync Request failed with code %d: %s\n", result, FkVciGetUdsErrorString(result));
*         }
*
*         // 停止心跳
*         FkVciSetUdsConfig(udsId, "--testerPresentInterval 0");
*
*         // 销毁UDS服务实例
*         FkVciDestroyUdsService(udsId);
*     }
*
*     // 所有操作完成后始终关闭设备
*     FkVciCloseDev(0);
*     // FkVciCloseLog();
*   }
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2024 丰柯科技。保留所有权利。
*
* 本软件按许可协议提供。使用本软件即表示接受许可条款。
*
* 作者: leiwei
* 版本: v5.1.0
* 日期: 2025-11-28
*----------------------------------------------------------------------------*/

#ifndef FKVCI_API_H
#define FKVCI_API_H

#ifdef _WIN32
#ifdef BUILD_FKVCI_API
#define FKVCI_API extern "C" __declspec(dllexport)
#else
#define FKVCI_API extern "C" __declspec(dllimport)
#endif
#else
#define FKVCI_API extern "C"
#endif

typedef unsigned char                                       UINT8_T;
typedef unsigned short                                      UINT16_T;
typedef unsigned int                                        UINT32_T;
typedef unsigned long long                                  UINT64_T;


// 正错误码，表示可接受错误，不影响后续执行
// 负错误码，表示发送异常，影响后续执行

/* 通用错误代码 */
#define FKVCI_ERROR_INVALID_PARAM                           (-1)   /* 无效的输入参数 */
#define FKVCI_ERROR_SYSTEM_EXCEPTION                        (-2)   /* 系统异常发生 */
#define FKVCI_ERROR_NOT_SUPPORTED                           (-3)   /* 操作不支持 */
#define FKVCI_ERROR_NO_DEVICES                              (-9)   /* 没有可用设备 */
#define FKVCI_ERROR_PERIOD_SEND_LIMIT                       (-11)  /* 达到周期发送限制 */
#define FKVCI_ERROR_PERIOD_REMOVE_FAILED                    (12)   /* 删除周期ID失败 */
#define FKVCI_ERROR_FILTER_LIMIT                            (61)   /* 达到过滤限制 */

/* 设备错误代码 */
#define FKVCI_ERROR_INVALID_INDEX                           (-101)  /* 无效的设备索引 */
#define FKVCI_ERROR_NOT_FOUND                               (-102)  /* 未找到设备 */
#define FKVCI_ERROR_NOT_OPENED                              (-103)  /* 设备未打开 */

/* 通讯错误代码 */
#define FKSOCKET_ERROR_CONNECT_FAILED                       (-401)  /* 连接设备失败 */
#define FKSOCKET_ERROR_NOT_CONNECTED                        (-402)  /* 未连接设备 */
#define FKSOCKET_ERROR_SEND_FAILED                          (-411)  /* 发送消息失败 */
#define FKSOCKET_ERROR_RESPONSE_TIMEOUT                     (-412)  /* 消息响应超时 */
#define FKSOCKET_ERROR_RESPONSE_NACK                        (-413)  /* 消息负响应 */

/* 通道错误代码 */
#define FKVCI_ERROR_INVALID_CHANNEL                         (-601)  /* 无效的通道索引 */
#define FKVCI_ERROR_CHANNEL_OPEN_FAILED                     (-602)  /* 通道打开失败 */
#define FKVCI_ERROR_CHANNEL_CLOSE_FAILED                    (-603)  /* 通道关闭失败 */
#define FKVCI_ERROR_INVALID_HANDLE                          (-611)  /* 无效的通道句柄 */
#define FKVCI_ERROR_CHANNEL_CONFIG_FAILED                   (-612)  /* 通道配置失败 */
#define FKVCI_ERROR_CHANNEL_BUFFER_EMPTY                    (621)   /* 通道缓冲区为空 */

/* CAN通道错误代码 */
#define FKCAN_ERROR_NOT_OPENED                              (-1004)  /* CAN通道未打开 */
#define FKCAN_ERROR_SET_TERMR_FAILED                        (-1021)  /* 设置终端电阻失败 */

/* KWP错误代码 */
#define FKKWP_ERROR_NOT_OPENED                              (-3004)  /* ASC通道未打开 */
#define FKKWP_ERROR_FILE_CHECK_FAILED                       (-3011)  /* 文件校验失败 */
#define FKKWP_ERROR_FILE_EXCEPTION                          (-3012)  /* 文件读写异常 */
#define FKKWP_ERROR_FILE_TRANSMIT_FAILED                    (-3013)  /* 文件传输失败 */

/* LIN通道错误代码 */
#define FKLIN_ERROR_NOT_OPENED                              (-5004)  /* LIN通道未打开 */
#define FKLIN_ERROR_SCHEDULE_RUNNING                        (-5011)  /* LIN通道真正执行调度表 */

/* SENT通道错误代码 */
#define FKSENT_ERROR_NOT_OPENED                             (-6004)  /* SENT通道未打开 */

#ifdef BUILD_FKKWP_API
#define FKVCI_PROTOCOL_DATA_MAX_LEN                         314     /* 注意：结构体建议保持8字节对齐 320 */
#else
#define FKVCI_PROTOCOL_DATA_MAX_LEN                         122     /* 注意：结构体建议保持8字节对齐 128 */
#endif

#pragma pack(push, 4)

/**
 * @brief CAN消息数据结构
 *
 * 包含CAN或CAN FD帧的所有信息，包括ID、数据长度、
 * 标志位、时间戳和载荷数据。
 */
typedef struct _FkVciCanDataType
{
    UINT32_T CanID;         /* CAN ID（11位标准或29位扩展） */
    UINT8_T  DLC;           /* 数据长度代码（CAN：0-8，CAN FD：0-64） */
    UINT8_T  FLAG;          /* 帧标志位：
                               bit0: 0=标准帧，1=扩展帧
                               bit1: 0=数据帧，1=远程帧
                               bit3: 1=CAN FD BRSEN（位速率切换使能）
                               bit6: 0=CAN，1=CAN FD */
    UINT8_T  REV1;          /* 保留供将来使用 */
    UINT8_T  REV2;          /* 发送时默认0， 接收时表示帧方向：0x01=发送，0x02=接收，0x04=错误 */
    UINT32_T TimesampL;     /* 发送时默认0， 接收时表示时间戳低32位（单位：0.1微秒） */
    UINT32_T TimesampH;     /* 发送时默认0， 接收时表示时间戳高32位 */
    UINT8_T  Data[64];      /* 帧数据（接收时当REV2=错误时，前4字节包含错误代码） */
} FkVciCanDataType;

typedef struct _FkVciKwpDataType
{
    UINT8_T ClientAddr;
    UINT8_T EcuAddr;
    UINT16_T DLC;
    UINT32_T TimesampL;
    UINT32_T TimesampH;
    UINT8_T  Data[256];
} FkVciKwpDataType;
/**
 * @brief LIN消息数据结构
 *
 * 包含LIN帧的所有信息，包括ID、数据长度、校验和类型、
 * 消息类型、载荷数据以及时间戳等。
 */
typedef struct _FkVciLinDataType
{
    UINT8_T  LinID;         /**< LIN ID（0-63） */

    UINT8_T  DLC;           /**< 数据长度（0-8字节） */

    UINT8_T  CheckType;     /**< 校验和类型：
                                 0 = 标准校验和 (Classic Checksum)
                                 1 = 增强校验和 (Enhanced Checksum) */

    UINT8_T  MsgType;       /**< 消息类型（用于区分发送或接收到的帧阶段/内容）：
                                 0x00 = 未知 / 未定义
                                 0x01 = 主任务写入      (Master Write:   发送 Header + Response)
                                 0x02 = 主任务读取      (Master Read:    发送 Header，期待从机响应)
                                 0x03 = 从任务写入      (Slave Write:    从机发送 Response)
                                 0x04 = 从任务读取      (Slave Read:     主任务请求读取，实际为 Header)
                                 0x05 = 仅检测到 Break  (Break:          只收到 Break 信号)
                                 0x06 = Break + Sync   (Break+Sync:     收到 Break 和 Sync 字段)
                                 0x07 = Break + Sync + PID
                                 0x08 = Break + Sync + PID + Data
                                 0x09 = Break + Sync + PID + Data + Check（完整帧）
                                 0x0B = 唤醒帧          (Wake Up)
                                 0x0C = 清除数据        (Clear Data) */

    UINT8_T  PID;           /**< 发送时通常填 0；
                                 接收时为受保护的 ID（Protected ID），即带奇偶校验位的 PID */

    UINT8_T  CheckSum;      /**< LIN 帧的校验和值（根据 CheckType 计算） */

    UINT8_T  REV1;          /**< 发送时通常填 0；
                                 接收时表示帧方向/角色：
                                 0x00 = 主任务读取 (Master Request / Header)
                                 0x01 = 从任务读取
                                 0x10 = 主任务写入
                                 0x11 = 从任务写入 */

    UINT8_T  REV2;          /**< 保留字段，供将来扩展使用（目前填 0） */

    UINT32_T TimesampL;     /**< 发送时：帧间隔时间（单位：毫秒），默认 0
                                 接收时：时间戳低 32 位（单位：0.1 微秒） */

    UINT32_T TimesampH;     /**< 接收时：时间戳高 32 位（与 TimesampL 组成 64 位时间戳） */

    UINT8_T  Data[8];       /**< 帧载荷数据，最多 8 字节（根据 DLC 确定有效长度） */

} FkVciLinDataType;

typedef struct _FkVciSentDataType
{
    UINT8_T DLC;  //长度 Data 中包含个SENT 信息
    UINT8_T REV;
    UINT32_T TimesampL;//发送时候为时间间隔 单位ms  接收为时间戳 单位us
    UINT32_T TimesampH;
    UINT8_T Data[64];
} FkVciSentDataType;

/**
 * @brief CAN和LIN数据类型的联合体
 *
 * 允许通过单一数据结构统一处理CAN和LIN消息。
 */
typedef union _FkVciDataType
{
    FkVciCanDataType Can;   /* CAN/CAN FD消息数据 */
    FkVciLinDataType Lin;   /* LIN消息数据 */
    FkVciSentDataType Sent; /* SENT消息数据 */
} FkVciDataType;

/**
 * @brief 完整消息结构
 *
 * 包含设备索引、通道、时间戳和实际
 * 消息数据（CAN或LIN）。
 */
typedef struct _FkVciMessage
{
    UINT8_T index;          /* 设备索引 */
    UINT8_T channel;        /* 通道索引 */
    UINT64_T timestamp;     /* 消息时间戳 */
    FkVciDataType frame;    /* 消息数据（CAN或LIN） */
} FkVciMessage;

/// <summary>
/// CANFD通道高级配置结构体
/// </summary>
typedef struct _FkVciCanFdConfig {
    UINT32_T baudRate;                  // CAN波特率
    UINT32_T fdBaudRate;                // CANFD波特率
    UINT8_T nSeg1;                      // 标称位时间第一段参数
    UINT8_T nSeg2;                      // 标称位时间第二段参数
    UINT8_T dSeg1;                      // 数据位时间第一段参数
    UINT8_T dSeg2;                      // 数据位时间第二段参数
    UINT8_T terminalResistorEnabled;    // 终端电阻使能，0: 不使能 >0: 使能
} FkVciCanFdConfig;

/**
 * @struct VciUdsFunctionalResponseData
 * @brief Holds a single, complete response from one ECU during a functional request.
 *
 * This structure is used to retrieve data from the functional response queue. It contains
 * the source address of the responding ECU and the complete data payload.
 *
 * @warning This structure is large (~4KB) due to the fixed-size data buffer. Avoid
 *          creating large arrays of this structure on the stack to prevent stack overflow.
 *          It is best used as a single instance on the stack or allocated on the heap.
 */
typedef struct {
    /** @brief The CAN ID of the ECU that sent this response (e.g., 0x7E8). */
    unsigned int source_address;

    /** @brief The actual length of the received data payload in bytes. */
    unsigned int data_len;

    /** @brief A buffer to hold the received data payload. */
    unsigned char data[VCI_UDS_MAX_PAYLOAD_SIZE];

    unsigned char reserve;  // for 4 byte alignment

} VciUdsFunctionalResponseData;

#pragma pack(pop)

/**
 * @brief 打开日志，用于调试和故障诊断
 *
 * 建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源
 *
 * @param logFile 日志文件路径，形如:logs/fkvci.log
 * @param level 日志等级，-1:默认输出（默认1）0:DEBUG 1:INFO 2:WARN 3:ERROR
 * @param maxSize 文件大小, 范围(1~100), 单位M. -1:默认10M
 * @param maxFiles 文件个数, 范围(1~20), -1:默认保留10个文件
 * @return 0:打开成功 其它:失败错误码
 */
FKVCI_API int FkVciOpenLog(const char* logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志
 *
 * 安全关闭日志记录系统，释放相关资源
 *
 * @return 0:关闭成功 其它:失败错误码
 */
FKVCI_API int FkVciCloseLog();

/**
 * @brief 清空VCI设备
 *
 * @return 无
 */
FKVCI_API void FkVciClearDevices();

/**
 * @brief 扫描局域网内的VCI设备
 *
 * 扫描会清空现有的设备列表，并用实际扫描到的设备信息进行填充。
 * 如果没有扫描到任何设备，设备列表将为空。
 *
 * @param deviceIndices [out] 用于存储扫描到的设备索引号的数组。
 * @param count [in|out] 指向长度变量的指针。输入时表示deviceIndices数组的最大长度，输出时表示实际扫描到的设备数量。
 * @param timeout 扫描超时时间，单位毫秒。 建议100~2000ms之间
 * @return 0:扫描成功 其它:失败错误码
 */
FKVCI_API int FkVciScanDevice(int* deviceIndices, UINT8_T* count, UINT32_T timeout);

/**
 * @brief 手动创建VCI设备
 *
 * 默认创建16个设备。每个设备8通道CAN/LIN，2通道SENT
 *
 * @return 0:创建成功 其它:失败错误码
 */
FKVCI_API int FkVciCreateDevices();

/**
 * @brief 获取指定设备支持的CAN通道数量
 *
 * 在调用 FkVciScanDevice 之后或使用默认设备时调用此函数。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return >=0: CAN通道数量, <0: 失败错误码
 */
FKVCI_API int FkVciGetCanChannelCount(int deviceIndex);

/**
 * @brief 获取指定设备支持的LIN通道数量
 *
 * 在调用 FkVciScanDevice 之后或使用默认设备时调用此函数。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return >=0: LIN通道数量, <0: 失败错误码
 */
FKVCI_API int FkVciGetLinChannelCount(int deviceIndex);

/**
 * @brief 打开设备
 *
 * 通过指定的设备索引连接到硬件设备，建立通信链路
 *
 * @param deviceType 设置类型（暂未启用）0:LAN 1:USB 2:COM
 * @param deviceIndex 设备索引:0x00~0x0F(对应ip:192.168.201.130~ip:192.168.201.145)
 * @param reserved 默认0，1~254表示绑定本地网卡(本地ip:192.168.201.reserved)
 * @return 0:打开成功 其它:失败错误码
 */
FKVCI_API int FkVciOpenDev(int deviceType, int deviceIndex, int reserved);

/**
 * @brief 关闭设备
 *
 * 安全地断开与硬件设备的连接，释放通信资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F 特殊值-1:停止所有打开的设备
 * @return 0:关闭成功 其它:失败错误码
 */
FKVCI_API int FkVciCloseDev(int deviceIndex);

/**
 * @brief 查询设备版本信息
 *
 * 读取设备固件版本信息，格式为: B0(主版本号), B1(年), B2(月), B3(日)
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return 0:查询失败 其它:版本信息 B0:version B1:year B2:month B3:day
 */
FKVCI_API UINT32_T FkVciGetVersion(int deviceIndex);

/**
 * @brief 获取设备基准时间
 *
 * 获取设备当前内部时间基准点，用于时间同步和消息时间戳校准
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return 正数:获取成功 0:获取失败
 */
FKVCI_API UINT64_T FkVciGetBaseTime(int deviceIndex);

/**
 * @brief 初始化CAN通道（打开通道）
 *
 * 配置并打开指定的CAN通道，设置基本通信参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param baudRate 同步波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCAN(int deviceIndex, int channelIndex, UINT32_T baudRate);

/**
 * @brief 初始化CANFD通道（打开通道）
 *
 * 配置并打开指定的CANFD通道，设置基本通信参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param baudRate CAN波特率
 * @param fdBaudRate CANFD波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCANFD(int deviceIndex, int channelIndex, UINT32_T baudRate, UINT32_T fdBaudRate);

/**
 * @brief 使用高级配置结构初始化CANFD通道（打开通道）
 *
 * 使用详细配置参数初始化CANFD通道，提供更精确的位时序控制
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param config 指向CANFD高级配置结构体的指针
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCANFDAdvanced(int deviceIndex, int channelIndex, const FkVciCanFdConfig* config);

/**
 * @brief 复位CAN通道（关闭通道）
 *
 * 停止指定CAN通道的所有活动并释放资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:复位成功 其它:失败错误码
 */
FKVCI_API int FkVciResetCAN(int deviceIndex, int channelIndex);

/**
 * @brief 清空CAN通道接收缓存
 *
 * 清除指定CAN通道的接收消息缓冲区
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号 特殊值-1:清空所有通道缓存
 * @return 0:清空成功 其它:失败错误码
 */
FKVCI_API int FkVciClearCAN(int deviceIndex, int channelIndex);

/**
 * @brief 接收CAN消息
 *
 * 从指定CAN通道读取接收到的消息，默认每个通道缓存2000条数据
 * 建议使用非阻塞方式读取（即timeout = 0），此方式不额外占用cpu，外部可循环读取，如每隔20ms读取。
 * 若需要读取指定条数的报文时，可使用阻塞（即timeout = 0）超时方式读取，此方式会消耗cpu。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param messages 指向CAN消息数组的指针
 * @param len [in|out] 指向长度变量的指针。输入时表示想要接收消息条数，输出时表示实际接收消息条数
 * @param timeout 读取等待时间，单位ms
 *               0：表示非阻塞读取
 *              >0：表示阻塞读取超时时间
 * @return 0:接收成功 其它:失败错误码
 */
FKVCI_API int FkVciReceiveCAN(int deviceIndex, int channelIndex, FkVciCanDataType* messages, UINT32_T* len, UINT32_T timeout);

/**
 * @brief 发送CAN消息
 *
 * 向指定CAN通道发送一个或多个消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param messages 指向CAN消息数组的指针
 * @param len 发送消息条数，最大值：0x7F
 * @return 0:发送成功 其它:失败错误码
 */
FKVCI_API int FkVciTransmitCAN(int deviceIndex, int channelIndex, const FkVciCanDataType* messages, UINT32_T len);

/**
 * @brief 周期发送CAN消息
 *
 * 设置一个CAN消息以固定周期重复发送
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param message 指向CAN消息的指针
 * @param periodTime 周期时间(毫秒)
 * @return 正数: 周期消息id 其它:失败错误码
 */
FKVCI_API int FkVciStartPeriodCAN(int deviceIndex, int channelIndex, const FkVciCanDataType* message, UINT32_T periodTime);

/**
 * @brief 周期发送CAN消息(首帧发送延迟）
 *
 * 设置一个CAN消息以固定周期重复发送
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param message 指向CAN消息的指针
 * @param periodTime 周期时间(毫秒)
 * @param delayTime 首帧延迟时间(毫秒)
 * @return 正数: 周期消息id 其它:失败错误码
 */
FKVCI_API int FkVciStartPeriodCANWithDelay(int deviceIndex, int channelIndex, const FkVciCanDataType* message, UINT32_T periodTime, UINT32_T delayTime);

/**
 * @brief 停止周期发送CAN消息
 *
 * 停止一个或多个周期性发送的CAN消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param id 周期消息id  特殊值-1:停止当前通道所有周期消息
 * @return 返回值
 *     停止单条周期消息：
 *         - 0: 成功
 *         - 其它: 失败
 *     停止当前通道周期消息:
 *         - >0: 停止的通道周期消息条数
 *         - 0: 当前通道没有正在运行的周期消息
 */
FKVCI_API int FkVciStopPeriodCAN(int deviceIndex, int channelIndex, int id);

/**
 * @brief 过滤CAN消息（非线程安全）
 *
 * 设置CAN消息ID过滤，只接收指定ID的消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param ids 指向过滤的消息ID数组的指针
 * @param len 过滤数组长度
 * @return 0:过滤设置成功 其它:失败错误码
 */
FKVCI_API int FkVciStartFilterCAN(int deviceIndex, int channelIndex, UINT32_T* ids, UINT32_T len);

/**
 * @brief 停止过滤CAN消息（非线程安全）
 *
 * 清除CAN消息过滤设置，接收所有消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:停止过滤成功 其它:失败错误码
 */
FKVCI_API int FkVciStopFilterCAN(int deviceIndex, int channelIndex);

/**
 * @brief 设置终端电阻使能状态
 *
 * 控制CAN通道的终端电阻是否启用
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param enable 1:使能 0:不使能
 * @return 0:设置成功 其它:失败错误码
 */
FKVCI_API int FkVciSetTerminalResistorCAN(int deviceIndex, int channelIndex, int enable);

/**
 * @brief 获取CAN总线负载率(建议调用周期1000ms)
 *
 * 监测CAN总线利用率，评估网络通信情况
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param busLoad 指向通道负载率数组的指针, 100.0表示100%
 * @param channelSize 通道数量 (busLoad数组长度应>=channelSize)
 * @return 0:获取成功 其它:失败错误码
 */
FKVCI_API int FkVciGetBusLoadCAN(int deviceIndex, double* busLoad, int channelSize);

///*******************************************************************************/

/**
 * @brief 初始化LIN通道（打开通道）
 *
 * 配置并打开指定的LIN通道，设置通信模式和参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param mode 0:主模式 1:从模式
 * @param baudRate 波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitLIN(int deviceIndex, int channelIndex, UINT32_T mode, UINT32_T baudRate);

/**
 * @brief 配置LIN通道参数
 *
 * 用于设置LIN通道的特殊参数，如超时时间、校验方式或特定协议参数(如TINIL)。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param configId 配置项ID (如 FKVCI_CONFIG_TINIL, FKVCI_SET_CONFIG 等)
 * @param configValue 配置值的指针，具体类型取决于 configId
 * @return 0:成功 其它:失败错误码
 */
FKVCI_API int FkVciConfigLIN(int deviceIndex, int channelIndex, UINT32_T configId, void* configValue);

/**
 * @brief 复位LIN通道（关闭通道）
 *
 * 停止指定LIN通道的所有活动并释放资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @return 0:复位成功 其它:失败错误码
 */
FKVCI_API int FkVciResetLIN(int deviceIndex, int channelIndex);

/**
 * @brief 清空LIN通道接收缓存
 *
 * 清除指定LIN通道的接收消息缓冲区
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号 特殊值-1:清空所有通道缓存
 * @return 0:清空成功 其它:失败错误码
 */
FKVCI_API int FkVciClearLIN(int deviceIndex, int channelIndex);

/**
 * @brief 接收LIN消息
 *
 * 从指定LIN通道读取接收到的消息，默认每个通道缓存2000条数据
 * 建议使用非阻塞方式读取（即timeout = 0），此方式不额外占用cpu，外部可循环读取，如每隔20ms读取。
 * 若需要读取指定条数的报文时，可使用阻塞（即timeout = 0）超时方式读取，此方式会消耗cpu。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param messages 指向LIN消息数组的指针
 * @param len [in|out] 指向长度变量的指针。输入时表示想要接收消息条数，输出时表示实际接收消息条数
 * @param timeout 读取等待时间，单位ms
 *               0：表示非阻塞读取
 *              >0：表示阻塞读取超时时间
 * @return 0:接收成功 其它:失败错误码
 */
FKVCI_API int FkVciReceiveLIN(int deviceIndex, int channelIndex, FkVciLinDataType* messages, UINT32_T* len, UINT32_T timeout);

/**
 * @brief 发送LIN消息
 *
 * 向指定LIN通道发送一个或多个消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param messages 指向LIN消息数组的指针
 * @param len 消息条数
 * @return 0:发送成功(加入待发送队列) 其它:失败错误码
 */
FKVCI_API int FkVciTransmitLIN(int deviceIndex, int channelIndex, const FkVciLinDataType* messages, UINT32_T len);

/**
 * @brief 启动LIN调度表
 *
 * 主模式下，此函数将一组LIN消息作为调度表下载到硬件并启动周期性调度。
 * 从模式下，此函数配置从机响应数据。
 * **注意：此功能与 FkVciTransmitLIN 互斥，不能同时使用。**
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param messages 指向LIN消息数组的指针，作为调度表条目
 * @param len 消息条数
 * @return 0:成功 其它:失败错误码
 */
FKVCI_API int FkVciStartScheduleLIN(int deviceIndex, int channelIndex, const FkVciLinDataType* messages, UINT32_T len);

/**
 * @brief 停止LIN调度表
 *
 * 主模式下，停止硬件的周期性调度。
 * 从模式下，清空已配置的从机响应数据。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @return 0:成功 其它:失败错误码
 */
FKVCI_API int FkVciStopScheduleLIN(int deviceIndex, int channelIndex);

/**
 * @brief 在从模式下写入一条响应消息
 *
 * 用于在调度表运行时，动态更新或添加一条从机响应数据。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param message 指向单条LIN消息的指针
 * @return 0:成功 其它:失败错误码
 */
FKVCI_API int FkVciWriteSlaveLIN(int deviceIndex, int channelIndex, const FkVciLinDataType* message);

/**
 * @brief 初始化SENT通道（打开通道）
 *
 * 配置并打开指定的SENT通道。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex SENT通道号 (通常为 0 或 1)
 * @param fastMessages 每个SENT帧中包含的快速消息(Fast Message)数量，范围通常是1-16。
 * @param tickTime SENT协议的Tick Time原始配置值。这是一个编码值，非直接的微秒数。
 *                 例如，范围1-90，其中1代表1.5us，请参考设备文档。
 * @param readInterval 连续读取SENT帧的时间间隔，单位为毫秒(ms)。
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitSENT(int deviceIndex, int channelIndex, UINT32_T fastMessages, UINT32_T tickTime, UINT32_T readInterval);

/**
 * @brief 复位SENT通道（关闭通道）
 *
 * 停止指定SENT通道的所有活动并释放资源。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex SENT通道号 (通常为 0 或 1)
 * @return 0:复位成功 其它:失败错误码
 */
FKVCI_API int FkVciResetSENT(int deviceIndex, int channelIndex);

/**
 * @brief 清空SENT通道接收缓存
 *
 * 清除指定SENT通道的接收消息缓冲区。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex SENT通道号 (通常为 0 或 1)。特殊值-1:清空所有SENT通道缓存。
 * @return 0:清空成功 其它:失败错误码
 */
FKVCI_API int FkVciClearSENT(int deviceIndex, int channelIndex);

/**
 * @brief 接收SENT消息
 *
 * 从指定SENT通道读取接收到的消息，默认每个通道缓存2000条数据
 * 建议使用非阻塞方式读取（即timeout = 0），此方式不额外占用cpu，外部可循环读取，如每隔20ms读取。
 * 若需要读取指定条数的报文时，可使用阻塞（即timeout = 0）超时方式读取，此方式会消耗cpu。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex SENT通道号 (通常为 0 或 1)
 * @param messages 指向SENT消息数组的指针
 * @param len [in|out] 指向长度变量的指针。输入时表示想要接收消息条数，输出时表示实际接收消息条数
 * @param timeout 读取等待时间，单位ms
 *               0：表示非阻塞读取
 *              >0：表示阻塞读取超时时间
 * @return 0:接收成功 其它:失败错误码
 */
FKVCI_API int FkVciReceiveSENT(int deviceIndex, int channelIndex, FkVciSentDataType* messages, UINT32_T* len, UINT32_T timeout);

/*******************************************************************************
 * UDS (ISO 15765) 功能
 * 支持 ISO 15765-2/ISO 15765-4
 *******************************************************************************/

/**
 * @brief 将UDS错误码转换为可读的字符串描述
 *
 * @param uds_error_code UDS操作返回的错误码。
 * @return 指向描述错误信息的静态字符串的指针。
 */
FKVCI_API const char* FkVciGetUdsErrorString(int uds_error_code);

/**
 * @brief 创建一个UDS服务实例
 *
 * 为指定的CAN通道创建一个UDS诊断服务实例。如果该通道已存在实例，则返回现有实例的ID。
 *
 * @param deviceIndex VCI设备索引。
 * @param channelIndex CAN通道索引。
 * @param reqId UDS物理请求的CAN ID (例如 0x7E0)。
 * @param resId UDS物理响应的CAN ID (例如 0x7E8)。
 * @param udsId [out] 指向用于接收创建的服务实例的唯一ID的指针。
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciCreateUdsService(int deviceIndex, int channelIndex, UINT32_T reqId, UINT32_T resId, UINT32_T* udsId);

/**
 * @brief 销毁一个UDS服务实例
 *
 * @param udsId 要销毁的服务实例ID。
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciDestroyUdsService(UINT32_T udsId);


/**
 * @brief 配置UDS服务实例的参数，并管理日志记录功能。
 *
 * 使用命令行风格的字符串来统一配置ISO-TP层的时序、流控、CAN ID、自动心跳（Tester Present）
 * 以及原始CAN报文的日志记录。未在命令中指定的参数将保持其当前值或默认值。
 *
 * @param udsId 服务实例ID。
 * @param commands 配置字符串，例如 "--stMin 0A --timeoutAr 5000 --enableLog 1 --logDir ./logs"。
 *                 支持的参数及其默认值:
 *
 *                 **[连接与地址]**
 *                 - `--canType <0|1|2>`: CAN帧类型 (0: Classic, 1: FD, 2: FD+BRS) (默认: 0)。
 *                 - `--funcId <hex>`: 功能请求CAN ID (默认: 7DF)。
 *                 - `--funcResMin <hex>`: 功能响应监听的最小CAN ID (默认: 700)。
 *                 - `--funcResMax <hex>`: 功能响应监听的最大CAN ID (默认: 7FF)。
 *
 *                 **[ISO-TP 时序与流控]**
 *                 - `--stMin <hex>`: Separation Time (STmin), 范围 00-FF (默认: 00)。
 *                 - `--blockSize <hex>`: Block Size (BS), 范围 00-FF, 00表示无限制 (默认: 00)。
 *                 - `--timeoutAs <ms>`: N_As/P2, 发送方等待响应超时 (默认: 1000 ms)。
 *                 - `--timeoutAr <ms>`: N_Ar/P2*, 接收方等待最终响应超时 (默认: 5000 ms)。
 *                 - `--timeoutBs <ms>`: N_Bs, 发送方等待流控帧超时 (默认: 1000 ms)。
 *                 - `--timeoutCr <ms>`: N_Cr, 接收方等待连续帧超时 (默认: 1000 ms)。
 *                 - `--maxNrc78 <count>`: 最大连续接收NRC 0x78的次数 (默认: 5)。
 *
 *                 **[应用层行为]**
 *                 - `--testerPresentInterval <ms>`: 自动发送心跳包的间隔 (默认: 2000 ms)。
 *                                                **设置为 > 0 的值会启动或更新心跳。**
 *                                                **设置为 0 会停止心跳。**
 *                 - `--testerPresentSubFunc <hex>`: 心跳包的子功能 (默认: 80)。
 *                 - `--testerPresentId <hex>`: 用于发送心跳包的CAN ID (默认: 0)。
 *                                            **如果为0, 则使用物理请求ID。可设为功能ID。**
 *
 *                 **[帧格式化]**
 *                 - `--paddingSize <dec>`: CAN帧填充目标字节数 (仅经典CAN)，0表示禁用 (默认: 0)。
 *                 - `--paddingByte <hex>`: 用于填充的字节值 (默认: AA)。
 *
 *                 **[原始报文日志记录]**
 *                 - `--enableLog <0|1>`: 控制原始UDS报文日志的开关。
 *                                      **- 设为 1: 打开日志。**
 *                                      **- 设为 0: 关闭日志。**
 *                 - `--logDir <path>`: 指定保存日志文件的目录路径 (默认: ".")。
 *                 - `--logBaseName <name>`: 日志文件的基础名称 (默认: "uds_raw_log")。
 *                                          **最终文件名会自动添加设备、通道和时间戳信息，**
 *                                          **格式如：`device0_channel0_uds_raw_log_20231027_143000_1.log`**
 *                 - `--logMaxSizeMB <dec>`: 单个日志文件的最大大小（单位：MB） (默认: 10)。
 *
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciSetUdsConfig(UINT32_T udsId, const char* commands);

/**
 * @brief 发送同步的UDS请求 (物理寻址, 阻塞)
 *
 * 发送一个UDS请求并等待响应。函数会阻塞直到收到完整响应或超时。
 *
 * @param udsId 服务实例ID。
 * @param request_pdu 指向请求数据的指针。
 * @param request_len 请求数据的长度。
 * @param response_pdu [out] 用于存储响应数据的缓冲区。
 * @param response_len [in|out] 指向长度变量的指针。输入时为缓冲区最大长度，输出时为实际响应数据长度。
 * @return 0: 成功, <0: 错误码, >0: 警告码 (例如 VCI_UDS_RESULT_BUFFER_TOO_SMALL)。
 */
FKVCI_API int FkVciUdsRequestSync(UINT32_T udsId, const UINT8_T* request_pdu, UINT32_T request_len, UINT8_T* response_pdu, UINT32_T* response_len);

/**
 * @brief 发送异步的UDS请求 (物理寻址, 非阻塞)
 *
 * 将一个UDS请求放入发送队列后立即返回。响应需要通过 `FkVciUdsReadResponse` 读取。
 *
 * @param udsId 服务实例ID。
 * @param request_pdu 指向请求数据的指针。
 * @param request_len 请求数据的长度。
 * @return 0: 成功入队, <0: 错误码。
 */
FKVCI_API int FkVciUdsRequestAsync(UINT32_T udsId, const UINT8_T* request_pdu, UINT32_T request_len);

/**
 * @brief 读取异步UDS请求的响应 (物理寻址, 阻塞)
 *
 * 从响应队列中读取一条响应。如果队列为空，函数会阻塞直到有响应或超时。
 *
 * @param udsId 服务实例ID。
 * @param response_pdu [out] 用于存储响应数据的缓冲区。
 * @param response_len [in|out] 指向长度变量的指针。输入时为缓冲区最大长度，输出时为实际响应数据长度。
 * @param timeout_ms 等待超时时间 (毫秒)。
 * @return 0: 成功, <0: 错误码, >0: 警告码 (例如 VCI_UDS_RESULT_BUFFER_TOO_SMALL)。
 */
FKVCI_API int FkVciUdsReadResponse(UINT32_T udsId, UINT8_T* response_pdu, UINT32_T* response_len, UINT32_T timeout_ms);

/**
 * @brief 发送功能性UDS请求 (功能寻址, 非阻塞)
 *
 * 将一个功能性UDS请求（广播）放入发送队列后立即返回。响应需要通过 `FkVciUdsReadFunctionalResponses` 读取。
 *
 * @param udsId 服务实例ID。
 * @param request_pdu 指向请求数据的指针。
 * @param request_len 请求数据的长度。
 * @return 0: 成功入队, <0: 错误码。
 */
FKVCI_API int FkVciUdsRequestFunctional(UINT32_T udsId, const UINT8_T* request_pdu, UINT32_T request_len);

/**
 * @brief 读取功能性UDS请求的响应 (功能寻址, 阻塞)
 *
 * 从功能响应队列中批量读取来自多个ECU的响应。此函数会首先等待指定的
 * 超时时间以接收第一个响应，然后会立即尝试读取队列中所有剩余的响应，
 * 直到填满用户提供的数组或队列为空。
 *
 * @param udsId 服务实例ID。
 * @param response_array [out] 指向用于存储响应数据的结构体数组的指针。
 * @param array_len [in|out] 指向长度变量的指针。输入时为 `response_array` 的容量，输出时为实际读取到的响应数量。
 * @param timeout_ms 等待第一个响应的超时时间 (毫秒)。
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciUdsReadFunctionalResponses(UINT32_T udsId, VciUdsFunctionalResponseData* response_array, UINT32_T* array_len, UINT32_T timeout_ms);

/**
 * @brief 清空UDS异步队列
 *
 * 清除指定服务实例中所有待处理的异步请求（物理和功能）和已接收的响应。
 *
 * @param udsId 服务实例ID。
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciUdsClearAsyncQueues(UINT32_T udsId);

#endif  //FKVCI_API_H
