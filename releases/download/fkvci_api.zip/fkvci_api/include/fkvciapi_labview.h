﻿/*----------------------------------------------------------------------------
* FKVCI API 接口
*
* 提供用于使用FKVCI硬件进行CAN/LIN车辆网络通信的全面接口。支持设备管理、通道配置、
* 消息传输和接收，并包含满足高级协议要求的特殊功能。
*
* 该库同时支持CAN（包括CAN FD）、LIN协议以及UDS诊断服务，提供设备管理、日志记录、过滤、
* 周期性消息发送和总线负载监控等功能。
*
* 主要特点：
* - 支持CAN 2.0和CAN FD协议
* - 支持LIN主从模式
* - 支持ISO 15765-2 (UDS on CAN)
* - CAN高级功能配置
* - 设备扫描与发现
* - 消息过滤功能
* - 周期性消息传输
* - 总线负载监控
* - 完整的日志系统
* - 多设备和多通道管理
*
* 使用示例:
*   // 初始化系统并打开设备
*   // FkVciOpenLog("logs/fkvci.log", 1, 5, 10);  // 可选的日志记录
*   int result = FkVciOpenDev(0, 0, 0);  // 打开设备索引0
*
*   if (result == 0) {
*     // === CAN通信示例 ===
*     // 初始化CAN1为500 kbps
*     FkVciInitCAN(0, 0, 500000);
*
*     // === CANFD高级初始化示例 ===
*     // 使用高级配置结构体初始化CANFD
*     FkVciCanFdConfig canfdConfig = {0};
*     canfdConfig.baudRate = 500000;               // 标称波特率500kbps
*     canfdConfig.fdBaudRate = 2000000;            // 数据波特率2Mbps
*     canfdConfig.nSeg1 = 0x1F;                    // 标称位时间段1参数
*     canfdConfig.nSeg2 = 0x08;                    // 标称位时间段2参数
*     canfdConfig.dSeg1 = 0x0F;                    // 数据位时间段1参数
*     canfdConfig.dSeg2 = 0x04;                    // 数据位时间段2参数
*     canfdConfig.terminalResistorEnabled = 1;     // 启用终端电阻
*
*     // 使用高级配置初始化CANFD通道
*     FkVciInitCANFDAdvanced(0, 0, &canfdConfig);
*
*     // 注意：以下是旧的CANFD初始化方法，推荐使用上面的高级配置方法
*     // FkVciInitCANFD(0, 0, 500000, 2000000);
*
*     // 发送CAN消息
*     FkVciCanDataType msg = {0};
*     msg.CanID = 0x100;
*     msg.DLC = 8;
*     for (int i = 0; i < 8; i++) msg.Data[i] = i;
*     FkVciTransmitCAN(0, 0, &msg, 1);
*
*     // 接收CAN消息
*     FkVciCanDataType rxMsgs[10];
*     UINT32_T msgCount = 10;
*     FkVciReceiveCAN(0, 0, rxMsgs, &msgCount, 1000);  // 最多等待1秒
*
*     // 开始周期性发送
*     int periodId = FkVciStartPeriodCAN(0, 0, &msg, 100);  // 每100毫秒
*
*     // 完成后停止周期性发送
*     FkVciStopPeriodCAN(0, 0, periodId);
*
*     // 完成后重置CAN通道
*     FkVciResetCAN(0, 0);
*
*     // === LIN通信示例 ===
*     // 以主模式初始化LIN2，波特率为19200 bps
*     FkVciInitLIN(0, 1, 0, 19200);
*
*     // 发送LIN消息
*     FkVciLinDataType linMsg = {0};
*     linMsg.LinID = 0x10;
*     linMsg.DLC = 8;
*     linMsg.CheckType = 1;  // 增强型校验和
*     linMsg.MsgType = 1;    // 主写入
*     for (int i = 0; i < 8; i++) linMsg.Data[i] = i;
*     FkVciTransmitLIN(0, 1, &linMsg, 1);
*
*     // 接收LIN消息
*     FkVciLinDataType rxLinMsgs[10];
*     UINT32_T linMsgCount = 10;
*     FkVciReceiveLIN(0, 1, rxLinMsgs, &linMsgCount, 1000);
*
*     // 完成后重置LIN通道
*     FkVciResetLIN(0, 1);
*
*     // === UDS诊断示例 ===
*     // 确保用于UDS的CAN通道已初始化 (复用上面的CAN通道0)
*     UINT32_T udsId = 0;
*     // 为设备0的CAN通道0创建一个UDS服务实例
*     result = FkVciCreateUdsService(0, 0, 0x7E0, 0x7E8, &udsId);
*     if (result == 0) {
*         // 配置UDS参数并启动心跳 (每2秒发送一次)
*         FkVciSetUdsConfig(udsId, "--testerPresentInterval 2000 --testerPresentSubFunc 80 --testerPresentId 7DF");
*
*         // 发送一个同步的UDS请求 (例如：读取ECU识别码)
*         UINT8_T request[] = {0x22, 0xF1, 0x90};
*         UINT8_T response[4095];
*         UINT32_T responseLen = sizeof(response);
*
*         result = FkVciUdsRequestSync(udsId, request, sizeof(request), response, &responseLen);
*         if (result >= 0) { // 0表示完全成功, >0表示有警告(如缓冲区不足)
*             // 请求成功，处理response中的数据
*             printf("UDS Response Received (%d bytes)\n", responseLen);
*         } else {
*             // 请求失败，打印错误信息
*             printf("UDS Sync Request failed with code %d: %s\n", result, FkVciGetUdsErrorString(result));
*         }
*
*         // 停止心跳
*         FkVciSetUdsConfig(udsId, "--testerPresentInterval 0");
*
*         // 销毁UDS服务实例
*         FkVciDestroyUdsService(udsId);
*     }
*
*     // 所有操作完成后始终关闭设备
*     FkVciCloseDev(0);
*     // FkVciCloseLog();
*   }
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2024 丰柯科技。保留所有权利。
*
* 本软件按许可协议提供。使用本软件即表示接受许可条款。
*
* 作者: leiwei
* 版本: v4.2.0
* 日期: 2025-11-06
*----------------------------------------------------------------------------*/

#ifndef FKVCI_API_H
#define FKVCI_API_H

#ifdef _WIN32
#ifdef BUILD_FKVCI_API
#define FKVCI_API extern "C" __declspec(dllexport)
#else
#define FKVCI_API extern "C" __declspec(dllimport)
#endif
#else
#define FKVCI_API extern "C"
#endif

typedef unsigned char                                       UINT8_T;
typedef unsigned short                                      UINT16_T;
typedef unsigned int                                        UINT32_T;
typedef unsigned long long                                  UINT64_T;

// 正错误码，表示可接受错误，不影响后续执行
// 负错误码，表示发送异常，影响后续执行

/* 通用错误代码 */
#define FKVCI_ERROR_INVALID_PARAM                           (-1)   /* 无效的输入参数 */
#define FKVCI_ERROR_SYSTEM_EXCEPTION                        (-2)   /* 系统异常发生 */
#define FKVCI_ERROR_NOT_SUPPORTED                           (-3)   /* 操作不支持 */
#define FKVCI_ERROR_NO_DEVICES                              (-9)   /* 没有可用设备 */
#define FKVCI_ERROR_PERIOD_SEND_LIMIT                       (-11)  /* 达到周期发送限制 */
#define FKVCI_ERROR_PERIOD_REMOVE_FAILED                    (12)   /* 删除周期ID失败 */
#define FKVCI_ERROR_FILTER_LIMIT                            (61)   /* 达到过滤限制 */

/* 设备错误代码 */
#define FKVCI_ERROR_INVALID_INDEX                           (-101)  /* 无效的设备索引 */
#define FKVCI_ERROR_NOT_FOUND                               (-102)  /* 未找到设备 */
#define FKVCI_ERROR_NOT_OPENED                              (-103)  /* 设备未打开 */

/* 通讯错误代码 */
#define FKSOCKET_ERROR_CONNECT_FAILED                       (-401)  /* 连接设备失败 */
#define FKSOCKET_ERROR_NOT_CONNECTED                        (-402)  /* 未连接设备 */
#define FKSOCKET_ERROR_SEND_FAILED                          (-411)  /* 发送消息失败 */
#define FKSOCKET_ERROR_RESPONSE_TIMEOUT                     (-412)  /* 消息响应超时 */

/* 通道错误代码 */
#define FKVCI_ERROR_INVALID_CHANNEL                         (-601)  /* 无效的通道索引 */
#define FKVCI_ERROR_CHANNEL_BUFFER_EMPTY                    (621)   /* 通道缓冲区为空 */

/* CAN通道错误代码 */
#define FKCAN_ERROR_OPEN_FAILED                             (-1001)  /* CAN通道打开失败 */
#define FKCAN_ERROR_CLOSE_FAILED                            (-1002)  /* CAN通道关闭失败 */
#define FKCAN_ERROR_INVALID_HANDLE                          (-1003)  /* 无效的通道句柄 */
#define FKCAN_ERROR_CONFIG_FAILED                           (-1011)  /* 配置失败 */
#define FKCAN_ERROR_SET_TERMR_FAILED                        (-1021)  /* 设置终端电阻失败 */

/* KWP错误代码 */
#define FKKWP_ERROR_FILE_CHECK_FAILED                       (-3011)  /* 文件校验失败 */
#define FKKWP_ERROR_FILE_EXCEPTION                          (-3012)  /* 文件读写异常 */
#define FKKWP_ERROR_FILE_TRANSMIT_FAILED                    (-3013)  /* 文件传输失败 */

/* LIN通道错误代码 */
#define FKLIN_ERROR_OPEN_FAILED                             (-5001)  /* LIN通道打开失败 */
#define FKLIN_ERROR_CLOSE_FAILED                            (-5002)  /* LIN通道关闭失败 */

#ifdef BUILD_FKKWP_API
#define FKVCI_PROTOCOL_DATA_MAX_LEN                         314     /* 注意：结构体建议保持8字节对齐 320 */
#else
#define FKVCI_PROTOCOL_DATA_MAX_LEN                         122     /* 注意：结构体建议保持8字节对齐 128 */
#endif

/*
 * To ensure UDS result codes are unique and do not conflict with other modules (e.g., VCI),
 * they are based directly on the ISO 15765 standard number. This approach is simple,
 * readable, and safe for all integer sizes.
 */
#define VCI_UDS_ERROR_BASE   (-15765)
#define VCI_UDS_WARNING_BASE ( 15765)


/**
 * @brief Defines the maximum payload size for a single UDS message according to ISO 15765-2.
 * This is limited by the 12-bit length field in the First Frame (0xFFF = 4095).
 */
#define VCI_UDS_MAX_PAYLOAD_SIZE 4095U

/**
 * @brief Defines the result codes for VCI UDS operations, based on ISO 15765-2.
 *
 * Convention:
 * - 0: Success.
 * - Negative values (e.g., -15765 - 101): Errors that terminated the operation.
 * - Positive values (e.g., 15765 + 304): Warnings or success with a special condition.
 */
typedef enum {
    /* =========================================================================
     * == Positive Values: Warnings / Success with Status
     * ========================================================================= */

    /**
     * @brief The provided response buffer was too small to hold the complete data.
     * The buffer has been filled with a truncated portion of the response.
     * The `response_len` parameter of the read function will contain the required size.
     */
    VCI_UDS_RESULT_BUFFER_TOO_SMALL = VCI_UDS_WARNING_BASE + 304,


    /* =========================================================================
     * == 0: Success
     * ========================================================================= */

    /** @brief Operation completed successfully with a positive response from the ECU. */
    VCI_UDS_RESULT_OK = 0,


    /* =========================================================================
     * == Negative Values: Errors
     * ========================================================================= */

    /* --- General Protocol Errors (Offset 1xx) --- */
    /**
     * @brief The ECU returned a Negative Response Code (NRC).
     * The specific NRC value can be found as the third byte in the response payload.
     */
    VCI_UDS_RESULT_NEGATIVE_RESPONSE = VCI_UDS_ERROR_BASE - 101,

    /* --- ISO-TP Layer Errors (Offset 2xx) --- */
    /** @brief Timeout waiting for the first response frame (SF or FF) from the ECU (N_As/P2). */
    VCI_UDS_RESULT_TIMEOUT_A = VCI_UDS_ERROR_BASE - 201,

    /** @brief Timeout waiting for a Flow Control (FC) frame from the ECU (N_Bs). */
    VCI_UDS_RESULT_TIMEOUT_BS = VCI_UDS_ERROR_BASE - 202,

    /** @brief Timeout waiting for a Consecutive Frame (CF) from the ECU (N_Cr). */
    VCI_UDS_RESULT_TIMEOUT_CR = VCI_UDS_ERROR_BASE - 203,

    /** @brief Timeout after receiving NRC 0x78 (Response Pending) (N_Ar/P2*). */
    VCI_UDS_RESULT_TIMEOUT_P2_STAR = VCI_UDS_ERROR_BASE - 204,

    /** @brief The ECU sent a Flow Control frame with an 'Overflow' status. */
    VCI_UDS_RESULT_FC_OVERFLOW = VCI_UDS_ERROR_BASE - 205,

    /** @brief Received a Consecutive Frame with an incorrect sequence number. */
    VCI_UDS_RESULT_SEQUENCE_ERROR = VCI_UDS_ERROR_BASE - 206,

    /** @brief Received an unexpected ISO-TP frame type for the current state. */
    VCI_UDS_RESULT_UNEXPECTED_FRAME = VCI_UDS_ERROR_BASE - 207,

    /** @brief Exceeded the client's limit for receiving NRC 0x78 (Response Pending). */
    VCI_UDS_RESULT_NRC78_LIMIT_EXCEEDED = VCI_UDS_ERROR_BASE - 208,

    /* --- API & Client-Side Errors (Offset 3xx) --- */
    /** @brief The underlying CAN frame sending function failed. */
    VCI_UDS_RESULT_SEND_FAILED = VCI_UDS_ERROR_BASE - 301,

    /** @brief The request payload exceeds the maximum size supported by ISO-TP (4095 bytes). */
    VCI_UDS_RESULT_PAYLOAD_TOO_LARGE = VCI_UDS_ERROR_BASE - 302,

    /** @brief A function was called with invalid parameters (e.g., null pointers). */
    VCI_UDS_RESULT_INVALID_PARAM = VCI_UDS_ERROR_BASE - 303,

    /** @brief The provided UDS instance ID is invalid or does not exist. */
    VCI_UDS_RESULT_INVALID_UDS_ID = VCI_UDS_ERROR_BASE - 305,

    /** @brief Failed to parse or apply the provided configuration. */
    VCI_UDS_RESULT_CONFIG_FAILED = VCI_UDS_ERROR_BASE - 306,

    /** @brief The maximum number of UDS instances has been reached. */
    VCI_UDS_RESULT_INSTANCE_LIMIT_EXCEEDED = VCI_UDS_ERROR_BASE - 307,

    /** @brief The operation was aborted by a user request. */
    VCI_UDS_RESULT_ABORTED = VCI_UDS_ERROR_BASE - 308,

    /* --- Asynchronous Operation Errors (Offset 4xx) --- */
    /** @brief For async `readResponse`, no response was available in the queue. */
    VCI_UDS_RESULT_NO_RESPONSE_IN_QUEUE = VCI_UDS_ERROR_BASE - 401,

    /** @brief The asynchronous request queue is full; the request was dropped. */
    VCI_UDS_RESULT_QUEUE_FULL = VCI_UDS_ERROR_BASE - 402,

    /* --- Internal Library Errors (Offset 5xx) --- */
    /** @brief An internal logic error occurred within the library. */
    VCI_UDS_RESULT_INTERNAL_ERROR = VCI_UDS_ERROR_BASE - 501,

} VciUdsResultCode;

#pragma pack(push, 4)

/**
 * @brief CAN消息数据结构
 *
 * 包含CAN或CAN FD帧的所有信息，包括ID、数据长度、
 * 标志位、时间戳和载荷数据。
 */
typedef struct _FkVciCanDataType
{
    UINT32_T CanID;         /* CAN ID（11位标准或29位扩展） */
    UINT8_T  DLC;           /* 数据长度代码（CAN：0-8，CAN FD：0-64） */
    UINT8_T  FLAG;          /* 帧标志位：
                               bit0: 0=标准帧，1=扩展帧
                               bit1: 0=数据帧，1=远程帧
                               bit3: 1=CAN FD BRSEN（位速率切换使能）
                               bit6: 0=CAN，1=CAN FD */
    UINT8_T  REV1;          /* 保留供将来使用 */
    UINT8_T  REV2;          /* 发送时默认0， 接收时表示帧方向：0x01=发送，0x02=接收，0x04=错误 */
    UINT32_T TimesampL;     /* 发送时默认0， 接收时表示时间戳低32位（单位：0.1微秒） */
    UINT32_T TimesampH;     /* 发送时默认0， 接收时表示时间戳高32位 */
    UINT8_T  Data[64];      /* 帧数据（接收时当REV2=错误时，前4字节包含错误代码） */
} FkVciCanDataType;

typedef struct _FkVciKwpDataType
{
    UINT8_T ClientAddr;
    UINT8_T EcuAddr;
    UINT16_T DLC;
    UINT32_T TimesampL;
    UINT32_T TimesampH;
    UINT8_T  Data[256];
} FkVciKwpDataType;

/**
 * @brief LIN消息数据结构
 *
 * 包含LIN帧的所有信息，包括ID、数据长度、
 * 校验和类型、消息类型和载荷数据。
 */
typedef struct _FkVciLinDataType
{
    UINT8_T  LinID;         /* LIN ID（0-63） */
    UINT8_T  DLC;           /* 数据长度（0-8字节） */
    UINT8_T  CheckType;     /* 校验和类型：0=标准，1=增强 */
    UINT8_T  MsgType;       /* 消息类型：
                               0=未知
                               1=主写入
                               2=主读取
                               3=从写入
                               4=从读取
                               5=清除数据 */
    UINT8_T  PID;           /* 发送时默认0， 接收时表示受保护ID（带奇偶校验的ID） */
    UINT8_T  CheckSum;      /* LIN校验和值 */
    UINT8_T  REV1;          /* 发送时默认0， 接收时表示帧方向：
                               0x00=主读取
                               0x01=从读取
                               0x10=主写入
                               0x11=从写入 */
    UINT8_T  REV2;          /* 保留供将来使用 */
    UINT32_T TimesampL;     /* 发送时：间隔（毫秒），默认0
                               接收时：时间戳低32位（单位：0.1微秒） */
    UINT32_T TimesampH;     /* 接收时：时间戳高32位 */
    UINT8_T  Data[8];       /* 帧数据（最多8字节） */
} FkVciLinDataType;

/**
 * @brief CAN和LIN数据类型的联合体
 *
 * 允许通过单一数据结构统一处理CAN和LIN消息。
 */
typedef union _FkVciDataType
{
    FkVciCanDataType Can;   /* CAN/CAN FD消息数据 */
    FkVciLinDataType Lin;   /* LIN消息数据 */
} FkVciDataType;

/**
 * @brief 完整消息结构
 *
 * 包含设备索引、通道、时间戳和实际
 * 消息数据（CAN或LIN）。
 */
typedef struct _FkVciMessage
{
    UINT8_T index;          /* 设备索引 */
    UINT8_T channel;        /* 通道索引 */
    UINT64_T timestamp;     /* 消息时间戳 */
    FkVciDataType frame;    /* 消息数据（CAN或LIN） */
} FkVciMessage;

/// <summary>
/// CANFD通道高级配置结构体
/// </summary>
typedef struct _FkVciCanFdConfig {
    UINT32_T baudRate;                  // CAN波特率
    UINT32_T fdBaudRate;                // CANFD波特率
    UINT8_T nSeg1;                      // 标称位时间第一段参数
    UINT8_T nSeg2;                      // 标称位时间第二段参数
    UINT8_T dSeg1;                      // 数据位时间第一段参数
    UINT8_T dSeg2;                      // 数据位时间第二段参数
    UINT8_T terminalResistorEnabled;    // 终端电阻使能，0: 不使能 >0: 使能
} FkVciCanFdConfig;

typedef struct _FkVciProtocolData {
    UINT8_T protocolId;
    UINT8_T protocolCmd{ 0 };
    UINT8_T protocolChannel;
    UINT8_T rev{ 0 };
    UINT16_T dataLen{ 0 };
    UINT8_T data[FKVCI_PROTOCOL_DATA_MAX_LEN];
} FkVciProtocolData;

/**
 * @struct VciUdsFunctionalResponseData
 * @brief Holds a single, complete response from one ECU during a functional request.
 *
 * This structure is used to retrieve data from the functional response queue. It contains
 * the source address of the responding ECU and the complete data payload.
 *
 * @warning This structure is large (~4KB) due to the fixed-size data buffer. Avoid
 *          creating large arrays of this structure on the stack to prevent stack overflow.
 *          It is best used as a single instance on the stack or allocated on the heap.
 */
typedef struct {
    /** @brief The CAN ID of the ECU that sent this response (e.g., 0x7E8). */
    unsigned int source_address;

    /** @brief The actual length of the received data payload in bytes. */
    unsigned int data_len;

    /** @brief A buffer to hold the received data payload. */
    unsigned char data[VCI_UDS_MAX_PAYLOAD_SIZE];

    unsigned char reserve;  // for 4 byte alignment
	
} VciUdsFunctionalResponseData;

#pragma pack(pop)

/**
 * @brief 打开日志，用于调试和故障诊断
 *
 * 建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源
 *
 * @param logFile 日志文件路径，形如:logs/fkvci.log
 * @param level 日志等级，-1:默认输出（默认1）0:DEBUG 1:INFO 2:WARN 3:ERROR
 * @param maxSize 文件大小, 范围(1~100), 单位M. -1:默认10M
 * @param maxFiles 文件个数, 范围(1~20), -1:默认保留10个文件
 * @return 0:打开成功 其它:失败错误码
 */
FKVCI_API int FkVciOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志
 *
 * 安全关闭日志记录系统，释放相关资源
 *
 * @return 0:关闭成功 其它:失败错误码
 */
FKVCI_API int FkVciCloseLog();

/**
 * @brief 扫描局域网内的VCI设备
 *
 * 扫描会清空现有的设备列表，并用实际扫描到的设备信息进行填充。
 * 如果没有扫描到任何设备，设备列表将为空。
 *
 * @param deviceIndices [out] 用于存储扫描到的设备索引号的数组。
 * @param count [in|out] 输入时表示deviceIndices数组的最大长度，输出时表示实际扫描到的设备数量。
 * @param timeout 扫描超时时间，单位毫秒。 建议100~2000ms之间
 * @return 0:扫描成功 其它:失败错误码
 */
FKVCI_API int FkVciScanDevice(int* deviceIndices, UINT8_T* count, UINT32_T timeout);

/**
 * @brief 手动创建VCI设备
 *
 * 默认创建16个设备。每个设备8通道CAN/LIN
 *
 * @return 0:创建成功 其它:失败错误码
 */
FKVCI_API int FkVciCreateDevices();

/**
 * @brief 获取指定设备支持的CAN通道数量
 *
 * 在调用 FkVciScanDevice 之后或使用默认设备时调用此函数。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return >=0: CAN通道数量, <0: 失败错误码
 */
FKVCI_API int FkVciGetCanChannelCount(int deviceIndex);

/**
 * @brief 获取指定设备支持的LIN通道数量
 *
 * 在调用 FkVciScanDevice 之后或使用默认设备时调用此函数。
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return >=0: LIN通道数量, <0: 失败错误码
 */
FKVCI_API int FkVciGetLinChannelCount(int deviceIndex);

/**
 * @brief 打开设备
 *
 * 通过指定的设备索引连接到硬件设备，建立通信链路
 *
 * @param deviceType 设置类型（暂未启用）0:LAN 1:USB 2:COM
 * @param deviceIndex 设备索引:0x00~0x0F(对应ip:192.168.201.130~ip:192.168.201.145)
 * @param reserved 默认0，1~254表示绑定本地网卡(本地ip:192.168.reserved)
 * @return 0:打开成功 其它:失败错误码
 */
FKVCI_API int FkVciOpenDev(int deviceType, int deviceIndex, int reserved);

/**
 * @brief 关闭设备
 *
 * 安全地断开与硬件设备的连接，释放通信资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F 特殊值-1:停止所有打开的设备
 * @return 0:关闭成功 其它:失败错误码
 */
FKVCI_API int FkVciCloseDev(int deviceIndex);

/**
 * @brief 查询设备版本信息
 *
 * 读取设备固件版本信息，格式为: B0(主版本号), B1(年), B2(月), B3(日)
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return 0:查询失败 其它:版本信息 B0:version B1:year B2:month B3:day
 */
FKVCI_API UINT32_T FkVciGetVersion(int deviceIndex);

/**
 * @brief 获取设备基准时间
 *
 * 获取设备当前内部时间基准点，用于时间同步和消息时间戳校准
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @return 正数:获取成功 0:获取失败
 */
FKVCI_API UINT64_T FkVciGetBaseTime(int deviceIndex);

/**
 * @brief 初始化CAN通道（打开通道）
 *
 * 配置并打开指定的CAN通道，设置基本通信参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param baudRate 同步波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCAN(int deviceIndex, int channelIndex, UINT32_T baudRate);

/**
 * @brief 初始化CANFD通道（打开通道）
 *
 * 配置并打开指定的CANFD通道，设置基本通信参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param baudRate CAN波特率
 * @param fdBaudRate CANFD波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCANFD(int deviceIndex, int channelIndex, UINT32_T baudRate, UINT32_T fdBaudRate);

/**
 * @brief 使用高级配置结构初始化CANFD通道（打开通道）
 *
 * 使用详细配置参数初始化CANFD通道，提供更精确的位时序控制
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param config CANFD高级配置结构体
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitCANFDAdvanced(int deviceIndex, int channelIndex, const FkVciCanFdConfig* config);

/**
 * @brief 复位CAN通道（关闭通道）
 *
 * 停止指定CAN通道的所有活动并释放资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:复位成功 其它:失败错误码
 */
FKVCI_API int FkVciResetCAN(int deviceIndex, int channelIndex);

/**
 * @brief 清空CAN通道接收缓存
 *
 * 清除指定CAN通道的接收消息缓冲区
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号 特殊值-1:清空所有通道缓存
 * @return 0:清空成功 其它:失败错误码
 */
FKVCI_API int FkVciClearCAN(int deviceIndex, int channelIndex);

/**
 * @brief 接收CAN消息
 *
 * 从指定CAN通道读取接收到的消息，默认每个通道缓存2000条数据
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param messages CAN消息数组
 * @param len [in|out] 输入时表示想要接收消息条数，输出时表示实际接收消息条数
 * @param timeout 读取等待时间，单位ms
 *              0：表示非阻塞读取
 *              >0： 表示读取超时时间
 * @return 0:接收成功 其它:失败错误码
 */
FKVCI_API int FkVciReceiveCAN(int deviceIndex, int channelIndex, FkVciCanDataType *messages, UINT32_T *len, UINT32_T timeout);

/**
 * @brief 发送CAN消息
 *
 * 向指定CAN通道发送一个或多个消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param messages CAN消息数组
 * @param len 发送消息条数，最大值：0x7F
 * @return 0:发送成功 其它:失败错误码
 */
FKVCI_API int FkVciTransmitCAN(int deviceIndex, int channelIndex, const FkVciCanDataType *messages, UINT32_T len);

/**
 * @brief 周期发送CAN消息
 *
 * 设置一个CAN消息以固定周期重复发送
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param message CAN消息
 * @param periodTime 周期时间(毫秒)
 * @return 正数: 周期消息id 其它:失败错误码
 */
FKVCI_API int FkVciStartPeriodCAN(int deviceIndex, int channelIndex, const FkVciCanDataType *message, UINT32_T periodTime);

/**
 * @brief 周期发送CAN消息(首帧发送延迟）
 *
 * 设置一个CAN消息以固定周期重复发送
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param message CAN消息
 * @param periodTime 周期时间(毫秒)
 * @param delayTime 首帧延迟时间(毫秒)
 * @return 正数: 周期消息id 其它:失败错误码
 */
FKVCI_API int FkVciStartPeriodCANWithDelay(int deviceIndex, int channelIndex, const FkVciCanDataType *message, UINT32_T periodTime, UINT32_T delayTime);

/**
 * @brief 停止周期发送CAN消息
 *
 * 停止一个或多个周期性发送的CAN消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param id 周期消息id  特殊值-1:停止当前通道所有周期消息
 * @return 返回值
 *     停止单条周期消息：
 *         - 0: 成功
 *         - 其它: 失败
 *     停止当前通道周期消息:
 *         - >0: 停止的通道周期消息条数
 *         - 0: 当前通道没有正在运行的周期消息
 */
FKVCI_API int FkVciStopPeriodCAN(int deviceIndex, int channelIndex, int id);

/**
 * @brief 过滤CAN消息（非线程安全）
 *
 * 设置CAN消息ID过滤，只接收指定ID的消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param ids 过滤的消息ID数组
 * @param len 过滤数组长度
 * @return 0:过滤设置成功 其它:失败错误码
 */
FKVCI_API int FkVciStartFilterCAN(int deviceIndex, int channelIndex, UINT32_T *ids, UINT32_T len);

/**
 * @brief 停止过滤CAN消息（非线程安全）
 *
 * 清除CAN消息过滤设置，接收所有消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @return 0:停止过滤成功 其它:失败错误码
 */
FKVCI_API int FkVciStopFilterCAN(int deviceIndex, int channelIndex);

/**
 * @brief 设置终端电阻使能状态
 *
 * 控制CAN通道的终端电阻是否启用
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex CAN通道号
 * @param enable 1:使能 0:不使能
 * @return 0:设置成功 其它:失败错误码
 */
FKVCI_API int FkVciSetTerminalResistorCAN(int deviceIndex, int channelIndex, int enable);

/**
 * @brief 获取CAN总线负载率(建议调用周期1000ms)
 *
 * 监测CAN总线利用率，评估网络通信情况
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param busLoad 通道负载率 100.0表示100%
 * @param channelSize 通道数量 (busLoad数组长度应>=channelSize)
 * @return 0:获取成功 其它:失败错误码
 */
FKVCI_API int FkVciGetBusLoadCAN(int deviceIndex, double* busLoad, int channelSize);

///*******************************************************************************/

/**
 * @brief 初始化LIN通道（打开通道）
 *
 * 配置并打开指定的LIN通道，设置通信模式和参数
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param mode 0:主模式 1:从模式
 * @param baudRate 波特率
 * @return 0:初始化成功 其它:失败错误码
 */
FKVCI_API int FkVciInitLIN(int deviceIndex, int channelIndex, UINT32_T mode, UINT32_T baudRate);

/**
 * @brief 复位LIN通道（关闭通道）
 *
 * 停止指定LIN通道的所有活动并释放资源
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @return 0:复位成功 其它:失败错误码
 */
FKVCI_API int FkVciResetLIN(int deviceIndex, int channelIndex);

/**
 * @brief 接收LIN消息
 *
 * 从指定LIN通道读取接收到的消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param messages LIN消息数组
 * @param len [in|out] 输入时表示想要接收消息条数，输出时表示实际接收消息条数
 * @param timeout 等待时间，单位ms
 * @return 0:接收成功 其它:失败错误码
 */
FKVCI_API int FkVciReceiveLIN(int deviceIndex, int channelIndex, FkVciLinDataType *messages, UINT32_T *len, UINT32_T timeout);

/**
 * @brief 发送LIN消息
 *
 * 向指定LIN通道发送一个或多个消息
 *
 * @param deviceIndex 设备索引:0x00~0x0F
 * @param channelIndex LIN通道号
 * @param messages LIN消息数组
 * @param len 发送消息条数，最大值：0x7F
 * @return 0:发送成功(加入待发送队列) 其它:失败错误码
 */
FKVCI_API int FkVciTransmitLIN(int deviceIndex, int channelIndex, const FkVciLinDataType *messages, UINT32_T len);

/*******************************************************************************
 * UDS (ISO 15765) 功能
 * 支持 ISO 15765-2/ISO 15765-4
 *******************************************************************************/

/**
 * @brief 将UDS错误码转换为可读的字符串描述
 *
 * @param uds_error_code UDS操作返回的错误码。
 * @return 指向描述错误信息的静态字符串的指针。
 */
FKVCI_API const char* FkVciGetUdsErrorString(int uds_error_code);

/**
 * @brief 创建一个UDS服务实例
 *
 * 为指定的CAN通道创建一个UDS诊断服务实例。如果该通道已存在实例，则返回现有实例的ID。
 *
 * @param deviceIndex VCI设备索引。
 * @param channelIndex CAN通道索引。
 * @param reqId UDS物理请求的CAN ID (例如 0x7E0)。
 * @param resId UDS物理响应的CAN ID (例如 0x7E8)。
 * @param udsId [out] 用于接收创建的服务实例的唯一ID。
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciCreateUdsService(int deviceIndex, int channelIndex, UINT32_T reqId, UINT32_T resId, UINT32_T* udsId);

/**
 * @brief 销毁一个UDS服务实例
 *
 * @param udsId 要销毁的服务实例ID。
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciDestroyUdsService(UINT32_T udsId);

/**
 * @brief 配置UDS服务实例的参数
 *
 * 使用命令行风格的字符串来配置ISO-TP层的时序、流控、CAN ID以及其他UDS服务参数。
 * **此函数也用于控制自动心跳（Tester Present）的启停。**
 * 未指定的参数将保持其当前值或默认值。
 *
 * @param udsId 服务实例ID。
 * @param commands 配置字符串，例如 "--stMin 0A --timeoutAr 5000 --testerPresentInterval 3000"。
 *                 支持的参数及其默认值:
 *
 *                 **[连接与地址]**
 *                 - `--canType <0|1|2>`: CAN帧类型 (0: Classic, 1: FD, 2: FD+BRS) (默认: 0)。
 *                 - `--funcId <hex>`: 功能请求CAN ID (默认: 7DF)。
 *                 - `--funcResMin <hex>`: 功能响应监听的最小CAN ID (默认: 700)。
 *                 - `--funcResMax <hex>`: 功能响应监听的最大CAN ID (默认: 7FF)。
 *
 *                 **[ISO-TP 时序与流控]**
 *                 - `--stMin <hex>`: Separation Time (STmin), 范围 00-FF (默认: 00)。
 *                 - `--blockSize <hex>`: Block Size (BS), 范围 00-FF, 00表示无限制 (默认: 00)。
 *                 - `--timeoutAs <ms>`: N_As/P2, 发送方等待响应超时 (默认: 1000 ms)。
 *                 - `--timeoutAr <ms>`: N_Ar/P2*, 接收方等待最终响应超时 (默认: 5000 ms)。
 *                 - `--timeoutBs <ms>`: N_Bs, 发送方等待流控帧超时 (默认: 1000 ms)。
 *                 - `--timeoutCr <ms>`: N_Cr, 接收方等待连续帧超时 (默认: 1000 ms)。
 *                 - `--maxNrc78 <count>`: 最大连续接收NRC 0x78的次数 (默认: 5)。
 *
 *                 **[应用层行为]**
 *                 - `--testerPresentInterval <ms>`: 自动发送心跳包的间隔 (默认: 2000 ms)。
 *                                                **设置为 > 0 的值会启动或更新心跳。**
 *                                                **设置为 0 会停止心跳。**
 *                 - `--testerPresentSubFunc <hex>`: 心跳包的子功能 (默认: 80)。
 *                 - `--testerPresentId <hex>`: 用于发送心跳包的CAN ID (默认: 0)。
 *                                            **如果为0, 则使用物理请求ID。可设为功能ID。**
 *
 *                 **[帧格式化]**
 *                 - `--paddingSize <dec>`: CAN帧填充目标字节数 (仅经典CAN)，0表示禁用 (默认: 0)。
 *                 - `--paddingByte <hex>`: 用于填充的字节值 (默认: AA)。
 *
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciSetUdsConfig(UINT32_T udsId, const char* commands);

/**
 * @brief 发送同步的UDS请求 (物理寻址, 阻塞)
 *
 * 发送一个UDS请求并等待响应。函数会阻塞直到收到完整响应或超时。
 *
 * @param udsId 服务实例ID。
 * @param request_pdu 指向请求数据的指针。
 * @param request_len 请求数据的长度。
 * @param response_pdu [out] 用于存储响应数据的缓冲区。
 * @param response_len [in|out] 输入时为缓冲区最大长度，输出时为实际响应数据长度。
 * @return 0: 成功, <0: 错误码, >0: 警告码 (例如 VCI_UDS_RESULT_BUFFER_TOO_SMALL)。
 */
FKVCI_API int FkVciUdsRequestSync(UINT32_T udsId, const UINT8_T* request_pdu, UINT32_T request_len, UINT8_T* response_pdu, UINT32_T* response_len);

/**
 * @brief 发送异步的UDS请求 (物理寻址, 非阻塞)
 *
 * 将一个UDS请求放入发送队列后立即返回。响应需要通过 `FkVciUdsReadResponse` 读取。
 *
 * @param udsId 服务实例ID。
 * @param request_pdu 指向请求数据的指针。
 * @param request_len 请求数据的长度。
 * @return 0: 成功入队, <0: 错误码。
 */
FKVCI_API int FkVciUdsRequestAsync(UINT32_T udsId, const UINT8_T* request_pdu, UINT32_T request_len);

/**
 * @brief 读取异步UDS请求的响应 (物理寻址, 阻塞)
 *
 * 从响应队列中读取一条响应。如果队列为空，函数会阻塞直到有响应或超时。
 *
 * @param udsId 服务实例ID。
 * @param response_pdu [out] 用于存储响应数据的缓冲区。
 * @param response_len [in|out] 输入时为缓冲区最大长度，输出时为实际响应数据长度。
 * @param timeout_ms 等待超时时间 (毫秒)。
 * @return 0: 成功, <0: 错误码, >0: 警告码 (例如 VCI_UDS_RESULT_BUFFER_TOO_SMALL)。
 */
FKVCI_API int FkVciUdsReadResponse(UINT32_T udsId, UINT8_T* response_pdu, UINT32_T* response_len, UINT32_T timeout_ms);

/**
 * @brief 发送功能性UDS请求 (功能寻址, 非阻塞)
 *
 * 将一个功能性UDS请求（广播）放入发送队列后立即返回。响应需要通过 `FkVciUdsReadFunctionalResponses` 读取。
 *
 * @param udsId 服务实例ID。
 * @param request_pdu 指向请求数据的指针。
 * @param request_len 请求数据的长度。
 * @return 0: 成功入队, <0: 错误码。
 */
FKVCI_API int FkVciUdsRequestFunctional(UINT32_T udsId, const UINT8_T* request_pdu, UINT32_T request_len);

/**
 * @brief 读取功能性UDS请求的响应 (功能寻址, 阻塞)
 *
 * 从功能响应队列中批量读取来自多个ECU的响应。此函数会首先等待指定的
 * 超时时间以接收第一个响应，然后会立即尝试读取队列中所有剩余的响应，
 * 直到填满用户提供的数组或队列为空。
 *
 * @param udsId 服务实例ID。
 * @param response_array [out] 用于存储响应数据的结构体数组。
 * @param array_len [in|out] 输入时为 `response_array` 的容量，输出时为实际读取到的响应数量。
 * @param timeout_ms 等待第一个响应的超时时间 (毫秒)。
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciUdsReadFunctionalResponses(UINT32_T udsId, VciUdsFunctionalResponseData* response_array, UINT32_T* array_len, UINT32_T timeout_ms);

/**
 * @brief 清空UDS异步队列
 *
 * 清除指定服务实例中所有待处理的异步请求（物理和功能）和已接收的响应。
 *
 * @param udsId 服务实例ID。
 * @return 0: 成功, <0: 错误码。
 */
FKVCI_API int FkVciUdsClearAsyncQueues(UINT32_T udsId);

#endif  //FKVCI_API_H
