#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# UDSCANServerTest.py - UDS on CAN ECU模拟器的交互式命令行测试工具。

import sys
import signal
import shlex
import logging
import time
import platform
from UDSCANServer import UDSCANServer
from FKVciMessage import get_status_description

# --- 配置顶层日志记录器 ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)-18s - %(levelname)-8s - %(message)s'
)

def safe_parse_int(s):
    """将字符串安全地解析为整数，支持0x前缀的十六进制。"""
    if not isinstance(s, str): return None
    try:
        return int(s, 0)
    except (ValueError, TypeError):
        return None

class UDSCANServerTest:
    def __init__(self):
        self.ecu = UDSCANServer()

    def cleanup(self):
        """清理资源。"""
        print("\n[清理] 正在停止服务并关闭设备...")
        self.ecu.stop_service() # <--- 修改点
        # 使用-1关闭所有已打开的设备
        self.ecu.close_device(-1)
        time.sleep(1.2) # 等待底层资源完全释放
        self.ecu.close_log()
        print("[退出] 已关闭日志，程序结束。")

    def parse_args(self, line):
        """使用shlex安全地解析命令行输入。"""
        try:
            return shlex.split(line)
        except ValueError:
            print("[错误] 命令格式不正确，请检查引号是否闭合。")
            return []

    def extract_arg(self, args, key, default=None, cast_func=str):
        """从参数列表中提取指定键的值。"""
        try:
            if key in args:
                idx = args.index(key)
                if idx + 1 < len(args):
                    return cast_func(args[idx + 1])
        except (ValueError, IndexError):
            pass
        return default

    def run(self):
        """主运行循环，等待并处理用户命令。"""
        print("=" * 60)
        print(f"UDS on CAN ECU 模拟器 v1.0.0 {platform.architecture()[0]}")
        print("=" * 60)
        print("输入 --help 查看帮助，--exit 或 Ctrl+C 退出")
        
        running = True
        while running:
            try:
                raw_line = input("ECU模拟器> ").strip()
                if not raw_line: continue
                
                args = self.parse_args(raw_line)
                if not args: continue
                
                cmd = args[0].lower()
                
                if cmd == '--exit':
                    running = False
                elif cmd == '--help':
                    self.print_help()
                elif cmd == '--open':
                    self.do_open(args)
                elif cmd == '--close':
                    self.do_close(args)
                elif cmd == '--initcan':
                    self.do_initcan(args)
                elif cmd == '--resetcan':
                    self.do_resetcan(args)
                elif cmd == '--clearcan':
                    self.do_clearcan(args)
                elif cmd == '--log':
                    self.do_log(args)
                elif cmd == '--setdid':
                    self.do_setdid(args)
                elif cmd == '--getdid':
                    self.do_getdid(args)
                else:
                    print(f"[错误] 未知命令: '{cmd}'。")

            except (KeyboardInterrupt, EOFError):
                running = False
                print("\n[中断] 用户请求退出。")
            except Exception as e:
                print(f"[严重异常] 发生未处理的错误: {e}")

        self.cleanup()

    def print_help(self):
        print("\n可用命令:")
        print("  --help                      - 显示此帮助信息。")
        print("  --open -dev <索引> [-type <类型>] [-res <保留>]")
        print("                              - 打开指定的VCI设备。")
        print("  --close -dev <索引>         - 关闭指定的VCI设备。")
        print("  --initcan -dev <索引> -ch <通道> -baud <波特率> -reqid <请求ID> -resid <响应ID>")
        print("                              - 初始化CAN通道并启动模拟服务。")
        print("  --resetcan -dev <索引> -ch <通道>")
        print("                              - 复位指定的CAN通道。")
        print("  --clearcan -dev <索引> -ch <通道>")
        print("                              - 清空指定CAN通道的缓冲区。")
        print("  --log on|off                - 开启或关闭FKVCI底层日志。")
        print("  --setdid -did <DID> -data <十六进制数据>")
        print("                              - 设置一个DID的值。")
        print("  --getdid -did <DID>         - 读取一个DID的值。")
        print("  --exit                      - 关闭模拟器并退出。")
        print("\n示例:")
        print("  --open -dev 0")
        print("  --initcan -dev 0 -ch 0 -baud 500000 -reqid 0x7E0 -resid 0x7E8")
        print("  --setdid -did 0xF190 -data 112233AABBCC")
        print("  --close -dev 0\n")

    def do_open(self, args):
        dev_type = self.extract_arg(args, '-type', 0, int)
        dev_index = self.extract_arg(args, '-dev', 0, int)
        res = self.extract_arg(args, '-res', 0, int)
        ret = self.ecu.open_device(dev_type, dev_index, res)
        print(f"[open] 返回: {ret} ({get_status_description(ret)})")

    def do_close(self, args):
        dev_index = self.extract_arg(args, '-dev', 0, int)
        ret = self.ecu.close_device(dev_index)
        print(f"[close] 返回: {ret} ({get_status_description(ret)})")

    def do_initcan(self, args):
        dev = self.extract_arg(args, '-dev', 0, int)
        ch = self.extract_arg(args, '-ch', 0, int)
        baud = self.extract_arg(args, '-baud', 500000, int)
        reqid = self.extract_arg(args, '-reqid', 0x7E0, safe_parse_int)
        resid = self.extract_arg(args, '-resid', 0x7E8, safe_parse_int)
        if reqid is None or resid is None:
            print("[错误] 请求ID或响应ID格式无效。")
            return
        ret = self.ecu.init_can(dev, ch, baud, reqid, resid)
        print(f"[initcan] 返回: {ret} ({get_status_description(ret)})")
        
    def do_resetcan(self, args):
        dev = self.extract_arg(args, '-dev', 0, int)
        ch = self.extract_arg(args, '-ch', 0, int)
        ret = self.ecu.reset_can(dev, ch)
        print(f"[resetcan] 返回: {ret} ({get_status_description(ret)})")

    def do_clearcan(self, args):
        dev = self.extract_arg(args, '-dev', 0, int)
        ch = self.extract_arg(args, '-ch', 0, int)
        ret = self.ecu.clear_can(dev, ch)
        print(f"[clearcan] 返回: {ret} ({get_status_description(ret)})")

    def do_log(self, args):
        action = "off"
        if "on" in args:
            action = "on"
        
        if action == "on":
            ret = self.ecu.open_log()
            print(f"开启FKVCI底层日志... 结果: {get_status_description(ret)}")
        else:
            ret = self.ecu.close_log()
            print(f"关闭FKVCI底层日志... 结果: {get_status_description(ret)}")

    def do_setdid(self, args):
        did = self.extract_arg(args, '-did', None, safe_parse_int)
        data = self.extract_arg(args, '-data', None, str)
        if did is None or data is None:
            print("用法: --setdid -did <DID> -data <十六进制数据>")
            return
        try:
            self.ecu.uds_logic.set_did(did, data)
        except Exception as e:
            print(f"[错误] 设置DID失败: {e}")

    def do_getdid(self, args):
        did = self.extract_arg(args, '-did', None, safe_parse_int)
        if did is None:
            print("用法: --getdid -did <DID>")
            return
        data = self.ecu.uds_logic.get_did(did)
        if data:
            print(f"  DID 0x{did:04X} 的数据: {data.hex().upper()}")
        else:
            print(f"  未找到 DID 0x{did:04X}。")

if __name__ == "__main__":
    cli = UDSCANServerTest()
    
    # 优雅地处理 Ctrl+C 和其他退出信号
    def signal_handler(sig, frame):
        # 这个处理器现在只是简单地触发主循环的退出
        # 实际的清理工作由主循环后的 cleanup() 调用完成
        print(f"\n[信号] 捕获到信号 {sig}, 准备退出...")
        # 通过引发KeyboardInterrupt来中断input()调用
        raise KeyboardInterrupt

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    cli.run()
