#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKUdsClient.py - 独立的UDS诊断接口封装

import os
import platform
import ctypes
from ctypes import *
import traceback

class FKUdsClient:
    def __init__(self):
        """
        构造函数，安静地尝试加载FKVCI库并定义API函数原型。
        只在加载失败时打印错误信息。
        """
        self.vci = None
        try:
            self._load_dll()
        except Exception as e:
            print(f"[FKUdsClient][致命错误] FKVCI 库加载失败: {e}")
            traceback.print_exc()

    def _load_dll(self):
        """加载 FKVCI DLL库并定义函数原型。"""
        current_arch = "64bit" if platform.architecture()[0] == "64bit" else "32bit"
        lib_folder = "Winx64" if current_arch == "64bit" else "Winx86"
        lib_path = os.path.abspath(f"./lib/{lib_folder}")
        
        os.environ['PATH'] = lib_path + os.pathsep + os.environ.get('PATH', '')
        
        dll_name = "fkvci.dll" if platform.system() == "Windows" else "libfkvci.so"
        full_dll_path = os.path.join(lib_path, dll_name)
        
        self.vci = ctypes.CDLL(full_dll_path)
        
        self._define_api()

    def _define_api(self):
        """定义所有需要的C API函数原型。"""
        # 1. 日志接口
        self.vci.FkVciOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
        self.vci.FkVciOpenLog.restype = c_int
        self.vci.FkVciCloseLog.argtypes = []
        self.vci.FkVciCloseLog.restype = c_int

        # 2. 设备接口
        self.vci.FkVciOpenDev.argtypes = [c_int, c_int, c_int]
        self.vci.FkVciOpenDev.restype = c_int
        self.vci.FkVciCloseDev.argtypes = [c_int]
        self.vci.FkVciCloseDev.restype = c_int

        # 3. CAN通道接口
        self.vci.FkVciInitCAN.argtypes = [c_int, c_int, c_uint]
        self.vci.FkVciInitCAN.restype = c_int
        # [新增] CANFD 初始化接口
        self.vci.FkVciInitCANFD.argtypes = [c_int, c_int, c_uint, c_uint]
        self.vci.FkVciInitCANFD.restype = c_int
        self.vci.FkVciResetCAN.argtypes = [c_int, c_int]
        self.vci.FkVciResetCAN.restype = c_int

        # 4. UDS自身接口
        self.vci.FkVciGetUdsErrorString.argtypes = [c_int]
        self.vci.FkVciGetUdsErrorString.restype = c_char_p
        self.vci.FkVciCreateUdsService.argtypes = [c_int, c_int, c_uint32, c_uint32, POINTER(c_int)]
        self.vci.FkVciCreateUdsService.restype = c_int
        self.vci.FkVciDestroyUdsService.argtypes = [c_int]
        self.vci.FkVciDestroyUdsService.restype = c_int
        self.vci.FkVciSetUdsConfig.argtypes = [c_int, c_char_p]
        self.vci.FkVciSetUdsConfig.restype = c_int
        self.vci.FkVciUdsRequestSync.argtypes = [c_int, POINTER(c_uint8), c_uint32, c_int, POINTER(c_uint8), POINTER(c_uint32)]
        self.vci.FkVciUdsRequestSync.restype = c_int
        self.vci.FkVciUdsRequestAsync.argtypes = [c_int, POINTER(c_uint8), c_uint32, c_int]
        self.vci.FkVciUdsRequestAsync.restype = c_int
        self.vci.FkVciUdsReadResponse.argtypes = [c_int, POINTER(c_uint8), POINTER(c_uint32), c_uint32]
        self.vci.FkVciUdsReadResponse.restype = c_int
        self.vci.FkVciUdsClearAsyncQueues.argtypes = [c_int]
        self.vci.FkVciUdsClearAsyncQueues.restype = c_int

    # --- Pythonic 封装 ---
    def open_log(self, path="logs/fkvci_uds.log", level=1, max_size=5, max_files=10):
        return self.vci.FkVciOpenLog(path.encode('utf-8'), level, max_size, max_files)

    def close_log(self):
        return self.vci.FkVciCloseLog()

    def open_device(self, dev_type=0, dev_index=0, reserved=0):
        return self.vci.FkVciOpenDev(dev_type, dev_index, reserved)

    def close_device(self, dev_index=-1):
        return self.vci.FkVciCloseDev(dev_index)

    def init_can(self, dev, ch, baud):
        return self.vci.FkVciInitCAN(dev, ch, baud)

    # [新增] CANFD 初始化封装
    def init_canfd(self, dev, ch, baud, fd_baud):
        return self.vci.FkVciInitCANFD(dev, ch, baud, fd_baud)

    def reset_can(self, dev, ch):
        return self.vci.FkVciResetCAN(dev, ch)

    def get_uds_error_string(self, error_code):
        result_bytes = self.vci.FkVciGetUdsErrorString(error_code)
        try:
            return result_bytes.decode('utf-8')
        except (UnicodeDecodeError, AttributeError):
            return "Invalid error string pointer"

    def create_uds_service(self, dev, ch, req_id, res_id):
        uds_id = c_int(-1)
        ret = self.vci.FkVciCreateUdsService(dev, ch, req_id, res_id, byref(uds_id))
        if ret == 0:
            return uds_id.value
        return ret

    def destroy_uds_service(self, uds_id):
        return self.vci.FkVciDestroyUdsService(uds_id)

    def set_uds_config(self, uds_id, config_str):
        return self.vci.FkVciSetUdsConfig(uds_id, config_str.encode('utf-8'))

    def uds_request_sync(self, uds_id, request_data, is_can_fd=0, max_response_len=4095):
        req_len = len(request_data)
        req_buffer = (c_uint8 * req_len)(*request_data)
        res_buffer = (c_uint8 * max_response_len)()
        res_len = c_uint32(max_response_len)
        ret = self.vci.FkVciUdsRequestSync(uds_id, req_buffer, req_len, is_can_fd, res_buffer, byref(res_len))
        response_data = bytes(res_buffer[:res_len.value])
        return ret, response_data

    def uds_request_async(self, uds_id, request_data, is_can_fd=0):
        req_len = len(request_data)
        req_buffer = (c_uint8 * req_len)(*request_data)
        return self.vci.FkVciUdsRequestAsync(uds_id, req_buffer, req_len, is_can_fd)

    def uds_read_response(self, uds_id, timeout_ms=2000, max_response_len=4095):
        res_buffer = (c_uint8 * max_response_len)()
        res_len = c_uint32(max_response_len)
        ret = self.vci.FkVciUdsReadResponse(uds_id, res_buffer, byref(res_len), timeout_ms)
        response_data = bytes(res_buffer[:res_len.value])
        return ret, response_data

    def uds_clear_async_queues(self, uds_id):
        return self.vci.FkVciUdsClearAsyncQueues(uds_id)
