#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# UDSCANServerLogic.py - UDS诊断服务的应用层逻辑实现。

import logging
import random
import threading
import time

logger = logging.getLogger('ECU_SIM.UDS')

# --- UDS服务ID常量 ---
UDS_DIAGNOSTIC_SESSION_CONTROL = 0x10
UDS_ECU_RESET = 0x11
UDS_READ_DATA_BY_ID = 0x22
UDS_SECURITY_ACCESS = 0x27
UDS_WRITE_DATA_BY_ID = 0x2E
UDS_TESTER_PRESENT = 0x3E
# --- UDS响应码 ---
UDS_POSITIVE_RESPONSE = 0x40
UDS_NEGATIVE_RESPONSE = 0x7F
# --- UDS否定响应码 (NRC) ---
NRC_SERVICE_NOT_SUPPORTED = 0x11
NRC_INCORRECT_MESSAGE_LENGTH = 0x13
NRC_REQUEST_SEQUENCE_ERROR = 0x24
NRC_REQUEST_OUT_OF_RANGE = 0x31
NRC_SECURITY_ACCESS_DENIED = 0x33
NRC_INVALID_KEY = 0x35
NRC_RESPONSE_PENDING = 0x78 # 新增：响应待定

class UdsLogic:
    """处理UDS服务的应用层逻辑。"""
    def __init__(self):
        # DID 数据字典
        self.dids = {
            0xF190: b'\xDE\xAD\xBE\xEF',  # 示例DID
            0xF199: b'\xAA' * 50,       # 用于测试多帧响应的长DID
        }
        # 安全访问状态
        self.security_level = 0
        self.seed = None
        self.lock = threading.Lock()

    def process_request(self, payload, server_instance=None):
        """
        处理完整的UDS请求数据，并返回响应数据。
        新增 server_instance 参数，用于支持需要延迟响应的复杂服务。
        """
        if not payload: return None
        sid = payload[0]
        handler = getattr(self, f'handle_{sid:02x}', self.handle_unsupported)
        logger.info(f"应用层: 正在处理服务 0x{sid:02X}...")
        return handler(payload, server_instance)

    def handle_unsupported(self, payload, server_instance=None):
        """处理不支持的服务的默认方法。"""
        logger.warning(f"应用层: 收到不支持的服务 0x{payload[0]:02X}。")
        return self.nrc(payload[0], NRC_SERVICE_NOT_SUPPORTED)

    def handle_10(self, payload, server_instance=None): # 诊断会话控制
        if len(payload) < 2: return self.nrc(0x10, NRC_INCORRECT_MESSAGE_LENGTH)
        session_type = payload[1]
        logger.info(f"应用层: 切换到会话模式 {session_type}。")
        p2_server_max_ms = 50
        p2_star_server_max_ms = 5000
        return bytes([0x50, session_type]) + \
               (p2_server_max_ms).to_bytes(2, 'big') + \
               (p2_star_server_max_ms // 10).to_bytes(2, 'big')

    def handle_11(self, payload, server_instance=None): # ECU Reset
        """
        重构以支持 NRC 78 (Response Pending)。
        - 子功能 0x04: 模拟一个耗时2秒的慢速复位。
        """
        if len(payload) < 2: return self.nrc(0x11, NRC_INCORRECT_MESSAGE_LENGTH)
        
        reset_type = payload[1]

        # 检查是否为我们定义的“慢速复位”子功能，并且server实例可用
        if reset_type == 0x04 and server_instance:
            logger.info("应用层: 收到慢速复位请求 (0x11 0x04)。将先发送 NRC 78。")
            
            # 准备最终的积极响应
            final_response = bytes([0x51, reset_type])
            
            # 请求核心服务在2秒后发送最终响应
            server_instance.schedule_final_response(final_response, delay_seconds=2.0)

            # 立即返回 NRC 78
            return self.nrc(0x11, NRC_RESPONSE_PENDING)
        else: 
            # 对于其他复位类型，或在无法延迟发送的旧模式下，立即响应
            logger.info(f"应用层: 正在执行快速复位 (类型 {reset_type})。")
            return bytes([0x51, reset_type])

    def handle_22(self, payload, server_instance=None): # 根据标识符读取数据
        if len(payload) < 3: return self.nrc(0x22, NRC_INCORRECT_MESSAGE_LENGTH)
        did = (payload[1] << 8) | payload[2]
        with self.lock:
            if did in self.dids:
                logger.info(f"应用层: 正在读取 DID 0x{did:04X}。")
                return bytes([0x62, payload[1], payload[2]]) + self.dids[did]
        logger.warning(f"应用层: 尝试读取不存在的 DID 0x{did:04X}。")
        return self.nrc(0x22, NRC_REQUEST_OUT_OF_RANGE)

    def handle_2e(self, payload, server_instance=None): # 根据标识符写入数据
        if len(payload) < 4: return self.nrc(0x2E, NRC_INCORRECT_MESSAGE_LENGTH)
        did = (payload[1] << 8) | payload[2]
        if self.security_level < 1:
             logger.warning(f"应用层: 写入 DID 0x{did:04X} 被拒绝，安全等级不足。")
             return self.nrc(0x2E, NRC_SECURITY_ACCESS_DENIED)
        with self.lock:
            if did in self.dids:
                self.dids[did] = payload[3:]
                logger.info(f"应用层: 已向 DID 0x{did:04X} 写入 {len(payload[3:])} 字节数据。")
                return bytes([0x6E, payload[1], payload[2]])
        logger.warning(f"应用层: 尝试写入不存在的 DID 0x{did:04X}。")
        return self.nrc(0x2E, NRC_REQUEST_OUT_OF_RANGE)
    
    def handle_27(self, payload, server_instance=None): # 安全访问
        if len(payload) < 2: return self.nrc(0x27, NRC_INCORRECT_MESSAGE_LENGTH)
        sub_func = payload[1]
        if sub_func % 2 == 1: # 请求种子
            self.seed = random.randbytes(4)
            logger.info(f"应用层: 为等级 {(sub_func+1)//2} 生成种子: {self.seed.hex().upper()}")
            return bytes([0x67, sub_func]) + self.seed
        else: # 发送密钥
            if self.seed is None: return self.nrc(0x27, NRC_REQUEST_SEQUENCE_ERROR)
            if len(payload) < 6: return self.nrc(0x27, NRC_INCORRECT_MESSAGE_LENGTH)
            key = bytes(payload[2:6])
            expected_key = bytes(a ^ b for a, b in zip(self.seed, b'\x12\x34\x56\x78'))
            if key == expected_key:
                level = sub_func // 2
                self.security_level = level
                logger.info(f"应用层: 安全访问成功！安全等级已设置为 {self.security_level}。")
                self.seed = None
                return bytes([0x67, sub_func])
            else:
                logger.warning(f"应用层: 密钥无效。期望 {expected_key.hex().upper()}, 收到 {key.hex().upper()}。")
                self.seed = None
                return self.nrc(0x27, NRC_INVALID_KEY)

    def handle_3e(self, payload, server_instance=None): # 待机握手
        if len(payload) < 2: return self.nrc(0x3E, NRC_INCORRECT_MESSAGE_LENGTH)
        return bytes([0x7E, payload[1]])

    def nrc(self, sid, code):
        return bytes([UDS_NEGATIVE_RESPONSE, sid, code])

    def set_did(self, did, data_hex):
        with self.lock:
            self.dids[did] = bytes.fromhex(data_hex)
            logger.info(f"命令: 已设置 DID 0x{did:04X} 的值为 {data_hex.upper()}")

    def get_did(self, did):
        with self.lock:
            return self.dids.get(did)
