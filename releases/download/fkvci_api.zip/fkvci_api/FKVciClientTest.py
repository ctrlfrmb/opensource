#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciClientTest.py - 交互式 CAN + LIN 控制台，基于 FKVciClient 封装调用

import sys
import signal
import time
import threading
import platform
from FKVciClient import FKVciClient
from FKVciMessage import hex_dump, get_status_description

def safe_parse_int(s):
    """将字符串安全地解析为整数，默认按16进制"""
    if not isinstance(s, str): return None
    try:
        return int(s, 16)
    except (ValueError, TypeError):
        return None

class FKVciClientTest:
    def __init__(self):
        self.client = FKVciClient()
        self.running = True
        self.auto_recv = False
        self.auto_recv_lin = False
        self.recv_thread = None
        self.recv_lin_thread = None
        self.period_ids = {}

    def cleanup(self):
        self.stop_auto_recv()
        self.stop_auto_recv_lin()
        self.client.close_device(-1)
        time.sleep(1.2)
        self.client.close_log()
        print("[退出] 已关闭日志")

    def parse_args(self, line):
        import shlex
        try:
            return shlex.split(line)
        except ValueError:
            print("[错误] 命令格式不正确")
            return []

    def extract_arg(self, args, key, default=None, cast=str):
        if key in args:
            idx = args.index(key)
            if idx + 1 < len(args):
                try:
                    return cast(args[idx + 1])
                except:
                    pass
        return default

    def run(self):
        print("=" * 60)
        print(f"FKVCI CAN+LIN 命令行工具 v2.0.0 ({platform.architecture()[0]})")
        print("=" * 60)
        print("输入 --help 查看帮助，--exit 退出")
        while self.running:
            try:
                raw = input(">>> ").strip()
                if not raw:
                    continue
                args = self.parse_args(raw)
                if not args:
                    continue
                cmd = args[0].lower()

                if cmd == "--exit":
                    break
                elif cmd == "--help":
                    self.print_help()
                elif cmd == "--scan":
                    self.do_scan(args)
                elif cmd == "--getcanchannels":
                    self.do_get_can_channels(args)
                elif cmd == "--getlinchannels":
                    self.do_get_lin_channels(args)
                elif cmd == "--open":
                    self.do_open(args)
                elif cmd == "--initcan":
                    self.do_initcan(args)
                elif cmd == "--initcanfd":
                    self.do_initcanfd(args)
                elif cmd == "--initcanfdadv":
                    self.do_initcanfd_advanced(args)
                elif cmd == "--send":
                    self.do_send(args)
                elif cmd == "--recv":
                    self.do_recv(args)
                elif cmd == "--startperiod":
                    self.do_start_period(args)
                elif cmd == "--stopperiod":
                    self.do_stop_period(args)
                elif cmd == "--resetcan":
                    self.do_reset_can(args)
                elif cmd == "--clearcan":
                    self.do_clear_can(args)
                elif cmd == "--setresistor":
                    self.do_set_resistor(args)
                elif cmd == "--getbusload":
                    self.do_get_busload(args)
                elif cmd == "--version":
                    self.do_version(args)
                elif cmd == "--basetime":
                    self.do_basetime(args)
                elif cmd == "--log":
                    if "on" in args:
                        self.client.open_log()
                        print("[log] 已开启")
                    else:
                        self.client.close_log()
                        print("[log] 已关闭")
                elif cmd == "--autorecvcan":
                    if "on" in args:
                        self.start_auto_recv()
                    else:
                        self.stop_auto_recv()
                elif cmd == "--initlin":
                    self.do_init_lin(args)
                elif cmd == "--sendlin":
                    self.do_send_lin(args)
                elif cmd == "--recvlin":
                    self.do_recv_lin(args)
                elif cmd == "--resetlin":
                    self.do_reset_lin(args)
                elif cmd == "--autorecvlin":
                    if "on" in args:
                        self.start_auto_recv_lin()
                    else:
                        self.stop_auto_recv_lin()
                else:
                    print("[未知命令] 输入 --help 查看支持的命令")
            except Exception as e:
                print(f"[异常] {e}")

        self.cleanup()

    def print_help(self):
        print("\n可用命令:")
        print("  --scan -timeout 500")
        print("  --getCanChannels -dev 0")
        print("  --getLinChannels -dev 0")
        print("  --open -type 0 -dev 0 -res 0")
        print("  --initCAN -dev 0 -ch 0 -baud 500000")
        print("  --initCANFD -dev 0 -ch 0 -baud 500000 -fd 2000000")
        print("  --initCANFDAdv -dev 0 -ch 0 -baud 500000 -fd 2000000 -nseg1 31 -nseg2 8 -dseg1 15 -dseg2 4 -term 1")
        print("  --send -dev 0 -ch 0 -id 123 -data 11 22 33")
        print("  --recv -dev 0 -ch 0")
        print("  --startPeriod -dev 0 -ch 0 -id 100 -data 01 02 03 -time 100")
        print("  --stopPeriod -dev 0 -ch 0 -pid 1")
        print("  --resetCAN -dev 0 -ch 0")
        print("  --clearCAN -dev 0 -ch 0")
        print("  --setResistor -dev 0 -ch 0 -enable 1")
        print("  --getBusLoad -dev 0")
        print("  --version -dev 0")
        print("  --baseTime -dev 0")
        print("  --log on|off")
        print("  --autoRecvCAN on|off")
        print("  --initLIN -dev 0 -ch 1 -mode 0 -baud 19200")
        print("  --sendLIN -dev 0 -ch 1 -id 10 -data 01 02")
        print("  --recvLIN -dev 0 -ch 1")
        print("  --resetLIN -dev 0 -ch 1")
        print("  --autoRecvLIN on|off")
        print("  --exit\n")

    def do_scan(self, args):
        timeout = self.extract_arg(args, "-timeout", 500, int)
        print(f"[scan] 正在扫描设备 (超时: {timeout}ms)...")
        devices = self.client.scan_devices(timeout_ms=timeout)
        if devices is not None:
            if devices:
                print(f"[scan] 扫描成功，发现 {len(devices)} 个设备: {devices}")
            else:
                print("[scan] 扫描完成，未发现任何设备。")
        else:
            print("[scan] 扫描失败。")

    def do_get_can_channels(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        count = self.client.get_can_channel_count(d)
        if count >= 0:
            print(f"[getCanChannels] 设备 {d} 支持 {count} 个CAN通道。")
        else:
            print(f"[getCanChannels] 获取失败: {get_status_description(count)}")

    def do_get_lin_channels(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        count = self.client.get_lin_channel_count(d)
        if count >= 0:
            print(f"[getLinChannels] 设备 {d} 支持 {count} 个LIN通道。")
        else:
            print(f"[getLinChannels] 获取失败: {get_status_description(count)}")

    def do_open(self, args):
        t = self.extract_arg(args, "-type", 0, int)
        d = self.extract_arg(args, "-dev", 0, int)
        r = self.extract_arg(args, "-res", 0, int)
        ret = self.client.open_device(t, d, r)
        print(f"[open] 返回: {ret} ({get_status_description(ret)})")

    def do_initcan(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        baud = self.extract_arg(args, "-baud", 500000, int)
        ret = self.client.init_can(d, ch, baud)
        print(f"[initCAN] 返回: {ret} ({get_status_description(ret)})")

    def do_initcanfd(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        baud = self.extract_arg(args, "-baud", 500000, int)
        fd_baud = self.extract_arg(args, "-fd", 2000000, int)
        ret = self.client.init_canfd(d, ch, baud, fd_baud)
        print(f"[initCANFD] 返回: {ret} ({get_status_description(ret)})")

    def do_initcanfd_advanced(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        baud = self.extract_arg(args, "-baud", 500000, int)
        fd_baud = self.extract_arg(args, "-fd", 2000000, int)
        n_seg1 = self.extract_arg(args, "-nseg1", 0x1F, int)
        n_seg2 = self.extract_arg(args, "-nseg2", 0x08, int)
        d_seg1 = self.extract_arg(args, "-dseg1", 0x0F, int)
        d_seg2 = self.extract_arg(args, "-dseg2", 0x04, int)
        term = self.extract_arg(args, "-term", 1, int)
        
        ret = self.client.init_canfd_advanced(d, ch, baud, fd_baud, n_seg1, n_seg2, d_seg1, d_seg2, term)
        print(f"[initCANFDAdv] 返回: {ret} ({get_status_description(ret)})")
        
        n_divider = 80000000 / ((n_seg1 + n_seg2 + 1) * baud)
        d_divider = 80000000 / ((d_seg1 + d_seg2 + 1) * fd_baud)
        print(f"[initCANFDAdv] 标称分频系数: {n_divider:.4f}, 数据分频系数: {d_divider:.4f}")
        
        n_sample_point = (1.0 + n_seg1) / (1.0 + n_seg1 + n_seg2) * 100.0
        d_sample_point = (1.0 + d_seg1) / (1.0 + d_seg1 + d_seg2) * 100.0
        print(f"[initCANFDAdv] 标称采样点: {n_sample_point:.2f}%, 数据采样点: {d_sample_point:.2f}%")

    def do_send(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        can_id_str = self.extract_arg(args, "-id", "123", str)
        can_id = safe_parse_int(can_id_str)
        if can_id is None:
            print("[错误] 无效的ID。")
            return
        data = []
        if "-data" in args:
            start = args.index("-data") + 1
            for i in range(start, len(args)):
                if args[i].startswith("-"):
                    break
                val = safe_parse_int(args[i])
                if val is not None: data.append(val)
        ret = self.client.send_can(d, ch, can_id, data)
        print(f"[send] 返回: {ret} ({get_status_description(ret)})")

    def do_recv(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        msg = self.client.recv_can(d, ch)
        if msg:
            ts = msg.get_full_timestamp()
            print(f"[recv] TS={ts}us, ID=0x{msg.CanID:X}, DLC={msg.DLC}, Data={hex_dump(msg.Data[:msg.DLC])}")
        else:
            print("[recv] 无数据")

    def do_start_period(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        can_id_str = self.extract_arg(args, "-id", "100", str)
        can_id = safe_parse_int(can_id_str)
        if can_id is None:
            print("[错误] 无效的ID。")
            return
        time_ms = self.extract_arg(args, "-time", 100, int)
        data = []
        if "-data" in args:
            start = args.index("-data") + 1
            for i in range(start, len(args)):
                if args[i].startswith("-"):
                    break
                val = safe_parse_int(args[i])
                if val is not None: data.append(val)
        pid = self.client.start_period(d, ch, can_id, data, time_ms)
        if pid > 0:
            self.period_ids[pid] = (d, ch)
            print(f"[startPeriod] 成功，ID={pid}")
        else:
            print(f"[startPeriod] 失败: {get_status_description(pid)}")

    def do_stop_period(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        pid = self.extract_arg(args, "-pid", -1, int)
        ret = self.client.stop_period(d, ch, pid)
        print(f"[stopPeriod] 返回: {ret} ({get_status_description(ret)})")

    def do_reset_can(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.client.reset_can(d, ch)
        print(f"[resetCAN] 返回: {ret} ({get_status_description(ret)})")

    def do_clear_can(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.client.clear_can(d, ch)
        print(f"[clearCAN] 返回: {ret} ({get_status_description(ret)})")

    def do_set_resistor(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        enable = self.extract_arg(args, "-enable", 1, int)
        ret = self.client.set_resistor(d, ch, enable)
        print(f"[setResistor] 返回: {ret} ({get_status_description(ret)})")

    def do_get_busload(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        loads = self.client.get_bus_load(d)
        if loads:
            for i, val in enumerate(loads):
                print(f"  CAN{i}: {val:.2f}%")
        else:
            print("[getBusLoad] 获取失败")

    def do_version(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        v = self.client.get_version(d)
        print(f"[version] 设备版本: {v}")

    def do_basetime(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        t = self.client.get_base_time(d)
        print(f"[baseTime] {t} µs")

    def do_init_lin(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 1, int)
        mode = self.extract_arg(args, "-mode", 0, int)
        baud = self.extract_arg(args, "-baud", 19200, int)
        ret = self.client.init_lin(d, ch, mode, baud)
        print(f"[initLIN] 返回: {ret} ({get_status_description(ret)})")

    def do_send_lin(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 1, int)
        lin_id_str = self.extract_arg(args, "-id", "10", str)
        lin_id = safe_parse_int(lin_id_str)
        if lin_id is None:
            print("[错误] 无效的ID。")
            return
        data = []
        if "-data" in args:
            start = args.index("-data") + 1
            for i in range(start, len(args)):
                if args[i].startswith("-"):
                    break
                val = safe_parse_int(args[i])
                if val is not None: data.append(val)
        ret = self.client.send_lin(d, ch, lin_id, data)
        print(f"[sendLIN] 返回: {ret} ({get_status_description(ret)})")

    def do_recv_lin(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 1, int)
        msg = self.client.recv_lin(d, ch)
        if msg:
            ts = msg.get_full_timestamp()
            print(f"[recvLIN] TS={ts}us, ID=0x{msg.LinID:X}, DLC={msg.DLC}, Data={hex_dump(msg.Data[:msg.DLC])}")
        else:
            print("[recvLIN] 无数据")

    def do_reset_lin(self, args):
        d = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 1, int)
        ret = self.client.reset_lin(d, ch)
        print(f"[resetLIN] 返回: {ret} ({get_status_description(ret)})")

    def start_auto_recv(self):
        if self.recv_thread:
            return
        self.auto_recv = True
        def worker():
            while self.auto_recv:
                msg = self.client.recv_can(0, 0)
                if msg:
                    ts = msg.get_full_timestamp()
                    print(f"\r[AutoRecv CAN] TS={ts}us, ID=0x{msg.CanID:X}, DLC={msg.DLC}, Data={hex_dump(msg.Data[:msg.DLC])}      ")
                    print(">>> ", end="", flush=True)
                time.sleep(0.02)
        self.recv_thread = threading.Thread(target=worker, daemon=True)
        self.recv_thread.start()
        print("[autoRecvCAN] 启动")

    def stop_auto_recv(self):
        if self.recv_thread:
            self.auto_recv = False
            self.recv_thread.join(timeout=1.0)
            self.recv_thread = None
            print("[autoRecvCAN] 停止")

    def start_auto_recv_lin(self):
        if self.recv_lin_thread:
            return
        self.auto_recv_lin = True
        def worker():
            while self.auto_recv_lin:
                msg = self.client.recv_lin(0, 1)
                if msg:
                    ts = msg.get_full_timestamp()
                    print(f"\r[AutoRecv LIN] TS={ts}us, ID=0x{msg.LinID:X}, DLC={msg.DLC}, Data={hex_dump(msg.Data[:msg.DLC])}      ")
                    print(">>> ", end="", flush=True)
                time.sleep(0.02)
        self.recv_lin_thread = threading.Thread(target=worker, daemon=True)
        self.recv_lin_thread.start()
        print("[autoRecvLIN] 启动")

    def stop_auto_recv_lin(self):
        if self.recv_lin_thread:
            self.auto_recv_lin = False
            self.recv_lin_thread.join(timeout=1.0)
            self.recv_lin_thread = None
            print("[autoRecvLIN] 停止")


if __name__ == "__main__":
    shell = FKVciClientTest()

    def signal_handler(sig, frame):
        print("\n[信号] 退出中...")
        shell.cleanup()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    shell.run()
