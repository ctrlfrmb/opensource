#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciCircleTest.py - 交互式 CAN 接口循环测试工具 (v3.0.1, 修正版)

import sys
import signal
import time
import threading
from ctypes import *
from FKVciApi import FKVciApi
from FKVciMessage import FkVciCanDataType, get_status_description

class FKVciCircleTest:
    def __init__(self):
        self.api = FKVciApi()
        self.running = True
        self.test_thread = None
        self.is_testing = False
        self.success_count = 0
        self.fail_count = 0
        self.test_count = 0
        self.start_time = None
        self.dev = 0
        self.ch = 0

    def cleanup(self):
        self.stop_test()
        self.api.vci.FkVciCloseDev(-1)
        time.sleep(0.2)
        self.api.vci.FkVciCloseLog()
        print("[退出] 已关闭所有设备和日志")

    def parse_args(self, line):
        import shlex
        try:
            return shlex.split(line)
        except ValueError:
            print("[错误] 命令格式不正确")
            return []

    def extract_arg(self, args, key, default=None, cast_func=str):
        if key in args:
            idx = args.index(key)
            if idx + 1 < len(args):
                try:
                    return cast_func(args[idx + 1])
                except (ValueError, TypeError):
                    pass
        return default

    def run(self):
        print("=" * 60)
        print("FKVCI CAN接口循环测试工具 v3.0.1")
        print("=" * 60)
        print("输入 --help 查看帮助，--exit 退出")
        
        while self.running:
            try:
                raw = input(">>> ").strip()
                if not raw: continue
                args = self.parse_args(raw)
                if not args: continue
                cmd = args[0].lower()

                command_map = {
                    "--exit": lambda args: setattr(self, 'running', False),
                    "--help": self.print_help,
                    "--starttest": self.do_start_test,
                    "--stoptest": self.do_stop_test,
                    "--log": self.do_log,
                }
                if cmd in command_map:
                    command_map[cmd](args)
                else:
                    print("[未知命令] 输入 --help 查看支持的命令")
            except (EOFError, KeyboardInterrupt):
                self.running = False
                break
            except Exception as e:
                print(f"[异常] {e}")

        self.cleanup()

    def print_help(self, *args):
        print("\n可用命令:")
        print("  --startTest -time 50 -count 0 -dev 0 -ch 0")
        print("    -time: 测试间隔周期(毫秒)")
        print("    -count: 测试循环次数(0表示无限循环)")
        print("    -dev: 设备号(默认0)")
        print("    -ch: 通道号(默认0)")
        print("  --stopTest       停止当前测试")
        print("  --log on|off     开启/关闭设备日志")
        print("  --exit           退出程序\n")

    def do_log(self, args):
        if "on" in args:
            ret = self.api.vci.FkVciOpenLog("logs/fkvci_circle_test.log".encode('utf-8'), 0, 5, 10)
            print(f"[log] 开启日志... {get_status_description(ret)}")
        else:
            self.api.vci.FkVciCloseLog()
            print("[log] 已关闭")

    def do_start_test(self, args):
        if self.is_testing:
            print("[警告] 测试已在进行中，请先停止")
            return
            
        interval_ms = self.extract_arg(args, "-time", 50, int)
        target_count = self.extract_arg(args, "-count", 0, int)
        self.dev = self.extract_arg(args, "-dev", 0, int)
        self.ch = self.extract_arg(args, "-ch", 0, int)
        
        print(f"[开始测试] 间隔={interval_ms}ms, 循环次数={'无限' if target_count == 0 else target_count}")
        print(f"[开始测试] 设备={self.dev}, 通道={self.ch}")
        
        self.start_test(interval_ms, target_count)
        
    def do_stop_test(self, args=None):
        if not self.is_testing:
            print("[警告] 当前没有测试在运行")
            return
            
        self.stop_test()
        print("[停止测试] 测试已终止")

    def start_test(self, interval_ms, target_count):
        self.is_testing = True
        self.success_count = 0
        self.fail_count = 0
        self.test_count = 0
        self.start_time = time.time()
        
        def test_worker():
            while self.is_testing:
                if target_count > 0 and self.test_count >= target_count:
                    print("\n[完成] 测试已达到指定次数")
                    self.is_testing = False
                    break
                
                success = self.run_test_cycle()
                
                self.test_count += 1
                if success: self.success_count += 1
                else: self.fail_count += 1
                
                self.print_status()
                time.sleep(interval_ms / 1000.0)
            
            # 确保线程退出时，主线程知道测试已结束
            self.is_testing = False

        self.test_thread = threading.Thread(target=test_worker, daemon=True)
        self.test_thread.start()

    def stop_test(self):
        if self.is_testing:
            self.is_testing = False
            if self.test_thread:
                self.test_thread.join(timeout=1.0)
                self.test_thread = None
            self.print_test_summary()

    def print_status(self):
        elapsed = time.time() - self.start_time if self.start_time else 0
        rate = self.success_count / max(1, self.test_count) * 100
        print(f"\r测试进度: {self.test_count}次 | "
              f"成功: {self.success_count} | "
              f"失败: {self.fail_count} | "
              f"成功率: {rate:.2f}% | "
              f"运行时间: {int(elapsed//60)}分{int(elapsed%60)}秒", end="")
        sys.stdout.flush()

    def print_test_summary(self):
        # 确保在开始统计前，测试已经停止并且计数器不会再变化
        if self.test_count == 0:
            print("\n[摘要] 未执行任何测试")
            return
            
        elapsed = time.time() - self.start_time
        rate = self.success_count / max(1, self.test_count) * 100
        avg_time = elapsed / max(1, self.test_count) * 1000
        print("\n\n" + "=" * 60)
        print("测试结果统计:")
        print(f"总测试次数: {self.test_count}")
        print(f"成功次数: {self.success_count}")
        print(f"失败次数: {self.fail_count}")
        print(f"成功率: {rate:.2f}%")
        print(f"总运行时间: {int(elapsed//60)}分{int(elapsed%60)}秒")
        print(f"平均每次测试耗时: {avg_time:.2f}ms")
        print("=" * 60)

    def run_test_cycle(self):
        # 步骤1: 打开设备
        ret = self.api.vci.FkVciOpenDev(0, self.dev, 0)
        if ret != 0:
            print(f"\n[错误] 打开设备失败: {get_status_description(ret)}")
            return False
            
        # 步骤2: 初始化CAN通道
        ret = self.api.vci.FkVciInitCANFD(self.dev, self.ch, 500000, 2000000)
        if ret != 0:
            print(f"\n[错误] 初始化CAN通道失败: {get_status_description(ret)}")
            self.api.vci.FkVciCloseDev(self.dev)
            return False
        
        # 步骤3: 发送CAN数据
        data = [0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88]
        buf = FkVciCanDataType()
        buf.CanID = 0x123
        buf.FLAG = 0
        buf.DLC = len(data)
        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        ret = self.api.vci.FkVciTransmitCAN(self.dev, self.ch, byref(buf), 1)
        if ret != 0:
            print(f"\n[错误] 发送CAN数据失败: {get_status_description(ret)}")
            self.api.vci.FkVciCloseDev(self.dev)
            return False
        
        # 步骤4: 关闭设备
        ret = self.api.vci.FkVciCloseDev(self.dev)
        if ret != 0:
            print(f"\n[错误] 关闭设备失败: {get_status_description(ret)}")
            return False
            
        return True

if __name__ == "__main__":
    shell = FKVciCircleTest()
    def signal_handler(sig, frame):
        print("\n[信号] 退出中...")
        shell.running = False
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    shell.run()
