#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# UDSCANServer.py - ECU模拟器的核心服务，处理CAN通信和ISO-TP协议。

import time
import threading
import logging
from queue import Queue, Empty
from FKVciApi import FKVciApi
from FKVciMessage import FkVciCanDataType, FkVciCanFdConfig # 引入 FkVciCanFdConfig
from UDSCANServerLogic import UdsLogic

logger = logging.getLogger('ECU_SIM.CORE')

# --- ISO-TP Protocol Control Information (PCI) Types ---
PCI_TYPE_SINGLE_FRAME = 0
PCI_TYPE_FIRST_FRAME = 1
PCI_TYPE_CONSECUTIVE_FRAME = 2

class UDSCANServer:
    """ECU模拟器核心类，被动执行指令并管理后台通信。"""
    def __init__(self):
        self.api = FKVciApi()
        self.uds_logic = UdsLogic()

        self.is_running = False
        self.recv_thread = None
        self.proc_thread = None
        self.task_queue = Queue()
        self.delayed_send_queue = Queue()

        self.dev_idx = -1
        self.ch_idx = -1
        self.req_id = -1
        self.res_id = -1

        # ISO-TP 接收状态机变量
        self.reassembly_buffer = bytearray()
        self.expected_len = 0
        self.next_seq_num = None

    # --- Public API for Control ---
    def open_device(self, dev_type, dev_index, reserved):
        return self.api.open_device(dev_type, dev_index, reserved)

    def close_device(self, dev_index):
        if self.is_running:
            self.stop_service()
        return self.api.close_device(dev_index)

    def init_can(self, dev, ch, baud, req_id, res_id):
        ret = self.api.init_can(dev, ch, baud)
        if ret == 0:
            self.dev_idx, self.ch_idx, self.req_id, self.res_id = dev, ch, req_id, res_id
            self.start_service()
        return ret
        
    # 【API对齐】参数'config'现在应为 FkVciCanFdConfig 对象
    def init_canfd_advanced(self, dev, ch, config_obj, req_id, res_id):
        ret = self.api.init_canfd_advanced(dev, ch, config_obj)
        if ret == 0:
            self.dev_idx, self.ch_idx, self.req_id, self.res_id = dev, ch, req_id, res_id
            self.start_service()
        return ret

    def reset_can(self, dev, ch):
        return self.api.reset_can(dev, ch)

    def clear_can(self, dev, ch):
        return self.api.clear_can(dev, ch)

    def open_log(self):
        return self.api.open_log("logs/uds_can_server.log", 0)

    def close_log(self):
        return self.api.close_log()

    # --- Service Lifecycle Management ---
    def start_service(self):
        if self.is_running:
            logger.warning("服务线程已在运行中。")
            return
        self.is_running = True
        self.recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
        self.proc_thread = threading.Thread(target=self._proc_loop, daemon=True)
        self.recv_thread.start()
        self.proc_thread.start()
        logger.info(f"ECU模拟服务已在通道 {self.ch_idx} 上启动...")

    def stop_service(self):
        if not self.is_running:
            return
        self.is_running = False
        if self.proc_thread:
            self.task_queue.put(None) 
            self.proc_thread.join(timeout=1.0)
        if self.recv_thread:
            self.recv_thread.join(timeout=1.0)
        logger.info("ECU模拟服务已停止。")

    def schedule_final_response(self, response_payload, delay_seconds):
        send_time = time.time() + delay_seconds
        self.delayed_send_queue.put((send_time, response_payload))
        logger.info(f"核心服务: 已将一个最终响应安排在 {delay_seconds:.2f} 秒后发送。")

    # --- Internal Worker Threads ---
    def _recv_loop(self):
        logger.info("接收线程已启动。")
        while self.is_running:
            frames = self.api.receive_can(self.dev_idx, self.ch_idx, 50, 0)
            if frames:
                for frame in frames:
                    if frame.CanID == self.req_id:
                        self.task_queue.put(frame)
            time.sleep(0.02) 
        logger.info("接收线程已退出。")

    def _proc_loop(self):
        logger.info("处理线程已启动。")
        while self.is_running:
            try:
                send_time, response = self.delayed_send_queue.get_nowait()
                if time.time() >= send_time:
                    logger.info(f"核心服务: 正在发送延迟的最终响应: {response.hex().upper()}")
                    self._send_tp_response(response)
                else:
                    self.delayed_send_queue.put((send_time, response))
            except Empty:
                pass

            try:
                frame = self.task_queue.get(timeout=0.01)
                if frame is None: break
                
                frame_data = bytes(frame.Data[:frame.DLC])
                logger.debug(f"处理任务: ID=0x{frame.CanID:X}, DLC={frame.DLC}, 数据={frame_data.hex().upper()}")
                self._process_tp_frame(frame_data)
            except Empty:
                continue
        logger.info("处理线程已退出。")

    # --- ISO-TP and UDS Logic ---
    def _process_tp_frame(self, payload_bytes):
        if not payload_bytes: return
        pci_type = payload_bytes[0] >> 4

        if pci_type == PCI_TYPE_SINGLE_FRAME:
            dl = payload_bytes[0] & 0x0F
            if 0 < dl <= 7 and len(payload_bytes) >= 1 + dl:
                payload = payload_bytes[1:1+dl]
                logger.info(f"传输层: 收到单帧 (SF), 长度 {len(payload)} 字节。")
                self._handle_uds_payload(payload)
        elif pci_type == PCI_TYPE_FIRST_FRAME:
            if len(payload_bytes) < 2: return
            dl = ((payload_bytes[0] & 0x0F) << 8) | payload_bytes[1]
            if dl > 7:
                self._reset_tp_state()
                logger.info(f"传输层: 收到首帧 (FF), 总长度 {dl} 字节。")
                self.reassembly_buffer = bytearray(payload_bytes[2:])
                self.expected_len = dl
                self.next_seq_num = 1
                self._send_flow_control()
        elif pci_type == PCI_TYPE_CONSECUTIVE_FRAME:
            seq_num = payload_bytes[0] & 0x0F
            if self.next_seq_num is not None and seq_num == self.next_seq_num:
                self.reassembly_buffer.extend(payload_bytes[1:])
                self.next_seq_num = (self.next_seq_num + 1) & 0x0F
                if len(self.reassembly_buffer) >= self.expected_len:
                    logger.info(f"传输层: 报文重组完成 ({self.expected_len} 字节)。")
                    self._handle_uds_payload(bytes(self.reassembly_buffer[:self.expected_len]))
                    self._reset_tp_state()
            else:
                logger.error(f"传输层: 序列号错误！期望 {self.next_seq_num}, 收到 {seq_num}。重置状态。")
                self._reset_tp_state()

    def _reset_tp_state(self):
        self.reassembly_buffer.clear()
        self.expected_len = 0
        self.next_seq_num = None

    def _handle_uds_payload(self, payload):
        response = self.uds_logic.process_request(payload, self)
        if response:
            self._send_tp_response(response)
            
    # --- Low-Level CAN Frame Sending ---
    def _send_can_frame(self, can_id, data):
        """【重要】构造并发送单个CAN帧，不再进行不必要的填充。"""
        frame = FkVciCanDataType()
        frame.CanID = can_id
        frame.DLC = len(data)
        frame.FLAG = 0  # Standard Data Frame
        
        # 直接将数据复制到帧的数据区
        frame.Data[:len(data)] = data
        
        self.api.transmit_can(self.dev_idx, self.ch_idx, frame)

    def _send_flow_control(self):
        fc_data = bytes([0x30, 0x00, 0x0A]) 
        logger.info(f"传输层: 正在发送流控帧 (FC)。")
        self._send_can_frame(self.res_id, fc_data)

    def _send_tp_response(self, payload):
        payload_len = len(payload)
        if payload_len <= 7:
            pci = (PCI_TYPE_SINGLE_FRAME << 4) | payload_len
            frame_data = bytes([pci]) + payload
            self._send_can_frame(self.res_id, frame_data)
            logger.info(f"传输层: 已发送单帧响应 ({payload_len} 字节)。")
        else:
            self._send_multi_frame_response(payload)

    def _send_multi_frame_response(self, payload):
        payload_len = len(payload)
        pci_ff = [(PCI_TYPE_FIRST_FRAME << 4) | (payload_len >> 8), payload_len & 0xFF]
        ff_data = bytes(pci_ff) + payload[:6]
        self._send_can_frame(self.res_id, ff_data)
        logger.info(f"传输层: 已发送首帧响应 (总长度 {payload_len})。")
        
        time.sleep(0.02) # 模拟等待FC帧的时间

        bytes_sent = 6
        seq_num = 1
        while bytes_sent < payload_len and self.is_running:
            chunk = payload[bytes_sent : bytes_sent + 7]
            pci_cf = (PCI_TYPE_CONSECUTIVE_FRAME << 4) | seq_num
            cf_data = bytes([pci_cf]) + chunk
            self._send_can_frame(self.res_id, cf_data)
            logger.debug(f"传输层: 已发送连续帧 #{seq_num}。")
            bytes_sent += len(chunk)
            seq_num = (seq_num + 1) & 0x0F
            time.sleep(0.01) # 模拟STmin
        logger.info(f"传输层: 多帧响应发送完毕。")
