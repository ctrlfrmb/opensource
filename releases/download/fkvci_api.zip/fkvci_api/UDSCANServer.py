#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# UDSCANServer.py - ECU模拟器的核心服务，处理CAN通信和ISO-TP协议。

import time
import threading
import logging
from queue import Queue, Empty
from FKVciClient import FKVciClient
from FKVciMessage import hex_dump, get_status_description, FkVciCanFdConfig
from UDSCANServerLogic import UdsLogic

logger = logging.getLogger('ECU_SIM.CORE')

PCI_TYPE_SINGLE_FRAME = 0
PCI_TYPE_FIRST_FRAME = 1
PCI_TYPE_CONSECUTIVE_FRAME = 2

class UDSCANServer:
    """ECU模拟器核心类，被动执行指令并管理后台通信。"""
    def __init__(self):
        self.client = FKVciClient()
        self.uds_logic = UdsLogic()

        self.is_running = False
        self.recv_thread = None
        self.proc_thread = None
        self.task_queue = Queue() # 任务队列，用于解耦收发
        self.delayed_send_queue = Queue() # 新增：用于处理需要延迟发送的响应

        self.dev_idx = -1
        self.ch_idx = -1
        self.req_id = -1
        self.res_id = -1

        # ISO-TP 接收状态机变量
        self.reassembly_buffer = bytearray()
        self.expected_len = 0
        self.next_seq_num = None

    def open_device(self, dev_type, dev_index, reserved):
        return self.client.open_device(dev_type, dev_index, reserved)

    def close_device(self, dev_index):
        """关闭指定的设备，并确保服务已停止。"""
        if self.is_running:
            self.stop_service()
        return self.client.close_device(dev_index)

    def init_can(self, dev, ch, baud, req_id, res_id):
        ret = self.client.init_can(dev, ch, baud)
        if ret == 0:
            self.dev_idx, self.ch_idx, self.req_id, self.res_id = dev, ch, req_id, res_id
            self.start_service()
        return ret
        
    def init_canfd_advanced(self, dev, ch, config, req_id, res_id):
        ret = self.client.init_canfd_advanced(dev, ch, **config)
        if ret == 0:
            self.dev_idx, self.ch_idx, self.req_id, self.res_id = dev, ch, req_id, res_id
            self.start_service()
        return ret

    def reset_can(self, dev, ch):
        return self.client.reset_can(dev, ch)

    def clear_can(self, dev, ch):
        return self.client.clear_can(dev, ch)

    def open_log(self):
        return self.client.open_log("logs/uds_can_server.log", 0)

    def close_log(self):
        return self.client.close_log()

    def start_service(self):
        if self.is_running:
            logger.warning("服务线程已在运行中。")
            return
        self.is_running = True
        
        self.recv_thread = threading.Thread(target=self._recv_loop, daemon=True)
        self.recv_thread.start()
        
        self.proc_thread = threading.Thread(target=self._proc_loop, daemon=True)
        self.proc_thread.start()
        
        logger.info(f"ECU模拟服务已在通道 {self.ch_idx} 上启动...")

    def stop_service(self):
        if not self.is_running:
            return
        self.is_running = False
        
        if self.recv_thread and self.recv_thread.is_alive():
            self.recv_thread.join(timeout=1.0)
        self.recv_thread = None
        
        if self.proc_thread and self.proc_thread.is_alive():
            self.task_queue.put(None) 
            self.proc_thread.join(timeout=1.0)
        self.proc_thread = None

        logger.info("ECU模拟服务已停止。")

    def schedule_final_response(self, response_payload, delay_seconds):
        """
        新增：提供给应用层(UdsLogic)的接口，用于安排一个延迟发送的响应。
        """
        send_time = time.time() + delay_seconds
        self.delayed_send_queue.put((send_time, response_payload))
        logger.info(f"核心服务: 已将一个最终响应安排在 {delay_seconds:.2f} 秒后发送。")

    def _recv_loop(self):
        """接收线程：只负责从VCI接收数据并放入任务队列。"""
        logger.info("接收线程已启动。")
        while self.is_running:
            frames = self.client.recv_can_bulk(self.dev_idx, self.ch_idx, 50, 100)
            if frames:
                for frame in frames:
                    if frame.CanID == self.req_id:
                        self.task_queue.put(frame)
            else:
                time.sleep(0.001)
        logger.info("接收线程已退出。")

    def _proc_loop(self):
        """
        处理线程：重构以支持即时任务和延迟任务。
        - 优先处理到期的延迟发送任务。
        - 然后处理来自客户端的新请求。
        """
        logger.info("处理线程已启动。")
        while self.is_running:
            # 1. 检查并处理到期的延迟任务
            try:
                send_time, response = self.delayed_send_queue.get_nowait()
                if time.time() >= send_time:
                    logger.info(f"核心服务: 正在发送延迟的最终响应: {response.hex().upper()}")
                    self._send_tp_response(response)
                else:
                    self.delayed_send_queue.put((send_time, response)) # 时间未到，放回队列
            except Empty:
                pass # 延迟队列为空是正常情况

            # 2. 检查并处理新的客户端请求
            try:
                # 使用短超时，以便能频繁检查延迟队列和 is_running 标志
                frame = self.task_queue.get(timeout=0.01)
                if frame is None: break
                
                logger.debug(f"处理任务: ID=0x{frame.CanID:X}, DLC={frame.DLC}, 数据={hex_dump(frame.Data[:frame.DLC])}")
                self._process_tp_frame(frame)
            except Empty:
                continue # 新请求队列为空是正常情况
        logger.info("处理线程已退出。")

    def _process_tp_frame(self, frame):
        """处理ISO-TP帧，管理状态机。"""
        # 优化：确保传入应用层的是 bytes 类型，而不是 list
        payload_bytes = bytes(frame.Data)
        pci_type = payload_bytes[0] >> 4

        if pci_type == PCI_TYPE_SINGLE_FRAME:
            dl = payload_bytes[0] & 0x0F
            if 0 < dl <= 7:
                payload = payload_bytes[1:1+dl]
                logger.info(f"传输层: 收到单帧 (SF), 长度 {len(payload)} 字节。")
                self._handle_uds_payload(payload)
        elif pci_type == PCI_TYPE_FIRST_FRAME:
            dl = ((payload_bytes[0] & 0x0F) << 8) | payload_bytes[1]
            if dl > 7:
                self._reset_tp_state()
                logger.info(f"传输层: 收到首帧 (FF), 总长度 {dl} 字节。")
                self.reassembly_buffer = bytearray(payload_bytes[2:frame.DLC])
                self.expected_len = dl
                self.next_seq_num = 1
                self._send_flow_control()
        elif pci_type == PCI_TYPE_CONSECUTIVE_FRAME:
            seq_num = payload_bytes[0] & 0x0F
            if self.next_seq_num is not None and seq_num == self.next_seq_num:
                self.reassembly_buffer.extend(payload_bytes[1:frame.DLC])
                self.next_seq_num = (self.next_seq_num + 1) & 0x0F
                if len(self.reassembly_buffer) >= self.expected_len:
                    logger.info(f"传输层: 报文重组完成 ({self.expected_len} 字节)。")
                    self._handle_uds_payload(bytes(self.reassembly_buffer[:self.expected_len]))
                    self._reset_tp_state()
            else:
                logger.error(f"传输层: 序列号错误！期望 {self.next_seq_num}, 收到 {seq_num}。重置状态。")
                self._reset_tp_state()

    def _reset_tp_state(self):
        self.reassembly_buffer.clear()
        self.expected_len = 0
        self.next_seq_num = None

    def _send_flow_control(self):
        fc_data = [0x30, 0x00, 0x0A] 
        logger.info(f"传输层: 正在发送流控帧 (FC)。")
        self.client.send_can(self.dev_idx, self.ch_idx, self.res_id, fc_data)

    def _handle_uds_payload(self, payload):
        """将自身实例(self)传递给应用层，使其具备调用 schedule_final_response 的能力。"""
        response = self.uds_logic.process_request(payload, self)
        if response:
            self._send_tp_response(response)

    def _send_tp_response(self, payload):
        payload_len = len(payload)
        if payload_len <= 7:
            pci = (PCI_TYPE_SINGLE_FRAME << 4) | payload_len
            frame_data = bytes([pci]) + payload
            self.client.send_can(self.dev_idx, self.ch_idx, self.res_id, list(frame_data))
            logger.info(f"传输层: 已发送单帧响应 ({payload_len} 字节)。")
        else:
            self._send_multi_frame_response(payload)

    def _send_multi_frame_response(self, payload):
        payload_len = len(payload)
        pci_ff = [(PCI_TYPE_FIRST_FRAME << 4) | (payload_len >> 8), payload_len & 0xFF]
        ff_data = bytes(pci_ff) + payload[:6]
        self.client.send_can(self.dev_idx, self.ch_idx, self.res_id, list(ff_data))
        logger.info(f"传输层: 已发送首帧响应 (总长度 {payload_len})。")
        
        time.sleep(0.02) # 等待流控帧

        bytes_sent = 6
        seq_num = 1
        while bytes_sent < payload_len and self.is_running:
            chunk = payload[bytes_sent : bytes_sent + 7]
            pci_cf = (PCI_TYPE_CONSECUTIVE_FRAME << 4) | seq_num
            cf_data = bytes([pci_cf]) + chunk
            self.client.send_can(self.dev_idx, self.ch_idx, self.res_id, list(cf_data))
            logger.debug(f"传输层: 已发送连续帧 #{seq_num}。")
            bytes_sent += len(chunk)
            seq_num = (seq_num + 1) & 0x0F
            time.sleep(0.01) # 遵守STmin
        logger.info(f"传输层: 多帧响应发送完毕。")
