#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciSentTest.py - 交互式 SENT 控制台 (v1.0.4)

import sys
import signal
import time
import threading
import platform
import shlex
from ctypes import *
from FKVciApi import FKVciApi
from FKVciMessage import FkVciSentDataType, get_vci_status_description

def safe_parse_int(s, base=10):
    """将字符串安全地解析为整数"""
    if not isinstance(s, str): return None
    try:
        return int(s, base)
    except (ValueError, TypeError):
        return None

def hex_dump(data, length=None):
    """将字节数组转换为十六进制字符串"""
    if length is None:
        length = len(data)
    return " ".join(f"{data[i]:02X}" for i in range(length))

def get_full_timestamp(msg):
    """从消息结构体中获取完整的64位时间戳"""
    return (msg.TimesampH << 32) | msg.TimesampL

def parse_sent_data(data, dlc):
    """
    解析SENT的原始数据负载。
    每个SENT帧包含多个字节，这里我们将它们分组显示。
    假设每个SENT消息是4字节（1字节状态+3字节数据）。
    """
    if dlc == 0:
        return "No Data"
    
    # 假设每个SENT消息是4字节对齐的
    # 你可以根据实际的硬件协议调整这里的 `chunk_size`
    chunk_size = 4 
    num_chunks = dlc // chunk_size
    
    output_parts = []
    for i in range(num_chunks):
        start = i * chunk_size
        end = start + chunk_size
        chunk = data[start:end]
        output_parts.append(hex_dump(chunk, len(chunk)))

    # 处理剩余不足一个chunk的数据
    remaining_start = num_chunks * chunk_size
    if remaining_start < dlc:
        remaining_data = data[remaining_start:dlc]
        output_parts.append(f"Rem: {hex_dump(remaining_data, len(remaining_data))}")

    return " | ".join(output_parts)

class FKVciSentTest:
    def __init__(self):
        self.api = None
        self.running = True
        self.auto_recv_thread = None
        self.auto_recv_flag = False
        try:
            self.api = FKVciApi()
        except Exception as e:
            print(f"[致命错误] FKVCI 库初始化失败: {e}")

    def cleanup(self):
        print("\n[退出] 正在清理资源...")
        self.stop_auto_recv()
        time.sleep(0.1)
        if self.api:
            self.api.vci.FkVciCloseDev(-1)
            time.sleep(0.5)
            self.api.vci.FkVciCloseLog()
        print("[退出] 已关闭所有设备和日志")

    def parse_args(self, line):
        try:
            return shlex.split(line)
        except ValueError:
            print("[错误] 命令格式不正确")
            return []

    def extract_arg(self, args, key, default=None, cast_func=str):
        if key in args:
            idx = args.index(key)
            if idx + 1 < len(args):
                try:
                    return cast_func(args[idx + 1])
                except (ValueError, TypeError):
                    pass
        return default

    def run(self):
        print("=" * 60)
        print(f"FKVCI SENT 命令行测试工具 v1.0.4 ({platform.architecture()[0]})")
        print("=" * 60)
        
        if not self.api:
            print("\n[错误] 无法启动，因为 FKVCI 库加载失败。")
            return

        print("输入 --help 查看帮助，--exit 或 Ctrl+C 退出")
        while self.running:
            try:
                raw_input_str = input("SENT >>> ").strip()
                if not raw_input_str:
                    continue
                args = self.parse_args(raw_input_str)
                if not args:
                    continue
                cmd = args[0].lower()

                command_map = {
                    "--exit": lambda a: self.stop_running(),
                    "--help": self.print_help,
                    "--scan": self.do_scan,
                    "--open": self.do_open,
                    "--close": self.do_close,
                    "--log": self.do_log,
                    "--initsent": self.do_init_sent,
                    "--resetsent": self.do_reset_sent,
                    "--clearsent": self.do_clear_sent,
                    "--recv": self.do_recv,
                    "--autorecv": self.do_auto_recv,
                }
                
                if cmd in command_map:
                    command_map[cmd](args)
                else:
                    print("[未知命令] 输入 --help 查看支持的命令")

            except (EOFError, KeyboardInterrupt):
                self.stop_running()
                break
            except Exception as e:
                print(f"[异常] {e}")

        self.cleanup()

    def stop_running(self, *args):
        if self.running:
            self.running = False
            print("\n[程序] 正在退出...")

    def print_help(self, *args):
        print("\nSENT可用命令 (所有参数均为10进制):")
        print("--- 通用控制 ---")
        print("  --log on|off")
        print("  --scan -timeout 500")
        print("  --open -dev 0")
        print("  --close -dev 0")
        print("--- SENT通道初始化 ---")
        print("  --initSENT -dev 0 -ch 0 -fastMsg 16 -tick 3 -interval 10")
        print("  --resetSENT -dev 0 -ch 0")
        print("  --clearSENT -dev 0 -ch 0")
        print("--- 接收测试 ---")
        print("  --recv -dev 0 -ch 0 -count 10 -timeout 1000")
        print("  --autoRecv on|off -dev 0 -ch 0")
        print("  --exit\n")

    def do_scan(self, args):
        timeout = self.extract_arg(args, "-timeout", 500, int)
        print(f"[scan] 正在扫描设备 (超时: {timeout}ms)...")
        max_devices = 16
        indices_array = (c_int * max_devices)()
        count = c_uint8(max_devices)
        ret = self.api.vci.FkVciScanDevice(indices_array, byref(count), timeout)
        if ret == 0:
            devices = [indices_array[i] for i in range(count.value)]
            if devices:
                print(f"[scan] 扫描成功，发现 {len(devices)} 个设备: {devices}")
            else:
                print("[scan] 扫描完成，未发现任何设备。")
        else:
            print(f"[scan] 扫描失败: {get_vci_status_description(ret)}")

    def do_open(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ret = self.api.vci.FkVciOpenDev(0, dev, 0)
        print(f"[open] 打开设备 {dev} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_close(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ret = self.api.vci.FkVciCloseDev(dev)
        print(f"[close] 关闭设备 {dev} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_log(self, args):
        if "on" in args:
            ret = self.api.vci.FkVciOpenLog("logs/fkvci_sent.log".encode('utf-8'), 0, 5, 10)
            print(f"[log] 开启日志返回: {ret}")
        else:
            self.api.vci.FkVciCloseLog()
            print("[log] 已关闭")

    def do_init_sent(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        fast_msg = self.extract_arg(args, "-fastMsg", 16, int)
        tick = self.extract_arg(args, "-tick", 3, int)
        interval = self.extract_arg(args, "-interval", 10, int)
        ret = self.api.vci.FkVciInitSENT(dev, ch, fast_msg, tick, interval)
        print(f"[initSENT] Dev{dev}-Ch{ch} FastMsg={fast_msg} Tick={tick} Interval={interval}ms 返回: {ret} ({get_vci_status_description(ret)})")

    def do_reset_sent(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.api.vci.FkVciResetSENT(dev, ch)
        print(f"[resetSENT] Dev{dev}-Ch{ch} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_clear_sent(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.api.vci.FkVciClearSENT(dev, ch)
        print(f"[clearSENT] Dev{dev}-Ch{ch} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_recv(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        max_count = self.extract_arg(args, "-count", 10, int)
        timeout = self.extract_arg(args, "-timeout", 1000, int)
        
        buffer = (FkVciSentDataType * max_count)()
        count = c_uint32(max_count)
        ret = self.api.vci.FkVciReceiveSENT(dev, ch, buffer, byref(count), timeout)
        
        if ret == 0 and count.value > 0:
            print(f"[recv] 收到 {count.value} 条消息:")
            for i in range(count.value):
                msg = buffer[i]
                ts = get_full_timestamp(msg) / 10.0
                data_str = parse_sent_data(msg.Data, msg.DLC)
                print(f"  [{i+1}] TS={ts:.1f}us, DLC={msg.DLC}, Data={data_str}")
        else:
            print(f"[recv] 无数据或接收失败: {get_vci_status_description(ret)}")

    def do_auto_recv(self, args):
        if "on" in args:
            dev = self.extract_arg(args, "-dev", 0, int)
            ch = self.extract_arg(args, "-ch", 0, int)
            self.start_auto_recv(dev, ch)
        else:
            self.stop_auto_recv()

    def start_auto_recv(self, dev, ch):
        if self.auto_recv_thread and self.auto_recv_thread.is_alive():
            print("[autoRecv] 自动接收已在运行")
            return
        
        self.auto_recv_flag = True
        
        def worker():
            MAX_RECV_COUNT = 50  # SENT消息可能很大，一次少读一点
            buffer_type = FkVciSentDataType * MAX_RECV_COUNT
            buffer = buffer_type()
            
            while self.auto_recv_flag:
                count = c_uint32(MAX_RECV_COUNT)
                ret = self.api.vci.FkVciReceiveSENT(dev, ch, buffer, byref(count), 0)
                
                if ret == 0 and count.value > 0:
                    sys.stdout.write("\r\033[K")
                    for i in range(count.value):
                        msg = buffer[i]
                        ts = get_full_timestamp(msg) / 10.0
                        data_str = parse_sent_data(msg.Data, msg.DLC)
                        print(f"[AutoRecv] TS={ts:.1f}us, DLC={msg.DLC}, Data={data_str}")
                    
                    sys.stdout.write("SENT >>> ")
                    sys.stdout.flush()
                
                time.sleep(0.05)

        self.auto_recv_thread = threading.Thread(target=worker, daemon=True)
        self.auto_recv_thread.start()
        print(f"[autoRecv] 启动 Dev{dev}-Ch{ch} 自动接收")

    def stop_auto_recv(self):
        if self.auto_recv_thread:
            self.auto_recv_flag = False
            self.auto_recv_thread.join(timeout=1.0)
            self.auto_recv_thread = None
            print("\n[autoRecv] 停止")

if __name__ == "__main__":
    shell = FKVciSentTest()
    def signal_handler(sig, frame):
        shell.stop_running()
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    shell.run()
