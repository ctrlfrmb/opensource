#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciFlowTest.py - 独立的请求-响应循环测试工具 (v2.0.0)

import sys
import signal
import time
import platform
from FKVciClient import FKVciClient
from FKVciMessage import hex_dump, get_status_description

def safe_parse_int(s):
    """将字符串安全地解析为整数，默认按16进制"""
    if not isinstance(s, str): return None
    try:
        return int(s, 16)
    except (ValueError, TypeError):
        return None

def parse_data_from_str(s):
    """从空格分隔的字符串解析数据列表"""
    return [val for val in (safe_parse_int(x) for x in s.split()) if val is not None]

class FlowTester:
    def __init__(self, dev_index, ch_index):
        self.client = FKVciClient()
        self.running = True
        self.dev = dev_index
        self.ch = ch_index
        self.success_count = 0
        self.fail_count = 0
        self.total_loops = 0

    def setup(self):
        """打开设备并初始化CAN通道"""
        self.client.open_log()
        print("[log] 已开启")
        ret = self.client.open_device(0, self.dev, 0)
        print(f"[Setup] 打开设备 {self.dev}... {get_status_description(ret)}")
        if ret != 0: return False
        
        ret = self.client.init_canfd(self.dev, self.ch, 500000, 2000000)
        print(f"[Setup] 初始化CANFD通道 {self.ch}... {get_status_description(ret)}")
        return ret == 0

    def cleanup(self):
        """关闭设备并打印最终统计"""
        print("\n" + "="*20 + " 最终测试总结 " + "="*18)
        self.print_stats()
        print("="*50)
        
        print("[Cleanup] 正在关闭设备...")
        self.client.close_device(self.dev)
        self.client.close_log()
        print("[Cleanup] 已完成。")

    def _format_can_message(self, msg):
        """格式化CAN报文用于打印，时间戳以秒为单位"""
        # 原始单位是0.1微秒，转换为秒
        ts_sec = msg.get_full_timestamp() / 10000000.0
        
        # REV2: 0x01=发送, 0x02=接收
        dir_str = "Tx" if msg.REV2 == 0x01 else "Rx"
            
        return (f"  [{ts_sec:18.6f}] [{dir_str}] ID=0x{msg.CanID:08X}, "
                f"DLC={msg.DLC:2}, Data={hex_dump(msg.Data[:msg.DLC])}")

    def print_stats(self):
        """打印当前的统计信息"""
        success_rate = (self.success_count / self.total_loops * 100) if self.total_loops > 0 else 0
        stats_line = (f"统计: [总计: {self.total_loops}]  "
                      f"[成功: {self.success_count}]  "
                      f"[失败: {self.fail_count}]  "
                      f"[成功率: {success_rate:.2f}%]")
        print(stats_line)

    def run(self):
        """主执行循环"""
        if not self.setup():
            print("[错误] 初始化失败，程序退出。")
            return

        try:
            # 1. 配置流程
            print("--- 请配置测试流程 (所有ID和数据均为十六进制) ---")
            send1_id_str = input("  [1] 输入初始发送ID: ")
            send1_id = safe_parse_int(send1_id_str)
            send1_data_str = input(f"  [1] 输入 ID=0x{send1_id:X} 的数据: ")
            send1_data = parse_data_from_str(send1_data_str)

            recv_id_str = input("  [2] 输入期望接收ID: ")
            recv_id = safe_parse_int(recv_id_str)
            recv_data_str = input(f"  [2] 输入 ID=0x{recv_id:X} 的期望数据 (输入几个字节就校验几个): ")
            recv_data_match = parse_data_from_str(recv_data_str)

            send2_id_str = input("  [3] 成功接收后，输入第二次发送ID: ")
            send2_id = safe_parse_int(send2_id_str)
            send2_data_str = input(f"  [3] 输入 ID=0x{send2_id:X} 的数据: ")
            send2_data = parse_data_from_str(send2_data_str)

            if None in [send1_id, recv_id, send2_id] or not recv_data_match:
                print("\n[错误] 输入无效，流程中止。")
                return
            
            timeout_s = int(input("  [4] 输入每次等待的超时时间 (秒，默认5): ") or "5")
            interval_ms = int(input("  [5] 输入每轮循环的间隔 (毫秒，默认1000): ") or "1000")

            print("\n--- 配置完成，流程开始 (按 Ctrl+C 停止) ---")
            
            while self.running:
                self.total_loops += 1
                print(f"\n--- 第 {self.total_loops} 轮 ---")
                
                # 步骤1: 发送初始报文
                print(f"[Send]   ID=0x{send1_id:X}, Data={hex_dump(send1_data)}")
                self.client.send_can(self.dev, self.ch, send1_id, send1_data, 1)
                
                # 步骤2: 等待特定响应
                print(f"[Wait]   等待 ID=0x{recv_id:X}, Data={hex_dump(recv_data_match)}... (超时: {timeout_s}s)")
                
                start_time = time.time()
                response_received = False
                while time.time() - start_time < timeout_s:
                    if not self.running: break
                    
                    # --- 核心修改：使用 recv_can_bulk 读取多帧 ---
                    messages = self.client.recv_can_bulk(self.dev, self.ch, max_count=100, timeout_ms=0)
                    
                    if messages:
                        for msg in messages:
                            # 只显示与我们关心的ID相关的报文
                            if msg.CanID == send1_id or msg.CanID == recv_id:
                                print(self._format_can_message(msg))
                            
                            # 检查是否是我们期望的响应
                            if msg.CanID == recv_id and list(msg.Data[:len(recv_data_match)]) == recv_data_match:
                                print("  [OK]     期望的响应已收到！")
                                response_received = True
                                break # 跳出 for 循环
                    
                    if response_received:
                        break # 跳出 while 循环
                    
                    # --- 核心修改：加入轮询间隔 ---
                    time.sleep(0.01) # 间隔10毫秒
                
                if not self.running: break

                # 步骤3: 根据接收结果决定下一步并统计
                if response_received:
                    self.success_count += 1
                    print(f"[Send]   ID=0x{send2_id:X}, Data={hex_dump(send2_data)}")
                    self.client.send_can(self.dev, self.ch, send2_id, send2_data, 1)
                else:
                    self.fail_count += 1
                    print(f"  [超时]   在 {timeout_s} 秒内未收到期望的响应，本轮失败。")
                
                # 每轮结束后打印统计信息
                self.print_stats()
                time.sleep(interval_ms / 1000.0)

        except (KeyboardInterrupt, EOFError):
            print("\n[中断] 正在退出流程...")
        finally:
            self.cleanup()

if __name__ == "__main__":
    print("=" * 60)
    print(f"FKVCI 请求-响应流程测试工具 v1.5.0")
    print("=" * 60)
    try:
        dev_idx = int(input("请输入设备索引 (如 0): "))
        ch_idx = int(input("请输入CAN通道索引 (如 0): "))
    except (ValueError, EOFError):
        print("\n输入无效，退出。")
        sys.exit(1)

    flow_tester = FlowTester(dev_idx, ch_idx)

    def signal_handler(sig, frame):
        flow_tester.running = False

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    flow_tester.run()
