#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciFlowTest.py - 独立的请求-响应循环测试工具 (v3.0.1, 修正版)

import sys
import signal
import time
from ctypes import *
from FKVciApi import FKVciApi
from FKVciMessage import FkVciCanDataType, get_vci_status_description

def safe_parse_int(s, base=16):
    """将字符串安全地解析为整数"""
    if not isinstance(s, str): return None
    try:
        return int(s, base)
    except (ValueError, TypeError):
        return None

def hex_dump(data, length=None):
    """将字节数组转换为十六进制字符串"""
    if length is None:
        length = len(data)
    return " ".join(f"{data[i]:02X}" for i in range(length))

def get_full_timestamp(msg):
    """从消息结构体中获取完整的64位时间戳"""
    return (msg.TimesampH << 32) | msg.TimesampL

def parse_data_from_str(s):
    """从空格分隔的字符串解析数据列表"""
    return [val for val in (safe_parse_int(x) for x in s.split()) if val is not None]

class FlowTester:
    def __init__(self, dev_index, ch_index):
        self.api = None
        self.running = True
        self.dev = dev_index
        self.ch = ch_index
        self.success_count = 0
        self.fail_count = 0
        self.total_loops = 0
        try:
            self.api = FKVciApi()
        except Exception as e:
            print(f"[致命错误] FKVCI 库初始化失败: {e}")

    def setup(self):
        """打开设备并初始化CAN通道"""
        if not self.api:
            print("[错误] API未初始化")
            return False
            
        ret = self.api.vci.FkVciOpenLog("logs/fkvci_flow_test.log".encode('utf-8'), 0, 5, 10)
        print(f"[log] 开启日志... {get_vci_status_description(ret)}")
        
        ret = self.api.vci.FkVciOpenDev(0, self.dev, 0)
        print(f"[Setup] 打开设备 {self.dev}... {get_vci_status_description(ret)}")
        if ret != 0: return False
        
        ret = self.api.vci.FkVciInitCANFD(self.dev, self.ch, 500000, 2000000)
        print(f"[Setup] 初始化CANFD通道 {self.ch}... {get_vci_status_description(ret)}")
        return ret == 0

    def cleanup(self):
        """关闭设备并打印最终统计"""
        print("\n" + "="*20 + " 最终测试总结 " + "="*18)
        self.print_stats()
        print("="*50)
        
        if self.api:
            print("[Cleanup] 正在关闭设备...")
            self.api.vci.FkVciCloseDev(self.dev)
            self.api.vci.FkVciCloseLog()
        print("[Cleanup] 已完成。")

    def _format_can_message(self, msg):
        """格式化CAN报文用于打印，时间戳以秒为单位"""
        ts_sec = get_full_timestamp(msg) / 10000000.0
        dir_str = "Tx" if msg.REV2 == 0x01 else "Rx"
        return (f"  [{ts_sec:18.6f}] [{dir_str}] ID=0x{msg.CanID:08X}, "
                f"DLC={msg.DLC:2}, Data={hex_dump(msg.Data, msg.DLC)}")

    def print_stats(self):
        """打印当前的统计信息"""
        success_rate = (self.success_count / self.total_loops * 100) if self.total_loops > 0 else 0
        stats_line = (f"统计: [总计: {self.total_loops}]  "
                      f"[成功: {self.success_count}]  "
                      f"[失败: {self.fail_count}]  "
                      f"[成功率: {success_rate:.2f}%]")
        print(stats_line)

    def _send_can_frame(self, can_id, data):
        """辅助函数，用于发送单帧CAN报文"""
        buf = FkVciCanDataType()
        buf.CanID = can_id
        buf.FLAG = 0
        buf.DLC = len(data)
        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        self.api.vci.FkVciTransmitCAN(self.dev, self.ch, byref(buf), 1)

    def run(self):
        """主执行循环"""
        if not self.setup():
            print("[错误] 初始化失败，程序退出。")
            if self.api:
                self.api.vci.FkVciCloseLog()
            return

        try:
            print("--- 请配置测试流程 (所有ID和数据均为十六进制) ---")
            send1_id = safe_parse_int(input("  [1] 输入初始发送ID: "))
            send1_data = parse_data_from_str(input(f"  [1] 输入 ID=0x{send1_id:X} 的数据: "))
            recv_id = safe_parse_int(input("  [2] 输入期望接收ID: "))
            recv_data_match = parse_data_from_str(input(f"  [2] 输入 ID=0x{recv_id:X} 的期望数据 (输入几个字节就校验几个): "))
            send2_id = safe_parse_int(input("  [3] 成功接收后，输入第二次发送ID: "))
            send2_data = parse_data_from_str(input(f"  [3] 输入 ID=0x{send2_id:X} 的数据: "))
            timeout_s = int(input("  [4] 输入每次等待的超时时间 (秒，默认5): ") or "5")
            interval_ms = int(input("  [5] 输入每轮循环的间隔 (毫秒，默认1000): ") or "1000")

            if None in [send1_id, recv_id, send2_id] or not recv_data_match:
                print("\n[错误] 输入无效，流程中止。")
                return
            
            print("\n--- 配置完成，流程开始 (按 Ctrl+C 停止) ---")
            
            MAX_RECV_COUNT = 100
            buffer_type = FkVciCanDataType * MAX_RECV_COUNT
            buffer = buffer_type()

            while self.running:
                self.total_loops += 1
                print(f"\n--- 第 {self.total_loops} 轮 ---")
                
                print(f"[Send]   ID=0x{send1_id:X}, Data={hex_dump(send1_data)}")
                self._send_can_frame(send1_id, send1_data)
                
                print(f"[Wait]   等待 ID=0x{recv_id:X}, Data={hex_dump(recv_data_match)}... (超时: {timeout_s}s)")
                
                start_time = time.time()
                response_received = False
                while time.time() - start_time < timeout_s and self.running:
                    count = c_uint32(MAX_RECV_COUNT)
                    ret = self.api.vci.FkVciReceiveCAN(self.dev, self.ch, buffer, byref(count), 0)
                    
                    if ret == 0 and count.value > 0:
                        for i in range(count.value):
                            msg = buffer[i]
                            if msg.CanID == send1_id or msg.CanID == recv_id:
                                print(self._format_can_message(msg))
                            
                            if msg.CanID == recv_id and list(msg.Data[:len(recv_data_match)]) == recv_data_match:
                                print("  [OK]     期望的响应已收到！")
                                response_received = True
                                break
                    
                    if response_received:
                        break
                    
                    time.sleep(0.01)
                
                if not self.running: break

                if response_received:
                    self.success_count += 1
                    print(f"[Send]   ID=0x{send2_id:X}, Data={hex_dump(send2_data)}")
                    self._send_can_frame(send2_id, send2_data)
                else:
                    self.fail_count += 1
                    print(f"  [超时]   在 {timeout_s} 秒内未收到期望的响应，本轮失败。")
                
                self.print_stats()
                time.sleep(interval_ms / 1000.0)

        except (KeyboardInterrupt, EOFError):
            print("\n[中断] 正在退出流程...")
        finally:
            self.cleanup()

if __name__ == "__main__":
    print("=" * 60)
    print("FKVCI 请求-响应流程测试工具 v3.0.1")
    print("=" * 60)
    try:
        dev_idx = int(input("请输入设备索引 (如 0): "))
        ch_idx = int(input("请输入CAN通道索引 (如 0): "))
    except (ValueError, EOFError):
        print("\n输入无效，退出。")
        sys.exit(1)

    tester = FlowTester(dev_idx, ch_idx)
    def signal_handler(sig, frame):
        tester.running = False
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    tester.run()
