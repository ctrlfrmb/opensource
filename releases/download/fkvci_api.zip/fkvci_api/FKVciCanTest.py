#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciCanTest.py - 交互式 CAN 控制台 (v1.0.4)

import sys
import signal
import time
import threading
import platform
import shlex
from ctypes import *
from FKVciApi import FKVciApi
from FKVciMessage import FkVciCanDataType, FkVciCanFdConfig, get_vci_status_description

def safe_parse_int(s, base=16):
    """将字符串安全地解析为整数"""
    if not isinstance(s, str): return None
    try:
        return int(s, base)
    except (ValueError, TypeError):
        return None

def hex_dump(data, length=None):
    """将字节数组转换为十六进制字符串"""
    if length is None:
        length = len(data)
    return " ".join(f"{data[i]:02X}" for i in range(length))

def get_full_timestamp(msg):
    """从消息结构体中获取完整的64位时间戳"""
    return (msg.TimesampH << 32) | msg.TimesampL

class FKVciCanTest:
    def __init__(self):
        self.api = None
        self.running = True
        self.auto_recv_thread = None
        self.auto_recv_flag = False
        self.period_ids = {}
        try:
            self.api = FKVciApi()
        except Exception as e:
            print(f"[致命错误] FKVCI 库初始化失败: {e}")

    def cleanup(self):
        print("\n[退出] 正在清理资源...")
        self.stop_auto_recv()
        time.sleep(0.1)
        if self.api:
            self.api.vci.FkVciCloseDev(-1)
            time.sleep(0.5)
            self.api.vci.FkVciCloseLog()
        print("[退出] 已关闭所有设备和日志")

    def parse_args(self, line):
        try:
            return shlex.split(line)
        except ValueError:
            print("[错误] 命令格式不正确")
            return []

    def extract_arg(self, args, key, default=None, cast_func=str):
        if key in args:
            idx = args.index(key)
            if idx + 1 < len(args):
                try:
                    return cast_func(args[idx + 1])
                except (ValueError, TypeError):
                    pass
        return default

    def run(self):
        print("=" * 60)
        print(f"FKVCI CAN 命令行测试工具 v1.0.4 ({platform.architecture()[0]})")
        print("=" * 60)
        
        if not self.api:
            print("\n[错误] 无法启动，因为 FKVCI 库加载失败。")
            return

        print("输入 --help 查看帮助，--exit 或 Ctrl+C 退出")
        while self.running:
            try:
                raw_input_str = input("CAN >>> ").strip()
                if not raw_input_str:
                    continue
                args = self.parse_args(raw_input_str)
                if not args:
                    continue
                cmd = args[0].lower()

                command_map = {
                    "--exit": lambda a: self.stop_running(),
                    "--help": self.print_help,
                    "--scan": self.do_scan,
                    "--open": self.do_open,
                    "--close": self.do_close,
                    "--version": self.do_version,
                    "--basetime": self.do_basetime,
                    "--log": self.do_log,
                    "--getcanchannels": self.do_get_can_channels,
                    "--initcan": self.do_initcan,
                    "--initcanfd": self.do_initcanfd,
                    "--initcanfdadv": self.do_initcanfd_advanced,
                    "--send": self.do_send,
                    "--recv": self.do_recv,
                    "--startperiod": self.do_start_period,
                    "--stopperiod": self.do_stop_period,
                    "--resetcan": self.do_reset_can,
                    "--clearcan": self.do_clear_can,
                    "--setresistor": self.do_set_resistor,
                    "--getbusload": self.do_get_busload,
                    "--autorecv": self.do_auto_recv,
                    "--filter": self.do_start_filter,
                    "--stopfilter": self.do_stop_filter,
                }
                
                if cmd in command_map:
                    command_map[cmd](args)
                else:
                    print("[未知命令] 输入 --help 查看支持的命令")

            except (EOFError, KeyboardInterrupt):
                self.stop_running()
                break
            except Exception as e:
                print(f"[异常] {e}")

        self.cleanup()

    def stop_running(self, *args):
        if self.running:
            self.running = False
            print("\n[程序] 正在退出...")

    def print_help(self, *args):
        print("\nCAN可用命令 (所有ID和数据均为16进制, dev/ch/baud等为10进制):")
        print("--- 通用控制 ---")
        print("  --log on|off")
        print("  --scan -timeout 500")
        print("  --open -dev 0")
        print("  --close -dev 0")
        print("  --version -dev 0")
        print("  --baseTime -dev 0")
        print("  --getCanChannels -dev 0")
        print("--- CAN通道初始化 ---")
        print("  --initCAN -dev 0 -ch 0 -baud 500000")
        print("  --initCANFD -dev 0 -ch 0 -baud 500000 -fd 2000000")
        print("  --initCANFDAdv -dev 0 -ch 0 -baud 500000 -fd 2000000 -nseg1 31 -nseg2 8 -dseg1 15 -dseg2 4 -term 1")
        print("  --resetCAN -dev 0 -ch 0")
        print("  --clearCAN -dev 0 -ch 0")
        print("--- 收发测试 ---")
        print("  --send -dev 0 -ch 0 -id 123 -data 11 22 33")
        print("  --recv -dev 0 -ch 0 -count 10 -timeout 500")
        print("  --autoRecv on|off -dev 0 -ch 0")
        print("--- 周期发送 ---")
        print("  --startPeriod -dev 0 -ch 0 -id 100 -data 01 02 03 -time 100")
        print("  --stopPeriod -dev 0 -ch 0 -pid 1 (或 -pid -1 停止所有)")
        print("--- 过滤 ---")
        print("  --filter -dev 0 -ch 0 -ids 100 200 300")
        print("  --stopFilter -dev 0 -ch 0")
        print("--- 其他 ---")
        print("  --setResistor -dev 0 -ch 0 -enable 1")
        print("  --getBusLoad -dev 0 -chCount 8")
        print("  --exit\n")

    def do_scan(self, args):
        timeout = self.extract_arg(args, "-timeout", 500, int)
        print(f"[scan] 正在扫描设备 (超时: {timeout}ms)...")
        max_devices = 16
        indices_array = (c_int * max_devices)()
        count = c_uint8(max_devices)
        ret = self.api.vci.FkVciScanDevice(indices_array, byref(count), timeout)
        if ret == 0:
            devices = [indices_array[i] for i in range(count.value)]
            if devices:
                print(f"[scan] 扫描成功，发现 {len(devices)} 个设备: {devices}")
            else:
                print("[scan] 扫描完成，未发现任何设备。")
        else:
            print(f"[scan] 扫描失败: {get_vci_status_description(ret)}")

    def do_open(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ret = self.api.vci.FkVciOpenDev(0, dev, 0)
        print(f"[open] 打开设备 {dev} 返回: {ret} ({get_vci_status_description(ret)})")

    def do_close(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ret = self.api.vci.FkVciCloseDev(dev)
        print(f"[close] 关闭设备 {dev} 返回: {ret} ({get_vci_status_description(ret)})")
        
    def do_version(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        raw = self.api.vci.FkVciGetVersion(dev)
        if raw == 0:
            print(f"[version] 查询设备 {dev} 版本失败")
            return
        v = (raw >> 24) & 0xFF
        y = ((raw >> 16) & 0xFF) + 2000
        m = (raw >> 8) & 0xFF
        d = raw & 0xFF
        print(f"[version] 设备 {dev} 版本: v{v}.{y:04d}.{m:02d}.{d:02d}")

    def do_basetime(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        t = self.api.vci.FkVciGetBaseTime(dev)
        print(f"[baseTime] 设备 {dev} 基准时间: {t} (0.1 µs)")

    def do_log(self, args):
        if "on" in args:
            ret = self.api.vci.FkVciOpenLog("logs/fkvci_can.log".encode('utf-8'), 0, 10, 10)
            print(f"[log] 开启日志返回: {ret}")
        else:
            self.api.vci.FkVciCloseLog()
            print("[log] 已关闭")

    def do_get_can_channels(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        count = self.api.vci.FkVciGetCanChannelCount(dev)
        if count >= 0:
            print(f"[getCanChannels] 设备 {dev} 支持 {count} 个CAN通道。")
        else:
            print(f"[getCanChannels] 获取失败: {get_vci_status_description(count)}")

    def do_initcan(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        baud = self.extract_arg(args, "-baud", 500000, int)
        ret = self.api.vci.FkVciInitCAN(dev, ch, baud)
        print(f"[initCAN] Dev{dev}-Ch{ch} @ {baud}bps 返回: {ret} ({get_vci_status_description(ret)})")

    def do_initcanfd(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        baud = self.extract_arg(args, "-baud", 500000, int)
        fd_baud = self.extract_arg(args, "-fd", 2000000, int)
        ret = self.api.vci.FkVciInitCANFD(dev, ch, baud, fd_baud)
        print(f"[initCANFD] Dev{dev}-Ch{ch} @ {baud}/{fd_baud}bps 返回: {ret} ({get_vci_status_description(ret)})")

    def do_initcanfd_advanced(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        baud = self.extract_arg(args, "-baud", 500000, int)
        fd_baud = self.extract_arg(args, "-fd", 2000000, int)
        n_seg1 = self.extract_arg(args, "-nseg1", 0x1F, int)
        n_seg2 = self.extract_arg(args, "-nseg2", 0x08, int)
        d_seg1 = self.extract_arg(args, "-dseg1", 0x0F, int)
        d_seg2 = self.extract_arg(args, "-dseg2", 0x04, int)
        term = self.extract_arg(args, "-term", 1, int)
        
        config = FkVciCanFdConfig(baud, fd_baud, n_seg1, n_seg2, d_seg1, d_seg2, term)
        ret = self.api.vci.FkVciInitCANFDAdvanced(dev, ch, byref(config))
        print(f"[initCANFDAdv] 返回: {ret} ({get_vci_status_description(ret)})")
        
        try:
            if baud > 0 and (n_seg1 + n_seg2 + 1) > 0:
                n_divider = 80000000 / ((n_seg1 + n_seg2 + 1) * baud)
                n_sample_point = (1.0 + n_seg1) / (1.0 + n_seg1 + n_seg2) * 100.0
                print(f"[info] 标称分频系数: {n_divider:.4f}, 采样点: {n_sample_point:.2f}%")
            if fd_baud > 0 and (d_seg1 + d_seg2 + 1) > 0:
                d_divider = 80000000 / ((d_seg1 + d_seg2 + 1) * fd_baud)
                d_sample_point = (1.0 + d_seg1) / (1.0 + d_seg1 + d_seg2) * 100.0
                print(f"[info] 数据分频系数: {d_divider:.4f}, 采样点: {d_sample_point:.2f}%")
        except ZeroDivisionError:
            print("[info] 无法计算采样点，波特率或分段参数可能为0")

    def do_send(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        can_id_str = self.extract_arg(args, "-id", "123")
        can_id = safe_parse_int(can_id_str)
        if can_id is None:
            print("[错误] 无效的ID。")
            return
        data = []
        if "-data" in args:
            start = args.index("-data") + 1
            for i in range(start, len(args)):
                if args[i].startswith("-"): break
                val = safe_parse_int(args[i])
                if val is not None: data.append(val)
        
        buf = FkVciCanDataType()
        buf.CanID = can_id
        buf.FLAG = 0
        buf.DLC = len(data)
        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        
        ret = self.api.vci.FkVciTransmitCAN(dev, ch, byref(buf), 1)
        print(f"[send] ID=0x{can_id:X}, Data={hex_dump(data)}, 返回: {ret} ({get_vci_status_description(ret)})")

    def do_recv(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        max_count = self.extract_arg(args, "-count", 10, int)
        timeout = self.extract_arg(args, "-timeout", 500, int)
        
        buffer = (FkVciCanDataType * max_count)()
        count = c_uint32(max_count)
        ret = self.api.vci.FkVciReceiveCAN(dev, ch, buffer, byref(count), timeout)
        
        if ret == 0 and count.value > 0:
            print(f"[recv] 收到 {count.value} 条消息:")
            for i in range(count.value):
                msg = buffer[i]
                ts = get_full_timestamp(msg) / 10.0
                print(f"  [{i+1}] TS={ts:.1f}us, ID=0x{msg.CanID:X}, DLC={msg.DLC}, Data={hex_dump(msg.Data, msg.DLC)}")
        else:
            print(f"[recv] 无数据或接收失败: {get_vci_status_description(ret)}")

    def do_auto_recv(self, args):
        if "on" in args:
            dev = self.extract_arg(args, "-dev", 0, int)
            ch = self.extract_arg(args, "-ch", 0, int)
            self.start_auto_recv(dev, ch)
        else:
            self.stop_auto_recv()

    def start_auto_recv(self, dev, ch):
        if self.auto_recv_thread and self.auto_recv_thread.is_alive():
            print("[autoRecv] 自动接收已在运行")
            return
        
        self.auto_recv_flag = True
        
        def worker():
            MAX_RECV_COUNT = 100
            buffer_type = FkVciCanDataType * MAX_RECV_COUNT
            buffer = buffer_type()
            
            while self.auto_recv_flag:
                count = c_uint32(MAX_RECV_COUNT)
                ret = self.api.vci.FkVciReceiveCAN(dev, ch, buffer, byref(count), 0)
                
                if ret == 0 and count.value > 0:
                    sys.stdout.write("\r\033[K")
                    for i in range(count.value):
                        msg = buffer[i]
                        ts = get_full_timestamp(msg) / 10.0
                        print(f"[AutoRecv] TS={ts:.1f}us, ID=0x{msg.CanID:X}, DLC={msg.DLC}, Data={hex_dump(msg.Data, msg.DLC)}")
                    
                    sys.stdout.write("CAN >>> ")
                    sys.stdout.flush()
                
                time.sleep(0.05)

        self.auto_recv_thread = threading.Thread(target=worker, daemon=True)
        self.auto_recv_thread.start()
        print(f"[autoRecv] 启动 Dev{dev}-Ch{ch} 自动接收")

    def stop_auto_recv(self):
        if self.auto_recv_thread:
            self.auto_recv_flag = False
            self.auto_recv_thread.join(timeout=1.0)
            self.auto_recv_thread = None
            print("\n[autoRecv] 停止")

    def do_start_period(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        can_id_str = self.extract_arg(args, "-id", "100")
        can_id = safe_parse_int(can_id_str)
        if can_id is None:
            print("[错误] 无效的ID。")
            return
        time_ms = self.extract_arg(args, "-time", 100, int)
        data = []
        if "-data" in args:
            start = args.index("-data") + 1
            for i in range(start, len(args)):
                if args[i].startswith("-"): break
                val = safe_parse_int(args[i])
                if val is not None: data.append(val)

        buf = FkVciCanDataType()
        buf.CanID = can_id
        buf.FLAG = 0
        buf.DLC = len(data)
        buf.Data[:len(data)] = (c_uint8 * len(data))(*data)
        
        pid = self.api.vci.FkVciStartPeriodCAN(dev, ch, byref(buf), time_ms)
        if pid > 0:
            self.period_ids[pid] = (dev, ch)
            print(f"[startPeriod] 成功，周期任务ID={pid} (0x{pid:X})")
        else:
            print(f"[startPeriod] 失败: {get_vci_status_description(pid)}")

    def do_stop_period(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        pid_str = self.extract_arg(args, "-pid", "-1")
        
        if pid_str == "-1":
            pid = -1
        else:
            pid = safe_parse_int(pid_str, base=10)
            if pid is None:
                pid = safe_parse_int(pid_str, base=16)
            if pid is None:
                print("[错误] 无效的PID。")
                return

        print(f"[stopPeriod] 正在停止 Dev{dev}-Ch{ch} 的周期任务 (PID={pid})...")
        ret = self.api.vci.FkVciStopPeriodCAN(dev, ch, pid)
        print(f"[stopPeriod] 返回: {ret} ({get_vci_status_description(ret)})")

    def do_start_filter(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ids = []
        if "-ids" in args:
            start = args.index("-ids") + 1
            for i in range(start, len(args)):
                if args[i].startswith("-"): break
                val = safe_parse_int(args[i])
                if val is not None: ids.append(val)
        
        if not ids:
            print("[错误] 请提供 -ids 参数，例如: --filter -dev 0 -ch 0 -ids 100 200 300")
            return
        
        id_array = (c_uint32 * len(ids))(*ids)
        ret = self.api.vci.FkVciStartFilterCAN(dev, ch, id_array, len(ids))
        print(f"[filter] 过滤IDs: {[f'0x{x:X}' for x in ids]}, 返回: {ret} ({get_vci_status_description(ret)})")

    def do_stop_filter(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.api.vci.FkVciStopFilterCAN(dev, ch)
        print(f"[stopFilter] 返回: {ret} ({get_vci_status_description(ret)})")

    def do_reset_can(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.api.vci.FkVciResetCAN(dev, ch)
        print(f"[resetCAN] 返回: {ret} ({get_vci_status_description(ret)})")

    def do_clear_can(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        ret = self.api.vci.FkVciClearCAN(dev, ch)
        print(f"[clearCAN] 返回: {ret} ({get_vci_status_description(ret)})")

    def do_set_resistor(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch = self.extract_arg(args, "-ch", 0, int)
        enable = self.extract_arg(args, "-enable", 1, int)
        ret = self.api.vci.FkVciSetTerminalResistorCAN(dev, ch, enable)
        print(f"[setResistor] 返回: {ret} ({get_vci_status_description(ret)})")

    def do_get_busload(self, args):
        dev = self.extract_arg(args, "-dev", 0, int)
        ch_count = self.extract_arg(args, "-chCount", 0, int)
        if ch_count <= 0:
            print("[错误] 请使用 -chCount 参数指定有效的通道数，例如: --getBusLoad -dev 0 -chCount 8")
            return

        arr = (c_double * ch_count)()
        ret = self.api.vci.FkVciGetBusLoadCAN(dev, arr, ch_count)
        if ret == 0:
            print(f"[getBusLoad] 设备 {dev} 总线负载:")
            for i in range(ch_count):
                print(f"  CAN{i+1}: {arr[i]:.2f}%")
        else:
            print(f"[getBusLoad] 获取失败: {get_vci_status_description(ret)}")

if __name__ == "__main__":
    shell = FKVciCanTest()
    def signal_handler(sig, frame):
        shell.stop_running()
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    shell.run()
