#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# FKVciApi.py - 对齐 fkvci/fkvciapi.h (Pythonic 版本)
# 封装 FKVCI C-API 调用, 提供统一的Python接口。

import os
import platform
import ctypes
from ctypes import *

from FKVciMessage import (
    FkVciCanDataType, FkVciLinDataType, FkVciSentDataType, FkVciCanFdConfig
)
from FKUdsMessage import VciUdsFunctionalResponseData

class FKVciApi:
    """
    一个封装了 fkvci.dll/libfkvci.so C API 的Python类。
    提供了对设备管理、CAN、LIN、SENT和UDS诊断的完整访问。
    """
    def __init__(self):
        self.vci = None
        try:
            self._load_dll()
            self._define_api()
        except Exception as e:
            raise RuntimeError(f"FKVCI库加载或API定义失败: {e}")

    def _load_dll(self):
        arch = platform.architecture()[0]
        if platform.system() == "Windows":
            lib_dir = os.path.abspath("./lib/Winx64" if arch == "64bit" else "./lib/Winx86")
            dll_name = "fkvci.dll"
            os.environ['PATH'] = lib_dir + os.pathsep + os.environ.get('PATH', '')
        else:
            lib_dir = os.path.abspath("./lib/Linux")
            dll_name = "libfkvci.so"
        
        lib_path = os.path.join(lib_dir, dll_name)
        if not os.path.exists(lib_path):
            raise FileNotFoundError(f"无法找到库文件: {lib_path}")
            
        self.vci = ctypes.CDLL(lib_path)

    def _define_api(self):
        """定义所有C函数的原型 (argtypes 和 restype)。"""
        # --- 通用与设备管理 ---
        self.vci.FkVciOpenLog.argtypes = [c_char_p, c_int, c_int, c_int]
        self.vci.FkVciOpenLog.restype = c_int
        self.vci.FkVciCloseLog.argtypes = []; self.vci.FkVciCloseLog.restype = c_int
        self.vci.FkVciClearDevices.argtypes = []; self.vci.FkVciClearDevices.restype = None
        self.vci.FkVciScanDevice.argtypes = [POINTER(c_int), POINTER(c_uint8), c_uint32]
        self.vci.FkVciScanDevice.restype = c_int
        self.vci.FkVciCreateDevices.argtypes = []; self.vci.FkVciCreateDevices.restype = c_int
        self.vci.FkVciGetCanChannelCount.argtypes = [c_int]; self.vci.FkVciGetCanChannelCount.restype = c_int
        self.vci.FkVciGetLinChannelCount.argtypes = [c_int]; self.vci.FkVciGetLinChannelCount.restype = c_int
        self.vci.FkVciOpenDev.argtypes = [c_int, c_int, c_int]; self.vci.FkVciOpenDev.restype = c_int
        self.vci.FkVciCloseDev.argtypes = [c_int]; self.vci.FkVciCloseDev.restype = c_int
        self.vci.FkVciGetVersion.argtypes = [c_int]; self.vci.FkVciGetVersion.restype = c_uint32
        self.vci.FkVciGetBaseTime.argtypes = [c_int]; self.vci.FkVciGetBaseTime.restype = c_uint64

        # --- CAN ---
        self.vci.FkVciInitCAN.argtypes = [c_int, c_int, c_uint32]; self.vci.FkVciInitCAN.restype = c_int
        self.vci.FkVciInitCANFD.argtypes = [c_int, c_int, c_uint32, c_uint32]; self.vci.FkVciInitCANFD.restype = c_int
        self.vci.FkVciInitCANFDAdvanced.argtypes = [c_int, c_int, POINTER(FkVciCanFdConfig)]; self.vci.FkVciInitCANFDAdvanced.restype = c_int
        self.vci.FkVciResetCAN.argtypes = [c_int, c_int]; self.vci.FkVciResetCAN.restype = c_int
        self.vci.FkVciClearCAN.argtypes = [c_int, c_int]; self.vci.FkVciClearCAN.restype = c_int
        self.vci.FkVciReceiveCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), POINTER(c_uint32), c_uint32]; self.vci.FkVciReceiveCAN.restype = c_int
        self.vci.FkVciTransmitCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), c_uint32]; self.vci.FkVciTransmitCAN.restype = c_int
        self.vci.FkVciStartPeriodCAN.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), c_uint32]; self.vci.FkVciStartPeriodCAN.restype = c_int
        self.vci.FkVciStartPeriodCANWithDelay.argtypes = [c_int, c_int, POINTER(FkVciCanDataType), c_uint32, c_uint32]; self.vci.FkVciStartPeriodCANWithDelay.restype = c_int
        self.vci.FkVciStopPeriodCAN.argtypes = [c_int, c_int, c_int]; self.vci.FkVciStopPeriodCAN.restype = c_int
        self.vci.FkVciStartFilterCAN.argtypes = [c_int, c_int, POINTER(c_uint32), c_uint32]; self.vci.FkVciStartFilterCAN.restype = c_int
        self.vci.FkVciStopFilterCAN.argtypes = [c_int, c_int]; self.vci.FkVciStopFilterCAN.restype = c_int
        self.vci.FkVciSetTerminalResistorCAN.argtypes = [c_int, c_int, c_int]; self.vci.FkVciSetTerminalResistorCAN.restype = c_int
        self.vci.FkVciGetBusLoadCAN.argtypes = [c_int, POINTER(c_double), c_int]; self.vci.FkVciGetBusLoadCAN.restype = c_int

        # --- LIN ---
        self.vci.FkVciInitLIN.argtypes = [c_int, c_int, c_uint32, c_uint32]; self.vci.FkVciInitLIN.restype = c_int
        self.vci.FkVciResetLIN.argtypes = [c_int, c_int]; self.vci.FkVciResetLIN.restype = c_int
        self.vci.FkVciClearLIN.argtypes = [c_int, c_int]; self.vci.FkVciClearLIN.restype = c_int
        self.vci.FkVciReceiveLIN.argtypes = [c_int, c_int, POINTER(FkVciLinDataType), POINTER(c_uint32), c_uint32]; self.vci.FkVciReceiveLIN.restype = c_int
        self.vci.FkVciTransmitLIN.argtypes = [c_int, c_int, POINTER(FkVciLinDataType), c_uint32]; self.vci.FkVciTransmitLIN.restype = c_int
        self.vci.FkVciStartScheduleLIN.argtypes = [c_int, c_int, POINTER(FkVciLinDataType), c_uint32]; self.vci.FkVciStartScheduleLIN.restype = c_int
        self.vci.FkVciStopScheduleLIN.argtypes = [c_int, c_int]; self.vci.FkVciStopScheduleLIN.restype = c_int
        self.vci.FkVciWriteSlaveLIN.argtypes = [c_int, c_int, POINTER(FkVciLinDataType)]; self.vci.FkVciWriteSlaveLIN.restype = c_int

        # --- SENT ---
        self.vci.FkVciInitSENT.argtypes = [c_int, c_int, c_uint32, c_uint32, c_uint32]; self.vci.FkVciInitSENT.restype = c_int
        self.vci.FkVciResetSENT.argtypes = [c_int, c_int]; self.vci.FkVciResetSENT.restype = c_int
        self.vci.FkVciClearSENT.argtypes = [c_int, c_int]; self.vci.FkVciClearSENT.restype = c_int
        self.vci.FkVciReceiveSENT.argtypes = [c_int, c_int, POINTER(FkVciSentDataType), POINTER(c_uint32), c_uint32]; self.vci.FkVciReceiveSENT.restype = c_int
        
        # --- UDS ---
        self.vci.FkVciGetUdsErrorString.argtypes = [c_int]; self.vci.FkVciGetUdsErrorString.restype = c_char_p
        self.vci.FkVciCreateUdsService.argtypes = [c_int, c_int, c_uint32, c_uint32, POINTER(c_uint32)]; self.vci.FkVciCreateUdsService.restype = c_int
        self.vci.FkVciDestroyUdsService.argtypes = [c_uint32]; self.vci.FkVciDestroyUdsService.restype = c_int
        self.vci.FkVciSetUdsConfig.argtypes = [c_uint32, c_char_p]; self.vci.FkVciSetUdsConfig.restype = c_int
        self.vci.FkVciUdsRequestSync.argtypes = [c_uint32, POINTER(c_uint8), c_uint32, POINTER(c_uint8), POINTER(c_uint32)]; self.vci.FkVciUdsRequestSync.restype = c_int
        self.vci.FkVciUdsRequestAsync.argtypes = [c_uint32, POINTER(c_uint8), c_uint32]; self.vci.FkVciUdsRequestAsync.restype = c_int
        self.vci.FkVciUdsReadResponse.argtypes = [c_uint32, POINTER(c_uint8), POINTER(c_uint32), c_uint32]; self.vci.FkVciUdsReadResponse.restype = c_int
        self.vci.FkVciUdsRequestFunctional.argtypes = [c_uint32, POINTER(c_uint8), c_uint32]; self.vci.FkVciUdsRequestFunctional.restype = c_int
        self.vci.FkVciUdsReadFunctionalResponses.argtypes = [c_uint32, POINTER(VciUdsFunctionalResponseData), POINTER(c_uint32), c_uint32]; self.vci.FkVciUdsReadFunctionalResponses.restype = c_int
        self.vci.FkVciUdsClearAsyncQueues.argtypes = [c_uint32]; self.vci.FkVciUdsClearAsyncQueues.restype = c_int

    # --- Pythonic Wrappers ---

    def open_log(self, path="logs/fkvci.log", level=1, max_size=5, max_files=10):
        return self.vci.FkVciOpenLog(path.encode('utf-8'), level, max_size, max_files)

    def close_log(self):
        return self.vci.FkVciCloseLog()

    def clear_devices(self):
        self.vci.FkVciClearDevices()

    def scan_device(self, max_devices=16, timeout=500):
        indices_buffer = (c_int * max_devices)()
        count_buffer = c_uint8(max_devices)
        ret = self.vci.FkVciScanDevice(indices_buffer, byref(count_buffer), timeout)
        if ret == 0:
            return list(indices_buffer[:count_buffer.value])
        return []

    def create_devices(self):
        return self.vci.FkVciCreateDevices()

    def get_can_channel_count(self, dev_index):
        return self.vci.FkVciGetCanChannelCount(dev_index)

    def get_lin_channel_count(self, dev_index):
        return self.vci.FkVciGetLinChannelCount(dev_index)
        
    def open_device(self, dev_type, dev_index, reserved):
        return self.vci.FkVciOpenDev(dev_type, dev_index, reserved)

    def close_device(self, dev_index):
        return self.vci.FkVciCloseDev(dev_index)

    def get_version(self, dev_index):
        return self.vci.FkVciGetVersion(dev_index)

    def get_base_time(self, dev_index):
        return self.vci.FkVciGetBaseTime(dev_index)

    def init_can(self, dev_index, ch_index, baud):
        return self.vci.FkVciInitCAN(dev_index, ch_index, baud)
        
    def init_canfd(self, dev_index, ch_index, baud, fd_baud):
        return self.vci.FkVciInitCANFD(dev_index, ch_index, baud, fd_baud)

    def init_canfd_advanced(self, dev_index, ch_index, config_obj):
        return self.vci.FkVciInitCANFDAdvanced(dev_index, ch_index, byref(config_obj))

    def reset_can(self, dev_index, ch_index):
        return self.vci.FkVciResetCAN(dev_index, ch_index)

    def clear_can(self, dev_index, ch_index):
        return self.vci.FkVciClearCAN(dev_index, ch_index)

    def transmit_can(self, dev_index, ch_index, frames):
        if not isinstance(frames, list): frames = [frames]
        count = len(frames)
        if count == 0: return 0
        buffer = (FkVciCanDataType * count)(*frames)
        return self.vci.FkVciTransmitCAN(dev_index, ch_index, buffer, count)

    def receive_can(self, dev_index, ch_index, max_frames, timeout_ms):
        buffer = (FkVciCanDataType * max_frames)()
        len_ptr = c_uint32(max_frames)
        ret = self.vci.FkVciReceiveCAN(dev_index, ch_index, buffer, byref(len_ptr), timeout_ms)
        if ret == 0 and len_ptr.value > 0:
            return [buffer[i] for i in range(len_ptr.value)]
        return []

    def start_period_can(self, dev_index, ch_index, frame, period_ms):
        return self.vci.FkVciStartPeriodCAN(dev_index, ch_index, byref(frame), period_ms)

    def start_period_can_with_delay(self, dev_index, ch_index, frame, period_ms, delay_ms):
        return self.vci.FkVciStartPeriodCANWithDelay(dev_index, ch_index, byref(frame), period_ms, delay_ms)

    def stop_period_can(self, dev_index, ch_index, period_id):
        return self.vci.FkVciStopPeriodCAN(dev_index, ch_index, period_id)

    def start_filter_can(self, dev_index, ch_index, ids):
        count = len(ids)
        if count == 0: return 0
        buffer = (c_uint32 * count)(*ids)
        return self.vci.FkVciStartFilterCAN(dev_index, ch_index, buffer, count)

    def stop_filter_can(self, dev_index, ch_index):
        return self.vci.FkVciStopFilterCAN(dev_index, ch_index)

    def set_terminal_resistor_can(self, dev_index, ch_index, enable):
        return self.vci.FkVciSetTerminalResistorCAN(dev_index, ch_index, 1 if enable else 0)

    def get_bus_load_can(self, dev_index, channel_count):
        buffer = (c_double * channel_count)()
        ret = self.vci.FkVciGetBusLoadCAN(dev_index, buffer, channel_count)
        if ret == 0:
            return list(buffer)
        return None

    def init_lin(self, dev_index, ch_index, mode, baud):
        return self.vci.FkVciInitLIN(dev_index, ch_index, mode, baud)

    def reset_lin(self, dev_index, ch_index):
        return self.vci.FkVciResetLIN(dev_index, ch_index)

    def clear_lin(self, dev_index, ch_index):
        return self.vci.FkVciClearLIN(dev_index, ch_index)

    def transmit_lin(self, dev_index, ch_index, frames):
        if not isinstance(frames, list): frames = [frames]
        count = len(frames)
        if count == 0: return 0
        buffer = (FkVciLinDataType * count)(*frames)
        return self.vci.FkVciTransmitLIN(dev_index, ch_index, buffer, count)

    def receive_lin(self, dev_index, ch_index, max_frames, timeout_ms):
        buffer = (FkVciLinDataType * max_frames)()
        len_ptr = c_uint32(max_frames)
        ret = self.vci.FkVciReceiveLIN(dev_index, ch_index, buffer, byref(len_ptr), timeout_ms)
        if ret == 0 and len_ptr.value > 0:
            return [buffer[i] for i in range(len_ptr.value)]
        return []

    def start_schedule_lin(self, dev_index, ch_index, schedule_frames):
        count = len(schedule_frames)
        if count == 0: return 0
        buffer = (FkVciLinDataType * count)(*schedule_frames)
        return self.vci.FkVciStartScheduleLIN(dev_index, ch_index, buffer, count)

    def stop_schedule_lin(self, dev_index, ch_index):
        return self.vci.FkVciStopScheduleLIN(dev_index, ch_index)

    def write_slave_lin(self, dev_index, ch_index, frame):
        return self.vci.FkVciWriteSlaveLIN(dev_index, ch_index, byref(frame))

    def init_sent(self, dev_index, ch_index, fast_messages, tick_time, read_interval):
        return self.vci.FkVciInitSENT(dev_index, ch_index, fast_messages, tick_time, read_interval)

    def reset_sent(self, dev_index, ch_index):
        return self.vci.FkVciResetSENT(dev_index, ch_index)

    def clear_sent(self, dev_index, ch_index):
        return self.vci.FkVciClearSENT(dev_index, ch_index)

    def receive_sent(self, dev_index, ch_index, max_frames, timeout_ms):
        buffer = (FkVciSentDataType * max_frames)()
        len_ptr = c_uint32(max_frames)
        ret = self.vci.FkVciReceiveSENT(dev_index, ch_index, buffer, byref(len_ptr), timeout_ms)
        if ret == 0 and len_ptr.value > 0:
            return [buffer[i] for i in range(len_ptr.value)]
        return []

    def get_uds_error_string(self, error_code):
        result_bytes = self.vci.FkVciGetUdsErrorString(error_code)
        try:
            return result_bytes.decode('utf-8')
        except (UnicodeDecodeError, AttributeError):
            return "Invalid error string pointer"

    def create_uds_service(self, dev_index, ch_index, req_id, res_id):
        uds_id_ptr = c_uint32(0)
        ret = self.vci.FkVciCreateUdsService(dev_index, ch_index, req_id, res_id, byref(uds_id_ptr))
        return ret, uds_id_ptr.value

    def destroy_uds_service(self, uds_id):
        return self.vci.FkVciDestroyUdsService(uds_id)

    def set_uds_config(self, uds_id, config_str):
        return self.vci.FkVciSetUdsConfig(uds_id, config_str.encode('utf-8'))

    def uds_request_sync(self, uds_id, request_data, max_response_len=4095):
        req_len = len(request_data)
        req_buffer = (c_uint8 * req_len)(*request_data)
        res_buffer = (c_uint8 * max_response_len)()
        res_len_ptr = c_uint32(max_response_len)
        ret = self.vci.FkVciUdsRequestSync(uds_id, req_buffer, req_len, res_buffer, byref(res_len_ptr))
        response_data = bytes(res_buffer[:res_len_ptr.value])
        return ret, response_data

    def uds_request_async(self, uds_id, request_data):
        req_len = len(request_data)
        req_buffer = (c_uint8 * req_len)(*request_data)
        return self.vci.FkVciUdsRequestAsync(uds_id, req_buffer, req_len)

    def uds_read_response(self, uds_id, timeout_ms=2000, max_response_len=4095):
        res_buffer = (c_uint8 * max_response_len)()
        res_len_ptr = c_uint32(max_response_len)
        ret = self.vci.FkVciUdsReadResponse(uds_id, res_buffer, byref(res_len_ptr), timeout_ms)
        response_data = bytes(res_buffer[:res_len_ptr.value])
        return ret, response_data

    def uds_request_functional(self, uds_id, request_data):
        req_len = len(request_data)
        req_buffer = (c_uint8 * req_len)(*request_data)
        return self.vci.FkVciUdsRequestFunctional(uds_id, req_buffer, req_len)

    def uds_read_functional_responses(self, uds_id, max_responses, timeout_ms):
        buffer = (VciUdsFunctionalResponseData * max_responses)()
        len_ptr = c_uint32(max_responses)
        ret = self.vci.FkVciUdsReadFunctionalResponses(uds_id, buffer, byref(len_ptr), timeout_ms)
        if ret == 0 and len_ptr.value > 0:
            return [buffer[i] for i in range(len_ptr.value)]
        return []

    def uds_clear_async_queues(self, uds_id):
        return self.vci.FkVciUdsClearAsyncQueues(uds_id)
