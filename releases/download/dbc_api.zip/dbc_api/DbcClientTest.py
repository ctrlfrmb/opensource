#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
DbcClientTest.py - DBC API 客户端交互式测试工具 v1.0.0
Author: leiwei

功能:
- 加载 / 卸载 DBC 文件（支持多实例）
- 查询 DBC 信息、消息列表、单条消息
- 存在性判断（hasMessage / hasSignal）
- CAN 数据编解码测试
- 交互式命令行操作
"""

from DbcClient import DbcClient
from DbcMessage import *
import signal
import sys
import json
import platform

VERSION = "1.0.0"

client = None
# 当前活跃的实例 ID（简化操作，避免每次输入 instanceId）
active_id = None


def signal_handler(sig, frame):
    raise KeyboardInterrupt


def set_active(instance_id):
    """设置当前活跃实例"""
    global active_id
    active_id = instance_id
    print(f"  当前活跃实例: {active_id}")


def get_active():
    """获取当前活跃实例 ID，无则提示"""
    global active_id
    if active_id is None:
        print("❌ 未设置活跃实例。请先 load <file> 或 use <id>")
        return None
    return active_id


def print_json(data, indent=2):
    """美化打印 JSON"""
    if data is None:
        print("  (无数据)")
        return
    print(json.dumps(data, indent=indent, ensure_ascii=False))


def parse_hex_bytes(hex_str):
    """
    解析十六进制字节字符串
    支持格式: "12 34 56 78" 或 "12345678" 或 "0x12 0x34"
    """
    hex_str = hex_str.replace("0x", "").replace("0X", "").replace(",", " ")
    parts = hex_str.split()
    if len(parts) == 1 and len(parts[0]) > 2:
        # 连续十六进制: "12345678"
        s = parts[0]
        return [int(s[i:i + 2], 16) for i in range(0, len(s), 2)]
    else:
        return [int(p, 16) for p in parts]


def parse_can_id(id_str):
    """解析 CAN ID，支持十进制和十六进制 (0x前缀)"""
    id_str = id_str.strip()
    if id_str.startswith("0x") or id_str.startswith("0X"):
        return int(id_str, 16)
    return int(id_str)


def print_help():
    print(f"""
================================================================================
                    DBC API 测试工具 v{VERSION}
================================================================================

实例管理:
  load <file> [encoding]            加载 DBC 文件 (自动设为活跃实例)
    示例: load vehicle.dbc
    示例: load vehicle.dbc GBK
  unload [id]                       卸载实例 (默认卸载活跃实例)
  use <id>                          切换活跃实例
  list                              列出所有已加载实例
  clearall                          清空所有实例

查询命令 (操作活跃实例):
  info                              获取 DBC 全局信息
  messages                          获取所有消息 (概要)
  messagesall                       获取所有消息 (完整 JSON)
  msg <canId|name>                  获取单条消息详情
    示例: msg 0x100
    示例: msg MotorControl

存在性判断:
  has msg <canId|name>              消息是否存在
  has sig <canId> <signalName>      信号是否存在于指定消息
  has signame <signalName>          信号是否存在于任意消息 (全局搜索)
  count                             消息总数
  sigcount <canId>                  指定消息的信号数

解码 (CAN bytes -> 信号值):
  decode <canId> <hex_bytes>        解码 CAN 数据
    示例: decode 0x100 12 34 56 78 00 00 00 00
  decodesig <canId> <sigName> <hex> 解码单个信号
    示例: decodesig 0x100 EngineSpeed 12 34 56 78 00 00 00 00

编码 (信号值 -> CAN bytes):
  encode <canId> <json>             编码信号值为 CAN 数据
    示例: encode 0x100 {{"signals":[{{"name":"Speed","physicalValue":3500}}]}}
  encodesig <canId> <sigName> <val> 编码单个信号 (物理值)
    示例: encodesig 0x100 EngineSpeed 3500.0
  encoderaw <canId> <sigName> <raw> 编码单个信号 (原始值)
    示例: encoderaw 0x100 EngineSpeed 35000

其它:
  status                            查看状态
  help                              显示帮助
  exit                              退出
================================================================================
""")


# =============================================================================
# 命令处理函数
# =============================================================================

def cmd_load(parts):
    global active_id
    if len(parts) < 2:
        print("用法: load <file> [encoding]")
        return
    file_path = parts[1]
    encoding = parts[2] if len(parts) > 2 else None
    result = client.load_file(file_path, encoding)
    if result > 0:
        set_active(result)


def cmd_unload(parts):
    global active_id
    if len(parts) > 1:
        inst_id = int(parts[1])
    else:
        inst_id = get_active()
        if inst_id is None:
            return
    client.unload_file(inst_id)
    if active_id == inst_id:
        active_id = None
        # 自动切换到下一个实例
        instances = client.get_loaded_instances()
        if instances:
            next_id = next(iter(instances))
            set_active(next_id)


def cmd_use(parts):
    if len(parts) < 2:
        print("用法: use <id>")
        return
    inst_id = int(parts[1])
    instances = client.get_loaded_instances()
    if inst_id in instances:
        set_active(inst_id)
    else:
        print(f"❌ 实例 {inst_id} 不存在。已加载: {list(instances.keys())}")


def cmd_list():
    instances = client.get_loaded_instances()
    count = client.get_instance_count()
    print(f"已加载实例: {count} 个")
    for inst_id, path in instances.items():
        marker = " ← 活跃" if inst_id == active_id else ""
        print(f"  [{inst_id}] {path}{marker}")
    if not instances:
        print("  (无)")


def cmd_info():
    inst = get_active()
    if inst is None:
        return
    status, data = client.get_info(inst)
    if status == DBC_RESULT_OK:
        print(f"DBC 信息 (实例 {inst}):")
        print_json(data)
    else:
        print(f"❌ {get_status_description(status)} ({status})")


def cmd_messages(full=False):
    inst = get_active()
    if inst is None:
        return
    status, data = client.get_messages(inst)
    if status != DBC_RESULT_OK:
        print(f"❌ {get_status_description(status)} ({status})")
        return

    if full:
        print_json(data)
        return

    # 概要模式
    msg_count = data.get("messageCount", 0)
    print(f"消息列表 ({msg_count} 条):")
    print(f"  {'ID':>10s}  {'Name':<30s}  {'DLC':>3s}  {'Sender':<15s}  "
          f"{'FD':>3s}  {'Sigs':>4s}  SendType")
    print(f"  {'-' * 100}")
    for msg in data.get("messages", []):
        can_id = msg.get("id", 0)
        name = msg.get("name", "?")
        dlc = msg.get("dlc", 0)
        sender = msg.get("sender", "?")
        is_fd = "FD" if msg.get("isCanFd", False) else ""
        if msg.get("isCanFdBrs", False):
            is_fd += "+B"
        sig_count = len(msg.get("signals", []))
        send_type = msg.get("sendType", "?")
        print(f"  0x{can_id:08X}  {name:<30s}  {dlc:>3d}  {sender:<15s}  "
              f"{is_fd:>3s}  {sig_count:>4d}  {send_type}")


def cmd_msg(parts):
    inst = get_active()
    if inst is None:
        return
    if len(parts) < 2:
        print("用法: msg <canId|name>")
        return

    identifier = parts[1]
    try:
        can_id = parse_can_id(identifier)
        status, data = client.get_message_by_id(inst, can_id)
    except ValueError:
        status, data = client.get_message_by_name(inst, identifier)

    if status == DBC_RESULT_OK:
        print_json(data)
    else:
        print(f"❌ {get_status_description(status)} ({status})")


def cmd_has(parts):
    inst = get_active()
    if inst is None:
        return
    if len(parts) < 3:
        print("用法: has msg <canId|name> | has sig <canId> <sigName> | has signame <sigName>")
        return

    sub = parts[1].lower()

    if sub == "msg":
        identifier = parts[2]
        try:
            can_id = parse_can_id(identifier)
            result = client.has_message_by_id(inst, can_id)
            label = f"0x{can_id:X}"
        except ValueError:
            result = client.has_message_by_name(inst, identifier)
            label = identifier

        if result is None:
            print(f"❌ 查询失败")
        elif result:
            print(f"✅ 消息 '{label}' 存在")
        else:
            print(f"❌ 消息 '{label}' 不存在")

    elif sub == "sig":
        if len(parts) < 4:
            print("用法: has sig <canId> <signalName>")
            return
        can_id = parse_can_id(parts[2])
        sig_name = parts[3]
        result = client.has_signal(inst, can_id, sig_name)
        if result is None:
            print(f"❌ 查询失败")
        elif result:
            print(f"✅ 信号 '{sig_name}' 存在于消息 0x{can_id:X}")
        else:
            print(f"❌ 信号 '{sig_name}' 不存在于消息 0x{can_id:X}")

    elif sub == "signame":
        sig_name = parts[2]
        result = client.has_signal_by_name(inst, sig_name)
        if result is None:
            print(f"❌ 查询失败")
        elif result:
            print(f"✅ 信号 '{sig_name}' 存在 (全局搜索)")
        else:
            print(f"❌ 信号 '{sig_name}' 不存在 (全局搜索)")

    else:
        print(f"未知子命令: has {sub}")


def cmd_count():
    inst = get_active()
    if inst is None:
        return
    count = client.get_message_count(inst)
    if count >= 0:
        print(f"消息数量: {count}")
    else:
        print(f"❌ {get_status_description(count)} ({count})")


def cmd_sigcount(parts):
    inst = get_active()
    if inst is None:
        return
    if len(parts) < 2:
        print("用法: sigcount <canId>")
        return
    can_id = parse_can_id(parts[1])
    count = client.get_signal_count(inst, can_id)
    if count >= 0:
        print(f"消息 0x{can_id:X} 的信号数量: {count}")
    else:
        print(f"❌ {get_status_description(count)} ({count})")


def cmd_decode(parts):
    inst = get_active()
    if inst is None:
        return
    if len(parts) < 3:
        print("用法: decode <canId> <hex_bytes>")
        print("示例: decode 0x100 12 34 56 78 00 00 00 00")
        return

    can_id = parse_can_id(parts[1])
    hex_bytes = parse_hex_bytes(" ".join(parts[2:]))

    status, data = client.decode(inst, can_id, hex_bytes)
    if status == DBC_RESULT_OK:
        msg_name = data.get("name", "?")
        signals = data.get("signals", [])
        hex_str = " ".join(f"{b:02X}" for b in hex_bytes)
        print(f"\n解码结果: 0x{can_id:X} ({msg_name})  数据: [{hex_str}]")
        print(f"  {'Signal':<25s}  {'RawValue':>12s}  {'PhysValue':>14s}  {'Unit':<8s}  Display")
        print(f"  {'-' * 85}")
        for sig in signals:
            name = sig.get("name", "?")
            raw = sig.get("rawValue", 0)
            phys = sig.get("physicalValue", 0.0)
            unit = sig.get("unit", "")
            display = sig.get("displayValue", "")
            print(f"  {name:<25s}  {raw:>12d}  {phys:>14.6f}  {unit:<8s}  {display}")
    else:
        print(f"❌ {get_status_description(status)} ({status})")


def cmd_decode_signal(parts):
    inst = get_active()
    if inst is None:
        return
    if len(parts) < 4:
        print("用法: decodesig <canId> <signalName> <hex_bytes>")
        return

    can_id = parse_can_id(parts[1])
    sig_name = parts[2]
    hex_bytes = parse_hex_bytes(" ".join(parts[3:]))

    status, raw, phys = client.decode_signal(inst, can_id, sig_name, hex_bytes)
    if status == DBC_RESULT_OK:
        print(f"信号 '{sig_name}': rawValue={raw}, physicalValue={phys:.6f}")
    else:
        print(f"❌ {get_status_description(status)} ({status})")


def cmd_encode(parts):
    inst = get_active()
    if inst is None:
        return
    if len(parts) < 3:
        print('用法: encode <canId> <json>')
        print('示例: encode 0x100 {"signals":[{"name":"Speed","physicalValue":3500}]}')
        return

    can_id = parse_can_id(parts[1])
    json_str = " ".join(parts[2:])

    try:
        signals = json.loads(json_str)
    except json.JSONDecodeError as e:
        print(f"❌ JSON 格式错误: {e}")
        return

    status, data_bytes, data_len = client.encode(inst, can_id, signals)
    if status == DBC_RESULT_OK:
        hex_str = " ".join(f"{b:02X}" for b in data_bytes)
        print(f"✅ 编码成功: [{hex_str}] ({data_len} bytes)")
    else:
        print(f"❌ {get_status_description(status)} ({status})")


def cmd_encode_signal(parts):
    inst = get_active()
    if inst is None:
        return
    if len(parts) < 4:
        print("用法: encodesig <canId> <signalName> <physValue>")
        return

    can_id = parse_can_id(parts[1])
    sig_name = parts[2]
    phys_value = float(parts[3])

    status, data_bytes = client.encode_signal(inst, can_id, sig_name, phys_value)
    if status == DBC_RESULT_OK:
        hex_str = " ".join(f"{b:02X}" for b in data_bytes)
        print(f"✅ 编码成功: [{hex_str}]")
    else:
        print(f"❌ {get_status_description(status)} ({status})")


def cmd_encode_raw(parts):
    inst = get_active()
    if inst is None:
        return
    if len(parts) < 4:
        print("用法: encoderaw <canId> <signalName> <rawValue>")
        return

    can_id = parse_can_id(parts[1])
    sig_name = parts[2]
    raw_value = int(parts[3])

    status, data_bytes = client.encode_signal_raw(inst, can_id, sig_name, raw_value)
    if status == DBC_RESULT_OK:
        hex_str = " ".join(f"{b:02X}" for b in data_bytes)
        print(f"✅ 编码成功: [{hex_str}]")
    else:
        print(f"❌ {get_status_description(status)} ({status})")


def cmd_status():
    instances = client.get_loaded_instances()
    count = client.get_instance_count()
    print(f"状态:")
    print(f"  DLL 已加载: {'是' if client.dbc_dll else '否'}")
    print(f"  实例数量: {count}")
    print(f"  活跃实例: {active_id if active_id else '无'}")
    for inst_id, path in instances.items():
        marker = " ← 活跃" if inst_id == active_id else ""
        msg_count = client.get_message_count(inst_id)
        print(f"    [{inst_id}] {path} ({msg_count} 消息){marker}")


# =============================================================================
# 主函数
# =============================================================================

def main():
    global client, active_id

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    print(f"DBC API 测试工具 v{VERSION} ({platform.architecture()[0]}) - 输入 help 获取帮助")

    try:
        client = DbcClient()
    except Exception as e:
        print(f"初始化失败: {e}")
        return

    while True:
        try:
            prompt = f"DBC[{active_id}]> " if active_id else "DBC> "
            line = input(prompt).strip()
            if not line:
                continue

            parts = line.split()
            cmd = parts[0].lower()

            if cmd == "help":
                print_help()

            elif cmd == "exit":
                break

            elif cmd == "load":
                cmd_load(parts)

            elif cmd == "unload":
                cmd_unload(parts)

            elif cmd == "use":
                cmd_use(parts)

            elif cmd == "list":
                cmd_list()

            elif cmd == "clearall":
                client.clear_all()
                active_id = None

            elif cmd == "info":
                cmd_info()

            elif cmd == "messages":
                cmd_messages(full=False)

            elif cmd == "messagesall":
                cmd_messages(full=True)

            elif cmd == "msg":
                cmd_msg(parts)

            elif cmd == "has":
                cmd_has(parts)

            elif cmd == "count":
                cmd_count()

            elif cmd == "sigcount":
                cmd_sigcount(parts)

            elif cmd == "decode":
                cmd_decode(parts)

            elif cmd == "decodesig":
                cmd_decode_signal(parts)

            elif cmd == "encode":
                cmd_encode(parts)

            elif cmd == "encodesig":
                cmd_encode_signal(parts)

            elif cmd == "encoderaw":
                cmd_encode_raw(parts)

            elif cmd == "status":
                cmd_status()

            else:
                print(f"未知命令: {cmd}  (输入 help 查看帮助)")

        except KeyboardInterrupt:
            print()
            break

        except EOFError:
            break

        except ValueError as e:
            print(f"参数错误: {e}")

        except Exception as e:
            print(f"错误: {e}")

    if client:
        client.cleanup()
    print("已退出")


if __name__ == "__main__":
    main()
