#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: leiwei
DbcClient.py - DBC API 客户端 Python 封装

提供对 dbc_api.dll 的完整 Python 封装，包括：
- DBC 文件加载 / 卸载（多实例支持）
- 消息和信号查询（JSON 输出）
- 存在性判断（hasMessage / hasSignal）
- CAN 数据编码 / 解码
- 日志管理

v1.0.0
"""

from DbcMessage import *
import ctypes
import platform
import os
import json


class DbcClient:
    """DBC API 客户端封装类"""

    def __init__(self, lib_path=None):
        """
        初始化 DBC 客户端

        Args:
            lib_path: DLL 库路径。None 则自动选择 Winx64/Winx86
        """
        self.dbc_dll = None
        self._instances = {}  # {instance_id: file_path}
        self._cleaned_up = False

        self._load_dll(lib_path)

    # =========================================================================
    # DLL 加载
    # =========================================================================

    def _load_dll(self, lib_path):
        """加载 DBC API DLL"""
        if lib_path is None:
            arch = platform.architecture()[0]
            if arch == "64bit":
                lib_path = os.path.abspath("./lib/Winx64")
            else:
                lib_path = os.path.abspath("./lib/Winx86")

        if not os.path.isdir(lib_path):
            raise FileNotFoundError(f"库路径不存在: {lib_path}")

        os.environ['PATH'] = lib_path + os.pathsep + os.environ.get('PATH', '')
        print(f"加载库路径: {lib_path}")

        try:
            if platform.system() == "Windows":
                dll_name = "dbc_api.dll"
                self.dbc_dll = ctypes.WinDLL(os.path.join(lib_path, dll_name))
            else:
                dll_name = "libdbc_api.so"
                self.dbc_dll = ctypes.CDLL(os.path.join(lib_path, dll_name))
        except OSError as e:
            raise RuntimeError(f"加载 {dll_name} 失败: {e}")

        self._define_api_prototypes()

        # 自动开启日志
        os.makedirs("logs", exist_ok=True)
        log_path = os.path.join("logs", "dbc_client_test.log").encode("utf-8")
        self.dbc_dll.DBCOpenLog(log_path, 1, 10, 10)
        print("DBC API 库加载成功，日志 -> dbc_client_test.log")

    def _define_api_prototypes(self):
        """定义所有 API 函数原型"""
        dll = self.dbc_dll

        # --- Log ---
        dll.DBCOpenLog.argtypes = [ctypes.c_char_p, ctypes.c_int,
                                   ctypes.c_int, ctypes.c_int]
        dll.DBCOpenLog.restype = ctypes.c_int

        dll.DBCCloseLog.argtypes = []
        dll.DBCCloseLog.restype = ctypes.c_int

        # --- Instance Management ---
        dll.DBCLoadFile.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        dll.DBCLoadFile.restype = ctypes.c_int

        dll.DBCUnloadFile.argtypes = [ctypes.c_int]
        dll.DBCUnloadFile.restype = ctypes.c_int

        dll.DBCClearAll.argtypes = []
        dll.DBCClearAll.restype = ctypes.c_int

        dll.DBCGetInstanceCount.argtypes = []
        dll.DBCGetInstanceCount.restype = ctypes.c_int

        # --- JSON Query ---
        dll.DBCGetInfo.argtypes = [ctypes.c_int, ctypes.c_char_p,
                                   ctypes.POINTER(ctypes.c_int)]
        dll.DBCGetInfo.restype = ctypes.c_int

        dll.DBCGetMessages.argtypes = [ctypes.c_int, ctypes.c_char_p,
                                       ctypes.POINTER(ctypes.c_int)]
        dll.DBCGetMessages.restype = ctypes.c_int

        dll.DBCGetMessageById.argtypes = [ctypes.c_int, ctypes.c_uint32,
                                          ctypes.c_char_p,
                                          ctypes.POINTER(ctypes.c_int)]
        dll.DBCGetMessageById.restype = ctypes.c_int

        dll.DBCGetMessageByName.argtypes = [ctypes.c_int, ctypes.c_char_p,
                                            ctypes.c_char_p,
                                            ctypes.POINTER(ctypes.c_int)]
        dll.DBCGetMessageByName.restype = ctypes.c_int

        # --- Existence Query ---
        dll.DBCHasMessageById.argtypes = [ctypes.c_int, ctypes.c_uint32]
        dll.DBCHasMessageById.restype = ctypes.c_int

        dll.DBCHasMessageByName.argtypes = [ctypes.c_int, ctypes.c_char_p]
        dll.DBCHasMessageByName.restype = ctypes.c_int

        dll.DBCHasSignal.argtypes = [ctypes.c_int, ctypes.c_uint32,
                                     ctypes.c_char_p]
        dll.DBCHasSignal.restype = ctypes.c_int

        dll.DBCHasSignalByName.argtypes = [ctypes.c_int, ctypes.c_char_p]
        dll.DBCHasSignalByName.restype = ctypes.c_int

        dll.DBCGetMessageCount.argtypes = [ctypes.c_int]
        dll.DBCGetMessageCount.restype = ctypes.c_int

        dll.DBCGetSignalCount.argtypes = [ctypes.c_int, ctypes.c_uint32]
        dll.DBCGetSignalCount.restype = ctypes.c_int

        # --- Decode ---
        dll.DBCDecode.argtypes = [ctypes.c_int, ctypes.c_uint32,
                                  ctypes.POINTER(ctypes.c_ubyte), ctypes.c_ubyte,
                                  ctypes.c_char_p, ctypes.POINTER(ctypes.c_int)]
        dll.DBCDecode.restype = ctypes.c_int

        dll.DBCDecodeSignal.argtypes = [ctypes.c_int, ctypes.c_uint32,
                                        ctypes.c_char_p,
                                        ctypes.POINTER(ctypes.c_ubyte),
                                        ctypes.c_ubyte,
                                        ctypes.POINTER(ctypes.c_uint64),
                                        ctypes.POINTER(ctypes.c_double)]
        dll.DBCDecodeSignal.restype = ctypes.c_int

        # --- Encode ---
        dll.DBCEncode.argtypes = [ctypes.c_int, ctypes.c_uint32,
                                  ctypes.c_char_p,
                                  ctypes.POINTER(ctypes.c_ubyte),
                                  ctypes.POINTER(ctypes.c_int)]
        dll.DBCEncode.restype = ctypes.c_int

        dll.DBCEncodeSignal.argtypes = [ctypes.c_int, ctypes.c_uint32,
                                        ctypes.c_char_p, ctypes.c_double,
                                        ctypes.POINTER(ctypes.c_ubyte),
                                        ctypes.c_ubyte]
        dll.DBCEncodeSignal.restype = ctypes.c_int

        dll.DBCEncodeSignalRaw.argtypes = [ctypes.c_int, ctypes.c_uint32,
                                           ctypes.c_char_p, ctypes.c_uint64,
                                           ctypes.POINTER(ctypes.c_ubyte),
                                           ctypes.c_ubyte]
        dll.DBCEncodeSignalRaw.restype = ctypes.c_int

    # =========================================================================
    # 内部辅助
    # =========================================================================

    def _call_json_api(self, func, *args, buffer_size=DBC_DEFAULT_BUFFER_SIZE):
        """
        调用返回 JSON 的 API 函数，自动处理 BUFFER_TOO_SMALL 重试

        Returns:
            (status, json_dict_or_none)
        """
        buf = ctypes.create_string_buffer(buffer_size)
        size = ctypes.c_int(buffer_size)

        status = func(*args, buf, ctypes.byref(size))

        if status == DBC_RESULT_BUFFER_TOO_SMALL:
            # size 已被设置为所需大小
            needed = size.value + 1
            buf = ctypes.create_string_buffer(needed)
            size = ctypes.c_int(needed)
            status = func(*args, buf, ctypes.byref(size))

        if status == DBC_RESULT_OK:
            try:
                json_str = buf.value.decode('utf-8')
                return status, json.loads(json_str)
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                print(f"  JSON 解析异常: {e}")
                return DBC_RESULT_INTERNAL_ERROR, None
        else:
            return status, None

    @staticmethod
    def _bytes_to_hex(data, length):
        """将 ctypes 数组转为十六进制字符串"""
        return " ".join(f"{data[i]:02X}" for i in range(length))

    # =========================================================================
    # 实例管理
    # =========================================================================

    def load_file(self, file_path, encoding=None):
        """
        加载 DBC 文件

        Args:
            file_path: DBC 文件路径
            encoding:  文件编码 ("UTF-8", "GBK", None=自动)

        Returns:
            instance_id (>0) on success, error_code (<=0) on failure
        """
        c_path = file_path.encode('utf-8')
        c_enc = encoding.encode('utf-8') if encoding else None

        result = self.dbc_dll.DBCLoadFile(c_path, c_enc)

        if result > 0:
            self._instances[result] = file_path
            print(f"✅ 加载成功: '{file_path}' -> 实例 ID: {result}")
        else:
            print(f"❌ 加载失败: '{file_path}' -> {get_status_description(result)} ({result})")

        return result

    def unload_file(self, instance_id):
        """卸载 DBC 实例"""
        status = self.dbc_dll.DBCUnloadFile(instance_id)
        if status == DBC_RESULT_OK:
            path = self._instances.pop(instance_id, "?")
            print(f"✅ 卸载成功: 实例 {instance_id} ('{path}')")
        else:
            print(f"❌ 卸载失败: {get_status_description(status)} ({status})")
        return status

    def clear_all(self):
        """清空所有实例"""
        status = self.dbc_dll.DBCClearAll()
        if status == DBC_RESULT_OK:
            count = len(self._instances)
            self._instances.clear()
            print(f"✅ 已清空所有实例 ({count} 个)")
        else:
            print(f"❌ 清空失败: {get_status_description(status)}")
        return status

    def get_instance_count(self):
        """获取已加载实例数"""
        return self.dbc_dll.DBCGetInstanceCount()

    def get_loaded_instances(self):
        """获取已加载实例的 {id: path} 字典"""
        return dict(self._instances)

    # =========================================================================
    # JSON 查询
    # =========================================================================

    def get_info(self, instance_id):
        """获取 DBC 全局信息 (JSON dict)"""
        return self._call_json_api(self.dbc_dll.DBCGetInfo, instance_id)

    def get_messages(self, instance_id):
        """获取所有消息 (JSON dict)，自动使用大缓冲区"""
        return self._call_json_api(self.dbc_dll.DBCGetMessages, instance_id,
                                   buffer_size=DBC_LARGE_BUFFER_SIZE)

    def get_message_by_id(self, instance_id, can_id):
        """按 CAN ID 获取消息 (JSON dict)"""
        return self._call_json_api(self.dbc_dll.DBCGetMessageById,
                                   instance_id, ctypes.c_uint32(can_id))

    def get_message_by_name(self, instance_id, message_name):
        """按名称获取消息 (JSON dict)"""
        return self._call_json_api(self.dbc_dll.DBCGetMessageByName,
                                   instance_id, message_name.encode('utf-8'))

    # =========================================================================
    # 存在性查询
    # =========================================================================

    def has_message_by_id(self, instance_id, can_id):
        """检查消息是否存在 (by CAN ID)  -> True/False/None(error)"""
        result = self.dbc_dll.DBCHasMessageById(instance_id, ctypes.c_uint32(can_id))
        if result < 0:
            return None
        return result == 1

    def has_message_by_name(self, instance_id, message_name):
        """检查消息是否存在 (by name)  -> True/False/None(error)"""
        result = self.dbc_dll.DBCHasMessageByName(instance_id,
                                                   message_name.encode('utf-8'))
        if result < 0:
            return None
        return result == 1

    def has_signal(self, instance_id, can_id, signal_name):
        """检查信号是否存在于指定消息 -> True/False/None(error)"""
        result = self.dbc_dll.DBCHasSignal(instance_id, ctypes.c_uint32(can_id),
                                            signal_name.encode('utf-8'))
        if result < 0:
            return None
        return result == 1

    def has_signal_by_name(self, instance_id, signal_name):
        """检查信号是否存在于任意消息 (全局搜索) -> True/False/None(error)"""
        result = self.dbc_dll.DBCHasSignalByName(instance_id,
                                                  signal_name.encode('utf-8'))
        if result < 0:
            return None
        return result == 1

    def get_message_count(self, instance_id):
        """获取消息数量 -> int (>=0 success, <0 error)"""
        return self.dbc_dll.DBCGetMessageCount(instance_id)

    def get_signal_count(self, instance_id, can_id):
        """获取指定消息的信号数量 -> int (>=0 success, <0 error)"""
        return self.dbc_dll.DBCGetSignalCount(instance_id, ctypes.c_uint32(can_id))

    # =========================================================================
    # CAN 数据解码
    # =========================================================================

    def decode(self, instance_id, can_id, data_bytes):
        """
        解码 CAN 数据为所有信号值 (JSON)

        Args:
            instance_id: 实例 ID
            can_id:      CAN 消息 ID
            data_bytes:  bytes 或 list[int]，CAN 数据

        Returns:
            (status, json_dict_or_none)
        """
        if isinstance(data_bytes, (bytes, bytearray)):
            data_len = len(data_bytes)
            c_data = (ctypes.c_ubyte * data_len)(*data_bytes)
        elif isinstance(data_bytes, list):
            data_len = len(data_bytes)
            c_data = (ctypes.c_ubyte * data_len)(*data_bytes)
        else:
            return DBC_RESULT_INVALID_PARAM, None

        buf = ctypes.create_string_buffer(DBC_DEFAULT_BUFFER_SIZE)
        size = ctypes.c_int(DBC_DEFAULT_BUFFER_SIZE)

        status = self.dbc_dll.DBCDecode(
            instance_id, ctypes.c_uint32(can_id),
            c_data, ctypes.c_ubyte(data_len),
            buf, ctypes.byref(size)
        )

        if status == DBC_RESULT_BUFFER_TOO_SMALL:
            needed = size.value + 1
            buf = ctypes.create_string_buffer(needed)
            size = ctypes.c_int(needed)
            status = self.dbc_dll.DBCDecode(
                instance_id, ctypes.c_uint32(can_id),
                c_data, ctypes.c_ubyte(data_len),
                buf, ctypes.byref(size)
            )

        if status == DBC_RESULT_OK:
            try:
                return status, json.loads(buf.value.decode('utf-8'))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                return DBC_RESULT_INTERNAL_ERROR, None

        return status, None

    def decode_signal(self, instance_id, can_id, signal_name, data_bytes):
        """
        解码单个信号

        Returns:
            (status, raw_value, physical_value)
        """
        if isinstance(data_bytes, (bytes, bytearray)):
            data_len = len(data_bytes)
            c_data = (ctypes.c_ubyte * data_len)(*data_bytes)
        elif isinstance(data_bytes, list):
            data_len = len(data_bytes)
            c_data = (ctypes.c_ubyte * data_len)(*data_bytes)
        else:
            return DBC_RESULT_INVALID_PARAM, 0, 0.0

        raw_value = ctypes.c_uint64(0)
        phys_value = ctypes.c_double(0.0)

        status = self.dbc_dll.DBCDecodeSignal(
            instance_id, ctypes.c_uint32(can_id),
            signal_name.encode('utf-8'),
            c_data, ctypes.c_ubyte(data_len),
            ctypes.byref(raw_value), ctypes.byref(phys_value)
        )

        return status, raw_value.value, phys_value.value

    # =========================================================================
    # CAN 数据编码
    # =========================================================================

    def encode(self, instance_id, can_id, signals):
        """
        编码信号值为 CAN 数据

        Args:
            instance_id: 实例 ID
            can_id:      CAN 消息 ID
            signals:     list[dict] 或 dict，信号值列表
                         例: [{"name": "Speed", "physicalValue": 3500.0}]
                         或  {"signals": [{"name": "Speed", "physicalValue": 3500.0}]}

        Returns:
            (status, data_bytes_or_none, data_len)
        """
        if isinstance(signals, list):
            json_obj = {"signals": signals}
        elif isinstance(signals, dict):
            json_obj = signals if "signals" in signals else {"signals": [signals]}
        else:
            return DBC_RESULT_INVALID_PARAM, None, 0

        json_str = json.dumps(json_obj).encode('utf-8')

        c_data = (ctypes.c_ubyte * 64)()  # max 64 bytes (CAN FD)
        c_len = ctypes.c_int(64)

        status = self.dbc_dll.DBCEncode(
            instance_id, ctypes.c_uint32(can_id),
            json_str, c_data, ctypes.byref(c_len)
        )

        if status == DBC_RESULT_OK:
            length = c_len.value
            result_bytes = bytes(c_data[i] for i in range(length))
            return status, result_bytes, length
        else:
            return status, None, 0

    def encode_signal(self, instance_id, can_id, signal_name, phys_value,
                      data_bytes=None, data_len=8):
        """
        编码单个信号 (物理值) 到 CAN 数据（原地修改）

        Args:
            data_bytes: 现有 CAN 数据 (None 则全零)
            data_len:   数据长度

        Returns:
            (status, data_bytes_or_none)
        """
        if data_bytes is None:
            c_data = (ctypes.c_ubyte * data_len)()
        else:
            data_len = len(data_bytes)
            c_data = (ctypes.c_ubyte * data_len)(*data_bytes)

        status = self.dbc_dll.DBCEncodeSignal(
            instance_id, ctypes.c_uint32(can_id),
            signal_name.encode('utf-8'), ctypes.c_double(phys_value),
            c_data, ctypes.c_ubyte(data_len)
        )

        if status == DBC_RESULT_OK:
            return status, bytes(c_data[i] for i in range(data_len))
        return status, None

    def encode_signal_raw(self, instance_id, can_id, signal_name, raw_value,
                          data_bytes=None, data_len=8):
        """
        编码单个信号 (原始值) 到 CAN 数据（原地修改）

        Returns:
            (status, data_bytes_or_none)
        """
        if data_bytes is None:
            c_data = (ctypes.c_ubyte * data_len)()
        else:
            data_len = len(data_bytes)
            c_data = (ctypes.c_ubyte * data_len)(*data_bytes)

        status = self.dbc_dll.DBCEncodeSignalRaw(
            instance_id, ctypes.c_uint32(can_id),
            signal_name.encode('utf-8'), ctypes.c_uint64(raw_value),
            c_data, ctypes.c_ubyte(data_len)
        )

        if status == DBC_RESULT_OK:
            return status, bytes(c_data[i] for i in range(data_len))
        return status, None

    # =========================================================================
    # 日志管理
    # =========================================================================

    def close_log(self):
        """关闭 DLL 日志系统"""
        if self.dbc_dll:
            self.dbc_dll.DBCCloseLog()

    def cleanup(self):
        """清理所有资源（程序退出前调用，幂等安全）"""
        if self._cleaned_up:
            return
        self._cleaned_up = True

        print("开始清理资源...")
        self.clear_all()
        self.close_log()
        print("资源清理完成。")
