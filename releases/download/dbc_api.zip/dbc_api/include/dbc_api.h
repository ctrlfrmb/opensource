/*----------------------------------------------------------------------------
*               DBC Parser C-API Interface
*-----------------------------------------------------------------------------
*
* Provides a pure C interface for DBC file parsing, CAN message
* encoding/decoding. Data exchange uses JSON strings for maximum
* cross-language compatibility (C, C++, Python, C#, LabVIEW, etc.).
*
* ═══════════════════════════════════════════════════════════════════════════
*                          Typical Usage
* ═══════════════════════════════════════════════════════════════════════════
*
* @code
*   // 1. Optional: enable logging
*   DBCOpenLog("logs/dbc.log", 1, 10, 5);
*
*   // 2. Load DBC file
*   int id = DBCLoadFile("vehicle.dbc", "UTF-8");
*   if (id <= 0) { printf("Load failed: %d\n", id); return; }
*
*   // 3. Query
*   printf("Messages: %d\n", DBCGetMessageCount(id));
*   if (DBCHasMessageById(id, 0x100) == 1) {
*       printf("Message 0x100 exists\n");
*   }
*
*   // 4. Decode CAN data
*   UINT8_T canData[] = {0x12, 0x34, 0x56, 0x78, 0x00, 0x00, 0x00, 0x00};
*   char buf[4096];
*   int len = sizeof(buf);
*   if (DBCDecode(id, 0x100, canData, 8, buf, &len) == 0) {
*       printf("Decoded: %s\n", buf);
*   }
*
*   // 5. Encode CAN data
*   const char* json = "{\"signals\":["
*       "{\"name\":\"EngineSpeed\",\"physicalValue\":3500.0}"
*   "]}";
*   UINT8_T outData[8];
*   int outLen = 8;
*   if (DBCEncode(id, 0x100, json, outData, &outLen) == 0) {
*       // outData contains encoded CAN bytes
*   }
*
*   // 6. Unload
*   DBCUnloadFile(id);
*
*   // 7. Optional: close log
*   DBCCloseLog();
* @endcode
*
*-----------------------------------------------------------------------------
* Author: leiwei E-mail: ctrlfrmb@gmail.com
* Version: v1.0.0
* Copyright (c) 2025. All rights reserved.
*----------------------------------------------------------------------------*/

#ifndef DBC_API_H
#define DBC_API_H

#include "dbc_api_def.h"

/* ═══════════════════════════════════════════════════════════════════════════
 *                          Log Management
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief Open log system
 * @param logFile   Log file path (directories auto-created)
 * @param level     Log level: 0=DEBUG, 1=INFO, 2=WARN, 3=ERROR
 * @param maxSize   Max single file size (MB)
 * @param maxFiles  Max rotated file count
 * @return DBC_RESULT_OK on success
 */
DBC_API int DBCOpenLog(const char* logFile, int level, int maxSize, int maxFiles);

/**
 * @brief Close log system
 * @return DBC_RESULT_OK on success
 */
DBC_API int DBCCloseLog(void);


/* ═══════════════════════════════════════════════════════════════════════════
 *                       Instance Management
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief Load and parse a DBC file
 *
 * @param filePath     DBC file path (UTF-8 encoded string)
 * @param fileEncoding File text encoding ("UTF-8", "GBK", "ASCII", NULL=auto)
 *
 * @return >0: Instance ID on success
 *         <=0: Error code (DbcResultCode) on failure
 */
DBC_API int DBCLoadFile(const char* filePath, const char* fileEncoding);

/**
 * @brief Unload a DBC instance and free resources
 * @param instanceId Instance ID returned by DBCLoadFile
 * @return DBC_RESULT_OK on success
 */
DBC_API int DBCUnloadFile(int instanceId);

/**
 * @brief Unload all instances and free all resources
 * @return DBC_RESULT_OK on success
 */
DBC_API int DBCClearAll(void);

/**
 * @brief Get the number of currently loaded instances
 * @return Instance count (>= 0)
 */
DBC_API int DBCGetInstanceCount(void);


/* ═══════════════════════════════════════════════════════════════════════════
 *                       DBC Data Query (JSON Output)
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief Get DBC global info as JSON
 *
 * @param instanceId   Instance ID
 * @param jsonBuffer   [out] Buffer to receive null-terminated JSON string
 * @param bufferSize   [in/out] Input: buffer capacity; Output: actual length
 *                     (excluding null terminator)
 *
 * @return DBC_RESULT_OK on success
 *         DBC_RESULT_BUFFER_TOO_SMALL if insufficient (*bufferSize = required)
 *
 * @b JSON:
 * @code{.json}
 * {"version":"","baudrate":500000,"nodes":["ECU1"],"messageCount":15,
 *  "filePath":"vehicle.dbc"}
 * @endcode
 */
DBC_API int DBCGetInfo(int instanceId, char* jsonBuffer, int* bufferSize);

/**
 * @brief Get all messages as JSON
 *
 * @param instanceId   Instance ID
 * @param jsonBuffer   [out] Buffer to receive JSON string
 * @param bufferSize   [in/out] Input: buffer capacity; Output: actual length
 *
 * @return DBC_RESULT_OK on success
 *         DBC_RESULT_BUFFER_TOO_SMALL if insufficient
 *
 * @b JSON (each message includes frame type flags):
 * @code{.json}
 * {"version":"1.0","messageCount":1,"messages":[{
 *   "id":256,"name":"MotorCtrl","dlc":8,"sender":"ECU1",
 *   "isExtended":false,"isCanFd":false,"isCanFdBrs":false,
 *   "isRemoteFrame":false,"cycleTime":100,"sendType":"Cyclic",
 *   "signals":[{"name":"Speed","startBit":0,"size":16,...}]
 * }]}
 * @endcode
 */
DBC_API int DBCGetMessages(int instanceId, char* jsonBuffer, int* bufferSize);

/**
 * @brief Get a specific message by CAN ID as JSON
 *
 * @param instanceId   Instance ID
 * @param canId        CAN message ID
 * @param jsonBuffer   [out] Buffer to receive JSON string
 * @param bufferSize   [in/out] Input: buffer capacity; Output: actual length
 *
 * @return DBC_RESULT_OK on success
 *         DBC_RESULT_MESSAGE_NOT_FOUND if not found
 */
DBC_API int DBCGetMessageById(int instanceId, UINT32_T canId,
                              char* jsonBuffer, int* bufferSize);

/**
 * @brief Get a specific message by name as JSON
 *
 * @param instanceId   Instance ID
 * @param messageName  Message name (UTF-8, case-sensitive)
 * @param jsonBuffer   [out] Buffer to receive JSON string
 * @param bufferSize   [in/out] Input: buffer capacity; Output: actual length
 *
 * @return DBC_RESULT_OK on success
 *         DBC_RESULT_MESSAGE_NOT_FOUND if not found
 */
DBC_API int DBCGetMessageByName(int instanceId, const char* messageName,
                                char* jsonBuffer, int* bufferSize);


/* ═══════════════════════════════════════════════════════════════════════════
 *                       Existence Query
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief Check if a message with the given CAN ID exists
 * @return 1=exists, 0=not exists, <0=error
 */
DBC_API int DBCHasMessageById(int instanceId, UINT32_T canId);

/**
 * @brief Check if a message with the given name exists
 * @return 1=exists, 0=not exists, <0=error
 */
DBC_API int DBCHasMessageByName(int instanceId, const char* messageName);

/**
 * @brief Check if a signal exists within a specific message
 * @param canId      CAN message ID
 * @param signalName Signal name (UTF-8, case-sensitive)
 * @return 1=exists, 0=not exists, <0=error
 */
DBC_API int DBCHasSignal(int instanceId, UINT32_T canId, const char* signalName);

/**
 * @brief Check if a signal exists in any message (full search)
 * @param signalName Signal name (UTF-8, case-sensitive)
 * @return 1=exists, 0=not exists, <0=error
 * @note O(N*M) complexity. Prefer DBCHasSignal() with known CAN ID.
 */
DBC_API int DBCHasSignalByName(int instanceId, const char* signalName);

/**
 * @brief Get message count in the DBC file
 * @return >= 0 on success, <0 on error
 */
DBC_API int DBCGetMessageCount(int instanceId);

/**
 * @brief Get signal count for a specific message
 * @return >= 0 on success, <0 on error (including message not found)
 */
DBC_API int DBCGetSignalCount(int instanceId, UINT32_T canId);


/* ═══════════════════════════════════════════════════════════════════════════
 *                       CAN Data Decode (CAN bytes -> Signal values)
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief Decode CAN data to all signal values as JSON
 *
 * @param instanceId   Instance ID
 * @param canId        CAN message ID
 * @param data         CAN data bytes
 * @param dataLen      CAN data length (0-64)
 * @param jsonBuffer   [out] Buffer to receive decoded JSON
 * @param bufferSize   [in/out] Input: buffer capacity; Output: actual length
 *
 * @return DBC_RESULT_OK on success
 *
 * @b JSON Output:
 * @code{.json}
 * {"id":256,"name":"MotorCtrl","signals":[
 *   {"name":"Speed","rawValue":35000,"physicalValue":3500.0,
 *    "unit":"rpm","displayValue":"3500"},
 *   {"name":"Status","rawValue":1,"physicalValue":1.0,
 *    "unit":"","displayValue":"1 - Running"}
 * ]}
 * @endcode
 */
DBC_API int DBCDecode(int instanceId, UINT32_T canId,
                      const UINT8_T* data, UINT8_T dataLen,
                      char* jsonBuffer, int* bufferSize);

/**
 * @brief Decode a single signal from CAN data
 *
 * @param instanceId   Instance ID
 * @param canId        CAN message ID
 * @param signalName   Signal name (UTF-8)
 * @param data         CAN data bytes
 * @param dataLen      CAN data length
 * @param rawValue     [out] Raw integer value (can be NULL)
 * @param physValue    [out] Physical value (can be NULL)
 *
 * @return DBC_RESULT_OK on success
 */
DBC_API int DBCDecodeSignal(int instanceId, UINT32_T canId,
                            const char* signalName,
                            const UINT8_T* data, UINT8_T dataLen,
                            UINT64_T* rawValue, double* physValue);


/* ═══════════════════════════════════════════════════════════════════════════
 *                       CAN Data Encode (Signal values -> CAN bytes)
 * ═══════════════════════════════════════════════════════════════════════════*/

/**
 * @brief Encode signal values (JSON) to CAN data bytes
 *
 * @param instanceId   Instance ID
 * @param canId        CAN message ID
 * @param signalsJson  JSON string with signal values
 * @param data         [out] CAN data bytes
 * @param dataLen      [in/out] Input: buffer capacity; Output: actual length
 *
 * @return DBC_RESULT_OK on success
 *
 * @b JSON Input (rawValue takes priority over physicalValue):
 * @code{.json}
 * {"signals":[
 *   {"name":"Speed","physicalValue":3500.0},
 *   {"name":"Status","rawValue":1}
 * ]}
 * @endcode
 *
 * @note Signals not listed in JSON are set to rawValue=0.
 */
DBC_API int DBCEncode(int instanceId, UINT32_T canId,
                      const char* signalsJson,
                      UINT8_T* data, int* dataLen);

/**
 * @brief Encode a single signal (physical value) into CAN data in-place
 *
 * Only the bits belonging to the specified signal are modified.
 * All other bits in data[] remain unchanged.
 *
 * @param instanceId   Instance ID
 * @param canId        CAN message ID
 * @param signalName   Signal name (UTF-8)
 * @param physValue    Physical value to encode
 * @param data         [in/out] CAN data bytes
 * @param dataLen      CAN data buffer length
 *
 * @return DBC_RESULT_OK on success
 */
DBC_API int DBCEncodeSignal(int instanceId, UINT32_T canId,
                            const char* signalName, double physValue,
                            UINT8_T* data, UINT8_T dataLen);

/**
 * @brief Encode a single signal (raw integer value) into CAN data in-place
 *
 * @param instanceId   Instance ID
 * @param canId        CAN message ID
 * @param signalName   Signal name (UTF-8)
 * @param rawValue     Raw integer value to encode
 * @param data         [in/out] CAN data bytes
 * @param dataLen      CAN data buffer length
 *
 * @return DBC_RESULT_OK on success
 */
DBC_API int DBCEncodeSignalRaw(int instanceId, UINT32_T canId,
                               const char* signalName, UINT64_T rawValue,
                               UINT8_T* data, UINT8_T dataLen);


#endif // DBC_API_H
