﻿/*----------------------------------------------------------------------------
*               DBC API Definitions
*-----------------------------------------------------------------------------
*
* Common definitions shared across all DBC API modules:
* - DLL export/import macros
* - Result codes (enum with unique offset range)
*
* This header has NO external dependencies and can be safely included
* by any module without risk of circular includes.
*
* Error code range: -15001 ~ -15100 (reserved for DBC API)
* This avoids collision with other DLLs in the same process.
*
* Author: leiwei E-mail: ctrlfrmb@gmail.com
* Version: v1.0.0
* Copyright (c) 2025. All rights reserved.
*----------------------------------------------------------------------------*/

#ifndef DBC_API_DEF_H
#define DBC_API_DEF_H

typedef unsigned char                                       UINT8_T;
typedef unsigned short                                      UINT16_T;
typedef unsigned int                                        UINT32_T;
typedef unsigned __int64                                    UINT64_T;

/* ═══════════════════════════════════════════════════════════════════════════
 *                          DLL Export Macros
 * ═══════════════════════════════════════════════════════════════════════════*/

#ifdef _WIN32
#ifdef BUILD_DBC_API
#define DBC_API extern "C" __declspec(dllexport)
#else
#define DBC_API extern "C" __declspec(dllimport)
#endif
#else
#define DBC_API extern "C"
#endif

/* ═══════════════════════════════════════════════════════════════════════════
 *                          Result Codes
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Range: -15001 ~ -15100 (unique to DBC API)
 *
 *  0             : Success
 *  -15001~-15009 : Parameter / input errors
 *  -15010~-15019 : (reserved)
 *  -15099        : Internal / unexpected error
 *  -15100        : Resource limit
 *
 * ═══════════════════════════════════════════════════════════════════════════*/

enum DbcResultCode {
    DBC_RESULT_OK                   =  0,

    /* --- Parameter / input errors --- */
    DBC_RESULT_INVALID_PARAM        = -15001,
    DBC_RESULT_FILE_NOT_FOUND       = -15002,
    DBC_RESULT_PARSE_FAILED         = -15003,
    DBC_RESULT_INVALID_INSTANCE_ID  = -15004,
    DBC_RESULT_MESSAGE_NOT_FOUND    = -15005,
    DBC_RESULT_SIGNAL_NOT_FOUND     = -15006,
    DBC_RESULT_BUFFER_TOO_SMALL     = -15007,
    DBC_RESULT_JSON_PARSE_ERROR     = -15008,
    DBC_RESULT_ENCODE_FAILED        = -15009,

    /* --- Internal errors --- */
    DBC_RESULT_INTERNAL_ERROR       = -15099,

    /* --- Resource limits --- */
    DBC_RESULT_TOO_MANY_INSTANCES   = -15100
};

#endif // DBC_API_DEF_H
