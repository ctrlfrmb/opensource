#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Author: leiwei
DbcMessage.py - DBC API 消息类型定义和常量

与 dbc_api_def.h v1.0.0 完全对应。
错误码范围: -15001 ~ -15100 (DBC API 独占段，避免多 DLL 冲突)
"""

# =============================================================================
# DBC API 结果状态码 (与 dbc_api_def.h v1.0.0 完全对应)
# =============================================================================

# === 成功状态 ===
DBC_RESULT_OK = 0

# === 参数 / 输入错误 (-15001 ~ -15009) ===
DBC_RESULT_INVALID_PARAM = -15001
DBC_RESULT_FILE_NOT_FOUND = -15002
DBC_RESULT_PARSE_FAILED = -15003
DBC_RESULT_INVALID_INSTANCE_ID = -15004
DBC_RESULT_MESSAGE_NOT_FOUND = -15005
DBC_RESULT_SIGNAL_NOT_FOUND = -15006
DBC_RESULT_BUFFER_TOO_SMALL = -15007
DBC_RESULT_JSON_PARSE_ERROR = -15008
DBC_RESULT_ENCODE_FAILED = -15009

# === 内部错误 ===
DBC_RESULT_INTERNAL_ERROR = -15099

# === 资源限制 ===
DBC_RESULT_TOO_MANY_INSTANCES = -15100

# 状态码描述字典
STATUS_DESCRIPTIONS = {
    DBC_RESULT_OK:                  "操作成功",
    DBC_RESULT_INVALID_PARAM:       "无效参数（空指针、越界值等）",
    DBC_RESULT_FILE_NOT_FOUND:      "DBC 文件未找到",
    DBC_RESULT_PARSE_FAILED:        "DBC 文件解析失败",
    DBC_RESULT_INVALID_INSTANCE_ID: "无效的实例 ID",
    DBC_RESULT_MESSAGE_NOT_FOUND:   "消息未找到（CAN ID 或名称不存在）",
    DBC_RESULT_SIGNAL_NOT_FOUND:    "信号未找到",
    DBC_RESULT_BUFFER_TOO_SMALL:    "缓冲区太小（需要更大的 buffer）",
    DBC_RESULT_JSON_PARSE_ERROR:    "JSON 解析错误（编码输入格式错误）",
    DBC_RESULT_ENCODE_FAILED:       "CAN 数据编码失败",
    DBC_RESULT_INTERNAL_ERROR:      "内部错误（异常、未知状态等）",
    DBC_RESULT_TOO_MANY_INSTANCES:  "实例数量达到上限（最大 100）",
}

# =============================================================================
# 常量
# =============================================================================
DBC_MAX_INSTANCES = 100              # 最大实例数
DBC_DEFAULT_BUFFER_SIZE = 4096       # 默认 JSON 缓冲区大小
DBC_LARGE_BUFFER_SIZE = 1024 * 1024  # 大缓冲区（获取所有消息时）


def get_status_description(status_code):
    """获取状态码的描述文字"""
    return STATUS_DESCRIPTIONS.get(status_code, f"未知错误码: {status_code}")


if __name__ == "__main__":
    print("DbcMessage.py v1.0.0 - DBC API 状态码定义")
    print("-" * 50)
    print(f"错误码范围: -15001 ~ -15100")
    print(f"最大实例数: {DBC_MAX_INSTANCES}")
    print(f"\n状态码列表:")
    for code, desc in sorted(STATUS_DESCRIPTIONS.items(), key=lambda x: -x[0]):
        print(f"  {code:>8d} : {desc}")
