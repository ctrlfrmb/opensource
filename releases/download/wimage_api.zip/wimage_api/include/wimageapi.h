/*----------------------------------------------------------------------------
* WImage 高速图像采集 API 接口
*
* 提供高性能的WImage图像采集设备通信接口，支持设备连接、高速图像采集控制。
* 该API旨在为上层应用提供一个简单、稳定、高效的硬件控制层。
*
* 主要特点：
* - 建立与WImage设备的UDP连接
* - 发送开始/停止高速图像采集命令
* - 内部实现基于内存池的高性能数据接收，避免丢包
* - 自动检测数据包序列号，监控丢包情况
* - 使用实例ID进行多设备并行管理
* - 完善的日志功能，便于调试和问题追溯
* - 健壮的错误处理机制和明确的状态码
* - 跨平台支持（Windows/Linux）
* - 线程安全设计
*
* C/C++ 使用示例:
*   #include "wimageapi.h"
*   #include <stdio.h>
*   #include <string.h>
*   #ifdef _WIN32
*   #include <windows.h>
*   #define sleep_ms(ms) Sleep(ms)
*   #else
*   #include <unistd.h>
*   #define sleep_ms(ms) usleep(ms * 1000)
*   #endif
*
*   int main() {
*       // 1. (可选) 打开日志，便于调试
*       WImageOpenLog("logs/wimage_api_test.log", 1, 5, 10);
*
*       // 2. 连接设备
*       // 参数示例: "--serverIp 192.168.1.10 --serverPort 5010 --savePath ./captured_images"
*       const char* connect_params = "--serverIp 192.168.1.10 --serverPort 5010 --savePath ./captured_images";
*       int instanceId = WImageConnect(connect_params);
*
*       if (instanceId > 0) {
*           printf("设备连接成功，实例ID: %d\n", instanceId);
*
*           // 3. 发送开始采样命令
*           const char* start_cmd = "Run1"; // 假设设备识别 "Run1" 为开始命令
*           if (WImageStartSampling(instanceId, start_cmd) == WIMAGE_RESULT_OK) {
*               printf("开始采样命令已发送。图像数据将保存到: ./captured_images\n");
*
*               // 4. 模拟采集过程，等待一段时间
*               printf("正在采集图像数据 (等待5秒)...\n");
*               sleep_ms(5000); // 采集5秒
*
*               // 5. 发送停止采样命令
*               const char* stop_cmd = "RESET"; // 假设设备识别 "RESET" 为停止命令
*               if (WImageStopSampling(instanceId, stop_cmd) == WIMAGE_RESULT_OK) {
*                   printf("停止采样命令已发送。\n");
*               } else {
*                   printf("停止采样命令发送失败，错误码: %d\n", WImageStopSampling(instanceId, stop_cmd));
*               }
*           } else {
*               printf("开始采样命令发送失败，错误码: %d\n", WImageStartSampling(instanceId, start_cmd));
*           }
*
*           // 6. 断开连接
*           WImageDisconnect(instanceId);
*           printf("设备已断开。\n");
*       } else {
*           printf("设备连接失败，错误码: %d\n", instanceId);
*       }
*
*       // 7. (可选) 关闭日志
*       WImageCloseLog();
*       return 0;
*   }
*
*-----------------------------------------------------------------------------
*               版 权 声 明
*-----------------------------------------------------------------------------
* 版权所有 (c) 2024 leiwei. 保留所有权利。
*
* 本软件按许可协议提供。使用本软件即表示接受许可条款。
*
* 作者: leiwei
* 版本: v1.0.0
* 日期: 2024-05-22
*----------------------------------------------------------------------------*/

#ifndef W_IMAGE_API_H
#define W_IMAGE_API_H

// #include "wimage/wimagemessage.h"

#ifdef _WIN32
    #ifdef BUILD_WIMAGE_API
        #define WIMAGE_API extern "C" __declspec(dllexport)
    #else
        #define WIMAGE_API extern "C" __declspec(dllimport)
    #endif
#else
    #define WIMAGE_API extern "C"
#endif

/**
 * @brief 打开日志，用于调试和故障诊断
 *
 * 建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源
 *
 * @param logFile 日志文件路径，形如:logs/fkvci.log
 * @param level 日志等级，-1:默认输出（默认1）0:DEBUG 1:INFO 2:WARN 3:ERROR
 * @param maxSize 文件大小, 范围(1~100), 单位M. -1:默认10M
 * @param maxFiles 文件个数, 范围(1~20), -1:默认保留10个文件
 * @return 0:打开成功 其它:失败错误码
 */
WIMAGE_API int WImageOpenLog(const char *logFile, int level, int maxSize, int maxFiles);

/**
 * @brief 关闭日志
 *
 * 安全关闭日志记录系统，释放相关资源
 *
 * @return 0:关闭成功 其它:失败错误码
 */
WIMAGE_API int WImageCloseLog();

/**
 * @brief 连接到WImage设备
 * @param commands 参数化连接字符串。格式为 key-value 对，例如:
 *        "--serverIp 192.168.1.100 --serverPort 5010 --savePath ./images --localIp 192.168.1.1 --maxCachedFrames 200"
 *        支持的参数如下:
 *        - `--serverIp <ip_address>`: (必填) WImage设备的IP地址。
 *        - `--serverPort <port>`: (可选, 默认: 5010) WImage设备的UDP端口。
 *        - `--savePath <path>`: (必填) 本地保存图像文件的目录路径。
 *        - `--localIp <ip_address>`: (可选) 绑定本地网卡IP，用于多网卡环境。
 *        - `--localPort <port>`: (可选) 绑定本地UDP端口。
 *        - `--maxCachedFrames <count>`: (可选, 默认: 100) 内部已完成帧队列的最大长度。
 *        - `--memoryPoolSize <size>`: (可选, 默认: 2000) UDP客户端内部内存池大小 (字节)。
 * @return >0:实例ID, <0:错误码 (例如: WIMAGE_RESULT_INVALID_PARAM, WIMAGE_RESULT_CONNECTION_FAILED)
 */
WIMAGE_API int WImageConnect(const char* commands);

/**
 * @brief 断开与WImage设备的连接
 * @param instanceId 实例ID
 * @return 0:成功, 其他:错误码 (例如: WIMAGE_RESULT_INVALID_INSTANCE_ID)
 */
WIMAGE_API int WImageDisconnect(int instanceId);

/**
 * @brief 向指定WImage设备发送开始采样命令
 * @param instanceId 实例ID
 * @param command_str 字符串形式的开始采样命令 (例如: "Run1")。
 * @return 0:成功, 其他:错误码 (例如: WIMAGE_RESULT_INVALID_INSTANCE_ID, WIMAGE_RESULT_SEND_FAILED)
 */
WIMAGE_API int WImageStartSampling(int instanceId, const char* command_str);

/**
 * @brief 向指定WImage设备发送停止采样命令
 * @param instanceId 实例ID
 * @param command_str 字符串形式的停止采样命令 (例如: "RESET")。
 * @return 0:成功, 其他:错误码 (例如: WIMAGE_RESULT_INVALID_INSTANCE_ID, WIMAGE_RESULT_SEND_FAILED)
 */
WIMAGE_API int WImageStopSampling(int instanceId, const char* command_str);

/**
 * @brief 断开所有WImage设备连接并清理所有资源
 * @return 0:成功, 其他:错误码 (例如: WIMAGE_RESULT_INTERNAL_ERROR)
 */
WIMAGE_API int WImageClearAll();

#endif // W_IMAGE_API_H
