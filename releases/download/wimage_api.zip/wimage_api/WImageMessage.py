#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# WImageMessage.py - WImage API消息类型定义和常量 (v1.1.0)

import ctypes

# --- WImage API 结果状态码 (与 wimagemessage.h v1.1.0 完全对应) ---
WIMAGE_RESULT_OK = 0
WIMAGE_RESULT_INVALID_PARAM = -1
WIMAGE_RESULT_INTERNAL_ERROR = -2
WIMAGE_RESULT_CONNECTION_FAILED = -6
WIMAGE_RESULT_TOO_MANY_INSTANCES = -11
WIMAGE_RESULT_INVALID_INSTANCE_ID = -12
WIMAGE_RESULT_SEND_FAILED = -21
WIMAGE_RESULT_NO_DATA = -22 # 虽然WImageApi不直接返回数据，但保留以防将来扩展或内部使用

STATUS_DESCRIPTIONS = {
    WIMAGE_RESULT_OK: "操作成功完成",
    WIMAGE_RESULT_INVALID_PARAM: "无效参数",
    WIMAGE_RESULT_INTERNAL_ERROR: "内部错误",
    WIMAGE_RESULT_CONNECTION_FAILED: "连接失败",
    WIMAGE_RESULT_TOO_MANY_INSTANCES: "实例数量达到上限",
    WIMAGE_RESULT_INVALID_INSTANCE_ID: "无效的实例ID",
    WIMAGE_RESULT_SEND_FAILED: "发送数据失败",
    WIMAGE_RESULT_NO_DATA: "无数据",
}

# WImageApi 不涉及特定的数据包结构（如LxiVoltagePacket），因为它直接写入文件。
# 如果未来有需要从API读取图像帧元数据或状态，可以在此处添加相应的ctypes结构体定义。

def get_status_description(status_code):
    """
    根据给定的状态码，返回对应的中文描述。
    """
    return STATUS_DESCRIPTIONS.get(status_code, f"未知错误码: {status_code}")
