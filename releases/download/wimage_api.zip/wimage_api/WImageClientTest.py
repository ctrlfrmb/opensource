#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# WImageClientTest.py - WImage客户端API测试和命令行界面 (v1.1.0)

from WImageClient import WImageClient
from WImageMessage import WIMAGE_RESULT_OK
import signal
import sys
import time
import platform

client = None

def signal_handler(sig, frame):
    print("\n接收到中断信号，正在清理资源...")
    if client:
        client.cleanup()
    print("程序已终止。")
    sys.exit(0)

def print_help():
    print("\n可用命令:")
    print("  help                                        显示此帮助信息")
    print("  connect <params>                            连接到WImage设备 (例如: connect --serverIp 192.168.1.10 --serverPort 5010 --savePath ./captured_images)")
    print("  disconnect                                  断开与WImage设备的连接")
    print("  start <command_str>                         发送开始采样命令 (例如: start Run1)")
    print("  stop <command_str>                          发送停止采样命令 (例如: stop RESET)")
    print("  runtest <duration_sec>                      运行一个自动化的连接-采集-停止-断开测试")
    print("  clearall                                    断开所有连接并清理所有实例")
    print("  status                                      检查当前连接状态")
    print("  exit                                        退出程序")
    print("\n示例:")
    print("  connect --serverIp 192.168.1.10 --serverPort 5010 --savePath ./captured_images")
    print("  start Run1")
    print("  (等待一段时间，图像数据将写入文件)")
    print("  stop RESET")
    print("  disconnect")


def main():
    global client
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("=" * 60)
    print(f" WImage 客户端命令行测试工具 v1.1.0 ({platform.architecture()[0]})")
    print("=" * 60)
    print("输入 'help' 获取帮助, 输入 'exit' 退出程序。")
    
    try:
        client = WImageClient()
    except Exception as e:
        print(f"初始化 WImage 客户端失败: {e}")
        return

    default_connect_params = "--serverIp 192.168.1.10 --savePath ./captured_images"
    default_start_cmd = "Run1"
    default_stop_cmd = "RESET"

    while True:
        try:
            cmd_line = input("WImage> ").strip()
            if not cmd_line:
                continue

            parts = cmd_line.split()
            command = parts[0].lower()

            if command == "help":
                print_help()
            
            elif command == "exit":
                break

            elif command == "connect":
                params = " ".join(parts[1:]) if len(parts) > 1 else default_connect_params
                client.connect(params)
            
            elif command == "disconnect":
                client.disconnect()
            
            elif command == "start":
                cmd_str = " ".join(parts[1:]) if len(parts) > 1 else default_start_cmd
                client.start_sampling(cmd_str)

            elif command == "stop":
                cmd_str = " ".join(parts[1:]) if len(parts) > 1 else default_stop_cmd
                client.stop_sampling(cmd_str)

            elif command == "runtest":
                if len(parts) != 2:
                    print("用法: runtest <duration_sec>")
                else:
                    try:
                        duration = int(parts[1])
                        print("\n--- 开始自动化测试 ---")
                        if client.connect(default_connect_params):
                            time.sleep(0.1)
                            if client.start_sampling(default_start_cmd):
                                save_path = default_connect_params.split('--savePath ')[1].split(' ')[0]
                                print(f"采集中，将持续 {duration} 秒...")
                                print(f"图像数据将保存到: {save_path}")
                                time.sleep(duration) # 模拟采集时间
                                client.stop_sampling(default_stop_cmd)
                            time.sleep(0.1)
                            client.disconnect()
                        print("--- 自动化测试结束 ---\n")
                    except ValueError:
                        print("错误: 测试时长必须是整数。")
                    except IndexError:
                        print("错误: 无法从默认连接参数中解析'--savePath'。")


            elif command == "clearall":
                client.clear_all()

            elif command == "status":
                if client.is_connected():
                    print(f"状态: 已连接, 实例 ID: {client.instance_id}")
                else:
                    print("状态: 未连接")

            else:
                print(f"未知命令: '{command}'. 输入 'help' 查看可用命令。")

        except Exception as e:
            print(f"发生未预料的错误: {e}")

    if client:
        client.cleanup()
    print("程序已退出。")

if __name__ == "__main__":
    main()
