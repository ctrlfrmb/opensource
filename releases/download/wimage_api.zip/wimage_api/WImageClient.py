#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Author: leiwei
# WImageClient.py - WImage客户端Python封装实现 (v1.1.0)

from WImageMessage import *
import ctypes
import platform
import os
import threading # 尽管WImageApi不直接读取数据，但为了保持LXIClient的结构，保留线程相关导入
import time

class WImageClient:
    def __init__(self, lib_path=None):
        self.wimage_dll = None
        self.instance_id = None
        self._load_dll(lib_path)
        
    def _load_dll(self, lib_path):
        if lib_path is None:
            arch = platform.architecture()[0]
            if arch == "64bit":
                lib_path = os.path.abspath("./lib/Winx64")
            else:
                lib_path = os.path.abspath("./lib/Winx86")
        
        os.environ['PATH'] = lib_path + os.pathsep + os.environ['PATH']
        print(f"加载库路径: {lib_path}")

        try:
            if platform.system() == "Windows":
                dll_name = "wimage_api.dll"
                self.wimage_dll = ctypes.WinDLL(os.path.join(lib_path, dll_name))
            else:
                dll_name = "libwimage_api.so"
                self.wimage_dll = ctypes.CDLL(os.path.join(lib_path, dll_name))
        except OSError as e:
            print(f"加载 {dll_name} 失败: {e}")
            raise

        self._define_api_prototypes()
        
        log_path = b"logs/wimage_client_test.log"
        self.wimage_dll.WImageOpenLog(log_path, 1, 5, 10) # level=1, 5MB, 10 files
        print("WImage API 库加载成功，日志已自动打开 -> logs/wimage_client_test.log")

    def _define_api_prototypes(self):
        # 定义 WImage API 函数原型
        self.wimage_dll.WImageOpenLog.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
        self.wimage_dll.WImageOpenLog.restype = ctypes.c_int

        self.wimage_dll.WImageConnect.argtypes = [ctypes.c_char_p]
        self.wimage_dll.WImageConnect.restype = ctypes.c_int

        self.wimage_dll.WImageDisconnect.argtypes = [ctypes.c_int]
        self.wimage_dll.WImageDisconnect.restype = ctypes.c_int

        self.wimage_dll.WImageStartSampling.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.wimage_dll.WImageStartSampling.restype = ctypes.c_int

        self.wimage_dll.WImageStopSampling.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.wimage_dll.WImageStopSampling.restype = ctypes.c_int
        
        self.wimage_dll.WImageClearAll.argtypes = []
        self.wimage_dll.WImageClearAll.restype = ctypes.c_int
        
        self.wimage_dll.WImageCloseLog.argtypes = []
        self.wimage_dll.WImageCloseLog.restype = ctypes.c_int

    def connect(self, connect_params):
        if self.is_connected():
            print("错误: 客户端已连接。请先断开连接。")
            return False

        print(f"正在使用参数连接: \"{connect_params}\"")
        result = self.wimage_dll.WImageConnect(connect_params.encode('utf-8'))

        if result > 0:
            self.instance_id = result
            print(f"连接成功，实例 ID: {self.instance_id}")
            return True
        else:
            print(f"连接失败: {get_status_description(result)} (错误码: {result})")
            return False

    def disconnect(self):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
        
        print(f"正在断开实例 ID: {self.instance_id}...")
        status = self.wimage_dll.WImageDisconnect(self.instance_id)

        if status == WIMAGE_RESULT_OK:
            print("成功断开连接。")
            self.instance_id = None
            return True
        else:
            print(f"断开连接失败: {get_status_description(status)} (错误码: {status})")
            return False

    def start_sampling(self, command_str):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False
        
        print(f"发送开始采样命令: \"{command_str}\"")
        status = self.wimage_dll.WImageStartSampling(self.instance_id, command_str.encode('utf-8'))

        if status == WIMAGE_RESULT_OK:
            print("启动采样命令发送成功。")
            return True
        else:
            print(f"启动采样命令发送失败: {get_status_description(status)} (错误码: {status})")
            return False

    def stop_sampling(self, command_str):
        if not self.is_connected():
            print("错误: 客户端未连接。")
            return False

        print(f"发送停止采样命令: \"{command_str}\"")
        status = self.wimage_dll.WImageStopSampling(self.instance_id, command_str.encode('utf-8'))
        
        if status == WIMAGE_RESULT_OK:
            print("停止采样命令发送成功。")
            return True
        else:
            print(f"停止采样命令发送失败: {get_status_description(status)} (错误码: {status})")
            return False

    def clear_all(self):
        print("正在清理所有 WImage 客户端实例...")
        status = self.wimage_dll.WImageClearAll()
        if status == WIMAGE_RESULT_OK:
            print("所有实例已清理。")
            self.instance_id = None
            return True
        else:
            print(f"清理所有实例时发生未知错误: {get_status_description(status)}")
            return False

    def is_connected(self):
        return self.instance_id is not None

    def cleanup(self):
        print("开始清理资源...")
        if self.is_connected():
            self.disconnect() # 确保断开连接
        
        if self.wimage_dll:
            self.wimage_dll.WImageCloseLog()
            print("日志已关闭。")
        print("资源清理完成。")
