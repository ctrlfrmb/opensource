// fmt_wrapper.h
#ifndef FMT_WRAPPER_H
#define FMT_WRAPPER_H

#ifdef _MSC_VER
    #pragma warning(push)
    #pragma warning(disable: 4244) 
#endif

#include <fmt/format.h>
// 如果你还用了其他 fmt 头文件，也在这里包含

#ifdef _MSC_VER
    #pragma warning(pop)
#endif

#endif // FMT_WRAPPER_H
